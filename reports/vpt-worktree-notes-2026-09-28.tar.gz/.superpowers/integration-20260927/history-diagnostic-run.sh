#!/bin/bash
set -euo pipefail
umask 077

test "$#" -eq 2
case "$1" in
  *[!a-z0-9-]* | '') exit 2 ;;
esac
diagnostic_lane=/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract
diagnostic_evidence="$diagnostic_lane/.superpowers/integration-20260927/recording-contract-$1"
cd "$diagnostic_lane" || exit 2
test ! -e "$diagnostic_evidence"
test "$(git -c core.fsmonitor=false rev-parse HEAD)" = 07ed8b92111a294df947dafd6c5b97b1c8024d1d
mkdir -p "$diagnostic_evidence/home" "$diagnostic_evidence/config" \
  "$diagnostic_evidence/data" "$diagnostic_evidence/state" "$diagnostic_evidence/cache" \
  "$diagnostic_evidence/tmp" "$diagnostic_evidence/runtime" \
  "$diagnostic_evidence/config-dirs" "$diagnostic_evidence/data-dirs"
git -c core.fsmonitor=false diff > "$diagnostic_evidence/instrumentation.patch"
git -c core.fsmonitor=false ls-files --cached --others --exclude-standard > "$diagnostic_evidence/source.paths"
diagnostic_sources=()
while IFS= read -r diagnostic_file; do
  diagnostic_sources+=("$diagnostic_file")
done < "$diagnostic_evidence/source.paths"
shasum -a 256 "${diagnostic_sources[@]}" > "$diagnostic_evidence/source.sha256"
cp .superpowers/integration-20260927/history-diagnostic-run.sh "$diagnostic_evidence/runner.sh"
diagnostic_cargo=(cargo test --locked --offline -p vpt-adapters --lib "$2" -- --nocapture)
if test "$2" = fmt; then
  diagnostic_cargo=(cargo fmt --all -- --check)
fi
diagnostic_command=(
  /usr/bin/env -u RUST_TEST_THREADS -u CARGO_BUILD_JOBS -u RUSTUP_TOOLCHAIN
  DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
  "HOME=$diagnostic_evidence/home" "XDG_CONFIG_HOME=$diagnostic_evidence/config"
  "XDG_DATA_HOME=$diagnostic_evidence/data" "XDG_STATE_HOME=$diagnostic_evidence/state"
  "XDG_CACHE_HOME=$diagnostic_evidence/cache" "XDG_RUNTIME_DIR=$diagnostic_evidence/runtime"
  "XDG_CONFIG_DIRS=$diagnostic_evidence/config-dirs" "XDG_DATA_DIRS=$diagnostic_evidence/data-dirs"
  "VPT_CONFIG=$diagnostic_evidence/config/vpt.toml" "TMPDIR=$diagnostic_evidence/tmp"
  CARGO_HOME=/Users/stephen/.cargo RUSTUP_HOME=/Users/stephen/.rustup
  RUSTUP_AUTO_INSTALL=0 CARGO_NET_OFFLINE=true CARGO_TERM_COLOR=never
  "CARGO_TARGET_DIR=$diagnostic_lane/target"
  PATH=/Users/stephen/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin
  "${diagnostic_cargo[@]}"
)
printf '%q ' "${diagnostic_command[@]}" > "$diagnostic_evidence/command"
printf '\n' >> "$diagnostic_evidence/command"
date -u +'%Y-%m-%dT%H:%M:%SZ' > "$diagnostic_evidence/started"
TIMEFORMAT='real_seconds=%R user_seconds=%U system_seconds=%S'
if { time "${diagnostic_command[@]}" > "$diagnostic_evidence/stdout" 2> "$diagnostic_evidence/stderr"; } 2> "$diagnostic_evidence/timing"; then
  diagnostic_status=0
else
  diagnostic_status=$?
fi
date -u +'%Y-%m-%dT%H:%M:%SZ' > "$diagnostic_evidence/completed"
printf 'exit_status=%s\n' "$diagnostic_status" > "$diagnostic_evidence/result"
if shasum -a 256 -c "$diagnostic_evidence/source.sha256" > "$diagnostic_evidence/hashes-after" 2>&1; then
  diagnostic_hash_status=0
else
  diagnostic_hash_status=$?
fi
printf 'hash_check_status=%s\n' "$diagnostic_hash_status" >> "$diagnostic_evidence/result"
cat "$diagnostic_evidence/result" "$diagnostic_evidence/timing"
test "$diagnostic_hash_status" -eq 0
exit "$diagnostic_status"
