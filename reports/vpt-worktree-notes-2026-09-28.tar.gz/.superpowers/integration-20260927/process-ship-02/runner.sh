#!/bin/bash
set -euo pipefail
umask 077

test "$#" -eq 1
integration_mode="$1"
integration_lane=/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract
cd "$integration_lane" || exit 2
integration_rustup=/Users/stephen/.rustup
integration_target="$integration_lane/target"
case "$integration_mode" in
  ship) integration_argv=(just ship) ;;
  release) integration_argv=(cargo build --locked --offline --workspace --release) ;;
  nightly)
    integration_rustup="$integration_lane/.superpowers/toolchains/rustup"
    integration_target=/Users/stephen/workspaces/Ivy/webdavis/vpt/.superpowers/worktrees/ledger-contracts/target/task12-nightly-build
    integration_argv=(cargo +nightly test --locked --offline --workspace --no-fail-fast
      --features dev-tools -- -Z unstable-options --report-time)
    ;;
  *) exit 2 ;;
esac
integration_evidence="$integration_lane/.superpowers/integration-20260927/process-$integration_mode"
if [[ "$integration_mode" == ship ]]; then
  integration_evidence="$integration_evidence-02"
fi
test ! -e "$integration_evidence"
test "$(git -c core.fsmonitor=false rev-parse HEAD)" = 0d15400d5ac04e9f492084b54f48c74951239646
git -c core.fsmonitor=false diff --quiet
git -c core.fsmonitor=false diff --cached --quiet
mkdir -p "$integration_evidence/home" "$integration_evidence/config" \
  "$integration_evidence/data" "$integration_evidence/state" \
  "$integration_evidence/cache" "$integration_evidence/tmp"
git -c core.fsmonitor=false ls-files --cached --others --exclude-standard > "$integration_evidence/source.paths"
while IFS= read -r integration_file; do
  shasum -a 256 "$integration_file"
done < "$integration_evidence/source.paths" > "$integration_evidence/source.sha256"
cp .superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/ledger-integration-20260927-run.sh "$integration_evidence/runner.sh"
git -c core.fsmonitor=false rev-parse HEAD > "$integration_evidence/head"
integration_command=(
  /usr/bin/env -u RUST_TEST_THREADS -u CARGO_BUILD_JOBS -u RUSTUP_TOOLCHAIN
  DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
  "HOME=$integration_evidence/home"
  "XDG_CONFIG_HOME=$integration_evidence/config"
  "XDG_DATA_HOME=$integration_evidence/data"
  "XDG_STATE_HOME=$integration_evidence/state"
  "XDG_CACHE_HOME=$integration_evidence/cache"
  "VPT_CONFIG=$integration_evidence/config/vpt.toml"
  "TMPDIR=$integration_evidence/tmp"
  CARGO_HOME=/Users/stephen/.cargo
  "RUSTUP_HOME=$integration_rustup"
  RUSTUP_AUTO_INSTALL=0 CARGO_NET_OFFLINE=true CARGO_TERM_COLOR=never
  "CARGO_TARGET_DIR=$integration_target"
  GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=core.fsmonitor GIT_CONFIG_VALUE_0=false
  PATH=/Users/stephen/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin
  "${integration_argv[@]}"
)
printf '%q ' "${integration_command[@]}" > "$integration_evidence/command"
printf '\n' >> "$integration_evidence/command"
date -u +'%Y-%m-%dT%H:%M:%SZ' > "$integration_evidence/started"
TIMEFORMAT='real_seconds=%R user_seconds=%U system_seconds=%S'
if { time "${integration_command[@]}" > "$integration_evidence/stdout" 2> "$integration_evidence/stderr"; } 2> "$integration_evidence/timing"; then
  integration_status=0
else
  integration_status=$?
fi
date -u +'%Y-%m-%dT%H:%M:%SZ' > "$integration_evidence/completed"
printf 'exit_status=%s\n' "$integration_status" > "$integration_evidence/result"
if shasum -a 256 -c "$integration_evidence/source.sha256" > "$integration_evidence/hashes-after" 2>&1; then
  integration_hash_status=0
else
  integration_hash_status=$?
fi
printf 'hash_check_status=%s\n' "$integration_hash_status" >> "$integration_evidence/result"
git -c core.fsmonitor=false status --short > "$integration_evidence/git-status"
cat "$integration_evidence/result" "$integration_evidence/timing"
test "$integration_hash_status" -eq 0
exit "$integration_status"
