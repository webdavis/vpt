#!/bin/bash
set -euo pipefail
umask 077

test "$#" -eq 0
integration_lane=/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract
cd "$integration_lane" || exit 2
integration_evidence="$integration_lane/.superpowers/integration-20260927/ship"
test ! -e "$integration_evidence"
test "$(git -c core.fsmonitor=false rev-parse HEAD)" = a88bd05a35acdb64c6603c59c793a210e11f773d
git -c core.fsmonitor=false diff --quiet
git -c core.fsmonitor=false diff --cached --quiet
mkdir -p "$integration_evidence/home" "$integration_evidence/config" \
  "$integration_evidence/data" "$integration_evidence/state" \
  "$integration_evidence/cache" "$integration_evidence/tmp"
integration_manifest=.superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/integration-20260927-source.sha256
shasum -a 256 -c "$integration_manifest" > "$integration_evidence/hashes-before"
cp "$integration_manifest" "$integration_evidence/source.sha256"
cp .superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/integration-20260927-run.sh "$integration_evidence/runner.sh"
git -c core.fsmonitor=false rev-parse HEAD > "$integration_evidence/head"
integration_command=(
  /usr/bin/env -u RUST_TEST_THREADS -u CARGO_BUILD_JOBS -u RUSTUP_TOOLCHAIN
  DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
  "HOME=$integration_evidence/home"
  "XDG_CONFIG_HOME=$integration_evidence/config"
  "XDG_DATA_HOME=$integration_evidence/data"
  "XDG_STATE_HOME=$integration_evidence/state"
  "XDG_CACHE_HOME=$integration_evidence/cache"
  "VPT_CONFIG=$integration_evidence/config/vpt.toml"
  "TMPDIR=$integration_evidence/tmp"
  CARGO_HOME=/Users/stephen/.cargo
  RUSTUP_HOME=/Users/stephen/.rustup
  RUSTUP_AUTO_INSTALL=0
  CARGO_NET_OFFLINE=true
  CARGO_TERM_COLOR=never
  "CARGO_TARGET_DIR=$integration_lane/target"
  GIT_CONFIG_COUNT=1
  GIT_CONFIG_KEY_0=core.fsmonitor
  GIT_CONFIG_VALUE_0=false
  PATH=/Users/stephen/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin
  just ship
)
printf '%q ' "${integration_command[@]}" > "$integration_evidence/command"
printf '\n' >> "$integration_evidence/command"
integration_started="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
TIMEFORMAT='real_seconds=%R user_seconds=%U system_seconds=%S'
if { time "${integration_command[@]}" > "$integration_evidence/stdout" 2> "$integration_evidence/stderr"; } 2> "$integration_evidence/timing"; then
  integration_status=0
else
  integration_status=$?
fi
integration_completed="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
printf 'exit_status=%s\nstarted=%s\ncompleted=%s\n' \
  "$integration_status" "$integration_started" "$integration_completed" > "$integration_evidence/result"
if shasum -a 256 -c "$integration_manifest" > "$integration_evidence/hashes-after" 2>&1; then
  integration_hash_status=0
else
  integration_hash_status=$?
fi
printf 'hash_check_status=%s\n' "$integration_hash_status" >> "$integration_evidence/result"
git -c core.fsmonitor=false status --short > "$integration_evidence/git-status"
cat "$integration_evidence/result" "$integration_evidence/timing"
if [ "$integration_hash_status" -ne 0 ]; then
  exit 2
fi
exit "$integration_status"
