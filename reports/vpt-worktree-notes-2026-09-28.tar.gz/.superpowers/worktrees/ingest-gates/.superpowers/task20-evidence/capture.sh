#!/bin/bash
set -euo pipefail

label=$1
shift
root=$(git rev-parse --show-toplevel)
case "$label" in
  *[!a-zA-Z0-9_-]*|'') exit 2 ;;
esac
output="$root/.superpowers/task20-evidence/$label"
mkdir -p "$output/home" "$output/config" "$output/cache" "$output/data" "$output/state" "$output/tmp"
export HOME="$output/home"
export XDG_CONFIG_HOME="$output/config"
export XDG_CACHE_HOME="$output/cache"
export XDG_DATA_HOME="$output/data"
export XDG_STATE_HOME="$output/state"
export TMPDIR="$output/tmp"
export VPT_CONFIG="$output/config/vpt.toml"
export CARGO_HOME=/Users/stephen/.cargo
export RUSTUP_HOME=/Users/stephen/.rustup
export RUSTUP_TOOLCHAIN=stable-aarch64-apple-darwin

git ls-files -m --others --exclude-standard | while IFS= read -r path; do
  shasum -a 256 "$path"
done > "$output/source-before.sha256"
printf '%q ' "$@" > "$output/argv.txt"
printf '\n' >> "$output/argv.txt"
env | grep -E '^(HOME|XDG_|TMPDIR|VPT_CONFIG|CARGO_HOME|RUSTUP_HOME|RUSTUP_TOOLCHAIN)=' | sort > "$output/env.txt"
start=$(date +%s)
set +e
"$@" > "$output/stdout" 2> "$output/stderr"
status=$?
set -e
end=$(date +%s)
printf '%s\n' "$status" > "$output/status.txt"
printf '%s\n' "$((end-start))" > "$output/elapsed-seconds.txt"
git ls-files -m --others --exclude-standard | while IFS= read -r path; do
  shasum -a 256 "$path"
done > "$output/source-after.sha256"
diff -u "$output/source-before.sha256" "$output/source-after.sha256" > "$output/source-diff.txt" || true
exit "$status"
