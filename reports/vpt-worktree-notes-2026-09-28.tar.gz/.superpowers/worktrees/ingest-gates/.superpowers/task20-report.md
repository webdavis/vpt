# Task 20 ingest gates evidence

Source base: `dd0b5b64bcef9ab9e9c89713422aafe9315f7f30`.

## Chronology

- `red-gates-01`: test-only E0502 borrowing error, no behavioral RED credit.
- `red-gates-02`: compiling 21-leaf target, 20 intended missing-behavior failures and one passing byte-copy preservation control. No timeout or fixture setup failure. Source manifests before and after match.
- `red-old-dataless-01`, `red-old-invalid-stage-01`, `red-old-cleanup-helper-01`: compiling intended old-behavior failures for temporary Task 19 expectations.
- `red-old-ordinary-failure-01`: passing preservation control after changing the ordinary failure fixture to owned StageOwned NoSpace, not a new-behavior RED.
- `red-private-dry-01`: one compiling intended stub failure at the private `defer` seam. Every port double panics if used, and the assertion expects the Deferred report.
- `green-private-dry-01`: the same selector passes.
- `green-gates-01`: 20 of 21 pass. The capture-instant fixture used the UTC start of year 10000, but the test clock's six-hour negative offset made its local year 9999, so it ingested normally. This was an invalid fixture witness.
- `green-invalid-capture-02`: fixture-only UTC plus one day yields the intended invalid local year and passes the single selector.
- `green-gates-02`: all 21 new leaves pass, source manifests before and after match.

The identity-invalid deferral branch was implemented before the corrected fixture reached it. Its initial leaf failure was caused by the invalid fixture, not that branch. This is a separate chronology exception pending operator decision; no test-first claim is made for that branch. The other 19 initial failures and private dry seam are genuine preimplementation behavior failures.

## Existing-leaf mapping

| Previous accepted leaf | Task 20 leaf | Reason |
| --- | --- | --- |
| `dataless_candidate_is_not_opened_before_gate_task` | `dataless_candidate_is_deferred_without_opening` | Temporary typed refusal becomes durable deferral. |
| `invalid_staged_container_cleanup_waits_for_failure_history` | `invalid_staged_container_cleanup_waits_for_deferred_history` | Staged invalidity becomes Deferred work before owned cleanup. |
| `cleanup_helper_error_keeps_owned_staging_and_safe_diagnostic` | `deferred_cleanup_helper_error_keeps_owned_staging_and_safe_diagnostic` | Same private staging and helper witness after deferral. |
| `ordinary_failure_saves_one_safe_event_with_original_time` | same name | Owned StageOwned NoSpace continues to witness an ordinary failure event instead of invalid source media, now deferred. |

Task 20 acceptance, independent review, mutation controls and integrated gates remain pending.

## Controller verification through source-final-root-02

The frozen 359-file manifest is `.superpowers/task20-evidence/source-final-root-02.sha256`,
digest `ba0ad2719f99bc4347041ed04982e2798e3c6a33b6b433e343edc71f57c53f3f`.
It includes tracked and unignored source. No task acceptance or integration is claimed.

### Diagnostic filtering and private argument grouping

- `red-escaped-diagnostic-root-01` fails the compiled escaped-name assertion before implementation.
- Three boundary/privacy cases were then added before implementation. In
  `red-diagnostic-boundaries-root-01`, three of five cases fail their intended assertions;
  the raw-content and existing safe-name controls pass.
- The filter now retains up to sixteen recognized helper field-name diagnostics, at most
  400 bytes each, allowing escaped printable ASCII names and rejecting raw controls.
  `green-diagnostic-boundaries-root-01` passes all five cases with unchanged run manifests.
- `formatted-ingest-control-root-01` passes 47 ingestion leaves; the separate private dry
  control passes. The private `Deferral` grouping preserves those exact names and results in
  `post-structure-ingest-root-01` and `post-structure-dry-root-01`.
- `clippy-root-01` records the original argument-count errors. `ship-root-01` records
  three unused-import errors; removing those imports is the only subsequent source change.

### Compiled mutation checks

Each row has a passing initial control, a compiled intended failure with exit 101, and a
passing restored control. The mutated bytes were checked before execution. Each capture's
before/after manifests agree, and the complete frozen source is restored after each row.
The directory pattern is `root-<id>-{control,mutant,restored}-01`.

| Check | Exact leaf |
| --- | --- |
| `d01` | `staged::escaped_additive_helper_field_name_survives_without_private_diagnostic` |
| `d02` | `staged::helper_diagnostic_length_limit_preserves_boundary_and_refuses_one_over` |
| `d03` | `staged::raw_helper_diagnostics_are_replaced_without_private_content` |
| `d04` | `staged::bounded_helper_diagnostics_preserve_all_sixteen_field_names` |
| `d05` | `staged::raw_helper_diagnostics_are_replaced_without_private_content` |
| `g01` | `deferral::above_threshold_does_not_repeat_deferred_event` |
| `g02` | `deferral::deferral_threshold_commits_seen_work_and_one_typed_event_together` |
| `g03` | `deferral::deferral_count_saturates_without_repeating_threshold_event` |
| `g05` | `failure::sink_stop_after_deferred_commit_keeps_stage_and_stops_following_work` |
| `g06` | `source::oversized_descriptor_defers_before_read_or_clone` |
| `g07` | `source::quiet_period_one_second_short_defers_and_exact_boundary_ingests` |
| `g04b` | `deferral::deferred_observation_preserves_first_seen_and_resets_source_gone` |
| `g08` | `staged::changed_source_after_stage_defers_before_owned_cleanup` |
| `g09` | `staged::invalid_staged_container_defers_and_cleans_only_owned_stage` |
| `g10` | `ingest::deferral::tests::private_dry_deferral_adds_report_without_any_port_action` |
| `g11` | `source::dataless_defers_before_open_and_preserves_observed_flags` |
| `g12` | `failure::unconfirmed_deferred_history_keeps_owned_stage_and_stops_cleanup` |
| `g11b` | `source::dataless_defers_before_open_and_preserves_observed_flags` |
| `g06b` | `source::oversized_descriptor_defers_before_read_or_clone` |

The separate `g04` mutation survives: setting an existing row's `first_seen` to `now`
cannot change the stored value. Memory's `upsert_seen` preserves the previous value, and
SQLite's conflict update omits that column. A new row already has `first_seen == now`.
The mutation occurs before the atomic write; no receipt or history fact exposes that
intermediate field. Shared ledger contracts pin preservation in both adapters.
This is not counted among the nineteen killed mutations. `g04b` changes the observable
source-gone field and fails its assertion.

### Full worktree checks

| Capture | Result | Recorded seconds |
| --- | --- | ---: |
| `ship-root-02` | Pass: 1,072 Rust leaves and 20 Swift leaves | 33 |
| `release-root-01` | Pass: locked offline workspace release build | 18 |
| `nightly-root-01` | Functional pass; timing gate fails | 21 |

The Rust name sets match across ship and nightly: 1,046 accepted names after the three
documented mappings, plus 26 additions. The twenty Swift names match accepted batch 16.
The size audit has 29 review thresholds and no handwritten Rust file over 500 lines.
The capture script records elapsed time to whole seconds.

`source::edited_source_waits_for_rest_then_becomes_a_second_recording` takes 1.027 seconds
in the normal-parallel nightly run, exceeding the unchanged one-second gate.
The diagnostic-only `timing-diagnostic-root-01` records cumulative milliseconds:
setup 193, first import 438, source edit 466, recent sweep 650, recent assertions 701,
stable sweep 985, final assertions 1014, and fixture cleanup 1081.
All instrumentation was restored and the frozen source manifest verified.
The next change will reduce repeated setup while retaining real deferral and retry coverage.

## Verified first-import fixture and current execution blocker

The edited-source test now seeds the prior recording, seen row and private archive file.
Its deferral and stable retry still use SQLite and the real archive adapter. The separate
`source::first_take_snapshot_matches_completed_ingest` test compares every recording and
seen field with a real first import, plus archive bytes, permissions and staging cleanup.
It passed before the setup substitution. The first import's history ordering remains covered
by the unchanged Task 19 tests; the seed represents its recording state, not a replayed run.

- `seed-parity-{control,mutant,restored}-root-01`: 0, 101, 0. Changing the expected duration
  from one second to two fails the full recording comparison.
- `seed-fixture-gates-root-01`: all 26 ingestion-gate leaves pass.
- `seed-quiet-{control,mutant,restored}-root-01`: 0, 101, 0. Disabling the quiet period
  makes the revised test fail because the fresh edit is ingested instead of deferred.
- `seed-identity-{control,mutant,restored}-root-01`: 0, 101, 0. Reusing the original
  recording's identity makes the stable edit collide with the retained archive.

The mutation bytes were verified before execution, and control/restored source manifests
match. Production code is unchanged by this fixture refactor. These are fixture-equivalence
and preservation checks, not new product-behavior RED claims.

### Revision 03 verification

`source-final-root-03.sha256` covers 359 files, digest
`2aa557faea59466f2ba2489d9b3e0cc8488e2ad94c1cd73940b972f62738919c`.

`static-root-03` passes formatting, all-target compilation, Clippy with warnings denied,
documentation with warnings denied, and the locked offline workspace release build.
Its recorded elapsed time is 23 whole seconds.

`nightly-root-02` is a failed full-workspace attempt, exit 101 in 228 whole seconds.
It reports 1,062 timed leaves: 1,045 pass and 17 fail existing database-child deadlines.
The expected 1,073-name set differs by precisely the eleven `ingest_failures` leaves
whose executable never reached the test runner. There are no unexpected names.
The revised edited-source leaf takes 0.887 seconds and its parity leaf takes 0.586 seconds.
The separate growing-source leaf takes 1.122 seconds, so the one-second gate remains open.

The seventeen failures are ledger contract child deadlines, fourteen at 500 milliseconds
and three at 700 milliseconds. Their last phases include database opening, operations,
closing and receipt reads. Other builds were observed on the host, but the cause of these
deadline failures has not been established. No deadline or concurrency setting changed.

The subsequent `ingest_failures` process, 90520, stalled before test output.
`nightly-root-02/ingest-failures-sample.txt` records only `_dyld_start` in a 96 KB process.
After checking its executable and parent again, root sent SIGTERM only to that process.
The following ingestion-gate executable also delayed before output, then completed on its
own. Its read-only signature verification passed. The attempted sample after that completion
reported that the process was no longer running. Neither delay is a VPT assertion failure.

### Revision 04 pending fixture

`source-current-root-04.sha256` covers the current 359 files, digest
`d54a973aa025a408360c628154d5954a284336f0bb1bb989c836d1a388f0a589`.
Only the additional partial-source snapshot helper and its parity test differ from revision 03.
The original growing-source setup has not been replaced. Its replacement must wait until
`source::partial_source_snapshot_matches_committed_deferral` actually runs and passes.

`partial-parity-control-root-01` compiles, but its executable stalls before any test output.
The saved `loader-sample.txt` again shows only `_dyld_start`; no test-first or GREEN credit
is claimed. The file is present without an offline flag, and the volume has 658 GiB available.
A read-only signature diagnostic also stalls. Root rechecked the exact command paths and
sent SIGTERM only to test process 97171 and diagnostic process 69996.
The capture ends with exit 101 after 273 whole seconds; the diagnostic exits 143.
The capture's before/after source manifests match.

No test or diagnostic from these runs remains active. Task 20 is unaccepted. Next work is
to re-establish executable startup, finish the partial-source fixture's parity and mutation
checks before substituting it, diagnose the ledger deadlines, and obtain independent review
and passing complete gates. The existing capture-instant chronology exception remains pending.

### Startup revalidation on the following goal turn

The previous turn made progress on the edited-source fixture and retention evidence review.
Root revalidated revision 04 with no source changes before attempting a bounded startup probe.
The installed `/opt/homebrew/bin/gtimeout --help` itself stalled, so no VPT test was launched.
`timeout-help-loader-sample-root-01.txt` samples process 22274 at 96 KB with only `_dyld_start`,
the same pre-main state seen in both VPT executables. The diagnostic had been running for
more than two minutes. This establishes that the observed startup problem also affects an
installed utility; its underlying operating-system cause remains unknown.

Root rechecked the exact command and parent 22273, then sent SIGTERM only to process 22274.
The enclosing shell continued to its read-only capture-script listing, so its eventual
success status does not mean the timeout utility ran successfully. No test, timeout limit,
tool installation, global setting or product source changed. Further executable verification
awaits a working host environment; the current manifest and unfinished fixture are retained.

## Revalidation after restart and fixture revisions 05 and 06

The host restarted on 2026-09-28. Native Rust tests now start and complete. The interrupted
readiness probe has neither a status nor test output and earns no verification credit.
The preceding implementation turn made progress on fixture changes and mutation evidence;
the intervening cleanup confirmation did not advance implementation.

### Growing-source fixture

`partial-parity-control-root-02` rejected an unsupported package feature before running tests.
The corrected `partial-parity-control-root-03` passes the complete seen-row comparison.
`partial-parity-mutant-root-01` changes the fixture's deferral count from one to two and fails
that comparison; `partial-parity-restored-root-01` passes with exact source restoration.
Only then was the growing-source test's first ingest replaced by the verified seen-row seed.
Its grown-file deferral and stable retry still execute the real use case and SQLite adapter.

`partial-fixture-control-root-01` passes all 27 ingestion-gate leaves. The two subsequent
mutations remove remembered deferred size and retain a nonzero count after successful import.
They fail the expected deferred-item and final-count assertions, respectively. Both restored
controls pass with unchanged manifests. These fixture changes add no product behavior.

Revision 05 covers 359 files in `source-final-root-05.sha256`, digest
`3a528aca52f7190b6c951c2f4aaaa65404f9f41e6c4e7d3be294b740804135f8`.
`ship-root-03` exits 101 in 23 whole seconds: recovery-required observation and seen-path
ordering exceed their unchanged 500 ms watchdogs. `tail-gates-root-05` passes in 29 whole
seconds: all-target compilation, release build, docs, secrets scan, size audit and all Swift
checks. It runs ten XCTest and ten Swift Testing leaves. This does not make ship pass.

### Database fixture setup

The seen-path ordering fixture now inserts its four rows through one existing ledger commit.
Its unsorted input and exact ordered-output assertion are unchanged. The recovery fixture
groups its initial schema and committed row in one transaction, preserving its uncommitted
row, spill payload, crash milestone, read refusal, snapshots and writable recovery assertions.

`seed-transactions-diagnostic-root-01` and `-02` both pass. Ordering uses three database-owner
cycles instead of six; the measured parent time changes from 72 to 63 ms. Recovery seed time
changes from 60 to 73 ms, so these trials establish no recovery speed improvement.
The temporary phase forwarding is restored before `seed-transactions-control-root-01`.

Each of `seed-order-sqlite`, `seed-order-memory` and `seed-recovery` has a compiled mutation
failure and passing restored control, suffixes `-mutant-root-01` and `-restored-root-01`.
The first two reverse real adapter ordering and fail the exact path array. The third gives
observational opening writable permission and fails the required recovery refusal. Each
mutated file was checked before execution; every capture's manifests match; every restored
control matches the common control source. No production mutation remains.

### Revision 06 combined evidence

`source-final-root-06.sha256` covers 359 files, digest
`a2df57532e455cb5b78e7a2e356e5f1b664baa7b4bc1862652745a299dccb583`.
`revision-06-audit.json` records every Rust name and result for the following runs.

| Capture | Result | Whole seconds |
| --- | --- | ---: |
| `ship-root-04` | 1,070 Rust leaves pass; four fail | 24 |
| `nightly-root-03` | 1,065 Rust leaves pass; nine fail; one passing leaf exceeds one second | 26 |
| `budget-anchor-diagnostic-root-01` | Both deadline-anchor leaves pass in ten focused trials | 1 |

Stable and nightly both execute exactly 1,074 distinct Rust names: all 1,046 accepted names
after the three documented mappings, plus 28 additions. Relative to revision 02, only the
two fixture-parity names are added. Both full runs preserve identical source manifests.

The stable failures are three existing ledger watchdogs and the history cleanup-anchor
assertion: after reaping, its signal-zero group probe reports EPERM instead of ESRCH.
All twenty focused anchor instances pass, and the nightly anchor passes. The intermittent
permission cause is unproven; the assertion has not been weakened.

Nightly's nine failures are existing ledger watchdogs, eight at 500 ms and one at 700 ms.
The revised growing-source leaf still takes 1.147 seconds. Edited-source is 0.795 seconds,
first-import parity 0.812, partial-source parity 0.582, recovery-required observation 0.352,
and SQLite seen-path ordering 0.478. Focused fixture speed did not establish full-suite speed.
The host reported ten active CPUs and load averages 10.31, 13.17 and 21.15 after the stable
run, with no VPT build still active. This observation does not prove the timeout cause.

The complete gates remain failed. No timeout, parallelism, acceptance count or approved
product behavior changed. Next ingestion work must address the full-suite timing failure
and investigate the inherited watchdog and permission failures before another combined run.
Independent review and the capture-instant chronology exception also remain pending.

## Revision 07: growing-source split

The operator conditionally approved the single capture-instant test-first exception on 2026-09-29. It takes effect only after independent review and combined checks pass. All other test-first requirements remain unchanged. Task 20 is not yet accepted; the current-base review and integration are in progress.

The growing-source test now has two mapped cases connected by a verified complete seen-row fixture. The fixture had compiling RED before implementation and a compiled count mutation before substitution. Size-memory and count-reset mutations also fail, then pass after exact restoration. All 1,075 Rust leaves pass normal-parallel timing (maximum 0.794 s); `just ship`, twenty unchanged Swift leaves and release pass. No production code or deadline changed. `revision-07-audit.json` records the mapping, source digest, measurements and remaining review/exception/integration gates.
