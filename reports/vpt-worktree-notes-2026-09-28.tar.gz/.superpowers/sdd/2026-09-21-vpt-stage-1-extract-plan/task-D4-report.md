# D4 execution report

Base: `3d5b18ed5701b505c68f0ad89fe3e160026ec1be`. D4 commit: `c84df8aba6f1154e77b11f9aa7f107d9b39f0889`. The pre-commit stable full gate and prescribed parallel timing run both pass 318 leaves, retaining the earlier 315 names and adding three supervision checks. The slowest measured leaf is 0.599 s. Independent re-review approves the nested ownership correction and its compiled regressions/mutations in `task-D4-review-2.md`. Earlier timeout and terminal-permission failures remain recorded below. Final acceptance still requires the controller's committed-HEAD gates.

## Constraints and ownership

D4 owns the private database shared-memory implementation, callback and fault plumbing, and focused synthetic tests. The controller owns the progress ledger and Todoist. This worker made no installation, live-data change, notification, push, pull request, merge or apply. The controller's operator-approved local toolchain installation is recorded below.

The dispatch reported no available Neovim tools, no answering instance in the same-pane diagnostic and scoped inventory, and empty earlier VPT buffer inventories. This implementation uses `apply_patch` under that limitation and has not retried probes or retargeted an editor.

The controller approved one `Rc<DatabaseFiles>` shared by pinned `State` and `SharedMemory`. Its private opener takes `&Rc<DatabaseFiles>` so both owners retain one directory authority and the same connection-local fault slot. It adds no thread sharing or reference cycle.

## Implementation and files

`shared_memory.rs` owns the independent companion descriptor, initialization state, held slot modes and mappings. Its private `mapping.rs` child owns each host-page-aligned mapping and releases its original base and length. Initialization follows the pinned three-byte invalidation and byte-128 lifetime protocol. Read-only uninitialized owners retain their descriptors, serve slot locks, and retry initialization on a later map. Slot operations validate flags, ranges and transitions before touching bytes 120 through 127. Mapping validates the requested 32768-byte region, provisions writable pages, and uses policy-specific protections. Explicit unmap and drop release mappings before descriptor closure.

`io/shared_memory.rs` translates the four typed map outcomes, routes slot operations through the existing contained callback boundary, supplies the sequentially consistent fence, and applies the per-file persistent-write-ahead-log setting on cleanup. Protocol read-only outcomes and contention do not poison the connection error latch. `registration/dispatch.rs` permits SQLite's requested read-write write-ahead-log open to return an actual read-only descriptor only where that role and access policy allow it. `Fault::Map` uses the existing connection-local slot. The parent modules, registration, state and lock-query helper contain only the required wiring.

The tests add 27 shared-memory/callback leaves, 12 WAL (write-ahead logging) leaves and six consumed-fault/recovery leaves. They cover pinned snapshots, native interoperability in both directions, writer contention, committed and uncommitted crashes, hot rollback-journal recovery, every requested observational snapshot, map protections, retained authority, initialization and independent-owner cleanup. Child scenarios reuse the existing isolated environment, milestone pipe and watchdog; core dumps are disabled for the protection probe. Strict last-close checks allocate descriptors inside a post-exec child to avoid the documented fork/open-file-description fixture hazard.

The existing `snapshot` interface still returns a sorted `Vec<Snapshot>` with all prior metadata fields and bytes, excluding access time. Acquisition is now descriptor-relative and no-follow; directories, symlinks and regular files keep their distinct treatment. The requested strengthening first broke a single-file caller, recorded in `task-D4-snapshot-control-01.log`. Parent-directory acquisition restored that existing interface; `task-D4-snapshot-control-02.log` passes all 13 file-policy leaves. No baseline test was removed or renamed.

The staged file inventory and complete patch are retained as `task-D4-staged-stat-02.log` and `task-D4-staged-diff-02.patch`. No dependency, public interface, production framework or module-wide lint suppression was added. The seven D3 item-level staging expectations still await genuine D5/D6 consumers.

## Chronology

All log links below are relative to this report. Raw attempts remain present, including failures.

| Attempt | Command or change | Result |
| --- | --- | --- |
| [Initial WAL RED](task-D4-red-wal-01.log) | `cargo test --locked -p vpt-adapters database::tests::wal -- --nocapture` | Compiled; exit 101; 11 failed, one passed. Writable arrangements reported journal mode `delete` instead of `wal`; native reads reported cannot-open. The rollback recovery observation already passed on D3. |
| [Initial durability RED](task-D4-red-failures-01.log) | `cargo test --locked -p vpt-adapters database::tests::failures -- --nocapture` | Compiled; exit 101; three WAL cases failed at unsupported WAL setup. Directory-sync and finalization-truncate atomicity already passed on D3. |
| [Direct initial RED](task-D4-red-shm-01.log) | `cargo test --locked -p vpt-adapters database::tests::shared_memory -- --nocapture` | Compiled; exit 101; 13 failed at the unsupported opener. |
| [Extended direct RED](task-D4-red-shm-02.log) | Same direct command after adding last-owner deletion and supervised write-protection probe | Compiled; exit 101; 15 failed at the unsupported opener. |
| [First-read fault RED](task-D4-red-map-failure-01.log) | `cargo test --locked -p vpt-adapters database::tests::failures::first_wal_read -- --nocapture` | Compiled; exit 101; one failed at unsupported WAL setup. |
| [Premature combined attempt](task-D4-green-attempt-01.log) | `cargo test --locked -p vpt-adapters database -- --nocapture` | Compiled; exit 101; 80 passed, 14 failed. Opening, mapping, slots, cleanup and callbacks had been implemented together. Direct cases passed; SQL exposed a callback flag mistake and missing read-only WAL fallback. |
| [Reset and reachable RED](task-D4-red-reachable-01.log) | Same direct command after removing downstream implementations | Compiled; exit 101; three opening/lifetime checks passed and twelve downstream checks failed. Mapping, slots, cleanup and callbacks were unsupported-only stubs. |

The initial direct failures established an unsupported opener, so they did not establish the intended later mapping, slot or cleanup failures. The controller required a redo without an operator exception. The downstream implementation was removed with `apply_patch`; it was not saved as a reference. Existing tests and logs were retained. New implementation proceeds from reachable operation-specific REDs. This correction does not turn the premature attempt into test-first evidence.

After reset, each implemented operation had its own reachable compiling failure. Negative guards required their intended typed error, so an unsupported stub could not satisfy them. The controller received each RED inventory before implementation, explicitly acknowledged the first groups, and then authorized routine continuation without waiting for each acknowledgement.

Focused runs use `cargo test --locked -p vpt-adapters <selector> -- --nocapture`. The selected leaves and exact operation failures are visible in each raw log; the table names the covering behavior and retained RED/GREEN files. Broad intermediate commands deliberately still include unsupported later operations, so their aggregate result can remain red after the named group becomes green.

| Behavior boundary | Reachable RED | GREEN or next boundary |
| --- | --- | --- |
| Region validation and non-extending missing region | `task-D4-red-reachable-01.log`: typed invalid-region assertion and first missing-region map call; opening/lifetime leaves already pass | `task-D4-map-validation-green-01.log`: both leaves pass, five passing and ten later failures in the broad group |
| Writable multi-region mapping and owned mapping lifetime | `task-D4-red-mapping-01.log`: `multiple_regions_are_shared_at_their_requested_offsets` fails directly at first map after open | `task-D4-mapping-green-01.log`: multi-region leaf passes; six passing and nine later failures |
| Read-only initialized mapping and uninitialized outcome | `task-D4-red-readonly-map-01.log`: successful open reaches map refusal | `task-D4-readonly-map-green-01.log`: the two isolated outcomes pass; extension and slot retry remain red; `task-D4-protection-green-01.log` passes the supervised signal probe |
| Read-only extension guard | `task-D4-red-extension-01.log`: an initialized read-only mapping precedes the second-region typed read-only assertion | `task-D4-extension-green-01.log`: one passed |
| Invalid slot flag/range guard | `task-D4-red-slot-validation-01.log`: typed invalid-input refusal required at lock | `task-D4-slot-validation-green-01.log`: one passed |
| Valid shared/exclusive slot operations | `task-D4-red-slots-01.log`: first valid lock returns unsupported | `task-D4-slots-green-01.log`: native byte-range contention leaf passed |
| Slot mode transitions | `task-D4-red-upgrades-01.log`: valid shared lock precedes the unsupported upgrade/wrong-mode unlock assertion | `task-D4-upgrades-green-01.log`: one passed |
| Retained read-only initialization retry | `task-D4-red-initialization-retry-01.log`: first uninitialized map and slot lock succeed, writer initializes, second reader map still incorrectly reports uninitialized | `task-D4-initialization-retry-green-01.log`: one passed |
| Mapping fault consumption | `task-D4-red-map-injection-01.log`: first mapping and slot lock succeed; injected second mapping incorrectly succeeds | `task-D4-map-injection-green-01.log`: consumed fault and cleanup leaf passed |
| Explicit release without deletion | `task-D4-red-explicit-close-01.log`: successful acquisitions reach unsupported `unmap(false)` | `task-D4-explicit-close-green-01.log`: independent-owner retention leaf passed |
| Last-owner deletion and read-only no-delete | `task-D4-red-deletion-01.log`, `task-D4-red-readonly-unmap-01.log`: successful setup reaches unsupported `unmap(true)` | `task-D4-deletion-green-01.log`, `task-D4-readonly-unmap-green-01.log`, `task-D4-retained-map-green-01.log`: all selected leaves passed |
| Callback output initialization and protocol translations | `task-D4-red-callback-map-01.log`: six callback leaves fail at mapping/null-output boundary | `task-D4-callback-map-green-01.log`: null-output and read-only outcomes pass; four leaves now reach extension, lock, barrier or unmap failures |
| Nonzero extension, callback slots, barrier and persistent cleanup | The four reachable failures in `task-D4-callback-map-green-01.log` were sent before wiring those operations | `task-D4-callbacks-green-01.log`: all six callback leaves passed |
| Read-only write-ahead-log open fallback | `task-D4-red-wal-readonly-open-01.log`: raw callback returns read-only error instead of success with actual read-only flags | `task-D4-wal-readonly-open-green-01.log`: success flags, write refusal and unchanged snapshot passed |

The first integrated control, `cargo test --locked -p vpt-adapters database -- --nocapture`, passed 105 database leaves in `task-D4-database-green-01.log`. The first-read map-fault test subsequently gained full quiescent snapshots and passed in `task-D4-first-read-map-control-01.log`. Formatting attempts are retained in `task-D4-format-01.log`, `task-D4-format-reset-01.log`, `task-D4-format-02.log` and `task-D4-format-03.log`.

The two-opener test is a controller-approved test-only supplement. A barrier starts two independent owners, a channel records success or busy, and at least one must succeed. Owners are released individually, checking lifetime exclusion while successful owners remain and release after both leave. Controls are `task-D4-opening-race-control-01.log` and the strengthened `task-D4-opening-race-control-02.log`. This exercises concurrent opening but does not force the lock-query-to-lock-acquisition interleaving. Deterministic existing-holder leaves establish the no-truncation contract. No production hook or probabilistic retry loop was added.

## Native protocol sources

The locked `libsqlite3-sys` 0.37.0 source is SQLite 3.51.3. Read-only protocol excerpts are in [the source log](task-D4-native-protocol-source-01.log). The local `sqlite3.c` SHA-256 is `9512509b1bccb7461f79bea8aad6280ae4699e925fa4804381b71f59e7efb0c5`.

Relevant source locations: lock flags at lines 1889-1919; lifetime initialization at 44051-44116; region mapping at 44307-44455; slot locking at 44485 onward; barrier and unmap at 44685-44745; retained read-only heap-index protocol at 69565-69602. Lifetime uses byte 128, slot bytes are 120 through 127, and initial writable truncation is three bytes.

The first SQL attempt identified two additional requirements directly in the bundled source. `sqlite3WalOpen` always asks for `READWRITE|CREATE|WAL` and inspects output flags for a read-only result (lines 68474-68479). `xShmMap` accepts any nonzero extension argument (line 44299); `walIndexPageRealloc` forwards `pWal->writeLock` (67540), which is set to 2 during initialization (69471). Both received the focused callback regressions above before their changes. Writable checkpointing and persistent companion retention are separate native decisions in `sqlite3WalClose` at 69258-69332. The existing observational no-checkpoint-on-close setting remains unchanged.

The primary source is `/Users/stephen/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.37.0/sqlite3/sqlite3.c`. The installed macOS SDK's `sys/fcntl.h` supplies the descriptor-owned lock constants; `sysconf(_SC_PAGESIZE)` supplies host mapping alignment. No third-party source or system-call table was modified.

## Compiled mutations and restoration

Each mutation changed only the bytes in its retained `.patch`, compiled the matching test, then restored those bytes with `apply_patch`. Each `<stem>-before.sha256` equals `<stem>-restored.sha256`; `cmp` ran before the restored control. Full baseline, edited and restored SHA-256 values are in [the nine-mutation manifest](task-D4-mutation-hashes-02.log); the original eight-mutation manifest remains retained. The per-mutation three hash files remain alongside each patch and test log. All mutant commands returned 101, and all restored controls returned 0. None failed to compile. Only the deliberate busy-hang mutation counts a timeout as its intended result.

The exact command for each table row was `cargo test --locked -p vpt-adapters <leaf-selector> -- --nocapture`, using the unqualified leaf name shown in its log. Every command selected one leaf.

| Mutation | Changed behavior and observed failure | Evidence stem (`task-D4-mutant-`) |
| --- | --- | --- |
| Slot offset | Lock byte base 120 becomes 121; `shared_and_exclusive_slot_contention_covers_the_native_byte_ranges` sees an unexpectedly successful exclusive acquisition | [patch](task-D4-mutant-slot-offset.patch), [failure](task-D4-mutant-slot-offset-red.log), [control](task-D4-mutant-slot-offset-control.log) |
| Observational protection | Read-only mapping adds `PROT_WRITE`; `observational_mapping_has_no_write_permission` gets permission denied at map before its milestone | [patch](task-D4-mutant-readonly-protection.patch), [failure](task-D4-mutant-readonly-protection-red.log), [decoded child error](task-D4-mutant-readonly-protection-decoded.log), [control](task-D4-mutant-readonly-protection-control.log) |
| Suppressed synchronization error | `synchronization?` becomes discarded result; consumed sync failure incorrectly reports successful commit | [patch](task-D4-mutant-suppressed-sync.patch), [failure](task-D4-mutant-suppressed-sync-red.log), [control](task-D4-mutant-suppressed-sync-control.log) |
| Persistent deletion | Unmap ignores `persistent_wal`; persistent companion existence assertion fails | [patch](task-D4-mutant-persistent-delete.patch), [failure](task-D4-mutant-persistent-delete-red.log), [control](task-D4-mutant-persistent-delete-control.log) |
| Other-owner release | Descriptor-owned set-lock becomes process-owned set-lock; close-retention assertion sees an unexpectedly available slot | [patch](task-D4-mutant-other-owner-lock.patch), [failure](task-D4-mutant-other-owner-lock-red.log), [control](task-D4-mutant-other-owner-lock-control.log) |
| Dropped uninitialized state | Callback clears the retained owner after `READONLY_CANTINIT`; heap-index read fails at the missing slot-lock state | [patch](task-D4-mutant-dropped-uninitialized.patch), [failure](task-D4-mutant-dropped-uninitialized-red.log), [control](task-D4-mutant-dropped-uninitialized-control.log) |
| Observational checkpoint on close | No-checkpoint setting changes from true to false; the normal successful-close leaf catches the unwanted record-lock probe | [patch](task-D4-mutant-readonly-close-checkpoint.patch), [failure](task-D4-mutant-readonly-close-checkpoint-red.log), [control](task-D4-mutant-readonly-close-checkpoint-control.log) |
| Real write-ahead-log busy hang | Busy timeout becomes at least 5000 ms; the owned 500 ms watchdog returns `TimedOut` during the real blocked transaction at 0.51 s; restored control passes at 0.04 s | [patch](task-D4-mutant-wal-busy-hang.patch), [failure](task-D4-mutant-wal-busy-hang-red.log), [control](task-D4-mutant-wal-busy-hang-control.log) |
| Refusal-fixture sensitivity | Hard-link rejection changes from link count not equal to one to zero; the preserved baseline leaf observes an unsafe successful open | [patch](task-D4-mutant-unsafe-hardlink.patch), [failure](task-D4-mutant-unsafe-hardlink-red.log), [control](task-D4-mutant-unsafe-hardlink-control.log) |

## Timing fixture correction

The first installed-nightly run passed the same 315 names as stable, but `database::tests::files::refusal::every_role_refuses_symbolic_links_directories_and_multiple_links` took 1.294 s. The remaining leaves were at most 0.582 s, and D4's maximum was 0.410 s. The complete attempt remains in `task-D4-timing-final-01.log`, with extracted timings in `task-D4-leaf-times-final-01.log`. This was a speed failure despite green assertions. The controller approved a fixture-only correction, not a speed waiver.

The fixture now arranges each of the 12 role/kind combinations once and creates a fresh `DatabaseFiles` with a cloned root per policy. It retains its exact name, all policies and entry kinds, both create modes, every refusal assertion, and a complete snapshot after each policy. It still exercises 96 opens and 48 removals; repeated setup falls from 48 roots to 12. The focused control passed in `task-D4-refusal-fixture-control-01.log`, and the additional hard-link mutant above proves refusal sensitivity after the move. No production behavior changed. Formatting is recorded in `task-D4-format-fixture-01.log`.

The fresh parallel timing run, `task-D4-timing-final-02.log`, passed all 315 names and measured that preserved refusal leaf at 0.318 s. Its names exactly match the first stable inventory. `task-D4-leaf-times-final-02.log` retains every measured leaf. This green timing run does not erase the subsequent stable failure.

`task-D4-ship-final-02.log` failed at the stable workspace test gate with seven D4 `TimedOut` errors from the unchanged 500 ms child watchdog: `failed_wal_write_never_commits_a_partial_pair`, `failed_wal_partial_write_never_commits_a_partial_pair`, `failed_wal_sync_never_reports_a_successful_commit`, `failed_journal_directory_sync_preserves_atomicity`, `failed_journal_finalization_truncate_preserves_atomicity`, `crash_after_commit_preserves_committed_wal_rows`, and `recovery_required_observation_preserves_every_entry`. The adapter target recorded 187 passing and seven failed leaves. None reported a transaction or containment assertion mismatch. The guarded command sequence stopped there, before fresh check/release/staged-secret commands. No retry or deadline increase ran. The exact slow phase is not yet established because the existing timeout error does not include captured child progress. The controller was notified before any further fixture change.

## Bounded diagnostic measurement, 2026-09-26

The resumed worker inspected the six-file unstaged diagnostic diff and its existing compiling RED/GREEN logs before running tests. The watchdog still returns `TimedOut` at its 500 ms deadline. Capture remains bounded to 65536 bytes per stream; timeout previews and the last captured phase escape at most 64 input bytes each. The timeout path adds one nonblocking child-status query and bounded formatting. The existing process-group termination, forced kill and 900 ms cleanup deadline are unchanged. Successful scenario output prints at most 16 phase lines, each limited to 96 input bytes before escaping. No source or index change was needed for this measurement.

Exactly one command ran: `cargo test --locked --offline -p vpt-adapters database -- --show-output`. It exited 0 with 106 passing leaves, no failures and 88 filtered leaves; compilation took 5.02 seconds and the selected suite took 1.11 seconds. No test-thread or build-job override was present. [The raw log](task-D4-timeout-diagnostics-database-20260926-01.log) retains all names and captured phase output. Its 106 passing names exactly match the database-selected names in `task-D4-timing-final-02.log`.

The seven leaves that failed in stable ship attempt 02 all passed here. Times below are milliseconds from each scenario child's first phase marker. For the crash and recovery rows, seed ready means the nested child reached its SQL milestone.

| Leaf | Seed ready | Transaction returned | Reopen or recovery open | Reuse start | Done |
| --- | ---: | ---: | ---: | ---: | ---: |
| `failed_wal_write_never_commits_a_partial_pair` | 171 | 172 | 221 | 252 | 289 |
| `failed_wal_partial_write_never_commits_a_partial_pair` | 154 | 160 | 204 | 228 | 265 |
| `failed_wal_sync_never_reports_a_successful_commit` | 158 | 175 | 220 | 230 | 273 |
| `failed_journal_directory_sync_preserves_atomicity` | 221 | 226 | 227 | 228 | 270 |
| `failed_journal_finalization_truncate_preserves_atomicity` | 128 | 171 | 171 | 198 | 252 |
| `crash_after_commit_preserves_committed_wal_rows` | 188 | n/a | 208 | 243 | 305 |
| `recovery_required_observation_preserves_every_entry` | 174 | n/a | 175 | 183 | 202 |

Setup occupies 128 to 221 ms of the five fault scenarios. The markers do not separate synchronization calls from scheduling or other setup work. They exclude startup before the first marker and cleanup after the last marker, so they do not measure whole-leaf duration. Timeout diagnostics report the last captured phase and pipe state without another drain; those observations may lag the child. The selected suite also excludes 88 adapter leaves and the other workspace targets. This passing run does not identify the cause of the earlier seven timeouts or establish that the full gate is repaired. Setup-transaction batching remains a hypothesis. Keep seed transactions unchanged while the controller adjudicates this evidence and schedules independent review and final gates.

The raw log SHA-256 is `9d978600fd15b772f4cdc691776e1be8b3533dd7be578eb2336ca97a82eae844`. Before and after the run, the unstaged binary diff SHA-256 was `e5c88d588ccf53b588d8775bbc1b3e2fdb6cec1a330a8b33ff9fab0b4e5a176d` and the staged binary diff SHA-256 was `eeed0a5c22929b55d085456ce19461117f57576e3f2c0461ac28d653626b6109`. Editor-tool discovery exposed no Neovim tools; the same-pane diagnostic returned only `auto`, which supplies no buffer inventory. No known open buffer was edited. The only new artifacts are this report section and the raw test log; D4 remains uncommitted and unaccepted.

## Diagnostic mutations and fresh gates, 2026-09-26

The controller kept seed transactions and deadlines unchanged and authorized diagnostic mutation checks. The stall fixture now emits `stall-start` before `stall-wait`, making selection of the latest phase observable. This was the only permanent source change before the ownership correction below. The same watchdog leaf covers each mutation:

`cargo test --locked --offline -p vpt-adapters database::tests::locks::child_watchdog_reaps_a_stalled_lock_test -- --exact --show-output`

| Mutation | Compiled failure | Restored control |
| --- | --- | --- |
| Remove reverse phase search | Exit 101; reports `phase=stall-start`; [log](task-D4-diagnostic-mutant-last-phase-red.log) | Exit 0, 0.56 s; [log](task-D4-diagnostic-mutant-last-phase-control.log) |
| Remove preview truncation | Exit 101; `bounded previews: 2265`; [log](task-D4-diagnostic-mutant-preview-bound-red.log) | Exit 0, 0.55 s; [log](task-D4-diagnostic-mutant-preview-bound-control.log) |
| Remove ASCII (American Standard Code for Information Interchange) escaping | Exit 101; required escaped control-byte text is absent; [log](task-D4-diagnostic-mutant-escaping-red.log) | Exit 0, 0.56 s; [log](task-D4-diagnostic-mutant-escaping-control.log) |

Each `task-D4-diagnostic-mutant-<name>.patch` retains the exact mutation. Its corresponding `before`, `edited` and `restored` SHA-256 files prove changed and restored source bytes; each restoration was compared before its control. All restored child-supervisor hashes equal `ed1ba70970830fbb00116b14017610e6b8f7d1eb2f554809b46fb3256962d5d6`. All three saved patches pass `git apply --check` against the restored source. The prior nine D4 mutation target hashes still match their recorded controls, verified in `task-D4-preserved-mutation-hashes-20260926-01.log`; their evidence is reused.

| Fresh command | Result | Evidence |
| --- | --- | --- |
| `CARGO_NET_OFFLINE=true just ship` | Exit 101; formatting and Clippy pass; 311 leaves pass and four setup terminal leaves fail; all 194 adapter leaves pass in 1.21 s | `task-D4-ship-final-20260926-01.log` |
| `cargo check --locked --offline --workspace --all-targets --features dev-tools` | Exit 0; 0.82 s | `task-D4-check-final-20260926-01.log` |
| `cargo build --locked --offline --release` | Exit 0; 13.80 s | `task-D4-release-final-20260926-01.log` |
| `RUSTDOCFLAGS="-D warnings" cargo doc --locked --offline --workspace --no-deps` | Exit 0; 0.87 s | `task-D4-doc-final-20260926-01.log` |
| `just file-size` | Exit 0; five soft-limit warnings | `task-D4-file-size-final-20260926-01.log` |
| `gitleaks git --redact --no-banner` | Exit 0; 101 commits; no leaks | `task-D4-history-secrets-final-20260926-01.log` |
| `gitleaks git --staged --redact --no-banner` | Exit 0; 63,802 bytes; no leaks | `task-D4-staged-secrets-final-20260926-01.log` |
| `gitleaks dir crates/vpt-adapters/src/database --redact --no-banner` | Exit 0; 184,640 bytes; no leaks | `task-D4-working-database-secrets-final-20260926-01.log` |

`task-D4-results-final-20260926-01.log` records every qualified leaf name and result. Its complete name set exactly matches the earlier 315-name inventory. The complete physical-line census contains all 111 tracked Rust files in `task-D4-file-sizes-final-20260926-01.log`. The diagnostic assertions extend the existing lock-test file to 319 lines, below the 400-line decomposition threshold; the other warnings remain schema 471, configuration tests 304, connection owner 211 implementation/223 total and shared-memory owner 210. Nothing exceeds 500 lines.

The four failing leaves are `setup_force_replaces_existing_config_with_selected_engine`, `setup_json_terminal_success_keeps_the_prompt_off_standard_streams`, `setup_terminal_eof_refuses_without_writing` and `setup_under_owned_terminal_writes_private_config_and_directories`. All fail at `terminal.rs:101` with an empty `prompt not observed` message; the setup target finishes in 0.04 s. The assertion discards the already-collected child status and standard streams. The controller authorized two distinct temporary observations, each followed by exact restoration: first add bounded escaped status/output previews; then also print only the failed terminal-open error number and kind. The second reports `errno=Some(1) kind=PermissionDenied` from the read/write `/dev/tty` open and VPT exit 2. Logs and patches are `task-D4-terminal-probe-20260926-01.log`, `task-D4-terminal-probe.patch`, `task-D4-terminal-errno-probe-20260926-01.log` and `task-D4-terminal-errno-probe.patch`. Neither probe changed assertions, deadlines or environments.

Both temporary files are restored and have empty diffs. Their before/restored hash files match: `terminal.rs` is `2de07d9ed852c2fde56064ddeb533ab864f46564c7ee94f215a18c43286a4e8c`, and `prompt.rs` is `4ec28f77244ef726a2957476bba9c3ceee2052508234dd52e43967e45b7bb9b6`. The controller then ran the unchanged focused leaf with scoped sandbox escalation; it passed in 0.33 s in `task-D4-controller-terminal-escalated-20260926-01.log`. This supports a permission-context explanation and calls for no product repair. The any-panic terminal timeout leaf does not establish valid timeout coverage in the restricted run.

At this checkpoint, only stable was listed by `rustup toolchain list`; the known nightly directory was absent. No missing `+nightly` command or installation was attempted by the worker. The operator later approved the controller's VPT-local installation, recorded below.

At this checkpoint the unstaged binary diff SHA-256 was `9c4356afddf76570f72c6abaea7411b3d7af3a618dc2c64b45c1a5377b72437f`; the staged diff remained `eeed0a5c22929b55d085456ce19461117f57576e3f2c0461ac28d653626b6109`. The controller accepted the independent review's nested-supervision finding: outer and inner fixtures each called `setsid`, so an outer timeout could kill the inner guard's owner without reaching its separate process group. No surviving child was observed. The controller then approved the bounded regression and ownership correction below.

## Direct peer ownership correction, 2026-09-26

The initial ownership regression sets the expected root process identifier explicitly and carries it unchanged through the cleared child environment. Each executed participant checks its actual parent before opening the database fixture. With nested ownership still present, the focused native-reader case compiled and failed at the wrong-parent assertion: expected 70330, actual 70333. The subsequent write-ahead-log group run had five passes and seven intended wrong-parent failures. These are safe operation-boundary regressions, not reproductions of a surviving child. The source-chain finding remains the independent evidence for the original escape path. Logs are `task-D4-root-ownership-red-20260926-01.log`, its `-decoded-20260926-01.log` companion, and `task-D4-root-ownership-red-20260926-02.log`.

The root test now owns every peer guard directly. Native-writer cases hold the native participant while a separately supervised rooted reader or contender runs. The native-reader case keeps its rooted writer alive across two distinct handshakes, before and after the commit. Rooted-writer contention uses separate writer and native-contender guards. Crash cases terminate and reap the root-owned participant at its SQL (Structured Query Language) milestone before starting the separate recovery or observation participant. No database or lock descriptors are acquired in the root coordinator. The seven existing leaf names, native snapshot assertions, busy outcomes, crash rows, integrity checks and observation snapshots remain intact.

One absolute start instant is passed to every peer. Setup and spawning consume the original 500 ms operation budget and 900 ms cleanup budget; later peers cannot reset either. The shared-budget regression completes a first participant by handshake, then arms a later pre-database stall with only 100 ms of the original budget remaining. The compiling RED measured 506.516 ms when spawning reset the origin. The pre-SQL stall regression establishes the root's exact process identifier and guard before sending the command that induces the stall. After guard cleanup, `waitpid` must report `ECHILD`, and a zero-signal group probe must report `ESRCH`. An exact-owned kill/reap backstop runs before failure assertions if the direct child remains alive. A zombie is safely reaped by the observation and causes the assertion to fail. No descendant is intentionally orphaned and no process-group implementation change was needed.

The two-handshake fixture exposed an existing readiness bug: the second wait reused the first captured marker. Its compiled RED fails before sending the first continuation. Readiness now advances a cursor only over complete captured lines, without removing bytes or weakening the 65536-byte capture bound. A second wait therefore needs a new marker. Logs are `task-D4-scenario-budget-red-20260926-01.log` and `task-D4-milestone-red-20260926-01.log`. The first integrated GREEN, `cargo test --locked --offline -p vpt-adapters database -- --show-output`, passed all 109 selected leaves in 1.35 s, with 88 filtered and compilation taking 2.53 s: `task-D4-root-peer-green-20260926-01.log`.

| Post-correction mutation | Compiled failure | Exact-restored control |
| --- | --- | --- |
| Reset the scenario origin for each spawn | Budget assertion reports 506.517 ms; exit 101, 0.52 s | Exit 0, 0.10 s |
| Raise the real write-ahead-log busy timeout to at least 5000 ms | Root-owned blocked participant hits `TimedOut`; exit 101, 0.52 s | Exit 0, 0.05 s |
| Reset the readiness cursor before each wait | Existing first marker incorrectly satisfies the second milestone; exit 101, 0.01 s | Exit 0, 0.50 s |

Artifacts use `task-D4-root-peer-mutant-{budget,busy,milestone}` followed by `.patch`, `-red.log`, `-control.log`, `-before.sha256`, `-edited.sha256` and `-restored.sha256`. Every before/restored hash pair compares equal, and each saved patch passes `git apply --check` after restoration. The commands use `cargo test --locked --offline -p vpt-adapters <fully-qualified-leaf> -- --exact --show-output`. The selectors are the budget and milestone supervision names shown in their logs and `database::tests::wal::native_writer_blocks_a_rooted_wal_transaction_with_a_bounded_wait` for the busy mutation.

The busy mutant is rerun because its relevant supervision topology changed. The other eight earlier D4 mutations remain applicable: slot offsets, mapping protection, suppressed sync, persistent deletion, other-owner release, retained uninitialized state, observational close and hard-link refusal have unchanged production targets and unchanged behavioral assertions. Their prior exact-restoration evidence remains in the report. The three bounded diagnostic mutations retain unchanged timeout formatting and watchdog assertions. The readiness mutation separately covers the new cursor. No blanket reuse claim is made for the changed busy topology.

The new private files are `tests/children/supervision.rs` and `tests/wal/peers.rs`. Both remain untracked until controller-authorized staging, so they are explicitly included in `task-D4-root-peer-source.sha256` and the final size census. At the source-stable review checkpoint, tracked unstaged diff SHA-256 is `cd39368aa07a355d0841a71af4d196d1c6f7a822aa70f3e910a86b044e10c683`; staged diff SHA-256 remains `eeed0a5c22929b55d085456ce19461117f57576e3f2c0461ac28d653626b6109`. The full database source manifest includes unchanged production files and both untracked files. Formatting of the coordinator's per-scenario phase clock was corrected after an initial format check, whose output is retained in `task-D4-root-peer-format-check-20260926-01.log`; the successful formatting command is `task-D4-root-peer-format-20260926-01.log`.

The operator approved an isolated minimal nightly installation owned by the controller under ignored `.superpowers/toolchains/rustup`. Its reported version is `1.100.0-nightly (5ceaf6608 2026-09-25)`, recorded in `nightly-local-install-20260926-01.log`. Final timing uses only command-local `RUSTUP_HOME` and `RUSTUP_AUTO_INSTALL=0`. Stable gates keep their ordinary environment. No tests or builds ran during the installation window.

## Final uncommitted gates after peer correction

The full stable and timing commands used scoped sandbox escalation for the owned terminal fixtures after the recorded `EPERM` diagnosis. Fixtures still isolate home, configuration, state and executable search paths. No thread-count or build-job override, deadline extension, seed-transaction change or retry loop was used.

| Command | Result | Evidence |
| --- | --- | --- |
| `CARGO_NET_OFFLINE=true just ship` | Exit 0; all 318 leaves pass, including 197 adapter leaves in 1.66 s and 15 setup leaves in 0.54 s; format, Clippy, documentation, history secrets and tracked-file size checks pass | `task-D4-root-peer-ship-20260926-01.log` |
| Prescribed parallel nightly timing command below | Exit 0; all 318 names match stable, 197 adapter leaves in 1.44 s; maximum leaf 0.599 s | `task-D4-root-peer-timing-20260926-01.log` |
| `cargo check --locked --offline --workspace --all-targets --features dev-tools` | Exit 0, 0.97 s | `task-D4-root-peer-check-20260926-01.log` |
| `cargo build --locked --offline --release` | Exit 0, 1.38 s | `task-D4-root-peer-release-20260926-01.log` |
| `gitleaks git --staged --redact --no-banner` | Exit 0; 63,802 bytes scanned; no leaks | `task-D4-root-peer-staged-secrets-20260926-01.log` |
| `gitleaks dir crates/vpt-adapters/src/database --redact --no-banner` | Exit 0; 191,406 bytes scanned, including the two untracked files; no leaks | `task-D4-root-peer-working-secrets-20260926-01.log` |

The timing command was:

```sh
env RUSTUP_HOME=/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract/.superpowers/toolchains/rustup RUSTUP_AUTO_INSTALL=0 cargo +nightly test --locked --offline --workspace --no-fail-fast --features dev-tools -- -Z unstable-options --report-time
```

The nightly emitted a `fetch_update` deprecation warning and unused-dependency warnings for `sha2` and `vpt-protocol`. These are recorded, not suppressed. The stable all-target Clippy gate passes with warnings denied. No dependency or production API change was made for the timing toolchain.

The new budget, direct-stall and second-milestone leaves measure 0.123 s, 0.514 s and 0.511 s respectively. The seven flattened leaves range from 0.208 s to 0.447 s. The preserved file-refusal leaf measures 0.318 s. Every measured leaf appears in `task-D4-root-peer-leaf-times-20260926-01.log`; both complete 318-name inventories are retained. The first comparison against the older inventory mixed sort orders and is retained as invalid comparison evidence. Sorting both inputs with `LC_ALL=C` produces an empty `task-D4-root-peer-missing-names-20260926-02.log` and exactly the three new supervision names in `task-D4-root-peer-added-names-20260926-02.log`.

The standard physical-line counting algorithm covers all 113 Rust files, including the two untracked files, in `task-D4-root-peer-file-sizes-20260926-01.log`. The new supervision file is 120 lines; the root peer coordinator is 59. Nothing exceeds 500 lines. Existing soft warnings remain schema 471, configuration tests 304, connection owner 211 implementation/223 total, shared-memory owner 210, and lock tests 319. An auxiliary assertion initially compared the text field `total` instead of its numeric count; that command error and the unchanged census are preserved. The corrected numeric-field assertion passes in `task-D4-root-peer-size-audit-20260926-02.log`. No source or test rerun was needed for either evidence-processing correction.

All 40 database source-file hashes still match the source-stable review manifest after these gates. Staged and tracked-unstaged diff hashes remain unchanged, and the terminal probes and busy-timeout mutation are exactly restored. Verification is in `task-D4-root-peer-source-verified-20260926-01.log` and the final diff hash files. `task-D4-root-peer-evidence.sha256` records:

- Source manifest: `04a3d9d28a714c70c644037ffa013a134d4e790a1a26dff111dd6946cfc6ce77`.
- Stable ship log: `51328cb28d38d657368076e5f783591db431dfffe8910f5381b367cc251cb81d`.
- Timing log: `b33d37ac66b9fccd1a3af859b1ad1626176d6cd80ef5c049cd23fb729116bed2`.

## Earlier gates, baseline comparison and size

| Command | Result before the fixture-only correction | Evidence |
| --- | --- | --- |
| `cargo clippy --locked -p vpt-adapters --all-targets -- -D warnings` | exit 0 | `task-D4-focused-clippy-01.log` |
| `just ship` | exit 0; 315 leaves; 20.43 s | `task-D4-ship-final-01.log` |
| `cargo check --locked --workspace --all-targets --features dev-tools` | exit 0; 7.34 s | `task-D4-check-final-01.log` |
| `cargo build --locked --release` | exit 0; 2.01 s | `task-D4-release-final-01.log` |
| `cargo +nightly test --locked --workspace --no-fail-fast --features dev-tools -- -Z unstable-options --report-time` | exit 0; speed failure described above | `task-D4-timing-final-01.log` |
| `gitleaks git --staged --redact --no-banner` | exit 0; 62,754 bytes; no leaks | `task-D4-staged-secrets-final-01.log` |

`just ship` runs the repository's complete formatting, workspace Clippy, workspace tests, documentation, history secrets and file-size gates. These include the commands behind `just lint-check` and `just test-rust`. The additional all-target and default-feature release checks exercise the final build configurations. Only installed toolchains were used. A read-only stable `--list --report-time` probe was refused because the flag is nightly-only; no tests ran in that probe. The controller selected installed nightly for measurement, without `RUSTC_BOOTSTRAP` or toolchain changes.

The first name extraction omitted binary prefixes and is retained as invalid comparison evidence in the `*-names-final-01.log`/`*-missing-final-01.log`/`*-leaves-final-01.log` files. Correct extraction prefixes each leaf with the actual running binary. `task-D4-passing-names-final-02.log` contains 315 names, `task-D4-baseline-missing-final-02.log` is empty, and `task-D4-added-leaves-final-02.log` contains exactly 45 D4 names. The first nightly name set exactly matches that stable set.

The staged physical-line census is `task-D4-file-sizes-final-01.log`, produced by the clean-code-rust `git ls-files`/`awk` command after staging all new files. No handwritten Rust file exceeds 500 lines. New production files are 210 lines for `shared_memory.rs`, 80 for its mapping child, and 86 for callback translation. The 210-line owner stays below the 250-line decomposition threshold; its acquisition and cleanup state remains together. New test files are at most 235 lines. Inherited warnings remain the 471-line schema, 304-line configuration tests and D3's 211-implementation/223-total owner. No unrelated size refactor was made.

## Self-review and handoff

I read the tracked diff and every new source/test file, checked the staged inventory, and reviewed lock-byte arithmetic, read-only flag translation, callback error handling, mapping alignment/protection, fault ownership and close ordering against the bundled source. The private child modules keep mapping ownership separate from callback translation. `Rc<DatabaseFiles>` has no path back to State or FileState. Mappings release before the companion descriptor; explicit cleanup preserves another owner's locks and retained directory authority. Persistent write-ahead-log cleanup leaves companion entries while SQLite retains checkpoint decisions.

The concurrency fixture's scheduling limitation and the corrected test-first chronology remain review concerns. The code contains the checked acquisition/recheck path, but the fixture does not force every race interleaving. No required compiled mutant survived. The existing command-deadline follow-up `6hc7MMRc2QhRm75g` remains separate and is not resolved by these green commands. The timing failure above concerns a different baseline file-policy fixture.

## Commit and final worker handoff

The controller authorized only the 27 reviewed database paths. Staging added the two new test files and preserved the reviewed source bytes. `task-D4-reviewed-staged-stat-20260926-01.log` records 27 files, 2113 insertions and 86 deletions. The complete tracked size census now includes all 113 Rust files, and `just file-size` passes with the same five soft warnings. The reviewed staged diff SHA-256 is `1d3429520bcdf6f3223bc6cabc8d4228cb8df88c94fe09876c6af3e09b96491d`.

The first post-staging secrets scan returned zero but logged a filesystem-monitor interprocess-communication error and scanned only 63,328 bytes. It is retained as non-final evidence in `task-D4-reviewed-staged-secrets-20260926-01.log`. The final invocation disabled that optimization only for its process and inherited Git subprocesses:

```sh
env GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=core.fsmonitor GIT_CONFIG_VALUE_0=false gitleaks git --staged --redact --no-banner
```

That scan exited zero, scanned 74,124 bytes and reported no leaks or errors in `task-D4-reviewed-staged-secrets-20260926-02.log`. No persistent Git setting changed. Metadata queries likewise used `git -c core.fsmonitor=false`; their staged diff hashes compare equal and all source hashes match review.

After reading the complete conventional-commits skill, the worker created one controller-authorized normal-hook commit, `c84df8aba6f1154e77b11f9aa7f107d9b39f0889`, with subject `feat(database): contain concurrent database access`. Its parent is the accepted base above. `SKIP_AI_COMMIT=1` bypassed message prepopulation only; no hook, verification or signing bypass flag was used. The normal global dispatch hooks remain enabled. No executable repository-local commit hooks exist. The commit contains no attribution trailer. Its command and output are retained in `task-D4-commit-20260926-01.log`.

The committed diff hash equals the reviewed staged diff hash. The final tracked worktree and index are clean, and status reports no untracked files. All 40 database source hashes still match the review manifest. `task-D4-committed-{inventory,head,status,source}-20260926-01.log` and `task-D4-committed-diff-20260926-01.sha256` record those checks. The committed-history scan used the same command-local configuration with `gitleaks git --redact --no-banner`; it exited zero, scanned 102 commits and 2,049,615 bytes, and reported no leaks in `task-D4-committed-history-secrets-20260926-01.log`.

## Outstanding verification

Independent re-review is approved with no new blocking finding. The original seven database timeout causes remain unproven, and the concurrent-opener fixture does not force every lock-query-to-acquisition interleaving. The reviewer accepts the ownership, budget, milestone and busy-hang evidence without an extra cleanup mutant because cleanup implementation bytes did not change. The controller owns the fresh committed-HEAD ship gate and acceptance. The worker has stopped tests, builds and source edits. No D5 work, push or pull request has begun.
