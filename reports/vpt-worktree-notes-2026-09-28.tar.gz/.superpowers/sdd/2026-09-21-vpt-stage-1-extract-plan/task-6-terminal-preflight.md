# Task 6 terminal harness preflight

Read-only source review by /root/vpt_setup_terminal_preflight. No files changed, probes run or terminal acquired. These are source contracts, not runtime evidence.

## Recommended minimal flow

1. The shared support::run spawn boundary replaces process_group(0) with one pre_exec callback calling setsid. Keep session creation out of Sandbox::vpt and the helper. setsid creates both session and group with the child PID, preserving killpg(child.id()) ownership; an existing group leader cannot call it successfully. Installed Rust source applies setpgid before pre_exec callbacks.
2. Parent opens /dev/ptmx read/write through std::fs::OpenOptions with O_NOCTTY. Rust file opens include O_CLOEXEC atomically. Call grantpt and unlockpt, obtain the slave path through TIOCPTYGNAME into the SDK's 128-byte buffer, then open that path with OpenOptions and O_NOCTTY. openpty has no documented close-on-exec option; applying fcntl later leaves an inheritance window during concurrent spawns.
3. Pass the slave as stdin through Stdio::from(File) to a terminal-exec fixture branch of the existing dev-tools-only vpt-fake-engine binary. After spawn, drop every parent slave copy, including the one retained by Command. Parent keeps the master.
4. After exec, the fixture helper calls ioctl(0, TIOCSCTTY as libc::c_ulong), then CommandExt::exec on the absolute VPT executable with inherited standard streams and sandbox environment. Exec preserves PID, group and controlling terminal. TIOCSCTTY is c_uint while ioctl takes c_ulong in pinned libc. Keep stdout and stderr independently captured or replaced by broken_output(); login_tty overwrites all three streams.
5. Drive the terminal and collect outputs under the same absolute deadline as child supervision. Use nonblocking descriptors and finite select waits, checking FD_SETSIZE before setting a descriptor. The SDK poll manual disclaims device support. The existing reader joins and final wait are blocking; an elapsed assertion after them cannot enforce a deadline.

The helper keeps ioctl out of pre_exec: Apple documents setsid as async-signal-safe, but no such guarantee was found for ioctl. The fork manual permits execing oneself before other APIs. This is a test utility, not a product adapter or a new package. Adapt the command crate's feature/dependency wiring only as needed for its existing dev-tools binary; preserve that branch when Task 24 expands the fake engine.

## Runtime obligations for Task 6

- Start from compiling bounded counterexamples, not an assumed successful platform call.
- Verify the actual VPT setup path through the fixture helper and the absence of a controlling terminal on ordinary run.
- Observe the prompt on the master before answering, without synchronization sleeps. Keep the final standard-output/error contracts and retained-peer regressions.
- Send configured canonical VEOF on an empty input line; expect refusal and no configuration write.
- Withhold an answer after readiness. The 500 ms deadline must fail, terminate the owned group, reap its direct child, and finish below one second.
- Reproduce retained output after child exit with a test-owned peer or descriptor, under a deadline independent of the collection code being mutated. Do not orphan a process to manufacture the hang. Cover same-group descendant cleanup separately, with its fixture parent retaining ownership and reaping its children.
- Mutation-verify session establishment, deadline enforcement and cleanup, then restore byte-identical controls.

killpg covers one group, not descendants that deliberately create another group or session. The runner cannot waitpid arbitrary grandchildren. Do not create detached escape fixtures or claim containment of such descendants.

## Source anchors

- crates/vpt/tests/support/mod.rs:68, spawn boundary; :85, output joins/final wait. Line numbers describe Task 4 HEAD 2858751.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man2/setsid.2:48, session/group semantics.
- /Users/stephen/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/src/rust/library/std/src/sys/process/unix/unix.rs:346, installed source spawn ordering.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man3/openpty.3:48, terminal allocation interface.
- /Users/stephen/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/src/rust/library/std/src/sys/fs/unix.rs:1234, close-on-exec file opens.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/sys/ttycom.h:164, terminal requests and slave-name buffer.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man4/termios.4:128, controlling terminal and foreground group.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man2/execve.2:150, preserved process attributes.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man2/fork.2:125, child safety boundary.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man2/poll.2:209, device limitation.
- https://doc.rust-lang.org/std/os/unix/process/trait.CommandExt.html#tymethod.exec, exec contract.

Compilation, EOF behavior, descriptor closure, cleanup and timings remain unverified until the Task 6 tests run. Installed nightly source is a reference; the stable toolchain used by VPT must pass the runtime checks.
