# D2 execution brief

## Controller constraints

- Actual incremental lint ruling: controller inspected task-D2-incremental-clippy-01.log and permits cfg_attr(not(test), expect(dead_code, reason = ...)) only on PENDING_BYTE, RESERVED_BYTE, SHARED_FIRST, SHARED_SIZE, LockKind, set_record_lock, has_conflict, record_lock, DatabaseLocks, its concrete impl and invalid. These 11 items await D3 callbacks/controls; inventory them under follow-up 6hc7x7wMwxF8R9rg and remove them in D3 as consumed. Later D4/D6 reuse is not a reason to retain a redundant expectation. No blanket allowance, hidden production compilation, visibility expansion or fabricated caller.
- D1 current-code preflight: database/mod.rs owns private FileRole and crate-private AccessPolicy/DatabaseError; database/files.rs owns pub(super) DatabaseFiles and its new/open/remove/revalidate methods. Checked create_read_write_file/unlink_file live in contained/file.rs. database/tests/support.rs already supplies canonical private root(), ROLES and complete owned-tree snapshots; database/tests/mod.rs registers files/support. Reuse these actual APIs and fixtures. Do not expand visibility or change setup's shared open_file hard-link behavior.
- D1 has nine narrow staging expectations inventoried in task-D1-report.md, tracked by 6hc7x7wMwxF8R9rg. Remove only an expectation genuinely consumed now; do not fabricate callers or broaden an allowance. D2's new lock owners may expose another legitimate incremental staging diagnostic: show the exact warning and planned consumer before adding an expectation.
- Read the actual command-test ownership code in crates/vpt/tests/support before adapting its bounded process-group/reader pattern inside this crate. The existing deadline follow-up does not authorize a longer deadline, duplicate fixture frameworks, unbounded cleanup, or a claim that scheduling contention is the cause. Preserve timing evidence and surface a recurrence.
- Dispatch only after D1 is independently accepted. Use its actual owned-file APIs and file layout. This is high-risk locking and process ownership: Astra implementation and independent Astra review.
- Own only the database locks, focused database test helpers and their registrations, plus D2 report/evidence. Main owns progress.md and Todoist. You are not alone; preserve all other work. One product writer, no subagents or new worktree.
- Verify native constants and the bundled SQLite implementation from local primary sources before using them. Keep separate file descriptions and bounded nonblocking operations. Do not use private API exposure to silence incremental dead-code errors; report the exact staging issue for a scoped controller ruling.
- Preserve all prior leaves. Use compiling behavioral RED, exact compiled mutations, byte-identical restored controls and unique raw evidence for each attempt. Run the required Rust, release, staged-size and secrets gates; the controller owns the fresh committed-HEAD ship.
- Existing command tests have intermittently exceeded their 500 ms deadline (Todoist 6hc7MMRc2QhRm75g). Reuse the actual ownership pattern, not an outdated sample. Preserve any recurrence without retry loops, increasing deadlines or broad process diagnostics. Do not begin D3-D7.
- No live source/destination/database access, source scans, install, push, pull request, merge, apply, destructive cleanup, third-party edits, system-call override probes or recreation of denied diagnostics. All fixtures must be owned and synthetic. Verify buffer safety and use apply_patch.

## Approved D2 task

## D2: Descriptor-owned locks and bounded process fixtures

**Files:** Create `database/locks.rs`, `database/tests/locks.rs` and `database/tests/children.rs`; modify
`database/mod.rs`, `database/tests/mod.rs` and `database/tests/support.rs`.

**Interfaces:** Consume D1's owned regular files. Produce crate-private
`LockKind::{Shared, Exclusive, Unlock}`,
`set_record_lock(file: &File, start: i64, length: i64, kind: LockKind) -> Result<(), DatabaseError>`, and
private `has_conflict(file: &File, start: i64, length: i64) -> Result<bool, DatabaseError>`.
`DatabaseLocks::new(file: File)` owns its file; `lock(&mut self, level: i32)` and
`unlock(&mut self, level: i32)` return `Result<(), DatabaseError>`; `reserved(&self)` returns
`Result<bool, DatabaseError>`. Private `file(&self) -> &File` serves the file callbacks and
`level(&self) -> i32` serves SQLite's lock-state query. A file state owns this lock owner instead of
duplicating its descriptor. The `level` arguments are checked SQLite lock constants, not arbitrary states
stored unchecked. Keep each connection on an independently opened file description.

The private test harness produces these interfaces. `ChildGuard` owns the child process group and output
readers.

```rust
pub(super) fn child(scenario: &str, directory: &Path) -> std::io::Result<ChildGuard>;
impl ChildGuard {
    pub(super) fn ready(&mut self) -> std::io::Result<()>;
    pub(super) fn send(&mut self, command: &str) -> std::io::Result<()>;
    pub(super) fn finish(self) -> std::io::Result<std::process::Output>;
}
```

- [ ] **Step 1: Write compiling lock and watchdog tests.**

```rust
#[test]
fn closing_another_description_keeps_the_writer_lock() {
    let (_temp, root) = root();
    let leaf = Path::new("vpt.db");
    let first = root.create_read_write_file(leaf, 0o600).unwrap();
    let unrelated = root.open_file(leaf, Access::ReadWrite).unwrap();
    let contender = root.open_file(leaf, Access::ReadWrite).unwrap();
    set_record_lock(&first, 0x4000_0001, 1, LockKind::Exclusive).unwrap();
    drop(unrelated);
    let error = set_record_lock(&contender, 0x4000_0001, 1, LockKind::Exclusive).unwrap_err();
    assert!(matches!(error, DatabaseError::Sqlite(rusqlite::Error::SqliteFailure(code, _))
        if code.code == rusqlite::ErrorCode::DatabaseBusy));
    drop(first);
    set_record_lock(&contender, 0x4000_0001, 1, LockKind::Exclusive).unwrap();
}
```

Add distinct transition leaves: two shared holders coexist; reserved excludes another reserved but allows
readers; pending blocks new readers; failed promotion retains pending; downgrade releases
pending/reserved but retains shared; unlock releases this description only. Verify the reserved query
with the current owner and a different description.

Add `fifo_database`, `fifo_journal`, `fifo_wal` and `fifo_shared_memory` child scenarios. Each creates
one owned FIFO, attempts the corresponding D1 open, and asserts a containment refusal. No child opens the
FIFO's writing end. These tests pin the existing nonblocking type check without risking a stalled test
runner.

The child entry point is a `#[test]` leaf selected with the exact fully qualified test name by
`std::env::current_exe()`. With no scenario marker it returns immediately. Its scenario is a fixed match
over test-owned names, not arbitrary commands. Clear the environment; set owned `HOME`, all three XDG
roots, `VPT_CONFIG` and `PATH`. Pass the synthetic root as one `OsString` argument or environment value.
Use pipe handshakes for ready/continue messages.

```rust
#[test]
fn child_watchdog_reaps_a_stalled_lock_test() {
    let (temp, _root) = root();
    let started = std::time::Instant::now();
    let process = child("stall", temp.path()).unwrap();
    assert_eq!(process.finish().unwrap_err().kind(), std::io::ErrorKind::TimedOut);
    assert!(started.elapsed() < std::time::Duration::from_secs(1));
}
```

- [ ] **Step 2: Run red, with a watchdog independent of the lock implementation.**

```bash
cargo test --locked -p vpt-adapters database::tests::locks -- --nocapture
```

Expected: lock assertions fail against explicit red stubs. The deliberate `stall` child is killed and
reaped. Its parent deadline is 500 ms, including readiness and output collection; cleanup has a bounded
50 ms graceful phase followed by termination of the owned group and reaping. Reuse the existing command
test harness's ownership pattern within this crate, without including files from another crate.

- [ ] **Step 3: Implement the lock protocol with nonblocking calls.**

```rust
const PENDING_BYTE: i64 = 0x4000_0000;
const RESERVED_BYTE: i64 = PENDING_BYTE + 1;
const SHARED_FIRST: i64 = PENDING_BYTE + 2;
const SHARED_SIZE: i64 = 510;
```

Build a zeroed `libc::flock`, assign `l_whence = SEEK_SET`, the checked range, and `F_RDLCK`, `F_WRLCK`
or `F_UNLCK`. Use `fcntl(fd, F_OFD_SETLK, &lock)`, never the blocking variant. Map `EACCES` and `EAGAIN`
to SQLite busy, interrupted calls to a retry of this nonblocking operation, and unsupported locking or
other errors to a typed failure. Query conflicts with `F_OFD_GETLK`; include this connection's known
reserved-or-higher state because a query does not conflict with its own description.

| Transition                   | Exact operations                                                                                   |
| ---------------------------- | -------------------------------------------------------------------------------------------------- |
| None to shared               | Read-lock pending byte; read-lock all 510 shared bytes; release pending byte, including on failure |
| Shared to reserved           | Write-lock reserved byte; keep shared lock                                                         |
| Shared/reserved to exclusive | Write-lock pending byte, then all shared bytes; on contention retain pending and report busy       |
| Pending to exclusive         | Retry the exclusive shared-range lock                                                              |
| Exclusive/pending to shared  | Convert shared range to read lock, then release pending and reserved bytes                         |
| Any to none                  | Release this description's locks and update its level                                              |

Update recorded levels only after successful transitions, except the deliberate retained pending state.
Propagate unlock errors. No process-global inode table or application `write.lock` substitutes for these
locks.

- [ ] **Step 4: Run green, native lock contention and hang controls.**

Add native child scenarios using the bundled SQLite `unix-posix` filesystem when registered. If that name
is absent, inspect the bundled build's `unix` implementation and select it only when it is the POSIX
record-lock implementation. Unsupported reference locking is a failed test with a clear reason, not a
passing skip. Test native writer versus rooted contender and rooted writer versus native contender. Do
not overlap native/rooted connections on the same inode in one process.

For the native contention tests, create a valid rollback-mode fixture with a native connection and close
it first. The rooted participant uses D2's file locks; the other process uses a real SQLite transaction.
This deliverable needs no future D3 owner. D4 adds full rooted SQL interoperability.

Remove `O_NONBLOCK` in the FIFO control mutation. The independent parent watchdog must fail the named
test and reap all owned children within one second. Mutate `F_OFD_SETLK` to `F_SETLK`; the
independent-close regression must fail. Restore each mutation and run the unmodified control. D4 adds the
real SQLite busy-timeout mutation once that bounded production operation exists.

- [ ] **Step 5: Format, review and commit.**

```bash
cargo fmt --all
cargo test --locked -p vpt-adapters database::tests::locks
git add crates/vpt-adapters/src/database
git commit -m "feat(database): coordinate descriptor-owned locks"
```
