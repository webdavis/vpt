# D1: Checked database files and access policies

## Controller verification

Accepted after independent Astra xhigh review with no findings, `task-D1-review-1.md`. The controller's committed-HEAD gate and named-leaf audit passed below. Twelve of the 38 adjusted implementation chunks are accepted. D2 may now begin; temporary lint expectations and the existing timing follow-up remain open.

The committed-HEAD `just ship` exited 0 in `task-D1-controller-ship.log`: 225 passing leaves, all 209 baseline names retained, 16 added and zero missing. The 98-commit secrets scan is clean. Worktree/index were clean and HEAD unchanged after the gate. Independent Astra review approved with no findings. The controller's aggregate adapter target took 13.48 seconds and setup took 1.66 seconds; these totals do not provide individual leaf timings and do not invalidate or replace the separate worker timing measurements. No 500 ms command deadline failed. The existing timing follow-up remains open.

Controller-read final SHA-256 values:

- `contained.rs`: `2320c18002190d65f55abeb5ebc2137265f17d05a4004ee82f46547e71acb3e9`
- `contained/file.rs`: `b5792bcf7d0d653d136f3dc8c53443ae9ce823d9c4ca96f48d5a793ec8ff033e`
- `database/mod.rs`: `9295054da741a9a482280b2e2ba843c58d9a0fd9fa8ead9f0491a26ab6c0dbc8`
- `database/files.rs`: `38de51d93cfc9b2df27065059ea82da156ea5206aac2640b992f4ed524c1f817`

Base: `153989840f9be9ddf4a1076ef2ca3ec455a5fa75`. Final HEAD: `1a00d858db6a744970599096318340af1ce7ccee`, `feat(database): contain database file access`. Worktree: `/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract`, branch `feat/stage-1-extract`. The commit contains only the 13 owned D1 source/test files and used normal hooks. The worktree and index were clean at controller acceptance. The implementation report below predates controller review; the acceptance record above is current.

The private `database` module authorizes one bare database leaf and its exact journal, write-ahead log (WAL), and shared-memory names. `AccessPolicy` and `DatabaseError` are crate-private; `DatabaseFiles`, its methods, and `FileRole` stay within `database`. New checked-root methods are crate-private `create_read_write_file` and `unlink_file`. No public type, dependency, application port, schema, command, or configuration contract changed. The existing five-crate dependency graph remains unchanged. The approved amendment is the behavior specification; no additional product document was created.

Existing opens use retained `RootDir::open_file`, check the descriptor link count, then repair writable files to `0600`. Exclusive creation validates the descriptor before chmod and synchronizes the held directory. Removal checks the named entry without following links and uses `unlinkat` against that directory. Observation opens existing files read-only, including a writable probe with `create=true`, and never creates, removes, or repairs them. Refreshed title copies can write only shared memory. Revalidation reports a missing, linked, wrong-type, or replaced acquired path as `Escape`; initial acquisition still reports ordinary absence. Existing config callers retain their hard-link error behavior because the shared `open_file` was not changed to reject hard links.

## Test-first evidence

The [database RED](task-D1-red-01.log) compiled and failed all 12 initial leaves against explicit `Unsupported` stubs. The [checked-root RED](task-D1-root-red-01.log) compiled and failed three leaves for creation, unlink, and missing/link revalidation. The transparent error conversions also have a characterization assertion preserving the payload and ordinary input/output classification. That assertion introduced no production change.

The first [adapter GREEN attempt](task-D1-green-01.log) passed 101/103 and exposed two fixture errors. An invalid UTF-8 byte filename was refused by the local filesystem, so the suffix test now uses a valid Unicode name. The initial-absence assertion used the temporary directory's `/var` alias, which `O_NOFOLLOW_ANY` correctly refused; it now uses the acquired canonical root. The newly added suffix leaf was renamed from `companions_append_exact_suffixes_to_a_valid_non_utf8_leaf` to `companions_append_exact_suffixes_to_the_database_leaf`. Both corrections affected fixtures only. The [corrected adapter control](task-D1-green-02.log) passed 103/103, and the [final focused control](task-D1-green-03.log) passed all 13 database leaves after adding the error characterization. The three checked-root leaves also pass in both final workspace runs.

The [baseline](task-D1-baseline-leaves-01.log) and [final](task-D1-final-leaves-01.log) inventories use binary name plus leaf name, with compiler hashes removed. All 209 baseline names are retained, the [missing list](task-D1-missing-leaves-01.log) is empty, and the [16 added names](task-D1-added-leaves-01.log) produce 225 passing leaves. No baseline leaf was renamed or removed.

Fixtures cover every role and policy, links, directories, multiply linked files, malformed leaves, absent files, root replacement, and ancestor replacement. Snapshots include bytes, entry type/mode, ownership, device/inode, link count, size, modification/change times, and flags. They exclude access time. Replacement and outside files remain owned fixtures; unchanged snapshots cover their entries and metadata as well as bytes. Writable creation is checked at `0600`; observational `0640` fixtures retain that mode. Returned descriptor access flags and failed writes prove actual read-only access.

## Exact mutation controls

Each mutant log contains the edited source read back from disk, its SHA-256, the compiler invocation, and the failed named tests. Each control records the equal original/restored hashes and passing tests. All 14 mutants compiled and failed behaviorally; none survived. Both pathname mutants fail the direct-root and ancestor-replacement leaves.

| Source mutation | Named behavior caught | Evidence |
| --- | --- | --- |
| Replace retained `openat` with pathname `open` | Lazy open and existing-file access after root/ancestor replacement | [mutant](task-D1-mut-pathname-open-01.log), [control](task-D1-control-pathname-open-01.log) |
| Replace retained `unlinkat` with pathname `unlink` | Cleanup after root/ancestor replacement | [mutant](task-D1-mut-pathname-unlink-01.log), [control](task-D1-control-pathname-unlink-01.log) |
| Remove existing-open no-follow flag | Every role refuses symbolic links | [mutant](task-D1-mut-follow-open-01.log), [control](task-D1-control-follow-open-01.log) |
| Bypass existing-descriptor link-count guard | Every role refuses multiple links | [mutant](task-D1-mut-open-links-01.log), [control](task-D1-control-open-links-01.log) |
| Bypass unlink link-count guard | Writable removal refuses unsafe entries | [mutant](task-D1-mut-unlink-links-01.log), [control](task-D1-control-unlink-links-01.log) |
| Allow creation under read-only policies | Each policy creates only permitted roles | [mutant](task-D1-mut-observation-create-01.log), [control](task-D1-control-observation-create-01.log) |
| Chmod existing observational descriptors | Observation snapshot remains unchanged | [mutant](task-D1-mut-observation-chmod-01.log), [control](task-D1-control-observation-chmod-01.log) |
| Make all refreshed-copy roles writable | Creation, descriptor access, and removal policy | [mutant](task-D1-mut-refresh-all-writable-01.log), [control](task-D1-control-refresh-all-writable-01.log) |
| Bypass removal policy | Observational and copied-file preservation | [mutant](task-D1-mut-remove-policy-01.log), [control](task-D1-control-remove-policy-01.log) |
| Bypass bare-leaf validation | Invalid database names are refused | [mutant](task-D1-mut-bare-leaf-01.log), [control](task-D1-control-bare-leaf-01.log) |
| Repair writable files to `0640` | Writable descriptor mode is `0600` | [mutant](task-D1-mut-repair-mode-01.log), [control](task-D1-control-repair-mode-01.log) |
| Remove exclusive creation | Existing valid file remains an `AlreadyExists` refusal | [mutant](task-D1-mut-exclusive-create-01.log), [control](task-D1-control-exclusive-create-01.log) |
| Remove revalidation error classification | Missing acquired path is an escape | [mutant](task-D1-mut-revalidation-missing-01.log), [control](task-D1-control-revalidation-missing-01.log) |
| Bypass identity comparison | Replacement directory is an escape | [mutant](task-D1-mut-revalidation-identity-01.log), [control](task-D1-control-revalidation-identity-01.log) |

## Final-source gates

| Command | Result | Evidence |
| --- | --- | --- |
| `just ship` | exit 0; 225 leaves; 26.19 s | [ship](task-D1-ship-final-01.log) |
| `just test-rust` | exit 0; 225 leaves; 6.12 s | [tests](task-D1-test-rust-final-01.log) |
| `just lint-check` | exit 0; 0.82 s | [lint](task-D1-lint-check-final-01.log) |
| `cargo check --locked --workspace --all-targets --features dev-tools` | exit 0; 3.69 s | [check](task-D1-check-all-targets-final-01.log) |
| `cargo build --locked --release` | exit 0; 2.34 s | [release](task-D1-release-final-01.log) |
| `cargo clippy --locked -p vpt-adapters --all-targets -- -D warnings` | exit 0; 0.66 s | [focused Clippy](task-D1-adapters-clippy-final-01.log) |
| `cargo clippy --locked --workspace --all-targets -- -D warnings` | exit 0; 3.46 s | [workspace Clippy](task-D1-workspace-clippy-final-01.log) |
| `cargo fmt --all -- --check` | exit 0 inside ship and lint | [ship](task-D1-ship-final-01.log) |
| `RUSTDOCFLAGS="-D warnings" cargo doc --locked --workspace --no-deps` | exit 0 inside ship | [ship](task-D1-ship-final-01.log) |
| Staged whitespace and physical-line audit | exit 0 | [audit](task-D1-size-audit-final-01.log) |
| Committed-HEAD `gitleaks git --redact --no-banner` | exit 0; 98 commits; no leaks; 3.23 s | [secrets](task-D1-committed-head-secrets-01.log) |

The [timing record](task-D1-timings-final-01.log) covers both workspace runs with the standard concurrent test runner. The longest complete test target finished in 0.57 s, which bounds every contained leaf below one second. All 104 adapter tests together finished in 0.37 s during ship and 0.53 s during `just test-rust`. The existing 500 ms command deadline issue did not recur. This records whole-target upper bounds, not invented individual durations.

The staged audit includes every new file. Changed production files are `contained.rs` (169 implementation / 171 total), `contained/file.rs` (144/144), `database/mod.rs` (85/87), `database/files.rs` (113/113), and adapters `lib.rs` (8/8). The largest new test child is 146 lines. The command entry point remains three lines. The only size warnings are the accepted inherited `config/schema.rs` 471-line and `config/load/tests.rs` 304-line files.

## Controller rulings and remaining work

The [incremental Clippy diagnostic](task-D1-incremental-clippy-01.log) proved that the private D1 boundary has no production consumer yet. The controller approved item-level `cfg_attr(not(test), expect(dead_code, reason = ...))` attributes. Normal and test builds still compile the production module. No synthetic caller, visibility expansion, blanket allowance, dependency, or feature gate was added. The [focused pre-mutation Clippy](task-D1-clippy-pre-mutation-01.log) and final Clippy runs are clean.

All nine temporary expectations are enumerated here. Remove each as its actual consumer arrives, tracked by `6hc7x7wMwxF8R9rg`:

| Item | Consuming task |
| --- | --- |
| `RootDir::create_read_write_file` | D3 creation callback |
| `RootDir::unlink_file` | D3 deletion callback |
| `AccessPolicy` | D3 connection policy, D5 ledger variants; title-only variant expectations may remain until D6 |
| `AccessPolicy::writable` | D3 file callbacks |
| `FileRole` | D3 role validation |
| `DatabaseError` | D3 local error retention, D5 ledger mapping |
| `DatabaseError::is_containment` | D3 containment latch, D5 mapping |
| `DatabaseFiles` | D3 registration ownership |
| `DatabaseFiles` implementation | D3 file callbacks and owner |

The controller also resolved removal durability: `unlink_file` performs the checked removal; `remove(role, true)` synchronizes the root and propagates failure; `false` does not add a sync. This follows the explicit D1 boolean and D3 callback contract. Creation still synchronizes. D3 owns directory-sync fault injection and callback-route verification; D1 does not claim those tests exist.

Security review traced path validation into descriptor-relative opens, metadata, descriptor chmod, and unlink. File type and link guards precede permissions changes. Ordinary storage failures retain their typed payload; containment stays distinct. Tests and source checks cover D1's file boundary only. D2 still owns locks and FIFO watchdog cases; D3 owns registration, callbacks, owner lifetime, and synchronization failures; D4 owns shared memory; D5 owns ledger/schema integration; D6 owns title-copy coordination. No database connection was opened, SQLite source or syscall hook modified, live data accessed, installation performed, or remote publication attempted. Independent Astra review remains the controller's next step.
