### Task 19: The ingest use case, happy path

The sweep runs over real adapters in these tests (a fixture container, the clone archive and the SQLite
ledger in a temporary directory) with three small fakes for the clock, the Trash and the notifier, so the
tests exercise the code that ships. They live as integration tests of the adapters crate. The use case is
generic over its six ports; nothing in it names a handle type, and the wholeness gate reads through the
recorder's and the archive's `read_at`.

**Files:**

- Create: `crates/vpt-domain/src/notification.rs`
- Modify: `crates/vpt-domain/src/lib.rs`
- Create: `crates/vpt-application/src/ports/clock.rs`, `crates/vpt-application/src/ports/trash.rs`,
  `crates/vpt-application/src/ports/notifier.rs`, `crates/vpt-application/src/ingest/mod.rs`,
  `crates/vpt-application/src/ingest/candidate.rs`, `crates/vpt-application/src/ingest/publish.rs`
- Modify: `crates/vpt-application/src/ports/mod.rs`, `crates/vpt-application/src/lib.rs`
- Test: `crates/vpt-adapters/tests/support/mod.rs`, `crates/vpt-adapters/tests/ingest_sweep.rs`,
  `crates/vpt-adapters/tests/ingest_titles.rs`

**Interfaces:**

- Consumes: every port so far, `RecordingLedger::{seen, record_seen, commit}`, the domain gates and
  `inspect`; `RecorderStore::refresh_titles(&self) -> Result<(), RecorderError>` before each non-dry
  sweep, and `Archive::validate_trash_path(&self, path: &Path) -> Result<(), ArchiveError>` before
  cleanup.

- Produces:

  - `vpt_domain::notification::{EventKind, EventState, Notification}`;
    `EventKind::{ReviewNeeded, TranscribeFailed, IngestFailed, Deferred, BriefWritten,`
    `Retention, ConfigRefused}` with `as_str`; `EventState::{NeedsAttention, Failed, Done}` with
    `as_str`; `Notification { pub event: EventKind, pub state: EventState,`
    `pub recording: Option<RecordingId>, pub detail: String, pub counts: Vec<(String, u64)>,`
    `pub paths: Vec<(String, PathBuf)>, pub occurred_at: UtcInstant }` with constructors
    `Notification::failed(event, detail: String, at: UtcInstant)`,
    `Notification::attention(event, recording: Option<RecordingId>, detail: String,`
    `paths: Vec<(String, PathBuf)>, at: UtcInstant)`,
    `Notification::done(event, detail: String, counts: Vec<(String, u64)>, at: UtcInstant)`.
  - `vpt_application::ports::{Clock, Trash, TrashError, Notifier, DeliveryOutcome}`:
    `trait Clock { fn now(&self) -> UtcInstant; fn offset_at(&self, at: UtcInstant) -> UtcOffset; }`;
    `TrashError::{HelperAbsent, HelperVersion { found: u32 }, Failed(String), Unknown(String)}`,
    `trait Trash { fn trash(&self, path: &Path) -> Result<PathBuf, TrashError>;`
    `fn take_diagnostics(&self) -> Vec<String>; }` (default: empty);
    `DeliveryOutcome::{Delivered, Suppressed, Failed(String)}`,
    `trait Notifier { fn deliver(&self, notification: &Notification) -> DeliveryOutcome;`
    `fn take_diagnostics(&self) -> Vec<String>; }` (default: empty).
  - `vpt_application::{Ingest, Mode, IngestReport, Deferred, WouldIngest, IngestFailure, IngestError}`
    (the file `ingest/` stays private, `lib.rs` re-exports these):
    `Ingest<'a, R, A, L, C, T, N> { pub recorder: &'a R, pub archive: &'a A, pub ledger: &'a L,`
    `pub clock: &'a C, pub trash: &'a T, pub notifier: &'a N, pub settings: &'a SourceSettings }` with
    `R: RecorderStore, A: Archive, L: RecordingLedger, C: Clock, T: Trash + ?Sized, N: Notifier + ?Sized`;
    `Mode { pub dry_run: bool, pub once: Option<PathBuf> }` (`Default` is the full sweep);
    `IngestReport { pub ingested: Vec<RecordingRecord>, pub already_ingested: Vec<RecordingId>,`
    `pub recovered: Vec<RecordingId>, pub deferred: Vec<Deferred>, pub skipped: u64,`
    `pub would_ingest: Vec<WouldIngest>, pub log: Vec<String> }`;
    `Deferred { pub path: PathBuf, pub reason: DeferralReason }`;
    `WouldIngest { pub path: PathBuf, pub title: Option<String>, pub title_source: TitleOrigin }`;
    `IngestFailure::{StoreUnreadable(String), EmptyStore, NoSpace, Sync(String),`
    `ArchiveCollision { target: PathBuf, staged: Sha256Digest, existing: Sha256Digest },`
    `OnceMissing(PathBuf), PathEscape(PathBuf), HelperVersion { found: u32 }, Ledger(LedgerError), Archive(String), Recorder(String)}`
    with `fn message(&self) -> String`; `IngestError { pub failure: IngestFailure,`
    `pub completed: Vec<RecordingId>, pub log: Vec<String> }` (`completed` holds every identity the run
    recovered or ingested, deduplicated; `log` is the run's log up to the failure);
    `Ingest::run(&self, mode: &Mode) -> Result<IngestReport, Box<IngestError>>`. This task supports the
    full sweep and `once`; Task 20 adds the gates, Task 21 the duplicates, Task 22 recovery, Task 23 the
    dry run and the aborts.
  - Test support in `crates/vpt-adapters/tests/support/mod.rs`: `Fixture::new() -> Fixture` with the
    public fields `temp`, `container` (a canonical `voice-memos` directory holding `Recordings/`, the
    four Apple subdirectories each with one inner file, and a live `CloudRecordings.db` in WAL mode whose
    connection the fixture keeps open), `recordings`, `audio`, `state`; methods
    `add_recording(&self, name: &str, bytes: &[u8]) -> PathBuf` (mtime 60 s before the fixed clock),
    `set_mtime(&self, path: &Path, secs: i64)`, `add_title(&self, path: &str, label: &str)`,
    `replace_title(&self, label: &str)`, `store(&self) -> VoiceMemosStore`,
    `titled_store(&self, refresh: bool) -> VoiceMemosStore`, `archive(&self) -> ClonefileArchive`,
    `ledger(&self) -> SqliteLedger`, `settings(&self) -> SourceSettings`, `parts(&self) -> Parts`,
    `entries(&self) -> Vec<Entry>` (every entry below the container, recursively: relative path, size,
    mtime seconds and nanoseconds, flags);
    `Parts { store, archive, ledger, clock, trash, notifier, settings }` with
    `fn ingest(&self) -> RealIngest<'_>` and `fn events(&self) -> Vec<EventKind>`;
    `FixedClock { pub now: UtcInstant, pub offset: UtcOffset }` (`Copy`) and `clock() -> FixedClock` (an
    August 2026 instant an hour after `CAPTURED`, offset `-21_600`); `RecordingTrash::new(dir: PathBuf)`
    with `pub moved: RefCell<Vec<PathBuf>>` and `pub absent: Cell<bool>`;
    `RecordingNotifier(pub RefCell<Vec<Notification>>)`; `CAPTURED: i64 = 1_787_604_456`;
    `digest_of(bytes: &[u8]) -> Sha256Digest`.

- [ ] **Step 1: Write the failing tests**

`crates/vpt-adapters/tests/support/mod.rs`:

```rust
//! Real adapters over a temporary directory, plus the three fakes the sweep
//! needs for the clock, the Trash and the notifier.

#![allow(dead_code)]

use sha2::{Digest, Sha256};
use std::cell::{Cell, RefCell};
use std::os::macos::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::time::{Duration, UNIX_EPOCH};
use vpt_adapters::ClonefileArchive;
use vpt_adapters::RootDir;
use vpt_adapters::SqliteLedger;
use vpt_adapters::{APPLE_SUBDIRECTORIES, VoiceMemosStore};
use vpt_application::ports::{Clock, DeliveryOutcome, Notifier, Trash, TrashError};
use vpt_application::{Ingest, SourceSettings};
use vpt_domain::digest::Sha256Digest;
use vpt_domain::notification::{EventKind, Notification};
use vpt_domain::time::{UtcInstant, UtcOffset};

pub const CAPTURED: i64 = 1_787_604_456;

/// Relative path, size, mtime seconds, mtime nanoseconds, flags.
pub type Entry = (PathBuf, u64, i64, i64, u32);

pub type RealIngest<'a> = Ingest<'a, VoiceMemosStore, ClonefileArchive, SqliteLedger, FixedClock, RecordingTrash, RecordingNotifier>;

pub struct Fixture {
    pub temp: tempfile::TempDir,
    pub container: PathBuf,
    pub recordings: PathBuf,
    pub audio: PathBuf,
    pub state: PathBuf,
    live_database: rusqlite::Connection,
}

impl Fixture {
    pub fn new() -> Fixture {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let container = base.join("voice-memos");
        let recordings = container.join("Recordings");
        let audio = base.join("home/audio");
        let state = base.join("state/vpt");
        for dir in [&recordings, &audio, &state] {
            std::fs::create_dir_all(dir).expect("fixture dir");
        }
        for name in APPLE_SUBDIRECTORIES {
            std::fs::create_dir(recordings.join(name)).expect("apple subdirectory");
            std::fs::write(recordings.join(name).join("inner.m4a"), b"never listed").expect("inner");
        }
        let live_database = rusqlite::Connection::open(container.join("CloudRecordings.db")).expect("live db");
        live_database.pragma_update(None, "journal_mode", "WAL").expect("wal");
        live_database
            .execute_batch("CREATE TABLE ZCLOUDRECORDING (Z_PK INTEGER PRIMARY KEY, ZPATH TEXT, ZCUSTOMLABEL TEXT)")
            .expect("schema");
        Fixture { temp, container, recordings, audio, state, live_database }
    }

    /// A source file whose mtime sits 60 s before the fixed clock.
    pub fn add_recording(&self, name: &str, bytes: &[u8]) -> PathBuf {
        let path = self.recordings.join(name);
        std::fs::write(&path, bytes).expect("recording");
        self.set_mtime(&path, clock().now.secs - 60);
        path
    }

    pub fn set_mtime(&self, path: &Path, secs: i64) {
        let at = UNIX_EPOCH + Duration::from_secs(u64::try_from(secs).expect("fixture epoch"));
        let file = std::fs::File::options().write(true).open(path).expect("open for times");
        file.set_times(std::fs::FileTimes::new().set_modified(at)).expect("mtime");
    }

    pub fn add_title(&self, path: &str, label: &str) {
        self.live_database
            .execute("INSERT INTO ZCLOUDRECORDING (ZPATH, ZCUSTOMLABEL) VALUES (?1, ?2)", [path, label])
            .expect("title row");
    }

    pub fn replace_title(&self, label: &str) {
        self.live_database.execute("UPDATE ZCLOUDRECORDING SET ZCUSTOMLABEL = ?1", [label]).expect("update title");
    }

    pub fn store(&self) -> VoiceMemosStore {
        VoiceMemosStore::open(&self.recordings).expect("store")
    }

    pub fn titled_store(&self, refresh: bool) -> VoiceMemosStore {
        self.store().with_titles(self.state.clone(), refresh)
    }

    pub fn archive(&self) -> ClonefileArchive {
        ClonefileArchive::open(&self.audio).expect("archive")
    }

    pub fn ledger(&self) -> SqliteLedger {
        SqliteLedger::open(&RootDir::open(&self.state).expect("state root")).expect("ledger")
    }

    pub fn settings(&self) -> SourceSettings {
        SourceSettings {
            recordings_dir: self.recordings.clone(),
            read_titles: false,
            quiet_period_secs: 30,
            deferral_page_threshold: 4,
            max_audio_bytes: 2_147_483_648,
        }
    }

    pub fn parts(&self) -> Parts {
        Parts {
            store: self.store(),
            archive: self.archive(),
            ledger: self.ledger(),
            clock: clock(),
            trash: RecordingTrash::new(self.temp.path().join("trash")),
            notifier: RecordingNotifier::default(),
            settings: self.settings(),
        }
    }

    /// Every entry below the container, recursively, in sorted order.
    pub fn entries(&self) -> Vec<Entry> {
        let mut entries = Vec::new();
        walk(&self.container, &self.container, &mut entries);
        entries.sort();
        entries
    }
}

fn walk(root: &Path, directory: &Path, out: &mut Vec<Entry>) {
    for entry in std::fs::read_dir(directory).expect("dir") {
        let entry = entry.expect("entry");
        let metadata = entry.metadata().expect("metadata");
        let path = entry.path();
        let relative = path.strip_prefix(root).expect("below the container").to_path_buf();
        out.push((relative, metadata.len(), metadata.st_mtime(), metadata.st_mtime_nsec(), metadata.st_flags()));
        if metadata.is_dir() {
            walk(root, &path, out);
        }
    }
}

pub fn digest_of(bytes: &[u8]) -> Sha256Digest {
    Sha256Digest(Sha256::digest(bytes).into())
}

pub struct Parts {
    pub store: VoiceMemosStore,
    pub archive: ClonefileArchive,
    pub ledger: SqliteLedger,
    pub clock: FixedClock,
    pub trash: RecordingTrash,
    pub notifier: RecordingNotifier,
    pub settings: SourceSettings,
}

impl Parts {
    pub fn ingest(&self) -> RealIngest<'_> {
        Ingest {
            recorder: &self.store,
            archive: &self.archive,
            ledger: &self.ledger,
            clock: &self.clock,
            trash: &self.trash,
            notifier: &self.notifier,
            settings: &self.settings,
        }
    }

    pub fn events(&self) -> Vec<EventKind> {
        self.notifier.0.borrow().iter().map(|notification| notification.event).collect()
    }
}

#[derive(Debug, Clone, Copy)]
pub struct FixedClock {
    pub now: UtcInstant,
    pub offset: UtcOffset,
}

impl Clock for FixedClock {
    fn now(&self) -> UtcInstant {
        self.now
    }

    fn offset_at(&self, _at: UtcInstant) -> UtcOffset {
        self.offset
    }
}

pub fn clock() -> FixedClock {
    FixedClock { now: UtcInstant { secs: CAPTURED + 3_600 }, offset: UtcOffset { secs: -21_600 } }
}

pub struct RecordingTrash {
    dir: PathBuf,
    pub moved: RefCell<Vec<PathBuf>>,
    pub absent: Cell<bool>,
}

impl RecordingTrash {
    pub fn new(dir: PathBuf) -> RecordingTrash {
        std::fs::create_dir_all(&dir).expect("trash dir");
        RecordingTrash { dir, moved: RefCell::new(vec![]), absent: Cell::new(false) }
    }
}

impl Trash for RecordingTrash {
    fn trash(&self, path: &Path) -> Result<PathBuf, TrashError> {
        if self.absent.get() {
            return Err(TrashError::HelperAbsent);
        }
        let target = self.dir.join(path.file_name().expect("name"));
        std::fs::rename(path, &target).map_err(|error| TrashError::Failed(error.kind().to_string()))?;
        self.moved.borrow_mut().push(path.to_path_buf());
        Ok(target)
    }
}

#[derive(Default)]
pub struct RecordingNotifier(pub RefCell<Vec<Notification>>);

impl Notifier for RecordingNotifier {
    fn deliver(&self, notification: &Notification) -> DeliveryOutcome {
        self.0.borrow_mut().push(notification.clone());
        DeliveryOutcome::Delivered
    }
}
```

`crates/vpt-adapters/tests/ingest_sweep.rs`:

```rust
mod support;

use std::os::unix::fs::PermissionsExt;
use support::{CAPTURED, Fixture, FixedClock, Parts, clock};
use vpt_application::Mode;
use vpt_application::ports::{Archive, RecordingLedger, StageStates, TitleOrigin};
use vpt_domain::fixtures::m4a;
use vpt_domain::time::UtcInstant;

#[test]
fn a_whole_recording_is_archived_under_its_identity_and_recorded_in_the_ledger() {
    let fixture = Fixture::new();
    let source = fixture.add_recording("20260824 144736-4F3AB19C.m4a", &m4a(CAPTURED, 612, b"audio bytes"));
    let parts = fixture.parts();

    let report = parts.ingest().run(&Mode::default()).expect("sweep");

    assert_eq!(report.ingested.len(), 1);
    let record = &report.ingested[0];
    assert!(record.id.as_str().starts_with("2026-08-24T144736-"), "{}", record.id);
    assert_eq!(record.source_path.as_deref(), Some(source.as_path()));
    assert_eq!(record.duration_secs, 612);
    assert_eq!(record.captured_at, UtcInstant { secs: CAPTURED });
    assert_eq!(record.captured_offset, clock().offset);
    assert_eq!(record.title, None);
    assert_eq!(record.title_source, TitleOrigin::Unavailable);
    assert_eq!(record.stages, StageStates::fresh());
    assert_eq!(record.audio_path, fixture.audio.join(format!("{}.m4a", record.id)));
    assert_eq!(std::fs::read(&record.audio_path).expect("archive"), m4a(CAPTURED, 612, b"audio bytes"));
    assert_eq!(std::fs::metadata(&record.audio_path).expect("meta").permissions().mode() & 0o777, 0o600);
    assert_eq!(parts.ledger.by_id(&record.id).expect("read"), Some(record.clone()));
    let row = parts.ledger.seen(&source).expect("seen").expect("row");
    assert_eq!(row.recording, Some(record.id.clone()));
    assert_eq!((row.deferral_count, row.deferral_reason, row.source_gone_at), (0, None, None));
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert!(parts.events().is_empty());
    assert!(parts.trash.moved.borrow().is_empty());
}

#[test]
fn a_full_sweep_with_titles_leaves_every_container_entry_with_its_size_mtime_and_flags() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    fixture.add_recording("b.m4a", &m4a(CAPTURED + 60, 2, b"bb"));
    std::fs::write(fixture.recordings.join("a.waveform"), b"w").expect("sidecar");
    fixture.add_title("a.m4a", "Alpha");
    let before = fixture.entries();
    let mut parts = fixture.parts();
    parts.store = fixture.titled_store(true);

    let report = parts.ingest().run(&Mode::default()).expect("sweep");

    assert_eq!(report.ingested.len(), 2);
    assert_eq!(report.ingested[0].title.as_deref(), Some("Alpha"));
    assert_eq!(report.ingested[0].title_source, TitleOrigin::VoiceMemos);
    assert_eq!(report.ingested[1].title, None);
    assert_eq!(fixture.entries(), before);
    assert!(fixture.state.join("title-copy").join("CloudRecordings.db").exists());
}

#[test]
fn a_second_sweep_skips_the_unchanged_entries_and_refreshes_last_seen() {
    let fixture = Fixture::new();
    let source = fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    let parts = fixture.parts();
    parts.ingest().run(&Mode::default()).expect("first");
    let later = Parts { clock: FixedClock { now: UtcInstant { secs: CAPTURED + 7_200 }, ..clock() }, ..fixture.parts() };

    let report = later.ingest().run(&Mode::default()).expect("second");

    assert!(report.ingested.is_empty());
    assert_eq!(report.skipped, 1);
    assert_eq!(later.ledger.recordings().expect("list").len(), 1);
    let row = later.ledger.seen(&source).expect("seen").expect("row");
    assert_eq!(row.last_seen, UtcInstant { secs: CAPTURED + 7_200 });
    assert_eq!(row.first_seen, UtcInstant { secs: CAPTURED + 3_600 });
}

#[test]
fn once_ingests_exactly_the_named_file() {
    let fixture = Fixture::new();
    let a = fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    fixture.add_recording("b.m4a", &m4a(CAPTURED + 1, 1, b"b"));
    let parts = fixture.parts();

    let report = parts.ingest().run(&Mode { dry_run: false, once: Some(a.clone()) }).expect("once");

    assert_eq!(report.ingested.len(), 1);
    assert_eq!(report.ingested[0].source_path.as_deref(), Some(a.as_path()));
    assert_eq!(parts.ledger.recordings().expect("list").len(), 1);
}
```

`crates/vpt-adapters/tests/ingest_titles.rs`:

```rust
mod support;

use support::{CAPTURED, Fixture};
use vpt_adapters::TitleCopy;
use vpt_application::Mode;
use vpt_application::ports::TitleLookup;
use vpt_domain::fixtures::m4a;

#[test]
fn every_non_dry_sweep_refreshes_titles_before_candidate_work() {
    for source in [Some(m4a(CAPTURED, 1, b"audio")), Some(b"broken".to_vec()), None] {
        let fixture = Fixture::new();
        if let Some(bytes) = source { fixture.add_recording("a.m4a", &bytes); }
        fixture.add_title("a.m4a", "Alpha");
        let mut parts = fixture.parts();
        parts.store = fixture.titled_store(true);
        let _ = parts.ingest().run(&Mode::default());
        assert_eq!(TitleCopy::existing(&fixture.state).title("a.m4a"), TitleLookup::Titled("Alpha".into()));
        fixture.replace_title("Beta");
        let _ = parts.ingest().run(&Mode::default());
        assert_eq!(TitleCopy::existing(&fixture.state).title("a.m4a"), TitleLookup::Titled("Beta".into()));
    }
}

#[test]
fn ordinary_title_copy_failure_still_ingests_untitled() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"audio"));
    let mut parts = fixture.parts();
    parts.store = fixture.store().with_titles(fixture.state.join("absent"), true);
    let report = parts.ingest().run(&Mode::default()).expect("ingested");
    assert_eq!(report.ingested.len(), 1);
    assert_eq!(report.ingested[0].title, None);
    assert!(parts.events().is_empty());
}

```

`Parts` is a plain struct, so the third test rebuilds it around a later clock with struct update syntax
over a fresh `fixture.parts()`.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters --test ingest_sweep --test ingest_titles`

Expected: the build fails with `unresolved import` for `vpt_application::Ingest` and the three new ports.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-domain/src/notification.rs`:

```rust
//! The event vpt raises: identities, counts, classes and paths, never text
//! from a recording.

use crate::identity::RecordingId;
use crate::time::UtcInstant;
use std::path::PathBuf;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EventKind {
    ReviewNeeded,
    TranscribeFailed,
    IngestFailed,
    Deferred,
    BriefWritten,
    Retention,
    ConfigRefused,
}

impl EventKind {
    pub fn as_str(self) -> &'static str {
        match self {
            EventKind::ReviewNeeded => "review_needed",
            EventKind::TranscribeFailed => "transcribe_failed",
            EventKind::IngestFailed => "ingest_failed",
            EventKind::Deferred => "deferred",
            EventKind::BriefWritten => "brief_written",
            EventKind::Retention => "retention",
            EventKind::ConfigRefused => "config_refused",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EventState {
    NeedsAttention,
    Failed,
    Done,
}

impl EventState {
    pub fn as_str(self) -> &'static str {
        match self {
            EventState::NeedsAttention => "needs_attention",
            EventState::Failed => "failed",
            EventState::Done => "done",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Notification {
    pub event: EventKind,
    pub state: EventState,
    pub recording: Option<RecordingId>,
    pub detail: String,
    pub counts: Vec<(String, u64)>,
    pub paths: Vec<(String, PathBuf)>,
    pub occurred_at: UtcInstant,
}

impl Notification {
    pub fn failed(event: EventKind, detail: String, at: UtcInstant) -> Notification {
        Notification { event, state: EventState::Failed, recording: None, detail, counts: vec![], paths: vec![], occurred_at: at }
    }

    pub fn attention(
        event: EventKind,
        recording: Option<RecordingId>,
        detail: String,
        paths: Vec<(String, PathBuf)>,
        at: UtcInstant,
    ) -> Notification {
        Notification { event, state: EventState::NeedsAttention, recording, detail, counts: vec![], paths, occurred_at: at }
    }

    pub fn done(event: EventKind, detail: String, counts: Vec<(String, u64)>, at: UtcInstant) -> Notification {
        Notification { event, state: EventState::Done, recording: None, detail, counts, paths: vec![], occurred_at: at }
    }
}
```

Add `pub mod notification;` to the domain `lib.rs`.

`crates/vpt-application/src/ports/clock.rs`:

```rust
//! Now, and the local offset at an instant.

use vpt_domain::time::{UtcInstant, UtcOffset};

pub trait Clock {
    fn now(&self) -> UtcInstant;
    fn offset_at(&self, at: UtcInstant) -> UtcOffset;
}
```

`crates/vpt-application/src/ports/trash.rs`:

```rust
//! The system Trash. `Unknown` is a reply that never came: the file may or
//! may not have moved.

use std::path::{Path, PathBuf};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TrashError {
    HelperAbsent,
    HelperVersion { found: u32 },
    Failed(String),
    Unknown(String),
}

pub trait Trash {
    fn trash(&self, path: &Path) -> Result<PathBuf, TrashError>;
    fn take_diagnostics(&self) -> Vec<String> { Vec::new() }
}
```

`crates/vpt-application/src/ports/notifier.rs`:

```rust
//! Delivery of one event. A failure here never fails the work it reports on.

use vpt_domain::notification::Notification;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DeliveryOutcome {
    Delivered,
    Suppressed,
    Failed(String),
}

pub trait Notifier {
    fn deliver(&self, notification: &Notification) -> DeliveryOutcome;
    fn take_diagnostics(&self) -> Vec<String> { Vec::new() }
}
```

`crates/vpt-application/src/ports/mod.rs` gains `mod clock;`, `mod notifier;`, `mod trash;` and
`pub use clock::Clock; pub use notifier::{DeliveryOutcome, Notifier};`
`pub use trash::{Trash, TrashError};`. `crates/vpt-application/src/lib.rs` gains `mod ingest;` and
`pub use ingest::{Deferred, Ingest, IngestError, IngestFailure, IngestReport, Mode, WouldIngest};`.

`crates/vpt-application/src/ingest/mod.rs`:

```rust
//! `vpt ingest`: the sweep of spec section 5, composed from the ports.

mod candidate;
mod publish;

use crate::ports::{Archive, Clock, LedgerError, Notifier, RecorderStore, RecordingLedger, RecordingRecord, TitleOrigin, Trash};
use crate::settings::SourceSettings;
use std::path::PathBuf;
use vpt_domain::digest::Sha256Digest;
use vpt_domain::identity::RecordingId;
use vpt_domain::notification::{EventKind, Notification};
use vpt_domain::sweep::DeferralReason;

pub struct Ingest<'a, R, A, L, C, T: ?Sized, N: ?Sized> {
    pub recorder: &'a R,
    pub archive: &'a A,
    pub ledger: &'a L,
    pub clock: &'a C,
    pub trash: &'a T,
    pub notifier: &'a N,
    pub settings: &'a SourceSettings,
}

/// A dry run stages, writes and notifies nothing; `once` names the one file to ingest.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Mode {
    pub dry_run: bool,
    pub once: Option<PathBuf>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Deferred {
    pub path: PathBuf,
    pub reason: DeferralReason,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WouldIngest {
    pub path: PathBuf,
    pub title: Option<String>,
    pub title_source: TitleOrigin,
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct IngestReport {
    pub ingested: Vec<RecordingRecord>,
    pub already_ingested: Vec<RecordingId>,
    pub recovered: Vec<RecordingId>,
    pub deferred: Vec<Deferred>,
    pub skipped: u64,
    pub would_ingest: Vec<WouldIngest>,
    pub log: Vec<String>,
}

impl IngestReport {
    /// Every identity this run made durable, recovered first, without repeats.
    pub fn completed(&self) -> Vec<RecordingId> {
        let mut ids = self.recovered.clone();
        for record in &self.ingested {
            if !ids.contains(&record.id) {
                ids.push(record.id.clone());
            }
        }
        ids
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IngestFailure {
    StoreUnreadable(String),
    EmptyStore,
    NoSpace,
    Sync(String),
    ArchiveCollision { target: PathBuf, staged: Sha256Digest, existing: Sha256Digest },
    /// A source or archive path outside its root or through a link: exit 3, `path_escape`.
    PathEscape(PathBuf),
    HelperVersion { found: u32 },
    Ledger(LedgerError),
    Archive(String),
    Recorder(String),
}

impl IngestFailure {
    pub fn message(&self) -> String {
        match self {
            IngestFailure::StoreUnreadable(detail) => format!("the recordings directory is unreadable: {detail}"),
            IngestFailure::EmptyStore => "the recordings directory holds no recording where it held some before".into(),
            IngestFailure::NoSpace => "no space left in the audio store".into(),
            IngestFailure::Sync(detail) => format!("could not sync the archive: {detail}"),
            IngestFailure::ArchiveCollision { target, .. } => {
                format!("{} exists with different content (archive_collision)", target.display())
            }
            IngestFailure::PathEscape(path) => format!("{} escapes its root (path_escape)", path.display()),
            IngestFailure::HelperVersion { found } => format!("helper major {found} is incompatible (helper_version)"),
            IngestFailure::Ledger(error) => format!("ledger failure: {error:?}"),
            IngestFailure::Archive(detail) => format!("archive failure: {detail}"),
            IngestFailure::Recorder(detail) => format!("source failure: {detail}"),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IngestError {
    pub failure: IngestFailure,
    pub completed: Vec<RecordingId>,
    pub log: Vec<String>,
}

impl<R, A, L, C, T, N> Ingest<'_, R, A, L, C, T, N>
where
    R: RecorderStore,
    A: Archive,
    L: RecordingLedger,
    C: Clock,
    T: Trash + ?Sized,
    N: Notifier + ?Sized,
{
    pub fn run(&self, mode: &Mode) -> Result<IngestReport, Box<IngestError>> {
        let mut report = IngestReport::default();
        match self.sweep(mode, &mut report) {
            Ok(()) => Ok(report),
            Err(failure) => {
                if !mode.dry_run {
                    let at = self.clock.now();
                    self.notifier.deliver(&Notification::failed(EventKind::IngestFailed, failure.message(), at));
                    report.log.extend(self.notifier.take_diagnostics());
                }
                Err(Box::new(IngestError { failure, completed: report.completed(), log: report.log }))
            }
        }
    }

    fn sweep(&self, mode: &Mode, report: &mut IngestReport) -> Result<(), IngestFailure> {
        if !mode.dry_run {
            self.recorder.refresh_titles().map_err(candidate::recorder_failure)?;
        }
        let candidates = match &mode.once {
            Some(path) => vec![self.recorder.candidate(path).map_err(candidate::recorder_failure)?],
            None => self.recorder.candidates().map_err(candidate::recorder_failure)?,
        };
        for candidate in &candidates {
            self.process(candidate, mode, report)?;
        }
        Ok(())
    }
}
```

`crates/vpt-application/src/ingest/candidate.rs`:

```rust
//! One candidate: the pre-open decision, the descriptor, then staging.

use super::{Ingest, IngestFailure, IngestReport, Mode};
use crate::ports::{Archive, Candidate, Clock, LedgerError, Notifier, RecorderError, RecorderStore, RecordingLedger, SeenRow, Trash};
use vpt_domain::sweep::{CandidateFacts, PreOpen, SeenFacts, pre_open};
use vpt_domain::time::UtcInstant;

impl<R, A, L, C, T, N> Ingest<'_, R, A, L, C, T, N>
where
    R: RecorderStore,
    A: Archive,
    L: RecordingLedger,
    C: Clock,
    T: Trash + ?Sized,
    N: Notifier + ?Sized,
{
    pub(super) fn process(&self, candidate: &Candidate, mode: &Mode, report: &mut IngestReport) -> Result<(), IngestFailure> {
        let now = self.clock.now();
        let seen = self.ledger.seen(&candidate.path).map_err(IngestFailure::Ledger)?;
        let facts = CandidateFacts { size: candidate.size, mtime: candidate.mtime, flags: candidate.flags };
        let seen_facts = seen.as_ref().map(|row| SeenFacts {
            size: row.size,
            mtime: row.mtime,
            ingested: row.recording.is_some() && row.deferral_reason.is_none(),
            deferred_size: row.deferred_size,
        });
        let seen = match pre_open(&facts, seen_facts.as_ref()) {
            PreOpen::Unchanged => match seen {
                Some(row) => return self.unchanged(row, now, mode, report),
                None => None,
            },
            PreOpen::Dataless | PreOpen::Open => seen,
        };
        let handle = self.recorder.open(&candidate.path).map_err(recorder_failure)?;
        let metadata = self.recorder.metadata(&handle).map_err(recorder_failure)?;
        self.stage_and_publish(candidate, &handle, &metadata, seen, now, mode, report)
    }

    /// An ingested entry whose triple did not move: only its liveness is refreshed.
    pub(super) fn unchanged(&self, mut row: SeenRow, now: UtcInstant, mode: &Mode, report: &mut IngestReport) -> Result<(), IngestFailure> {
        report.skipped += 1;
        if mode.dry_run {
            return Ok(());
        }
        row.last_seen = now;
        row.source_gone_at = None;
        self.ledger.record_seen(&row).map_err(IngestFailure::Ledger)
    }
}

pub(super) fn recorder_failure(error: RecorderError) -> IngestFailure {
    match error {
        RecorderError::Escape(path) | RecorderError::NotRegular(path) => IngestFailure::PathEscape(path),
        RecorderError::Unreadable(detail) => IngestFailure::StoreUnreadable(detail),
        RecorderError::NotFound(path) => IngestFailure::Recorder(format!("{} is not a recording", path.display())),
        RecorderError::Io(detail) => IngestFailure::Recorder(detail),
    }
}

pub(super) fn fresh_seen(candidate: &Candidate, now: UtcInstant) -> SeenRow {
    SeenRow {
        path: candidate.path.clone(),
        file_name: candidate.file_name.clone(),
        size: candidate.size,
        mtime: candidate.mtime,
        flags: candidate.flags,
        first_seen: now,
        last_seen: now,
        deferral_count: 0,
        deferral_reason: None,
        deferred_size: None,
        source_gone_at: None,
        recording: None,
    }
}

pub(super) fn ledger_failure(error: LedgerError) -> IngestFailure {
    IngestFailure::Ledger(error)
}
```

`crates/vpt-application/src/ingest/publish.rs`:

```rust
//! Stage, verify, hash, publish, commit; and the owned cleanup on every
//! exit before publication.

use super::candidate::{fresh_seen, ledger_failure, recorder_failure};
use super::{Ingest, IngestFailure, IngestReport, Mode};
use crate::ports::{
    Archive, ArchiveError, Candidate, Clock, LedgerCommit, Notifier, Published, RecorderStore, RecordingLedger, RecordingRecord,
    SeenRow, SourceMetadata, StageStates, TitleLookup, TitleOrigin, Trash, TrashError,
};
use std::path::Path;
use vpt_domain::container::{Container, ContainerError, inspect};
use vpt_domain::identity::RecordingId;
use vpt_domain::time::UtcInstant;

impl<R, A, L, C, T, N> Ingest<'_, R, A, L, C, T, N>
where
    R: RecorderStore,
    A: Archive,
    L: RecordingLedger,
    C: Clock,
    T: Trash + ?Sized,
    N: Notifier + ?Sized,
{
    #[allow(clippy::too_many_arguments)]
    pub(super) fn stage_and_publish(
        &self,
        candidate: &Candidate,
        handle: &R::Handle,
        metadata: &SourceMetadata,
        seen: Option<SeenRow>,
        now: UtcInstant,
        mode: &Mode,
        report: &mut IngestReport,
    ) -> Result<(), IngestFailure> {
        let staged = match self.archive.stage(|directory, directory_identity, name| self.recorder.clone_into(handle, directory, directory_identity, name)) {
            Ok(staged) => staged,
            Err(failure) => return Err(self.abandon(failure.owned_staging.as_deref(), archive_failure(failure.cause), report)),
        };
        let after = self.owned(&staged.path, self.recorder.metadata(handle).map_err(recorder_failure), report)?;
        if after != *metadata {
            self.discard(&staged.path, report)?;
            return Err(IngestFailure::Recorder("the source changed while it was staged".into()));
        }
        let container = match self.owned(&staged.path, self.inspect_archive(&staged.path), report)? {
            Ok(container) => container,
            Err(error) => {
                self.discard(&staged.path, report)?;
                return Err(IngestFailure::Archive(format!("staged container invalid: {error:?}")));
            }
        };
        let offset = self.clock.offset_at(container.creation_time);
        let Ok(id) = RecordingId::derive(container.creation_time, offset, &staged.digest) else {
            self.discard(&staged.path, report)?;
            return Err(IngestFailure::Archive("capture instant unrepresentable".into()));
        };
        if !staged.copy_on_write {
            report.log.push(format!("{}: the archive is not copy-on-write", candidate.file_name));
        }
        let _ = mode;
        match self.archive.publish(&staged.path, &format!("{id}.m4a")) {
            Ok(Published::Placed(audio_path)) => {
                let (title, title_source) = lookup_title(self.recorder.title(&candidate.file_name));
                let record = RecordingRecord {
                    id,
                    source_path: Some(candidate.path.clone()),
                    digest: staged.digest,
                    captured_at: container.creation_time,
                    captured_offset: offset,
                    duration_secs: container.duration_secs,
                    title,
                    title_source,
                    ingested_at: now,
                    audio_path,
                    stages: StageStates::fresh(),
                    audio_trashed_at: None,
                };
                let batch = LedgerCommit {
                    seen: vec![ingested_seen(candidate, seen, &record.id, now)],
                    recordings: vec![record.clone()],
                    publications: vec![],
                };
                self.ledger.commit(&batch).map_err(ledger_failure)?;
                report.ingested.push(record);
                Ok(())
            }
            Ok(Published::Exists(audio_path)) => {
                self.discard(&staged.path, report)?;
                Err(IngestFailure::Archive(format!("{} exists", audio_path.display())))
            }
            Err(ArchiveError::PlacedUnsynced(target)) => Err(IngestFailure::Sync(format!("{} placed, directory not synced", target.display()))),
            Err(error) => Err(self.abandon(Some(&staged.path), archive_failure(error), report)),
        }
    }

    /// The wholeness gate over an archive file through the archive's own reads.
    pub(super) fn inspect_archive(&self, path: &Path) -> Result<Result<Container, ContainerError>, IngestFailure> {
        let handle = self.archive.open(path).map_err(archive_failure)?;
        let len = self.archive.size(&handle).map_err(archive_failure)?;
        Ok(inspect(len, |offset, buf| self.archive.read_at(&handle, offset, buf)))
    }

    /// A step after staging: on failure the staged file is this run's to clean up.
    pub(super) fn owned<V>(&self, staged: &Path, outcome: Result<V, IngestFailure>, report: &mut IngestReport) -> Result<V, IngestFailure> {
        outcome.map_err(|failure| self.abandon(Some(staged), failure, report))
    }

    /// Trash what this run owns, then hand back the failure that ended it.
    pub(super) fn abandon(&self, owned: Option<&Path>, failure: IngestFailure, report: &mut IngestReport) -> IngestFailure {
        if let Some(path) = owned
            && let Err(cleanup) = self.discard(path, report)
        {
            report.log.push(cleanup.message());
        }
        failure
    }

    /// Move a staged file to the Trash; when that cannot happen the file
    /// stays at mode 0600 and the log says cleanup is pending.
    pub(super) fn discard(&self, staged: &Path, report: &mut IngestReport) -> Result<(), IngestFailure> {
        self.archive.validate_trash_path(staged).map_err(archive_failure)?;
        let result = self.trash.trash(staged);
        report.log.extend(self.trash.take_diagnostics());
        if let Err(error) = result {
            if let TrashError::HelperVersion { found } = error {
                report.log.push(format!("{}: staged file kept at mode 0600, cleanup pending (helper version)", staged.display()));
                return Err(IngestFailure::HelperVersion { found });
            }
            let reason = match error {
                TrashError::HelperAbsent => "helper absent",
                TrashError::HelperVersion { .. } => "helper version",
                TrashError::Failed(_) => "trash failed",
                TrashError::Unknown(_) => "trash reply unknown",
            };
            report.log.push(format!("{}: staged file kept at mode 0600, cleanup pending ({reason})", staged.display()));
        }
        Ok(())
    }
}

pub(super) fn archive_failure(error: ArchiveError) -> IngestFailure {
    match error {
        ArchiveError::NoSpace => IngestFailure::NoSpace,
        ArchiveError::Sync(detail) => IngestFailure::Sync(detail),
        ArchiveError::PlacedUnsynced(target) => IngestFailure::Sync(format!("{} placed, directory not synced", target.display())),
        ArchiveError::Escape(path) => IngestFailure::PathEscape(path),
        ArchiveError::Io(detail) => IngestFailure::Archive(detail),
    }
}

pub(super) fn lookup_title(lookup: TitleLookup) -> (Option<String>, TitleOrigin) {
    match lookup {
        TitleLookup::Titled(title) => (Some(title), TitleOrigin::VoiceMemos),
        TitleLookup::Unavailable => (None, TitleOrigin::Unavailable),
    }
}

pub(super) fn ingested_seen(candidate: &Candidate, seen: Option<SeenRow>, id: &RecordingId, now: UtcInstant) -> SeenRow {
    let mut row = seen.unwrap_or_else(|| fresh_seen(candidate, now));
    row.size = candidate.size;
    row.mtime = candidate.mtime;
    row.flags = candidate.flags;
    row.last_seen = now;
    row.deferral_count = 0;
    row.deferral_reason = None;
    row.deferred_size = None;
    row.source_gone_at = None;
    row.recording = Some(id.clone());
    row
}
```

The `let _ = mode;` line holds the parameter until Task 20 turns the two staged gates into deferrals that
honour the mode; it is deleted there. A ledger failure after `Placed` leaves the archive file at its
final name, where the next sweep's recovery (Task 22) finds it, so nothing is trashed on that path.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters --test ingest_sweep --test ingest_titles`

Expected: 4 sweep tests and 2 title-sweep tests PASS. Run
`cargo clippy --workspace --all-targets --features dev-tools -- -D warnings` and expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(ingest): archive a whole recording under its identity"
```

______________________________________________________________________

