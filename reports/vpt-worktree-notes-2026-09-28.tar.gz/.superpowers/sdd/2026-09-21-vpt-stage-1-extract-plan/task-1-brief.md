### Task 1: Workspace scaffold and `vpt --version`

**Files:**

- Create: `Cargo.toml`, `rust-toolchain.toml`, `README.md`, `justfile`, `.github/workflows/ci.yml`
- Create: `crates/vpt-domain/Cargo.toml`, `crates/vpt-domain/src/lib.rs`
- Create: `crates/vpt-application/Cargo.toml`, `crates/vpt-application/src/lib.rs`
- Create: `crates/vpt-protocol/Cargo.toml`, `crates/vpt-protocol/src/lib.rs`
- Create: `crates/vpt-adapters/Cargo.toml`, `crates/vpt-adapters/src/lib.rs`
- Create: `crates/vpt/Cargo.toml`, `crates/vpt/src/main.rs`, `crates/vpt/src/lib.rs`,
  `crates/vpt/src/cli/mod.rs`, `crates/vpt/src/cli/args.rs`, `crates/vpt/src/commands/mod.rs`,
  `crates/vpt/src/commands/version.rs`
- Test: `crates/vpt/tests/support/mod.rs`, `crates/vpt/tests/version.rs`, `crates/vpt/tests/usage.rs`

**Interfaces:**

- Consumes: nothing.

- Produces: `vpt::run() -> !` (the crate's only public item; `cli` and `commands` are private modules);
  `cli::args::{Verb, Invocation { pub verb: Verb, pub json: bool,`
  `pub config: Option<PathBuf> }, UsageError(pub String),`
  `parse(args: impl IntoIterator<Item = OsString>) -> Result<Invocation, UsageError>,` `USAGE: &str}`;
  `commands::version::{VERSION: &str, document(helper_version: Option<&str>) ->`
  `serde_json::Value, human(helper_version: Option<&str>) -> String}`; the test harness
  `support::{VPT: &str, Sandbox::new(name: &str) -> Sandbox, Sandbox::path(&self) ->`
  `&Path, Sandbox::config_path(&self) -> PathBuf, Sandbox::vpt(&self) ->`
  `std::process::Command, run(command: &mut Command) -> Output, stdout(output: &Output) ->`
  `String, stderr(output: &Output) -> String}`.

- [ ] **Step 1: Write the failing acceptance test**

`crates/vpt/tests/support/mod.rs`:

```rust
//! The sandbox every binary test runs in: a private HOME and config, and a PATH
//! holding nothing but what the test puts there. Env rides on the Command, never
//! on the process, because the test binary is threaded.

#![allow(dead_code)]

use std::path::{Path, PathBuf};
use std::process::{Command, Output};

pub const VPT: &str = env!("CARGO_BIN_EXE_vpt");

pub struct Sandbox {
    root: PathBuf,
}

impl Sandbox {
    pub fn new(name: &str) -> Self {
        let root = std::env::temp_dir().join(format!("vpt-{}-{name}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        for leaf in ["home", "config", "data", "state", "bin", "voice-memos/Recordings"] {
            std::fs::create_dir_all(root.join(leaf)).expect("sandbox leaf");
        }
        let root = root.canonicalize().expect("canonical sandbox root");
        Sandbox { root }
    }

    pub fn path(&self) -> &Path {
        &self.root
    }

    pub fn config_path(&self) -> PathBuf {
        self.root.join("config/vpt/config.toml")
    }

    pub fn vpt(&self) -> Command {
        let mut command = Command::new(VPT);
        command
            .env_clear()
            .env("HOME", self.root.join("home"))
            .env("XDG_CONFIG_HOME", self.root.join("config"))
            .env("XDG_DATA_HOME", self.root.join("data"))
            .env("XDG_STATE_HOME", self.root.join("state"))
            .env("VPT_CONFIG", self.config_path())
            .env("PATH", self.root.join("bin"));
        command
    }
}

pub fn run(command: &mut Command) -> Output {
    command.output().expect("vpt spawned")
}

pub fn stdout(output: &Output) -> String {
    String::from_utf8_lossy(&output.stdout).into_owned()
}

pub fn stderr(output: &Output) -> String {
    String::from_utf8_lossy(&output.stderr).into_owned()
}
```

`crates/vpt/tests/version.rs`:

```rust
mod support;

use support::{Sandbox, run, stdout};

#[test]
fn version_reports_the_crate_version_and_no_helper_when_the_path_is_empty() {
    let sandbox = Sandbox::new("version-json");

    let output = run(sandbox.vpt().args(["--version", "--json"]));

    assert_eq!(output.status.code(), Some(0));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["schema"], "vpt.result/1");
    assert_eq!(document["command"], "version");
    assert_eq!(document["version"], env!("CARGO_PKG_VERSION"));
    assert!(document["helper_version"].is_null());
}

#[test]
fn version_without_json_prints_one_human_line() {
    let sandbox = Sandbox::new("version-human");

    let output = run(sandbox.vpt().arg("--version"));

    assert_eq!(output.status.code(), Some(0));
    assert_eq!(stdout(&output), format!("vpt {} (helper absent)\n", env!("CARGO_PKG_VERSION")));
}
```

`crates/vpt/tests/usage.rs`:

```rust
mod support;

use support::{Sandbox, run, stderr, stdout};

#[test]
fn an_unknown_verb_prints_usage_to_stderr_and_exits_2() {
    let sandbox = Sandbox::new("usage-unknown");

    let output = run(sandbox.vpt().arg("transcode"));

    assert_eq!(output.status.code(), Some(2));
    assert_eq!(stdout(&output), "");
    let err = stderr(&output);
    assert!(err.starts_with("vpt: unknown verb transcode\n"), "{err}");
    assert!(err.contains("usage: vpt"), "{err}");
}
```

`crates/vpt/src/cli/args.rs` starts as its test module alone; Step 3 adds the code above it:

```rust
//! Argument decoding. Hand rolled: nine verbs and four flags do not justify a parser crate.

#[cfg(test)]
mod tests {
    use super::*;
    use std::ffi::OsString;
    use std::path::PathBuf;

    fn parsed(line: &str) -> Result<Invocation, UsageError> {
        parse(std::iter::once(OsString::from("vpt")).chain(line.split(' ').map(OsString::from)))
    }

    #[test]
    fn json_and_config_are_global_flags_in_any_position() {
        let invocation = parsed("ingest --json --config /tmp/c.toml --dry-run").expect("parsed");
        assert!(invocation.json);
        assert_eq!(invocation.config, Some(PathBuf::from("/tmp/c.toml")));
        assert_eq!(invocation.verb, Verb::Ingest { dry_run: true, once: None });
    }

    #[test]
    fn an_unknown_verb_is_a_usage_error_naming_it() {
        assert_eq!(parsed("transcode"), Err(UsageError("unknown verb transcode".into())));
    }

    #[test]
    fn a_trailing_unknown_argument_is_refused() {
        assert_eq!(parsed("doctor --loud"), Err(UsageError("unexpected argument --loud".into())));
    }

    #[test]
    fn a_value_flag_without_a_value_is_refused() {
        assert_eq!(parsed("ingest --once"), Err(UsageError("--once needs a value".into())));
    }
}
```

- [ ] **Step 2: Create the workspace so the tests can compile, then run them to verify they fail**

`Cargo.toml`:

```toml
[workspace]
resolver = "3"
default-members = ["crates/vpt"]
members = [
  "crates/vpt-adapters",
  "crates/vpt-application",
  "crates/vpt",
  "crates/vpt-domain",
  "crates/vpt-protocol",
]
```

`rust-toolchain.toml`:

```toml
# Every crate builds on stable. rustup reads this file from the current
# directory upward, so a builder that runs cargo from this checkout gets stable
# whatever its default toolchain is.
[toolchain]
channel = "stable"
```

`crates/vpt-domain/Cargo.toml`:

```toml
# vpt-domain: vpt policy as total functions of their arguments.
#
# No workspace dependencies and no infrastructure dependency: nothing here reads
# a file, opens a database, parses TOML or JSON, spawns a process or asks the
# clock. A caller hands it an observation and it answers.

[package]
name = "vpt-domain"
version = "0.1.0"
edition = "2024"

[features]
fixtures = []
```

`crates/vpt-domain/src/lib.rs`:

```rust
//! Pure policy: identity, the wholeness gate, sweep gates, retention and value types.
```

`crates/vpt-application/Cargo.toml`:

```toml
# vpt-application: one concrete use case per verb, and the ports they own.
#
# Depends on vpt-domain and on nothing else in the workspace. A use case names
# the external capability it needs as a trait it declares itself, and an adapter
# implements that trait from the outside.

[package]
name = "vpt-application"
version = "0.1.0"
edition = "2024"

[dependencies]
vpt-domain = { path = "../vpt-domain" }
```

`crates/vpt-application/src/lib.rs`:

```rust
//! Use cases and the ports they own.
```

`crates/vpt-protocol/Cargo.toml`:

```toml
# vpt-protocol: the versioned documents that cross a process boundary.
#
# No workspace dependencies, including vpt-domain: this is what a command engine,
# an agent command or a notify command reads and writes, and the internal model
# must not leak into it. Translation lives in the adapters.

[package]
name = "vpt-protocol"
version = "0.1.0"
edition = "2024"

[dependencies]
serde = { version = "1.0.229", features = ["derive"] }
serde_json = "1.0.151"
```

`crates/vpt-protocol/src/lib.rs`:

```rust
//! The versioned JSON documents vpt reads and writes across a process boundary.
```

`crates/vpt-adapters/Cargo.toml`:

```toml
# vpt-adapters: everything concrete, organized by the capability it provides.
#
# Depends inward only: on the ports in vpt-application, the policy in
# vpt-domain and the documents in vpt-protocol. Only the command crate depends
# on this one.

[package]
name = "vpt-adapters"
version = "0.1.0"
edition = "2024"

[dependencies]
vpt-application = { path = "../vpt-application" }
vpt-domain = { path = "../vpt-domain" }
vpt-protocol = { path = "../vpt-protocol" }

libc = "0.2.189"
rusqlite = { version = "=0.39.0", default-features = false, features = [
  "bundled",
] }
serde_json = "1.0.151"
sha2 = "0.11.0"
toml = { version = "1.1.4", default-features = false, features = [
  "parse",
  "serde",
  "std",
] }

[dev-dependencies]
tempfile = "3.27.0"
vpt-domain = { path = "../vpt-domain", features = ["fixtures"] }
```

`crates/vpt-adapters/src/lib.rs`:

```rust
//! Concrete adapters: filesystem, SQLite, processes and configuration.
```

`crates/vpt/Cargo.toml`:

```toml
# vpt: argument decoding, exit codes and composition. The binary keeps the
# tool's name because every caller invokes it by that name.

[package]
name = "vpt"
version = "0.1.0"
edition = "2024"

[[bin]]
name = "vpt"
path = "src/main.rs"

# The fake helper and fake command used by the tests are feature gated so that
# `cargo install --git <url> vpt` installs only vpt.
[features]
dev-tools = []

[[bin]]
name = "vpt-fake-engine"
path = "src/bin/vpt-fake-engine.rs"
required-features = ["dev-tools"]

[dependencies]
vpt-adapters = { path = "../vpt-adapters" }
vpt-application = { path = "../vpt-application" }
vpt-domain = { path = "../vpt-domain" }
vpt-protocol = { path = "../vpt-protocol" }

serde_json = "1.0.151"

[dev-dependencies]
rusqlite = { version = "=0.39.0", default-features = false, features = [
  "bundled",
] }
vpt-domain = { path = "../vpt-domain", features = ["fixtures"] }
```

`crates/vpt/src/bin/vpt-fake-engine.rs` (Task 24 fills it; the file must exist for the manifest):

```rust
fn main() {
    eprintln!("vpt-fake-engine: no subcommand yet");
    std::process::exit(2);
}
```

`crates/vpt/src/main.rs`:

```rust
fn main() {
    vpt::run();
}
```

`crates/vpt/src/lib.rs`:

```rust
//! The command crate: parse, dispatch, emit, exit. No policy lives here.

mod cli;
mod commands;

pub fn run() -> ! {
    std::process::exit(2);
}
```

`crates/vpt/src/cli/mod.rs`:

```rust
pub(crate) mod args;
```

`crates/vpt/src/commands/mod.rs`:

```rust
pub(crate) mod version;
```

`crates/vpt/src/commands/version.rs` starts as one line, `//! \`vpt --version\`.`, and `args.rs\` is the
test module written in Step 1. Every module is declared before the red run so the test modules are
compiled and selected; a run that selects zero tests, or that succeeds, does not satisfy this step.

Run: `cargo test -p vpt --test version --test usage`

Expected: all three acceptance tests FAIL, `assertion failed: left: Some(2), right: Some(0)` for the two
version tests (the binary exits 2 before parsing anything) and the usage test on its
`starts_with("vpt: unknown verb transcode")` assertion.

Run: `cargo test -p vpt --lib`

Expected: the build of the `args::tests` module fails with `cannot find` for `parse`, `Invocation`,
`UsageError` and `Verb`: the module is compiled and its four tests are what the code must satisfy.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt/src/cli/args.rs`, above the test module:

```rust
//! Argument decoding. Hand rolled: nine verbs and four flags do not justify a parser crate.

use std::ffi::OsString;
use std::path::PathBuf;

pub const USAGE: &str = "usage: vpt [--json] [--config <file>] <verb>\n\
verbs: setup [--force] | doctor | ingest [--dry-run] [--once <path>] | show <id> |\n\
       list [--stage <stage>] | storage | retention run [--dry-run] |\n\
       symlink deploy | symlink verify | --version\n";

#[derive(Debug, PartialEq, Eq)]
pub enum Verb {
    Version,
    Setup { force: bool },
    Doctor,
    Ingest { dry_run: bool, once: Option<PathBuf> },
    Show { id: String },
    List { stage: Option<String> },
    Storage,
    RetentionRun { dry_run: bool },
    SymlinkDeploy,
    SymlinkVerify,
}

#[derive(Debug, PartialEq, Eq)]
pub struct Invocation {
    pub verb: Verb,
    pub json: bool,
    pub config: Option<PathBuf>,
}

#[derive(Debug, PartialEq, Eq)]
pub struct UsageError(pub String);

pub fn parse(args: impl IntoIterator<Item = OsString>) -> Result<Invocation, UsageError> {
    let mut words: Vec<String> = args
        .into_iter()
        .skip(1)
        .map(|word| word.to_string_lossy().into_owned())
        .collect();
    let json = take_flag(&mut words, "--json");
    let config = take_value(&mut words, "--config")?.map(PathBuf::from);
    let verb = parse_verb(&mut words)?;
    if let Some(extra) = words.first() {
        return Err(UsageError(format!("unexpected argument {extra}")));
    }
    Ok(Invocation { verb, json, config })
}

fn parse_verb(words: &mut Vec<String>) -> Result<Verb, UsageError> {
    if words.is_empty() {
        return Err(UsageError("a verb is required".into()));
    }
    let first = words.remove(0);
    match first.as_str() {
        "--version" => Ok(Verb::Version),
        "setup" => Ok(Verb::Setup { force: take_flag(words, "--force") }),
        "doctor" => Ok(Verb::Doctor),
        "ingest" => Ok(Verb::Ingest {
            dry_run: take_flag(words, "--dry-run"),
            once: take_value(words, "--once")?.map(PathBuf::from),
        }),
        "show" => Ok(Verb::Show { id: take_positional(words, "<id>")? }),
        "list" => Ok(Verb::List { stage: take_value(words, "--stage")? }),
        "storage" => Ok(Verb::Storage),
        "retention" => match take_positional(words, "run")?.as_str() {
            "run" => Ok(Verb::RetentionRun { dry_run: take_flag(words, "--dry-run") }),
            other => Err(UsageError(format!("unknown retention subcommand {other}"))),
        },
        "symlink" => match take_positional(words, "deploy|verify")?.as_str() {
            "deploy" => Ok(Verb::SymlinkDeploy),
            "verify" => Ok(Verb::SymlinkVerify),
            other => Err(UsageError(format!("unknown symlink subcommand {other}"))),
        },
        other => Err(UsageError(format!("unknown verb {other}"))),
    }
}

fn take_flag(words: &mut Vec<String>, flag: &str) -> bool {
    match words.iter().position(|word| word == flag) {
        Some(index) => {
            words.remove(index);
            true
        }
        None => false,
    }
}

fn take_value(words: &mut Vec<String>, flag: &str) -> Result<Option<String>, UsageError> {
    let Some(index) = words.iter().position(|word| word == flag) else {
        return Ok(None);
    };
    if index + 1 >= words.len() || words[index + 1].starts_with("--") {
        return Err(UsageError(format!("{flag} needs a value")));
    }
    words.remove(index);
    Ok(Some(words.remove(index)))
}

fn take_positional(words: &mut Vec<String>, name: &str) -> Result<String, UsageError> {
    if words.is_empty() || words[0].starts_with("--") {
        return Err(UsageError(format!("{name} is required")));
    }
    Ok(words.remove(0))
}
```

The test module of Step 1 stays below this code, unchanged. `crates/vpt/src/commands/version.rs`:

```rust
//! `vpt --version`: the crate version and the helper's, when one answers.

use serde_json::{Value, json};

pub const VERSION: &str = env!("CARGO_PKG_VERSION");

pub fn document(helper_version: Option<&str>) -> Value {
    json!({
        "schema": "vpt.result/1",
        "command": "version",
        "version": VERSION,
        "helper_version": helper_version,
    })
}

pub fn human(helper_version: Option<&str>) -> String {
    match helper_version {
        Some(helper) => format!("vpt {VERSION} (helper {helper})\n"),
        None => format!("vpt {VERSION} (helper absent)\n"),
    }
}
```

`crates/vpt/src/lib.rs`:

```rust
//! The command crate: parse, dispatch, emit, exit. No policy lives here.

mod cli;
mod commands;

use cli::args::{Invocation, Verb, parse};
use std::io::Write;

pub fn run() -> ! {
    let code = match parse(std::env::args_os()) {
        Ok(invocation) => dispatch(&invocation),
        Err(error) => {
            eprint!("vpt: {}\n{}", error.0, cli::args::USAGE);
            2
        }
    };
    std::process::exit(code);
}

fn dispatch(invocation: &Invocation) -> i32 {
    match &invocation.verb {
        Verb::Version => {
            let text = if invocation.json {
                format!("{}\n", commands::version::document(None))
            } else {
                commands::version::human(None)
            };
            let _ = std::io::stdout().write_all(text.as_bytes());
            0
        }
        _ => {
            eprint!("vpt: verb not implemented yet\n{}", cli::args::USAGE);
            2
        }
    }
}
```

`README.md`:

```markdown
# vpt

The Voice Processing Tool: it archives the voice memos Apple's Voice Memos syncs to a Mac, transcribes
them, and writes Markdown notes. The design is `docs/superpowers/specs/2026-09-20-vpt-design.md`.

## Install

Two steps, both required for the Apple speech engine, desktop notifications and the Trash:

1. `cargo install --git https://github.com/webdavis/vpt vpt` installs `vpt` into `~/.cargo/bin`.
2. `cd helper/vpt-macos && swift build -c release` builds `vpt-macos`; copy
   `.build/release/vpt-macos` beside `vpt` (into `~/.cargo/bin`).

Then `vpt setup` writes the configuration and `vpt doctor` reports what it found.
```

`justfile`:

```just
# The gates, in CI order. `just ship` runs them all.

fmt:
  cargo fmt --all -- --check

clippy:
  cargo clippy --locked --workspace --all-targets --features dev-tools -- -D warnings

test:
  cargo test --locked --workspace --no-fail-fast --features dev-tools

doc:
  RUSTDOCFLAGS="-D warnings" cargo doc --locked --workspace --no-deps

gitleaks:
  gitleaks git --no-banner

# Physical lines after rustfmt, implementation lines before the first
# #[cfg(test)]. A file over 500 total fails; 200 implementation and 300 total
# are warnings.
file-size:
  #!/usr/bin/env bash
  set -euo pipefail
  status=0
  while IFS= read -r f; do
    read -r impl total < <(awk '
      /^[[:space:]]*#\[cfg\(test\)\]/ && !seen { seen = 1 }
      !seen { impl++ }
      { total++ }
      END {
        if (FILENAME ~ /(^|\/)tests(\.rs|\/)/) impl = 0
        printf "%d %d\n", impl, total
      }' "$f")
    if (( total > 500 )); then
      printf 'FAIL %5d total %s\n' "$total" "$f"
      status=1
    elif (( total > 300 || impl > 200 )); then
      printf 'WARN %5d impl %5d total %s\n' "$impl" "$total" "$f"
    fi
  done < <(git ls-files 'crates/*.rs' 'crates/**/*.rs')
  exit "$status"

ship: fmt clippy test doc gitleaks file-size
```

`.github/workflows/ci.yml`:

```yaml
name: CI
on:
  push:
    branches:
      - main
  pull_request:
permissions:
  contents: read
jobs:
  gates:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1
        with:
          persist-credentials: false
      - name: Install just and gitleaks
        run: brew install gitleaks just
      - name: Toolchain
        run: rustup show active-toolchain
      - name: Format
        run: just fmt
      - name: Clippy
        run: just clippy
      - name: Test
        run: just test
      - name: Docs
        run: just doc
      - name: Secrets scan
        run: just gitleaks
      - name: File size
        run: just file-size
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt`

Expected: `test result: ok.` for the four unit tests in `args.rs`, the two tests in `version.rs` and the
one in `usage.rs`.

Run: `cargo fmt --all -- --check &&`
`cargo clippy --locked --workspace --all-targets --features dev-tools -- -D warnings`

Expected: no output from fmt; clippy finishes with `Finished` and no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add Cargo.toml Cargo.lock rust-toolchain.toml README.md justfile .github crates
SKIP_AI_COMMIT=1 git commit -m "feat: workspace scaffold and vpt --version"
```

______________________________________________________________________

