# D4 independent review

Verdict: Needs fixes. One important test-supervision finding blocks acceptance. No concrete D4 database implementation defect was identified in this review.

Reviewed on 2026-09-26 by the independent Astra reviewer against `3d5b18ed5701b505c68f0ad89fe3e160026ec1be`. The complete staged and unstaged database diff had SHA-256 `15c81b2c86beafe92c729a4a4aea4950888346075367e1d25c25b03a83c611fe`. The controller retains final acceptance and committed-HEAD verification.

## Finding 1: nested participants lose their deadline owner

Important, test environment. New calls at `crates/vpt-adapters/src/database/tests/wal/scenarios.rs:62`, `:94` and `:125` launch supervised participants from an already supervised scenario. The outer supervisor is created at `tests/wal.rs:57`. Every `child()` call executes `setsid()` at `tests/children.rs:57`, so the participant belongs to a different process group from its scenario parent.

When the outer 500 ms watchdog expires, `tests/children/process.rs:19` and `:25` signal the outer group, and its cleanup waits only for that direct child. Termination of the scenario parent does not unwind Rust or run the inner `ChildGuard` destructor. The nested group's signals and deadline were owned by that now-dead parent. An inner participant stalled during database setup before `ready()` therefore has no surviving supervisor that must terminate or reap it. Closing its input pipe only helps after it reaches the input read. The outer deadline also starts before the inner deadline, so the inner watchdog cannot establish this guarantee.

The affected paths are the four native interoperability cases and the three crash/recovery cases. The blast radius is synthetic test processes and the database descriptors or locks they retain. This finding does not establish a production database leak or explain the historical seven timeouts.

Evidence is the actual call and cleanup chain. No surviving child was observed or intentionally orphaned during this review. The existing busy-timeout mutant hangs the outer rooted transaction; it does not prove cleanup of a stalled nested participant. The controller accepted the source finding and assigned the implementation worker a controlled, test-first regression. That fixture must establish independent exact-process cleanup before inducing the stall and retain reaping evidence. The prior `task-6-terminal-cleanup-followup.md` explains why group disappearance alone does not prove a killed parent reaped a grandchild on macOS.

Required resolution: keep effective cleanup ownership for every participant through outer timeout, without increasing deadlines or introducing a general supervisor framework. Demonstrate the nested-stall regression failing for this ownership gap, then passing after the fix, with a compiled failing cleanup mutant and a restored passing control.

## Implementation review

I read the approved containment design, D4 execution brief and controller rulings, the execution report, all changed files, and the surrounding registration, owner, file, lock, callback and process support code. The clean-code and Rust skills guided boundary and test review. OWASP review traced containment inputs to retained-descriptor operations. Humanizer was applied to this report.

The primary protocol source was the locked `libsqlite3-sys` 0.37.0 SQLite 3.51.3 amalgamation. Its current SHA-256 matches the report: `9512509b1bccb7461f79bea8aad6280ae4699e925fa4804381b71f59e7efb0c5`. Source comparison covered lock flags at 1889, initialization at 44051, mapping at 44307, slots at 44485, barrier/unmap at 44685, close at 69258, and the retained read-only heap-index protocol at 69565.

- Slot bytes 120 through 127 and lifetime byte 128 match native SQLite. Checked flags and ranges reject shared/exclusive transitions. Independent descriptor ownership preserves another connection's locks.
- Initialization truncates to three bytes only after exclusive lifetime acquisition. A raced failed acquisition rechecks for an initialized shared holder. The read-only uninitialized owner retains its descriptor and slot capability, retries initialization on mapping, and never truncates.
- Mappings retain their original base and length, align offsets to the host page size, provision writable regions before use, and return stable raw pointers while owned. Read-only mappings use read protection. Explicit cleanup releases mappings before closing the shared-memory descriptor.
- The private `Rc<DatabaseFiles>` retains directory authority and the same connection-local fault slot without a cycle or added thread sharing. Filename and role checks still precede contained acquisition; the read-only WAL fallback is scoped to the required role and reports actual access flags.
- Callback translations preserve null outputs, arbitrary nonzero extension requests, contention and read-only protocol results. These outcomes do not poison the error latch. Persistent companions and observational no-checkpoint-on-close behavior remain distinct from writable checkpointing.

The 210-line shared-memory owner has one cohesive ownership responsibility and remains below the decomposition threshold. No dependency, public interface, or third-party implementation changed.

## Evidence and limits

The initial combined downstream implementation violated the intended order. It was removed, and the retained operation-specific compiling RED logs establish the subsequent redo. I inspected the reachable reset, initialization retry, read-only WAL-open and diagnostic RED/GREEN logs and the remaining behavior inventory. This accepts the corrected redo chronology; it does not turn the premature attempt into test-first evidence or extend D3's historical waiver.

All nine functional mutation patches, failure/control results and restoration hashes were inspected. They compiled, failed and returned to passing controls. The current shared-memory owner, mapping, callback and lock hashes match those restored controls. The three bounded-diagnostic mutations also compiled, failed and passed after restoration. No test, build, mutation or live probe ran in this reviewer lane.

The two-opener fixture exercises concurrent opening but does not force the lock-query-to-acquisition interleaving. Existing-holder tests and source review support the no-truncation invariant; deterministic proof of every race interleaving is absent.

Timing attempt 02 passed all 315 leaves and reduced the unchanged refusal leaf to 0.318 s while preserving its operations. The following stable ship attempt had seven 500 ms database watchdog failures. The later selected 106-leaf measurement passed but does not identify their cause or establish a repair. The refusal-fixture hard-link mutant validates retained sensitivity.

Fresh `task-D4-ship-final-20260926-01.log` passes all 194 adapter leaves, including the database cases, but fails four existing setup terminal leaves at `crates/vpt/tests/setup/terminal.rs:101` with an empty `prompt not observed` diagnostic. `task-D4-check-final-20260926-01.log` passes. No source evidence attributes those terminal failures to D4. The controller reports that nightly is unavailable in the current session, so historical nightly timings are not fresh final-state timing evidence.

Acceptance remains pending the supervision fix, its independent review, complete fresh gates, normal-hook commit and the controller's committed-HEAD checks. The report makes no claim that the historical timeout cause is fixed.
