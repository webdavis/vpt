import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
evidence = root / '.superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan'
prefix = 'crates/vpt-adapters/src/'
base = prefix + 'contained.rs'
files = prefix + 'contained/file.rs'
directory = prefix + 'contained/directory.rs'
rename = prefix + 'contained/rename.rs'
leaf = 'contained::tests::'
cases = []


def case(name, path, before, after, test, count=1):
    cases.append(dict(name=name, path=path, before=before, after=after, test=test, count=count))


case('leaf-depth', base, '(Some(Component::Normal(name)), None)', '(Some(Component::Normal(name)), _)', leaf + 'escapes_and_nested_paths_are_refused_naming_root_and_path')
case('root-component-link', base, 'libc::O_NOFOLLOW_ANY', 'libc::O_NOFOLLOW', leaf + 'a_root_must_be_a_directory_reached_through_no_link')
case('file-link', base, 'libc::O_NOFOLLOW | libc::O_CLOEXEC;', 'libc::O_CLOEXEC;', leaf + 'files::open_file_refuses_a_link_and_a_directory_at_the_leaf')
case('stat-link', files, 'libc::AT_SYMLINK_NOFOLLOW,', '0,', leaf + 'files::stat_judges_the_leaf_itself_and_regular_refuses_a_link')
case('regular-link', files, 'Kind::File => Ok(leaf)', 'Kind::File | Kind::Link => Ok(leaf)', leaf + 'files::stat_judges_the_leaf_itself_and_regular_refuses_a_link')
case('file-kind', files, 'if !file.metadata().map_err(|error| io(&leaf, error))?.is_file()', 'if !file.metadata().map_err(|error| io(&leaf, error))?.is_dir()', leaf + 'files::open_file_refuses_a_link_and_a_directory_at_the_leaf')
case('fifo-blocking', files, 'access | NO_FOLLOW | libc::O_NONBLOCK', 'access | NO_FOLLOW', leaf + 'fifo::opening_a_fifo_returns_not_regular_without_a_writer')
case('exclusive-create', files, 'libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL | NO_FOLLOW', 'libc::O_WRONLY | libc::O_CREAT | NO_FOLLOW', leaf + 'files::create_file_is_exclusive_and_sets_the_mode')
case('private-file-mode', files, 'Permissions::from_mode(mode)', 'Permissions::from_mode(0o644)', leaf + 'files::create_file_is_exclusive_and_sets_the_mode')
case('rename-exclusive', rename, 'self.rename(from, to, libc::RENAME_EXCL)', 'self.rename(from, to, 0)', leaf + 'files::rename_exclusive_keeps_an_existing_target_and_rename_over_replaces_it')
case('rename-effect', rename, 'self.rename(from, to, 0)', 'let _ = (from, to); Ok(())', leaf + 'files::rename_exclusive_keeps_an_existing_target_and_rename_over_replaces_it')
case('revalidation-identity', base, 'self.identity()? != current.identity()?', 'false && self.identity()? != current.identity()?', leaf + 'directory::revalidation_refuses_a_replaced_root_directory')
case('public-names-validation', directory, '        self.revalidate()?;\n', '', leaf + 'directory::revalidation_refuses_a_replaced_root_directory')
source = (root / directory).read_text()
start = source.index('    pub(super) fn retained_names(')
end = source.index('\n}\n\npub(super) fn entry_name', start)
path_enumeration = '''    pub(super) fn retained_names(&self) -> Result<Vec<String>, ContainedError> {
        let mut names = Vec::new();
        for entry in std::fs::read_dir(&self.path).map_err(|error| io(&self.path, error))? {
            let entry = entry.map_err(|error| io(&self.path, error))?;
            if let Ok(name) = entry.file_name().into_string() { names.push(name); }
        }
        names.sort();
        Ok(names)
    }'''
case('path-enumeration', directory, source[start:end], path_enumeration, leaf + 'directory::retained_enumeration_reads_the_original_directory_twice_after_path_substitution')
case('shared-directory-offset', directory, 'libc::openat(self.file.as_raw_fd(), c".".as_ptr(), flags)', 'libc::fcntl(self.file.as_raw_fd(), libc::F_DUPFD_CLOEXEC, 0)', leaf + 'directory::retained_enumeration_reads_the_original_directory_twice_after_path_substitution')
case('invalid-name', directory, 'name.to_str()\n        .ok()', 'Some(name.to_str().unwrap_or("invalid"))', leaf + 'directory::directory_names_skip_invalid_utf8_and_dot_entries')
case('dot-name', directory, '*name != "." && *name != ".."', '*name != "."', leaf + 'directory::directory_names_skip_invalid_utf8_and_dot_entries')
case('sorted-names', directory, 'names.sort();', 'names.sort_by(|left, right| right.cmp(left));', leaf + 'directory::names_lists_every_entry_sorted_and_sync_succeeds')
case('private-directory-mode', directory, '0o700', '0o755', leaf + 'directory::subdirectory_creates_0700_once_and_refuses_a_link_or_a_file', 2)
case('subdirectory-link', directory, 'libc::O_RDONLY | libc::O_DIRECTORY | NO_FOLLOW, 0', 'libc::O_RDONLY | libc::O_DIRECTORY, 0', leaf + 'directory::reading_a_subdirectory_creates_nothing_and_refuses_a_link')
source = (root / base).read_text()
start = source.index('    pub fn try_clone(')
end = source.index('    pub fn identity(', start)
case('clone-retained', base, source[start:end], '    pub fn try_clone(&self) -> Result<Self, ContainedError> { Self::open(&self.path) }\n', leaf + 'files::file_operations_stay_below_the_retained_root_after_substitution')
for field, before in [('mtime-seconds', 'mtime_secs: raw.st_mtime'), ('mtime-nanos', 'mtime_nanos: u32::try_from(raw.st_mtime_nsec).unwrap_or(0)'), ('flags', 'flags: raw.st_flags')]:
    case('stat-' + field, files, before, before.split(':')[0] + ': 0', leaf + 'files::stat_judges_the_leaf_itself_and_regular_refuses_a_link')
case('loader-checked-open', prefix + 'config/load.rs', 'root\n        .open_file(Path::new(name), Access::Read)\n        .map_err(|error| config_contained(path, error))?', 'std::fs::File::open(path).map_err(|error| config_io(path, error))?', 'config::load::contained_tests::a_configuration_leaf_symlink_is_refused')
case('root-creation-consumer', prefix + 'config/roots/directory.rs', 'directory.subdirectory(name).map(|_| ()).map_err(map)', 'let _ = (directory, name); Ok(())', 'config::roots::tests::creating_roots_refuses_a_link_added_after_resolution')
source = (root / files).read_text()
start = source.index('        let fd = unsafe {')
end = source.index('        opened(fd, leaf,', start)
case('file-open-retained', files, source[start:end], '        let fd = unsafe { libc::open(c_string(leaf)?.as_ptr(), flags, mode as libc::c_uint) };\n', leaf + 'files::file_operations_stay_below_the_retained_root_after_substitution')


def patch(path, before, after):
    diff = list(difflib.unified_diff(before.splitlines(True), after.splitlines(True)))[2:]
    body = ''.join('@@\n' if line.startswith('@@') else line for line in diff)
    result = subprocess.run(['apply_patch'], input=f'*** Begin Patch\n*** Update File: {path}\n{body}*** End Patch\n', text=True, capture_output=True)
    assert result.returncode == 0, result.stdout + result.stderr
    assert path.read_text() == after, 'exact on-disk bytes differ'


def run(item, label):
    build = ['cargo', 'test', '--locked', '-p', 'vpt-adapters', '--lib', '--no-run', '--message-format=json']
    compiled = subprocess.run(build, capture_output=True, text=True, timeout=60)
    build_log = evidence / f'task5a-{item["name"]}-{label}-build.log'
    build_log.write_text('$ ' + ' '.join(build) + '\n' + compiled.stdout + compiled.stderr + f'\nexit={compiled.returncode}\n')
    assert compiled.returncode == 0, f'{item["name"]}: compilation failed, {build_log}'
    artifacts = [json.loads(line) for line in compiled.stdout.splitlines() if line.startswith('{')]
    executable = next(entry['executable'] for entry in artifacts if entry.get('reason') == 'compiler-artifact' and entry.get('executable') and entry['target']['name'] == 'vpt_adapters')
    command = [executable, '--exact', item['test'], '--nocapture']
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True, text=True, timeout=5)
    elapsed = time.monotonic() - started
    output = result.stdout + result.stderr
    log = evidence / f'task5a-{item["name"]}-{label}.log'
    log.write_text('$ ' + ' '.join(command) + '\n' + output + f'\nexit={result.returncode} elapsed={elapsed:.6f}s\n')
    assert 'running 1 test' in output and item['test'] in output, f'{item["name"]}: leaf not selected'
    assert elapsed < 1, f'{item["name"]}: leaf exceeded one second'
    return dict(command=command, exit=result.returncode, elapsed=elapsed, log=str(log.relative_to(root)), build_log=str(build_log.relative_to(root)))


ledger_path = evidence / 'task5a-mutations-all.json'
ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else []
selected = set(sys.argv[1:])
for item in cases:
    if selected and item['name'] not in selected:
        continue
    path = root / item['path']
    original = path.read_text()
    assert original.count(item['before']) == item['count'], f'{item["name"]}: ambiguous mutation'
    mutant = original.replace(item['before'], item['after'])
    entry = dict(item)
    entry['original_sha256'] = hashlib.sha256(original.encode()).hexdigest()
    entry['mutant_sha256'] = hashlib.sha256(mutant.encode()).hexdigest()
    try:
        patch(path, original, mutant)
        entry['mutant'] = run(item, 'mutant')
    finally:
        if path.read_text() != original:
            patch(path, path.read_text(), original)
        entry['restored_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        assert entry['restored_sha256'] == entry['original_sha256']
        entry['control'] = run(item, 'control')
        ledger = [prior for prior in ledger if prior['name'] != item['name']] + [entry]
        ledger_path.write_text(json.dumps(ledger, indent=2) + '\n')
    assert entry['mutant']['exit'] == 101, f'{item["name"]}: mutant survived'
    assert entry['control']['exit'] == 0, f'{item["name"]}: restored control failed'
    print(f'{item["name"]}: compiled mutant 101 / identical control 0, {entry["mutant"]["elapsed"]:.3f}s / {entry["control"]["elapsed"]:.3f}s', flush=True)
