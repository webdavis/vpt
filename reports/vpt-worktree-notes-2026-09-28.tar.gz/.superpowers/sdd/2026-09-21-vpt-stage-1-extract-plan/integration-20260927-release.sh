#!/bin/bash
set -euo pipefail
umask 077

test "$#" -eq 0
release_lane=/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract
cd "$release_lane" || exit 2
release_evidence="$release_lane/.superpowers/integration-20260927/release"
test ! -e "$release_evidence"
mkdir -p "$release_evidence/home" "$release_evidence/config" \
  "$release_evidence/data" "$release_evidence/state" \
  "$release_evidence/cache" "$release_evidence/tmp"
release_manifest=.superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/integration-20260927-source.sha256
shasum -a 256 -c "$release_manifest" > "$release_evidence/hashes-before"
git -c core.fsmonitor=false rev-parse HEAD > "$release_evidence/head"
release_command=(
  /usr/bin/env -u RUST_TEST_THREADS -u CARGO_BUILD_JOBS -u RUSTUP_TOOLCHAIN
  DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
  "HOME=$release_evidence/home"
  "XDG_CONFIG_HOME=$release_evidence/config"
  "XDG_DATA_HOME=$release_evidence/data"
  "XDG_STATE_HOME=$release_evidence/state"
  "XDG_CACHE_HOME=$release_evidence/cache"
  "VPT_CONFIG=$release_evidence/config/vpt.toml"
  "TMPDIR=$release_evidence/tmp"
  CARGO_HOME=/Users/stephen/.cargo
  RUSTUP_HOME=/Users/stephen/.rustup
  RUSTUP_AUTO_INSTALL=0
  CARGO_NET_OFFLINE=true
  CARGO_TERM_COLOR=never
  "CARGO_TARGET_DIR=$release_lane/target"
  PATH=/Users/stephen/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin
  cargo build --locked --release
)
printf '%q ' "${release_command[@]}" > "$release_evidence/rust-command"
printf '\n' >> "$release_evidence/rust-command"
TIMEFORMAT='real_seconds=%R user_seconds=%U system_seconds=%S'
if { time "${release_command[@]}" > "$release_evidence/rust-stdout" 2> "$release_evidence/rust-stderr"; } 2> "$release_evidence/rust-timing"; then
  release_status=0
else
  release_status=$?
fi
printf 'exit_status=%s\n' "$release_status" > "$release_evidence/rust-result"
test "$release_status" -eq 0
release_command=(
  /usr/bin/env DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
  bash helper/vpt-macos/scripts/with-isolated-env.sh
  .build/isolated/scratch/release/vpt-macos --version
)
printf '%q ' "${release_command[@]}" > "$release_evidence/swift-command"
printf '\n' >> "$release_evidence/swift-command"
if "${release_command[@]}" > "$release_evidence/swift-stdout" 2> "$release_evidence/swift-stderr"; then
  release_status=0
else
  release_status=$?
fi
printf 'exit_status=%s\n' "$release_status" > "$release_evidence/swift-result"
test "$release_status" -eq 0
printf '{"schema":"vpt.helper/1","version":"1.0.0"}\n' > "$release_evidence/swift-expected"
cmp "$release_evidence/swift-expected" "$release_evidence/swift-stdout"
test ! -s "$release_evidence/swift-stderr"
shasum -a 256 -c "$release_manifest" > "$release_evidence/hashes-after"
git -c core.fsmonitor=false diff -- README.md > "$release_evidence/readme-diff"
cat "$release_evidence/rust-result" "$release_evidence/rust-timing" \
  "$release_evidence/swift-result" "$release_evidence/swift-stdout"
