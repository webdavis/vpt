# Task 32 execution brief

The atomic repository/application slice is dispatched on 2026-09-27 after Task 31 acceptance at
`37c070c3b7905b6fd37a3b09648fa35d26287626`. Read `task-32-brief.md` completely and
`task-D7-integration-addendum.md`. The controller read both complete sources. Inspect actual
retention, runtime/error, store, helper and event APIs before implementation. Command/startup
wiring still waits for Task 27's actual runtime; the current command crate has `RuntimeLedger`
but no `Runtime` or ingest command implementation.

Apply the report/alert amendment through the accepted EventSink. The combined retention event is
logged to private `events.jsonl` and selects only the optional report command. Preserve its existing
privacy and partial-progress contract. No built-in notification or helper fallback is in scope.

For this audio-only stage, `EventDetail::Retention.completed` is the number of actual combined
recovered/new moves, `Moved.len()`. The encoder derives `counts.audio` from that value. Completed
recording identities and already-absent reconciliation are separate: an expiration may be completed
without a new move, so neither receipt IDs nor reconciled completion totals supply this count.
Pin zero-move reconciliation and actual-move reporting before the producer/encoder change;
preserve all non-retention count documents. Later artifact stages extend per-store counts when
their real producers exist. The Task 26 writer owns the separate recovery-evidence codec change.

## State and history coupling

The independent repository slice deliberately left transaction coupling to this task. The accepted
`RetentionJournal` methods commit separately; calling them beside `RunHistory::commit_step` cannot
satisfy spec section 8.7.1. Keep those existing contracts intact. Add a narrow application-owned
`RetentionHistory` port for the retention consumer, implemented by both ledgers through the existing
private history transaction. Other history consumers need no retention-specific methods.

- Preparation takes the run and `NewIntent`, inserts the journal row, checks its generated positive
  identifier and saves the matching `EffectIntent` in one transaction. Return the intent identifier,
  effect identifier and `HistoryReceipt` through `HistoryWrite`. Reserve no identifier separately and
  add no generic transaction callback or schema solely for this coupling.
- Completion validates the journal row against its saved effect, then saves the recording's Trash
  mark, journal completion and confirmed effect/work outcome together. Its receipt carries the
  completed recording identity even though no new recording row was inserted. Test repeated
  completion against the journal's existing first-completion-time contract.
- Two pending intents may name the same recording. Keep the first saved audio Trash timestamp
  while each journal row retains its own first completion time. Repeating either completed intent
  adds no new outcome fact and changes neither timestamp. Cover a backward-moving clock without
  imposing chronological ordering on those observed times. Root found the initial unconditional
  audio-mark overwrite during review; its correction requires the shared failing regression first.
- Export the preparation receipt before revalidating and invoking the helper. Unconfirmed or
  post-commit-failed preparation stops before Trash. Retain a known committed receipt and generated
  identity on post-commit failure. After an actual move, retain that progress even if the subsequent
  completion save fails; never report that the move rolled back.
- Failed or unknown helper outcomes retain the pending journal and save their typed observations.
  Recovery uses the original saved effect identity. A validated absent target can be completed
  without another helper call; changed targets remain refused. A journal row without a matching
  history intent requires a detectable missing-history observation, never an invented original
  event identity or occurrence time. Export replay has no Trash capability.

Before implementation, add shared contract tests for generated-ID correlation, preparation and
completion rollback, post-commit receipts, completed IDs, repeated completion and missing-history
evidence. Assembled tests must prove no helper after failed preparation, actual-move progress after
failed completion, one combined report event and a wholly observational dry run. This is later
Task 32 work, not an expansion or acceptance condition for Task 19's current history slice.

## Execution

- Own Task 32's retention use case, startup recovery, command composition and focused adapter/command acceptance tests, plus its ignored report/evidence. Main owns progress and Todoist. Preserve other work; one product writer and no subagents. Root authorized `feat/retention-execution` in VPT's ignored worktree directory from the accepted head above.
- Retention consumes only ledger-owned audio in this stage. Untracked or changed files stay put with the specified reason. Never unlink an artifact. Fake Trash uses a recoverable move inside the owned fixture; no system Trash, live source, notification or destination is touched by a test.
- Validate the retained store authority, immediate parent, pinned recording path and recorded digest before reading an intent target, and revalidate the path immediately before the helper call. Route the intent journal through D5's strengthened database wrapper. SQL and decoder failures retain the established safe typed error contract.
- Commit the intent before calling the helper. Retain it after an unknown or failed outcome. Startup reconciliation handles absent, unchanged and replaced targets as specified before accepting new mutating work. Record each actual move and completed recording ID even if a later row update, journal completion or intent fails.
- Keep one retention event for the combined recovered and new moves, including partial failure. Ingest startup carries recovered IDs and diagnostics into its existing outcome. Preserve exact JSON envelopes, empty stdout on error, counts and notification privacy.
- Dry run is purely observational: no application lock, source opener, title database, migration, publication repair, intent reconciliation, Trash request or event. Helper version validation follows the approved task contract. The full expanded D7 snapshot, including companions and directory metadata, must remain unchanged; checking only main database bytes is insufficient.
- Use companion-preserving native fixture writes and close them before snapshots. Any concurrent native writer is an owned child process with handshake and bounded cleanup, not a connection sharing the rooted owner's process.
- Add compiling RED before behavior, then exact compiled mutations for ownership/digest refusal, intent-before-move ordering, retained partial progress, observation routing and typed containment conversion. Verify restored passing controls and preserve every prior leaf. Do not increase deadlines or retry a recurrence under `6hc7MMRc2QhRm75g` without diagnosis.
- Follow clean-code-rust, buffer safety, apply_patch, normal commit hooks and required final-source Rust/release/staged-size gates. Main owns fresh committed-HEAD ship and independent review. No installation, publication, apply, third-party changes or destructive cleanup.
