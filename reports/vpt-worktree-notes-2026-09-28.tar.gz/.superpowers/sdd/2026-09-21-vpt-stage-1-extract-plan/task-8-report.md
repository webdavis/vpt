# Task 8: recording identity

Controller acceptance: commit 2b50fa373f9d6483663ffd7a21bb246e844b96cf passed independent Sol review without findings (task-8-review-1.md). The fresh committed-HEAD just ship exited 0 with 178 leaves, all 171 baseline leaves preserved, and a clean 95-commit secrets scan (task-8-controller-ship.log). Restored identity hash and clean worktree/index were verified before Task 9 began. The historical deadline follow-up remains open; no recurrence was observed in Task 8.

Base: `8c017586fec61c29cd1dd9c04d9de1463babcc15`.

`vpt_domain::identity` now derives the 30-byte recording ID from Task 7's local civil time and the first twelve lowercase digest characters. It parses that ID and its 17-byte timestamp through public functions. Byte shape is checked before any string slice, and `Civil::is_valid` enforces Gregorian dates and clock bounds. `derive` applies the offset before checking whether the local year has four digits; an unrepresentable result remains a typed error. The module uses no I/O, clock, or new dependency.

## Tests and mutations

The first unprivileged test invocation could not write the worktree target or log; its output is in [preflight](task-8-preflight-01.log). The next invocation compiled the placeholders and ran seven tests: five failed on missing behavior and two rejection-only tests passed ([RED](task-8-red-02.log)). The first implementation passed all seven ([GREEN](task-8-green-01.log)). A later test addition pinned rejection of a leading plus sign in a fixed-width field; [its control](task-8-control-signed-fields-01.log) passed. No existing test was removed or renamed. The [named leaf audit](task-8-leaf-audit-01.log) compares [171 Task 7 leaves](task-7-fix1-final-leaves.log) with [178 Task 8 leaves](task-8-final-leaves-01.log): [seven added](task-8-added-leaves-01.log), [zero missing](task-8-missing-leaves-01.log).

Each row names the exact source substitution. The mutant compiled and failed the named test with exit 101; its restored control passed with exit 0. The raw logs contain the mutated source line and SHA-256 hash. The offset and shifted-prefix controls used source hash `9184ec7a9f8651fcb6bcec991480f772d350850a4bf595f806463ca1609fad77`. After the signed-field test was added, the restored source hash was `77ecfea31c01ab45f5175fb726a55e45e4019ab58b8fd33aa04b02dfddc47c57` for every later control and the final size audit.

| Mutation | Caught by | Raw evidence |
| --- | --- | --- |
| `captured.civil(offset)` to `captured.civil(UtcOffset { secs: 0 })` | exact local capture hour | [mutant](task-8-mut-offset-01.log), [control](task-8-control-offset-01.log) |
| `digest.hash12()` to `digest.hash8()` | valid derivation requires twelve characters | [mutant](task-8-mut-hash-prefix-01.log), [paired rerun](task-8-mut-hash8-02.log), [control](task-8-control-hash8-02.log) |
| `digest.hash12()` to `digest.hex()[1..13].to_owned()` | exact prefix on a valid 30-byte ID | [mutant](task-8-mut-hash-shift-01.log), [control](task-8-control-hash-01.log) |
| `civil.is_valid()` to `true` | nonexistent leap day | [mutant](task-8-mut-calendar-01.log), [control](task-8-control-calendar-01.log) |
| `u8::is_ascii_digit` to `u8::is_ascii` | leading plus sign refused | [mutant](task-8-mut-timestamp-digits-01.log), [control](task-8-control-timestamp-digits-01.log) |
| lowercase hash range to `u8::is_ascii_hexdigit` | uppercase hash refused | [mutant](task-8-mut-lowercase-hash-01.log), [control](task-8-control-lowercase-hash-01.log) |
| `parse_local_timestamp(&text[..TIMESTAMP_LEN])?` to a slice only | ID parser checks calendar too | [mutant](task-8-mut-id-calendar-wiring-01.log), [control](task-8-control-id-calendar-wiring-01.log) |
| derive error mapping `Unrepresentable` to `Malformed` | four-digit range error type | [mutant](task-8-mut-unrepresentable-error-01.log), [control](task-8-control-unrepresentable-error-01.log) |

## Final source checks

| Command | Result | Raw evidence |
| --- | --- | --- |
| `just ship` | exit 0, 178 passing leaves, docs built, 94-commit scan clean, 77.53 s | [ship](task-8-ship-01.log) |
| `cargo check --locked --workspace --all-targets --features dev-tools` | exit 0, 13.68 s | [check](task-8-check-01.log) |
| `just test-rust` | exit 0, 178 passing leaves, 6.63 s | [test](task-8-test-rust-01.log) |
| `just lint-check` | exit 0, 2.60 s | [lint](task-8-lint-check-01.log) |
| `cargo build --locked --release` | exit 0, 16.69 s | [release](task-8-release-01.log) |
| `cargo clippy --locked -p vpt-domain --all-targets -- -D warnings` | exit 0, 2.33 s | [domain Clippy](task-8-domain-clippy-01.log) |
| `git diff --cached --check` and staged Rust size audit | exit 0; `identity.rs` 109 implementation, 274 total lines; `lib.rs` 6 total | [size audit](task-8-size-audit-01.log) |

The ship file-size gate still warns on inherited `config/schema.rs` (471 implementation lines) and `config/load/tests.rs` (304 total lines). The existing intermittent 500 ms setup and usage deadline issue did not recur in these runs; its cause remains open under Todoist `6hc7MMRc2QhRm75g`.

Commit `2b50fa3` contains only `identity.rs` and its `lib.rs` export. The [committed-HEAD redacted secrets scan](task-8-committed-head-secrets-01.log) exited 0: 95 commits scanned, no leaks found, 15.33 s. The controller owns the fresh committed-HEAD ship and independent review.
