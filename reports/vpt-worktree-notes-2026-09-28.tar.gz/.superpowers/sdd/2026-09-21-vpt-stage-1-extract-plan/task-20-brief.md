### Task 20: The gates: deferrals, retries and the deferred page

**Files:**

- Modify: `crates/vpt-application/src/ingest/candidate.rs`,
  `crates/vpt-application/src/ingest/publish.rs`
- Test: `crates/vpt-adapters/tests/support/fakes.rs`, `crates/vpt-adapters/tests/support/mod.rs`,
  `crates/vpt-adapters/tests/ingest_gates.rs`

**Interfaces:**

- Consumes: `vpt_domain::sweep::{size_gate, rest_gate, SweepLimits, DeferralReason}`, `inspect`,
  `RecorderStore::read_at`.

- Produces: `Ingest::defer(&self, candidate: &Candidate, seen: Option<SeenRow>,`
  `reason: DeferralReason, now: UtcInstant, mode: &Mode, report: &mut IngestReport) -> Result<(),`
  `IngestFailure>` (appends to `report.deferred`; outside a dry run records the deferral with a
  saturating count and raises the `deferred` event exactly when the count crosses the threshold). Test
  support in `support/fakes.rs`: `ProbeStore<'a>::new(inner: &'a VoiceMemosStore) -> ProbeStore`
  implementing `RecorderStore` over the real store with `pub dataless: RefCell<Vec<String>>` (names
  reported with `SF_DATALESS` set, and a panic if one is opened), `pub reads: Cell<u64>` (calls to
  `read_at`), `pub grow_after_open: Cell<bool>` (the second `metadata` call reports one more byte),
  `pub extra_flags: Cell<u32>` (flags added to every observed candidate),
  `pub clone: Cell<CloneBehaviour>` with `CloneBehaviour::{Real, ByteCopy, Truncated, Exists}`.

- [ ] **Step 1: Write the failing tests**

`crates/vpt-adapters/tests/support/mod.rs` gains `pub mod fakes;` beside its `#![allow(dead_code)]`.
`crates/vpt-adapters/tests/support/fakes.rs`:

```rust
//! Recorder and archive doubles that delegate to the real adapters and inject
//! one named failure or observation each.

use std::cell::{Cell, RefCell};
use std::fs::File;
use std::io::Write;
use std::os::unix::fs::{FileExt, OpenOptionsExt};
use std::path::Path;
use vpt_adapters::VoiceMemosStore;
use vpt_application::ports::{Candidate, CloneError, CloneKind, RecorderError, RecorderStore, SourceMetadata, TitleLookup};
use vpt_domain::container::ReadFailure;
use vpt_domain::sweep::SF_DATALESS;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CloneBehaviour {
    Real,
    ByteCopy,
    Truncated,
    Exists,
}

pub struct ProbeStore<'a> {
    inner: &'a VoiceMemosStore,
    pub dataless: RefCell<Vec<String>>,
    pub extra_flags: Cell<u32>,
    pub reads: Cell<u64>,
    pub grow_after_open: Cell<bool>,
    pub metadata_calls: Cell<u32>,
    pub clone: Cell<CloneBehaviour>,
}

impl<'a> ProbeStore<'a> {
    pub fn new(inner: &'a VoiceMemosStore) -> ProbeStore<'a> {
        ProbeStore {
            inner,
            dataless: RefCell::new(vec![]),
            extra_flags: Cell::new(0),
            reads: Cell::new(0),
            grow_after_open: Cell::new(false),
            metadata_calls: Cell::new(0),
            clone: Cell::new(CloneBehaviour::Real),
        }
    }

    fn forced_dataless(&self, path: &Path) -> bool {
        self.dataless.borrow().iter().any(|name| path.ends_with(name))
    }
}

/// The whole source through the descriptor, shortened by `drop` bytes at the end.
fn copy_bytes(source: &File, directory: &Path, name: &str, drop: usize) -> Result<(), CloneError> {
    let size = usize::try_from(source.metadata().map_err(|e| CloneError::Io(e.to_string()))?.len()).expect("size");
    let mut bytes = vec![0u8; size];
    source.read_exact_at(&mut bytes, 0).map_err(|e| CloneError::Io(e.to_string()))?;
    bytes.truncate(size.saturating_sub(drop));
    let mut out = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(directory.join(name))
        .map_err(|e| CloneError::Io(e.to_string()))?;
    out.write_all(&bytes).map_err(|e| CloneError::Io(e.to_string()))
}

impl RecorderStore for ProbeStore<'_> {
    type Handle = File;

    fn candidates(&self) -> Result<Vec<Candidate>, RecorderError> {
        let mut candidates = self.inner.candidates()?;
        for candidate in &mut candidates {
            candidate.flags |= self.extra_flags.get();
            if self.forced_dataless(&candidate.path) {
                candidate.flags |= SF_DATALESS;
            }
        }
        Ok(candidates)
    }

    fn candidate(&self, path: &Path) -> Result<Candidate, RecorderError> {
        let mut candidate = self.inner.candidate(path)?;
        candidate.flags |= self.extra_flags.get();
        if self.forced_dataless(path) {
            candidate.flags |= SF_DATALESS;
        }
        Ok(candidate)
    }

    fn open(&self, path: &Path) -> Result<File, RecorderError> {
        assert!(!self.forced_dataless(path), "a dataless entry was opened: {}", path.display());
        self.inner.open(path)
    }

    fn metadata(&self, handle: &File) -> Result<SourceMetadata, RecorderError> {
        let mut metadata = self.inner.metadata(handle)?;
        self.metadata_calls.set(self.metadata_calls.get() + 1);
        if self.grow_after_open.get() && self.metadata_calls.get() >= 2 {
            metadata.size += 1;
        }
        Ok(metadata)
    }

    fn read_at(&self, handle: &File, offset: u64, buf: &mut [u8]) -> Result<(), ReadFailure> {
        self.reads.set(self.reads.get() + 1);
        self.inner.read_at(handle, offset, buf)
    }

    fn clone_into(&self, handle: &File, directory: &Path, directory_identity: (u64, u64), name: &str) -> Result<CloneKind, CloneError> {
        match self.clone.get() {
            CloneBehaviour::Real => self.inner.clone_into(handle, directory, directory_identity, name),
            CloneBehaviour::ByteCopy => copy_bytes(handle, directory, name, 0).map(|()| CloneKind::ByteCopy),
            CloneBehaviour::Truncated => copy_bytes(handle, directory, name, 12).map(|()| CloneKind::CopyOnWrite),
            CloneBehaviour::Exists => Err(CloneError::Exists),
        }
    }

    fn title(&self, file_name: &str) -> TitleLookup {
        self.inner.title(file_name)
    }

    fn refresh_titles(&self) -> Result<(), RecorderError> {
        self.inner.refresh_titles()
    }

    fn subdirectory_counts(&self) -> Vec<(String, Option<u64>)> {
        self.inner.subdirectory_counts()
    }
}
```

`crates/vpt-adapters/tests/ingest_gates.rs`:

```rust
mod support;

use std::os::unix::fs::PermissionsExt;
use support::fakes::{CloneBehaviour, ProbeStore};
use support::{CAPTURED, Fixture, FixedClock, Parts, clock};
use vpt_application::ports::{Archive, RecordingLedger};
use vpt_application::{Ingest, Mode};
use vpt_domain::fixtures::{box_of, m4a, mvhd_v1};
use vpt_domain::notification::EventKind;
use vpt_domain::sweep::DeferralReason;
use vpt_domain::time::UtcInstant;

fn probed(parts: &Parts, probe: &ProbeStore<'_>) -> vpt_application::IngestReport {
    let ingest = Ingest {
        recorder: probe,
        archive: &parts.archive,
        ledger: &parts.ledger,
        clock: &parts.clock,
        trash: &parts.trash,
        notifier: &parts.notifier,
        settings: &parts.settings,
    };
    ingest.run(&Mode::default()).expect("sweep")
}

#[test]
fn dataless_never_opens() {
    let fixture = Fixture::new();
    let source = fixture.add_recording("cloud.m4a", &m4a(CAPTURED, 1, b"x"));
    let parts = fixture.parts();
    let probe = ProbeStore::new(&parts.store);
    probe.dataless.borrow_mut().push("cloud.m4a".into());
    probe.extra_flags.set(0x20);

    let report = probed(&parts, &probe);

    assert_eq!(report.deferred, vec![vpt_application::Deferred { path: source.clone(), reason: DeferralReason::Dataless }]);
    let row = parts.ledger.seen(&source).expect("seen").expect("row");
    assert_eq!((row.deferral_count, row.deferral_reason), (1, Some(DeferralReason::Dataless)));
    assert_eq!(row.flags & 0x40000020, 0x40000020);
    assert!(report.ingested.is_empty());
    assert!(parts.archive.archived().expect("archived").is_empty());
    assert!(parts.events().is_empty());
}

#[test]
fn oversize_never_reads() {
    let fixture = Fixture::new();
    fixture.add_recording("big.m4a", &m4a(CAPTURED, 1, &[0u8; 4_096]));
    let mut parts = fixture.parts();
    parts.settings.max_audio_bytes = 1_000;
    let probe = ProbeStore::new(&parts.store);

    let report = probed(&parts, &probe);

    assert_eq!(report.deferred[0].reason, DeferralReason::AudioTooLarge);
    assert_eq!(probe.reads.get(), 0);
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
}

#[test]
fn a_truncated_download_is_deferred_then_not_at_rest_after_growing_then_ingested_when_still() {
    let fixture = Fixture::new();
    let whole = m4a(CAPTURED, 1, b"payload");
    let source = fixture.add_recording("a.m4a", &whole[..whole.len() - 12]);
    let parts = fixture.parts();

    let first = parts.ingest().run(&Mode::default()).expect("first");
    assert_eq!(first.deferred[0].reason, DeferralReason::InvalidContainer);
    assert!(parts.archive.archived().expect("archived").is_empty(), "nothing is cloned before every gate passes");

    fixture.add_recording("a.m4a", &whole);
    let second = parts.ingest().run(&Mode::default()).expect("second");
    assert_eq!(second.deferred[0].reason, DeferralReason::NotAtRest, "the size moved since the last deferral");
    assert!(second.ingested.is_empty());
    assert_eq!(parts.ledger.seen(&source).expect("seen").map(|row| row.deferral_count), Some(2));

    let third = parts.ingest().run(&Mode::default()).expect("third");
    assert_eq!(third.ingested.len(), 1);
    assert_eq!(parts.ledger.seen(&source).expect("seen").map(|row| (row.deferral_count, row.deferred_size)), Some((0, None)));
}

#[test]
fn a_file_younger_than_the_quiet_period_is_not_at_rest() {
    let fixture = Fixture::new();
    let path = fixture.add_recording("fresh.m4a", &m4a(CAPTURED, 1, b"x"));
    fixture.set_mtime(&path, clock().now.secs - 10);
    let parts = fixture.parts();

    let report = parts.ingest().run(&Mode::default()).expect("sweep");

    assert_eq!(report.deferred[0].reason, DeferralReason::NotAtRest);
    assert!(report.ingested.is_empty());
}

#[test]
fn the_deferred_event_is_raised_once_when_the_count_crosses_the_threshold() {
    let fixture = Fixture::new();
    let whole = m4a(CAPTURED, 1, b"payload");
    let source = fixture.add_recording("a.m4a", &whole[..whole.len() - 12]);
    let mut parts = fixture.parts();
    parts.settings.deferral_page_threshold = 2;

    for _ in 0..3 {
        parts.ingest().run(&Mode::default()).expect("sweep");
    }

    assert_eq!(parts.events(), vec![EventKind::Deferred]);
    assert_eq!(parts.ledger.seen(&source).expect("seen").map(|row| row.deferral_count), Some(3));
}

#[test]
fn an_edited_recording_is_deferred_while_fresh_then_ingested_as_a_second_recording() {
    let fixture = Fixture::new();
    let source = fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"first take"));
    let parts = fixture.parts();
    let first = parts.ingest().run(&Mode::default()).expect("first");
    let original = first.ingested[0].id.clone();
    std::fs::write(&source, m4a(CAPTURED + 30, 2, b"second take")).expect("edit");
    fixture.set_mtime(&source, clock().now.secs - 5);

    let second = parts.ingest().run(&Mode::default()).expect("second");
    assert_eq!(second.deferred[0].reason, DeferralReason::NotAtRest);
    assert_eq!(parts.ledger.recordings().expect("list").len(), 1);

    let later = Parts { clock: FixedClock { now: UtcInstant { secs: clock().now.secs + 60 }, ..clock() }, ..fixture.parts() };
    let third = later.ingest().run(&Mode::default()).expect("third");
    assert_eq!(third.ingested.len(), 1);
    assert_ne!(third.ingested[0].id, original);
    assert_eq!(later.ledger.recordings().expect("list").len(), 2);
    assert_eq!(later.ledger.seen(&source).expect("seen").and_then(|row| row.recording), Some(third.ingested[0].id.clone()));
}

#[test]
fn source_change_discards_stage() {
    let fixture = Fixture::new();
    let source = fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"moving"));
    let parts = fixture.parts();
    let probe = ProbeStore::new(&parts.store);
    probe.grow_after_open.set(true);

    let report = probed(&parts, &probe);

    assert_eq!(report.deferred[0].reason, DeferralReason::ChangedDuringRead);
    assert_eq!(parts.trash.moved.borrow().len(), 1, "the staged clone went to the Trash");
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert!(parts.archive.archived().expect("archived").is_empty());
    assert_eq!(parts.ledger.seen(&source).expect("seen").and_then(|row| row.recording), None);
    assert!(parts.events().is_empty());
}

#[test]
fn invalid_stage_is_trashed() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"whole at the source"));
    let parts = fixture.parts();
    let probe = ProbeStore::new(&parts.store);
    probe.clone.set(CloneBehaviour::Truncated);

    let report = probed(&parts, &probe);

    assert_eq!(report.deferred[0].reason, DeferralReason::InvalidContainer);
    assert_eq!(parts.trash.moved.borrow().len(), 1);
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert!(parts.ledger.recordings().expect("list").is_empty());
    assert!(parts.events().is_empty());
}

#[test]
fn absent_trash_preserves_private_stage() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"whole at the source"));
    let parts = fixture.parts();
    parts.trash.absent.set(true);
    let probe = ProbeStore::new(&parts.store);
    probe.clone.set(CloneBehaviour::Truncated);

    let report = probed(&parts, &probe);

    assert_eq!(report.deferred[0].reason, DeferralReason::InvalidContainer);
    let leftovers = parts.archive.staged_leftovers().expect("leftovers");
    assert_eq!(leftovers.len(), 1);
    assert_eq!(std::fs::metadata(&leftovers[0]).expect("meta").permissions().mode() & 0o777, 0o600);
    assert!(report.log.iter().any(|line| line.contains("cleanup pending")), "{:?}", report.log);
    assert!(parts.ledger.recordings().expect("list").is_empty());
    assert!(parts.events().is_empty());
}

#[test]
fn incompatible_cleanup_helper_refuses_without_losing_diagnostics_or_staging() {
    struct Incompatible;
    impl vpt_application::ports::Trash for Incompatible {
        fn trash(&self, _path: &std::path::Path) -> Result<std::path::PathBuf, vpt_application::ports::TrashError> {
            Err(vpt_application::ports::TrashError::HelperVersion { found: 7 })
        }
        fn take_diagnostics(&self) -> Vec<String> {
            vec!["unknown additive helper field: capabilities".into()]
        }
    }
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"whole at source"));
    let parts = fixture.parts();
    let probe = ProbeStore::new(&parts.store);
    probe.clone.set(CloneBehaviour::Truncated);
    let ingest = Ingest {
        recorder: &probe, archive: &parts.archive, ledger: &parts.ledger,
        clock: &parts.clock, trash: &Incompatible, notifier: &parts.notifier,
        settings: &parts.settings,
    };
    let error = ingest.run(&Mode::default()).expect_err("helper version refusal");
    assert_eq!(error.failure, vpt_application::IngestFailure::HelperVersion { found: 7 });
    assert!(error.completed.is_empty());
    assert!(error.log.iter().any(|line| line == "unknown additive helper field: capabilities"));
    assert_eq!(parts.archive.staged_leftovers().expect("staging").len(), 1);
    assert!(parts.ledger.recordings().expect("rows").is_empty());
}

#[test]
fn a_capture_instant_with_no_four_digit_year_is_deferred_as_an_invalid_container() {
    let fixture = Fixture::new();
    let mut bytes = box_of(b"ftyp", b"M4A ");
    bytes.extend(box_of(b"mdat", b"audio"));
    bytes.extend(box_of(b"moov", &mvhd_v1(253_402_300_800, 1)));
    fixture.add_recording("far.m4a", &bytes);
    let mut parts = fixture.parts();
    parts.clock.offset = vpt_domain::time::UtcOffset { secs: 0 };

    let report = parts.ingest().run(&Mode::default()).expect("sweep");

    assert_eq!(report.deferred[0].reason, DeferralReason::InvalidContainer);
    assert_eq!(parts.trash.moved.borrow().len(), 1);
    assert!(parts.ledger.recordings().expect("list").is_empty());
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters --test ingest_gates`

Expected: `dataless_never_opens` PANICS in the probe (the entry is opened); `oversize_never_reads`, the
truncated-download test, the quiet-period test and the edited-recording test FAIL because the entries are
ingested or fail outright; the threshold test FAILS with no events; `source_change_discards_stage` and
`invalid_stage_is_trashed` FAIL with a `Recorder` or `Archive` error where a deferral is expected; the
absent-trash and far-future tests FAIL the same way.

- [ ] **Step 3: Write the minimal implementation**

Replace `process` in `crates/vpt-application/src/ingest/candidate.rs` and add `defer` to the same `impl`
block:

```rust
    pub(super) fn process(&self, candidate: &Candidate, mode: &Mode, report: &mut IngestReport) -> Result<(), IngestFailure> {
        let now = self.clock.now();
        let seen = self.ledger.seen(&candidate.path).map_err(IngestFailure::Ledger)?;
        let facts = CandidateFacts { size: candidate.size, mtime: candidate.mtime, flags: candidate.flags };
        let seen_facts = seen.as_ref().map(|row| SeenFacts {
            size: row.size,
            mtime: row.mtime,
            ingested: row.recording.is_some() && row.deferral_reason.is_none(),
            deferred_size: row.deferred_size,
        });
        let seen = match pre_open(&facts, seen_facts.as_ref()) {
            PreOpen::Dataless => return self.defer(candidate, seen, DeferralReason::Dataless, now, mode, report),
            PreOpen::Unchanged => match seen {
                Some(row) => return self.unchanged(row, now, mode, report),
                None => None,
            },
            PreOpen::Open => seen,
        };
        let handle = self.recorder.open(&candidate.path).map_err(recorder_failure)?;
        let metadata = self.recorder.metadata(&handle).map_err(recorder_failure)?;
        let limits = SweepLimits { max_audio_bytes: self.settings.max_audio_bytes, quiet_period_secs: self.settings.quiet_period_secs };
        if let Err(reason) = size_gate(metadata.size, &limits) {
            return self.defer(candidate, seen, reason, now, mode, report);
        }
        if inspect(metadata.size, |offset, buf| self.recorder.read_at(&handle, offset, buf)).is_err() {
            return self.defer(candidate, seen, DeferralReason::InvalidContainer, now, mode, report);
        }
        if let Err(reason) = rest_gate(metadata.mtime, metadata.size, now, seen_facts.as_ref(), &limits) {
            return self.defer(candidate, seen, reason, now, mode, report);
        }
        self.stage_and_publish(candidate, &handle, &metadata, seen, now, mode, report)
    }

    /// Record one deferral and page exactly when the count crosses the threshold.
    pub(super) fn defer(
        &self,
        candidate: &Candidate,
        seen: Option<SeenRow>,
        reason: DeferralReason,
        now: UtcInstant,
        mode: &Mode,
        report: &mut IngestReport,
    ) -> Result<(), IngestFailure> {
        report.deferred.push(super::Deferred { path: candidate.path.clone(), reason });
        if mode.dry_run {
            return Ok(());
        }
        let mut row = seen.unwrap_or_else(|| fresh_seen(candidate, now));
        row.size = candidate.size;
        row.mtime = candidate.mtime;
        row.flags = candidate.flags;
        row.last_seen = now;
        row.source_gone_at = None;
        let previous = row.deferral_count;
        row.deferral_count = previous.saturating_add(1);
        row.deferral_reason = Some(reason);
        row.deferred_size = Some(candidate.size);
        self.ledger.record_seen(&row).map_err(IngestFailure::Ledger)?;
        let threshold = self.settings.deferral_page_threshold;
        if previous < threshold && row.deferral_count >= threshold {
            self.notifier.deliver(&Notification::attention(
                EventKind::Deferred,
                None,
                format!("deferred {} times: {}", row.deferral_count, reason.as_str()),
                vec![("source".into(), candidate.path.clone())],
                now,
            ));
            report.log.extend(self.notifier.take_diagnostics());
        }
        Ok(())
    }
```

with these imports in `candidate.rs` replacing the earlier `vpt_domain::sweep` line:

```rust
use vpt_domain::container::inspect;
use vpt_domain::notification::{EventKind, Notification};
use vpt_domain::sweep::{CandidateFacts, DeferralReason, PreOpen, SeenFacts, SweepLimits, pre_open, rest_gate, size_gate};
```

In `publish.rs` the two staged gates and the identity become deferrals. Replace the block from
`let after = ...` to the `let Ok(id) = ...` binding with:

```rust
        let after = self.owned(&staged.path, self.recorder.metadata(handle).map_err(recorder_failure), report)?;
        if after != *metadata {
            self.discard(&staged.path, report)?;
            return self.defer(candidate, seen, DeferralReason::ChangedDuringRead, now, mode, report);
        }
        let container = match self.owned(&staged.path, self.inspect_archive(&staged.path), report)? {
            Ok(container) => container,
            Err(_) => {
                self.discard(&staged.path, report)?;
                return self.defer(candidate, seen, DeferralReason::InvalidContainer, now, mode, report);
            }
        };
        let offset = self.clock.offset_at(container.creation_time);
        let Ok(id) = RecordingId::derive(container.creation_time, offset, &staged.digest) else {
            self.discard(&staged.path, report)?;
            return self.defer(candidate, seen, DeferralReason::InvalidContainer, now, mode, report);
        };
```

delete the `let _ = mode;` line, and add `use vpt_domain::sweep::DeferralReason;` to its imports. A
capture instant whose local year has no four-digit form is the container's fault, so it defers as
`invalid_container` (spec section 4.3 derives the identity from the container alone).

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters --test ingest_gates --test ingest_sweep`

Expected: all gate and cleanup tests PASS. Run
`cargo clippy --workspace --all-targets --features dev-tools -- -D warnings` and expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(ingest): the sweep gates defer, retry and page at the threshold"
```

______________________________________________________________________

