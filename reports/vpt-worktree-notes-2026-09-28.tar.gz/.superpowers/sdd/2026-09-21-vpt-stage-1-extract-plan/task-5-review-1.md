Spec compliance: Approved.

Code quality: Approved. No Critical, Important, or Minor findings.

Reviewer: /root/vpt_build_review_5, gpt-6-astra xhigh.
Base: 2858751a6161df5c41fd90c93a55afac6b46f979.
Head: 19d0f58e3d8e994a47b7bf918e7bc1efabe59487.

- crates/vpt-domain/src/layout.rs:93 implements directional Home/Config protection, symmetric store/state protection, and Released disjointness. Tests exercise both argument orders.
- crates/vpt-adapters/src/config/roots.rs:29 protects the container and validates roots before creation. roots/directory.rs:7 canonicalizes existing aliases without writes; roots/directory.rs:34 enforces missing-parent restrictions.
- crates/vpt-adapters/src/config/settings.rs:13 converts the existing validated configuration into application types. config/paths.rs:3 preserves configuration-path precedence.

Evidence reviewed: controller task-5-controller-ship.log passes all 105 leaves; the name map retains all 77 baseline leaves. The mutation ledger records 19 behavioral failures with passing restored controls. Release build, committed-HEAD secrets scan, and changed-file size audit pass.

Cannot independently verify: unchanged validation internals or eventual command integration from this diff. Existing validation regressions pass in the controller log; command integration belongs to later tasks.

Considered and set aside: descriptor races and safe creation belong to Task 5a; SQLite belongs to D1 after Task 10. The two inherited size warnings are unchanged and previously approved. No outside-diff code reads, Git commands, suite reruns, or mutations performed.
