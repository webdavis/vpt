# Task 10: Pure sweep gates

## Controller acceptance

Accepted at 153989840f9be9ddf4a1076ef2ca3ec455a5fa75 after independent Sol high review, task-10-review-1.md, with no findings. The controller's fresh committed-HEAD just ship exited 0 in task-10-controller-ship.log. Independent leaf comparison retained all 202 baseline names and counted seven added, for 209 passing tests. The 97-commit secrets scan is clean; worktree/index are clean and HEAD is unchanged. Final sweep.rs SHA-256 is e84eac29791fa29182444c37c34f4a1e4f516636259074b869a60340232cf7c1; private tests SHA-256 is f5559ea80b558025d3b1474695badc535f7987077c274b1e2382c18a4c9ba37b. No command deadline recurrence, but the earlier follow-up remains open. No installation or live use occurred.

Committed as `1539898` (`feat(domain): add pure sweep gates`) on `feat/stage-1-extract`. The commit contains only `crates/vpt-domain/src/lib.rs`, `crates/vpt-domain/src/sweep.rs`, and `crates/vpt-domain/src/sweep/tests.rs`. The worktree and index are clean.

The domain exports the specified candidate, seen, limits, reason, and pre-open types, plus `SF_DATALESS`, `pre_open`, `size_gate`, and `rest_gate`. Dataless wins over an unchanged ingested triple. Size equality passes. The rest gate compares signed 128-bit nanoseconds against the full `u64` quiet period, including the `i64::MIN` to `i64::MAX` span; `FileTime::age_secs` remains unchanged. All five persisted reason spellings are pinned as independent string literals and parsed back. No time helper, dependency, or other product API was added.

## Test-first and mutation evidence

The [compiling RED](task-10-red-01.log) ran seven named tests against compiling stubs and failed all seven behaviorally. The first [GREEN](task-10-green-01.log) passed all seven. A size-driven move put those tests in a private child file; the [post-move control](task-10-post-split-control-01.log) passed the same seven names. The [binary-plus-leaf comparison](task-10-missing-leaves-01.log) retained all [202 baseline leaves](task-10-baseline-leaves-01.log) and added exactly [seven sweep leaves](task-10-added-leaves-01.log), yielding [209 final leaves](task-10-final-leaves-01.log). Compiler hashes were excluded from the comparison.

Ten source mutations compiled and failed their named behavior tests. Each mutant log records the changed source line and source hash; each control passed after restoration to the same pre-split SHA-256 hash, `677516a3cc3963cc8b7fd166fd63713725d83d578a4ad3f1dd5d6213bc0a7230`. No mutant survived.

| Mutation | Behavior caught | Raw evidence |
| --- | --- | --- |
| Require flags to equal `SF_DATALESS` exactly | Another flag cannot hide the dataless bit | [mutant](task-10-mut-dataless-flag-01.log), [corrected control](task-10-control-dataless-flag-02.log) |
| Check unchanged before the dataless bit | Dataless takes priority over an ingested triple | [mutant](task-10-mut-dataless-priority-01.log), [control](task-10-control-dataless-priority-01.log) |
| Invert `seen.ingested` | Only an already ingested triple skips opening | [mutant](task-10-mut-unchanged-ingested-01.log), [control](task-10-control-unchanged-ingested-01.log) |
| Change size `>` to `>=` | A file exactly at the byte limit passes | [mutant](task-10-mut-size-equality-01.log), [control](task-10-control-size-equality-01.log) |
| Change quiet-period `<` to `<=` | Exact time equality passes | [mutant](task-10-mut-rest-equality-01.log), [control](task-10-control-rest-equality-01.log) |
| Drop file-time nanoseconds | A file one nanosecond too young defers | [mutant](task-10-mut-rest-nanoseconds-01.log), [control](task-10-control-rest-nanoseconds-01.log) |
| Clamp the quiet period to `i64::MAX` | The `u64::MAX` limit remains full width | [mutant](task-10-mut-rest-full-width-01.log), [control](task-10-control-rest-full-width-01.log) |
| Change deferred-size `!=` to `==` | A changed size since deferral is not at rest | [mutant](task-10-mut-deferred-size-01.log), [control](task-10-control-deferred-size-01.log) |
| Change the `dataless` formatter literal | Persisted spelling is pinned independently | [mutant](task-10-mut-reason-format-01.log), [control](task-10-control-reason-format-01.log) |
| Change the `invalid_container` parser literal | Persisted parse spelling is pinned independently | [mutant](task-10-mut-reason-parse-01.log), [control](task-10-control-reason-parse-01.log) |

The [first dataless control](task-10-control-dataless-flag-01.log) passed its test but recorded an indentation-altered hash, so it did not count as a byte-identical restore. The correction and [second control](task-10-control-dataless-flag-02.log) restored the exact hash. Both attempts remain in the raw evidence.

## Final-source gates

| Command | Result and time | Raw evidence |
| --- | --- | --- |
| `just ship` | exit 0, 209 passing leaves, 37.17 s | [ship](task-10-ship-final-01.log) |
| `just test-rust` | exit 0, 209 passing leaves, 3.94 s | [test](task-10-test-rust-final-01.log) |
| `just lint-check` | exit 0, 1.56 s | [lint](task-10-lint-check-final-01.log) |
| `cargo check --locked --workspace --all-targets --features dev-tools` | exit 0, 5.94 s | [check](task-10-check-all-targets-final-01.log) |
| `cargo build --locked --release` | exit 0, 7.66 s | [release](task-10-release-final-01.log) |
| `cargo clippy --locked -p vpt-domain --all-targets --features fixtures -- -D warnings` | exit 0, 0.36 s | [Clippy](task-10-domain-clippy-final-01.log) |
| `cargo fmt --all -- --check` | exit 0, 0.34 s | [format](task-10-fmt-final-01.log) |
| `RUSTDOCFLAGS='-D warnings' cargo doc --locked --workspace --no-deps` | exit 0, 0.76 s | [documentation](task-10-doc-final-02.log) |
| staged whitespace and physical line audit | exit 0; sweep 104 implementation / 106 total, private tests 209 total | [audit](task-10-size-audit-final-01.log) |
| committed-HEAD `gitleaks git --redact --no-banner` | exit 0, 97 commits, no leaks, 10.75 s | [secrets](task-10-committed-head-secrets-01.log) |

The first standalone documentation command used the environment assignment in the wrong position after `/usr/bin/time` and exited 127 before invoking Cargo; its [raw attempt](task-10-doc-final-01.log) is retained. The corrected command above passed. The ship file-size gate reported only the inherited `config/schema.rs` 471-line and `config/load/tests.rs` 304-line warnings. The new files were staged and audited separately because the ship recipe counts tracked files. The tracked 500 ms command-test deadline issue did not recur. The controller owns the fresh committed-HEAD ship and review; no push, pull request, installation, apply, live destination, or cleanup was performed.
