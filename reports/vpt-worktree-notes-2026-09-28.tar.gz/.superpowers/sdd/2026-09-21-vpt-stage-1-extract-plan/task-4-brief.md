### Task 4: Value rules and the duration syntax

## Controller execution constraints

- Use the plan's Global Constraints, the approved spec's key types and ranges, and the already reviewed Task 3 loader. Do not overwrite prior loader regressions or implement Task 5 early.
- RED must compile and fail behavior assertions. Introduce minimal compiling stubs for missing APIs rather than treating unresolved names as test evidence.
- Exercise duration boundaries at the pure parser: empty input, signs/whitespace, a multibyte final character, the largest valid seconds value, parse overflow and multiplication overflow. Keep exact range endpoints, non-finite ratios and integer-width boundaries covered through load_text.
- After GREEN, mutate the guards with verified on-disk edits and named failing leaf tests, restore them, and run the complete current workspace gates and exact staged-file size audit. Keep tests below one second and all filesystem inputs sandboxed.
- No unsolicited docstrings, broad lint suppressions, subagents, unrelated edits, push, pull request, installation or real destinations. Preserve prior task ownership and report full evidence in task-4-report.md.

**Files:**

- Create: `crates/vpt-domain/src/duration.rs`
- Modify: `crates/vpt-domain/src/lib.rs`
- Create: `crates/vpt-adapters/src/config/validate.rs`
- Modify: `crates/vpt-adapters/src/config/mod.rs`, `crates/vpt-adapters/src/config/load.rs`

**Interfaces:**

- Consumes: `config::{spec_for, Kind, Kind::expected, ConfigError, load_text}` (Task 3).

- Produces: `vpt_domain::duration::parse_duration(text: &str) -> Result<u64, DurationError>` (seconds)
  and `DurationError::{MissingUnit, UnknownUnit(char), NotAPositiveInteger, Overflow}`;
  `ConfigError::key(&self) -> Option<&str>` (the key a refusal names);
  `config::validate::validate(table: &toml::Table) -> Result<(), ConfigError>`, a private module of
  `config` called at the end of `load_text`.

- [ ] **Step 1: Write the failing tests**

Declare the modules first: `crates/vpt-domain/src/lib.rs` gains `pub mod duration;` and
`crates/vpt-adapters/src/config/mod.rs` gains `mod validate;`, so both test modules are compiled and
selected by the red run. `crates/vpt-domain/src/duration.rs` starts as its test module alone:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn zero_means_never_and_needs_no_unit() {
        assert_eq!(parse_duration("0"), Ok(0));
    }

    #[test]
    fn each_unit_converts_to_seconds() {
        assert_eq!(parse_duration("45s"), Ok(45));
        assert_eq!(parse_duration("2m"), Ok(120));
        assert_eq!(parse_duration("24h"), Ok(86_400));
        assert_eq!(parse_duration("90d"), Ok(7_776_000));
    }

    #[test]
    fn a_positive_number_without_a_unit_is_refused() {
        assert_eq!(parse_duration("90"), Err(DurationError::MissingUnit));
    }

    #[test]
    fn an_unknown_unit_and_a_negative_number_are_refused() {
        assert_eq!(parse_duration("3w"), Err(DurationError::UnknownUnit('w')));
        assert_eq!(parse_duration("-3d"), Err(DurationError::NotAPositiveInteger));
        assert_eq!(parse_duration("0d"), Err(DurationError::NotAPositiveInteger));
    }

    #[test]
    fn overflow_is_refused_rather_than_wrapped() {
        assert_eq!(parse_duration("999999999999999999d"), Err(DurationError::Overflow));
    }
}
```

`crates/vpt-adapters/src/config/validate.rs`, likewise the test module alone:

```rust
#[cfg(test)]
mod tests {
    use crate::config::{ConfigError, load_text};

    fn with(body: &str) -> Result<toml::Table, ConfigError> {
        load_text(&format!("config_version = 1\n{body}"))
    }

    #[test]
    fn a_ratio_outside_its_range_is_refused_naming_the_key() {
        let error = with("[reconcile]\nconfidence_floor = 1.5\n").unwrap_err();
        assert_eq!(error, ConfigError::OutOfRange { key: "reconcile.confidence_floor".into(), rule: "a ratio in [0, 1]".into() });
    }

    #[test]
    fn a_ratio_accepts_integer_endpoints_and_refuses_a_non_finite_number() {
        assert!(with("[reconcile]\nconfidence_floor = 0\n").is_ok());
        assert!(with("[reconcile]\nconfidence_floor = 1\n").is_ok());
        assert!(with("[reconcile]\nmax_divergence_ratio = 1\n").is_ok());
        assert_eq!(with("[reconcile]\nconfidence_floor = inf\n").unwrap_err().key(), Some("reconcile.confidence_floor"));
    }

    #[test]
    fn the_divergence_ratio_must_be_above_zero() {
        let error = with("[reconcile]\nmax_divergence_ratio = 0.0\n").unwrap_err();
        assert_eq!(error.key(), Some("reconcile.max_divergence_ratio"));
        assert_eq!(with("[reconcile]\nmax_divergence_ratio = 0\n").unwrap_err().key(), Some("reconcile.max_divergence_ratio"));
    }

    #[test]
    fn a_positive_integer_refuses_zero_and_accepts_the_32_bit_maximum() {
        let error = with("[source]\nquiet_period_secs = 0\n").unwrap_err();
        assert_eq!(error, ConfigError::OutOfRange { key: "source.quiet_period_secs".into(), rule: "a positive 32-bit integer".into() });
        assert!(with("[source]\nquiet_period_secs = 4294967295\n").is_ok());
    }

    #[test]
    fn a_count_accepts_zero_and_the_32_bit_maximum_and_refuses_what_lies_outside() {
        for key in ["tags]\nmax_per_note", "tags]\nmax_suggested", "brief]\nmax_notes", "brief]\nmax_spans_per_note", "relations]\nsession_gap_minutes"] {
            assert!(with(&format!("[{key} = 0\n")).is_ok(), "{key} = 0");
            assert!(with(&format!("[{key} = 4294967295\n")).is_ok(), "{key} = u32::MAX");
            assert!(with(&format!("[{key} = -1\n")).is_err(), "{key} = -1");
            assert!(with(&format!("[{key} = 4294967296\n")).is_err(), "{key} = u32::MAX + 1");
        }
    }

    #[test]
    fn a_32_bit_key_refuses_a_value_above_32_bits() {
        assert_eq!(with("[engines]\ntimeout_secs = 4294967296\n").unwrap_err().key(), Some("engines.timeout_secs"));
        assert!(with("[source]\nmax_audio_bytes = 4294967296\n").is_ok());
    }

    #[test]
    fn a_wrong_type_is_refused_naming_the_expected_type() {
        let error = with("[source]\nread_titles = \"yes\"\n").unwrap_err();
        assert_eq!(error, ConfigError::WrongType { key: "source.read_titles".into(), expected: "boolean".into() });
    }

    #[test]
    fn an_enum_refuses_a_value_outside_its_set() {
        let error = with("[notify]\nmode = \"loud\"\n").unwrap_err();
        assert_eq!(error, ConfigError::OutOfRange { key: "notify.mode".into(), rule: "one of desktop, command, off".into() });
    }

    #[test]
    fn a_duration_accepts_the_integer_zero_and_the_unit_form() {
        assert!(with("[retention.hold]\naudio = 0\n").is_ok());
        assert!(with("[retention.hold]\naudio = \"90d\"\n").is_ok());
        assert_eq!(with("[retention.hold]\naudio = \"90\"\n").unwrap_err().key(), Some("retention.hold.audio"));
    }

    #[test]
    fn an_argv_must_be_a_list_of_strings() {
        assert_eq!(with("[notify]\ncommand = [1, 2]\n").unwrap_err().key(), Some("notify.command"));
    }
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-domain duration`

Expected: the build of the `duration::tests` module fails with `cannot find` for `parse_duration` and
`DurationError`. The module is compiled and selected; a run that selects zero tests, or that succeeds,
does not satisfy this step.

Run: `cargo test -p vpt-adapters validate`

Expected: the build of the `validate::tests` module fails, `no method named key` on `ConfigError`. Once
Step 3 adds `key` and nothing else, every test but the `is_ok` assertions FAILS because `load_text`
accepts anything the table names; the whole of Step 3 turns them green.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-domain/src/duration.rs`:

```rust
//! The configuration duration syntax: `0`, or a positive decimal integer
//! followed by `s`, `m`, `h` or `d`, converted to seconds with overflow checked.

#[derive(Debug, PartialEq, Eq)]
pub enum DurationError {
    MissingUnit,
    UnknownUnit(char),
    NotAPositiveInteger,
    Overflow,
}

pub fn parse_duration(text: &str) -> Result<u64, DurationError> {
    if text == "0" {
        return Ok(0);
    }
    let Some(unit) = text.chars().last() else {
        return Err(DurationError::NotAPositiveInteger);
    };
    if unit.is_ascii_digit() {
        return Err(DurationError::MissingUnit);
    }
    let digits = &text[..text.len() - unit.len_utf8()];
    if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(DurationError::NotAPositiveInteger);
    }
    let count: u64 = digits.parse().map_err(|_| DurationError::Overflow)?;
    if count == 0 {
        return Err(DurationError::NotAPositiveInteger);
    }
    let multiplier = match unit {
        's' => 1,
        'm' => 60,
        'h' => 3_600,
        'd' => 86_400,
        other => return Err(DurationError::UnknownUnit(other)),
    };
    count.checked_mul(multiplier).ok_or(DurationError::Overflow)
}
```

`crates/vpt-adapters/src/config/validate.rs`, above its test module:

```rust
//! The value rules of spec section 10, applied by kind from the key table.

use super::load::ConfigError;
use super::schema::{Kind, spec_for};
use toml::{Table, Value};
use vpt_domain::duration::parse_duration;

pub fn validate(table: &Table) -> Result<(), ConfigError> {
    walk(table, "")
}

fn walk(table: &Table, prefix: &str) -> Result<(), ConfigError> {
    for (name, value) in table {
        let path = if prefix.is_empty() { name.clone() } else { format!("{prefix}.{name}") };
        match value {
            Value::Table(inner) => walk(inner, &path)?,
            leaf => {
                let kind = if path.starts_with("retention.hold.") { Kind::Duration } else { spec_for(&path).unwrap_or(Kind::Text) };
                check(&path, kind, leaf)?;
            }
        }
    }
    Ok(())
}

/// A TOML number as f64: a float as is, an integer widened, so `0` and `1`
/// are valid ratio endpoints.
fn number(value: &Value) -> Option<f64> {
    value.as_float().or_else(|| value.as_integer().map(|n| n as f64))
}

fn check(key: &str, kind: Kind, value: &Value) -> Result<(), ConfigError> {
    let wrong = || ConfigError::WrongType { key: key.into(), expected: kind.expected().into() };
    let range = |rule: &str| ConfigError::OutOfRange { key: key.into(), rule: rule.into() };
    match kind {
        Kind::Bool => value.as_bool().map(|_| ()).ok_or_else(wrong),
        Kind::PositiveInt => match value.as_integer() {
            Some(n) if n >= 1 && n <= i64::from(u32::MAX) => Ok(()),
            Some(_) => Err(range("a positive 32-bit integer")),
            None => Err(wrong()),
        },
        Kind::NonNegativeInt => match value.as_integer() {
            Some(n) if n >= 0 && n <= i64::from(u32::MAX) => Ok(()),
            Some(_) => Err(range("a non-negative 32-bit integer")),
            None => Err(wrong()),
        },
        Kind::PositiveInt64 => match value.as_integer() {
            Some(n) if n >= 1 => Ok(()),
            Some(_) => Err(range("a positive 64-bit integer")),
            None => Err(wrong()),
        },
        Kind::Ratio => match number(value) {
            Some(f) if f.is_finite() && (0.0..=1.0).contains(&f) => Ok(()),
            Some(_) => Err(range("a ratio in [0, 1]")),
            None => Err(wrong()),
        },
        Kind::RatioAboveZero => match number(value) {
            Some(f) if f.is_finite() && f > 0.0 && f <= 1.0 => Ok(()),
            Some(_) => Err(range("a ratio in (0, 1]")),
            None => Err(wrong()),
        },
        Kind::Duration => match value {
            Value::Integer(0) => Ok(()),
            Value::String(text) => parse_duration(text).map(|_| ()).map_err(|_| range("0 or <n>s|m|h|d")),
            _ => Err(range("0 or <n>s|m|h|d")),
        },
        Kind::Enum(options) => match value.as_str() {
            Some(text) if options.contains(&text) => Ok(()),
            Some(_) => Err(range(&format!("one of {}", options.join(", ")))),
            None => Err(wrong()),
        },
        Kind::Text | Kind::Secret => value.as_str().map(|_| ()).ok_or_else(wrong),
        Kind::TextList | Kind::Argv => match value.as_array() {
            Some(items) if items.iter().all(Value::is_str) => Ok(()),
            _ => Err(wrong()),
        },
    }
}
```

In `load.rs`, add `key()` to `ConfigError` and call `validate` before returning:

```rust
impl ConfigError {
    pub fn key(&self) -> Option<&str> {
        match self {
            ConfigError::UnknownKey(key)
            | ConfigError::WrongType { key, .. }
            | ConfigError::OutOfRange { key, .. } => Some(key),
            _ => None,
        }
    }
}
```

and in `load_text`, replace `Ok(merged)` with:

```rust
    super::validate::validate(&merged)?;
    Ok(merged)
```

`validate` stays a private module of `config`: nothing outside the loader calls it.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-domain -p vpt-adapters`

Expected: all PASS, Task 3's fifteen tests included.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates/vpt-domain crates/vpt-adapters
SKIP_AI_COMMIT=1 git commit -m "feat(config): value rules by kind and the duration syntax"
```

______________________________________________________________________
