# D4 supervision fix review

Verdict: Approved. Finding 1 from `task-D4-review-1.md` is resolved. No new blocking finding. This approves the reviewed implementation and evidence; the controller owns final acceptance, the normal-hook commit and committed-HEAD checks.

Reviewed on 2026-09-26 by the original independent Astra reviewer. I read the full tracked unstaged diff, both new untracked files, the original review/report and the fresh failure, control and gate evidence. All 40 entries in `task-D4-root-peer-source.sha256` match the current files, including `tests/children/supervision.rs` and `tests/wal/peers.rs`. Production database code and `tests/children/process.rs` are unchanged by this fix. I ran no tests, builds or mutations and wrote only this ignored review.

## Ownership and deadlines

`tests/wal/peers.rs` now launches every affected participant directly from the root test. The root retains each `ChildGuard` while another participant runs. SQLite work and database descriptor acquisition remain inside executed children. A failed spawn, readiness wait, send, completion or assertion unwinds the root-owned guards, so cleanup no longer depends on a scenario process that the outer watchdog can kill.

Every peer receives the same scenario start through `child_for_root`. `children.rs` derives its 500 ms operation deadline and 900 ms cleanup deadline from that start, including later peers. `ProcessGroup` retains its existing bounded termination and reaping behavior. The startup parent check receives the original root process identifier through the cleared environment and runs before database setup.

Readiness parsing advances `ready_offset` only across complete newline-terminated records. It consumes each marker once and leaves an incomplete record available for the next poll. This makes the snapshot writer's second readiness message a distinct commit milestone.

## Preserved SQL evidence

| Existing scenario | Retained assertion and ordering |
| --- | --- |
| Native writer, rooted reader | Native participant holds its uncommitted second row while the rooted observational reader sees only `[1]`; native rollback follows the read. |
| Native writer, rooted contender | Native writer remains held while the rooted transaction returns busy, with the original 20 ms lower bound and 500 ms upper bound. |
| Native reader, rooted writer | Reader first sees sum 1. Root waits for the writer's second marker after committing row 2, then reader still sees 1 inside its transaction and 3 after committing that transaction. |
| Rooted writer, native contender | Rooted participant holds its uncommitted insert while the native transaction returns busy. Rooted close follows the native result. |
| Uncommitted crash | Root terminates and reaps the seed participant after its SQL milestone. Writable recovery sees `[1]`, then proves reuse and integrity. |
| Committed crash | Termination follows the commit milestone. Recovery sees `[1, 2, 3]`, then proves reuse and integrity. |
| Required recovery observation | The hot rollback-journal seed is terminated first. Observation fails with its complete snapshot unchanged, then writable recovery sees `[1]` and proves reuse and integrity. |

No original leaf name, seed transaction or SQL assertion was removed. Single-process snapshot and observational cases retain their previous behavior.

## Test-first and mutation evidence

The first ownership RED compiled and failed at the parent-identity assertion. The broader ownership RED failed exactly the seven nested scenarios while the other five WAL (write-ahead logging) leaves passed. The decoded first failure reports actual parent `70333` versus expected root `70330`. These logs prove the ownership contract failed; they do not demonstrate an observed process leak.

`task-D4-scenario-budget-red-20260926-01.log` compiled and failed the later-peer case at 506.516 ms. The direct-stall cleanup case already passed with unchanged `ProcessGroup`. `task-D4-milestone-red-20260926-01.log` compiled and failed because the second wait reused the first marker. The combined restored control, `task-D4-root-peer-green-20260926-01.log`, passes all 109 database leaves in 1.35 s.

| Compiled mutation | Failure | Restored control |
| --- | --- | --- |
| Reset the scenario start per spawn | 506.517 ms exceeds the 300 ms assertion | Pass, 0.10 s |
| Extend SQLite busy handling to at least five seconds | Real blocked WAL transaction reaches the independent watchdog at 0.52 s | Pass, 0.05 s |
| Reset the consumed-marker offset | Second readiness wait returns the first marker, failing at 0.01 s | Pass, 0.50 s |

The exact patches, changed hashes, byte-identical restorations and passing controls are retained under `task-D4-root-peer-mutant-{budget,busy,milestone}`. I inspected each. The restored owner and child-supervisor hashes match the source manifest.

No additional cleanup mutation is required for this fix. The failure was the location of ownership; cleanup implementation bytes did not change. The ownership RED catches that route, the direct pre-SQL stall checks both `waitpid` reporting `ECHILD` and exact group disappearance with `ESRCH`, and the existing direct watchdog retains forced-cleanup coverage. The new cleanup assertion also has an exact-owned-child termination/reaping backstop. Budget and milestone mutations exercise the newly changed behavior, and the real busy mutation exercises timeout through the flattened route. This evidence supersedes the first review's broader request for a separate cleanup mutant. No intentionally orphaned fixture is needed.

## Final gate evidence and remaining limits

The fresh stable ship log, `task-D4-root-peer-ship-20260926-01.log`, records 318 passing leaves, including all 197 adapter leaves, and reaches the documentation, secrets and file-size checks without an error. The fresh nightly log, `task-D4-root-peer-timing-20260926-01.log`, also records 318 passing leaves. Its maximum measured leaf is 0.599 s. The three supervision leaves measure 0.123, 0.514 and 0.511 s; the seven affected SQL cases are at most 0.447 s.

The earlier setup terminal failures were separately traced to sandbox permission refusal. The unchanged focused control passed with scoped escalation, and the fresh full ship records all 15 setup leaves passing. No terminal product repair is part of D4.

The original seven database timeouts remain historical failures with an unproven cause. Green final gates do not establish that cause. The concurrent-opener fixture still does not force every lock-query-to-acquisition interleaving. The original report's test-first redo and evidence limits remain applicable. The controller must record the completed gates, stage the two new files and perform its committed-HEAD verification before accepting D4.
