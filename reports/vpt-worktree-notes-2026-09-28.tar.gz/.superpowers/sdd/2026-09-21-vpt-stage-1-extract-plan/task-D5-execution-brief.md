# D5 execution brief

## Controller constraints

- D3's independent review found owner.rs cohesive at 211 implementation/223 total lines, above the 200 target but below decomposition and hard ceilings. Keep ownership/close ordering together unless this task's real growth warrants a responsibility split. Do not refactor it solely to erase the soft warning; carry the measured result into the report.
- Staging-lint cleanup is tracked as 6hc7x7wMwxF8R9rg. Record anything legitimately still awaiting D6 by exact item, not a general deferral.
- Audit the D1-D4 staging lint inventory after ledger integration. Remove every temporary expect(dead_code) whose owner/file/ledger consumer now exists. Only an explicitly named title-policy variant genuinely awaiting D6 may remain, with its removal tracked there. Do not add synthetic use sites or change visibility to hide unused private code.
- Dispatch only after D4 is independently accepted. Read the actual D1-D4 database APIs and approved containment design. Integration and observational guarantees remain high-risk: Astra implementation and independent Astra review.
- Own only the application ledger error/export, adapter ledger/schema/connection modules and focused tests named below, plus required adapter exports and D5 report/evidence. Main owns progress.md and Todoist. You are not alone; preserve others' work. One product writer, no subagents or new worktree.
- The amendment replaces original Task 11's native opening and cleanup mechanism. Its original public contract and exact version-1 schema are copied below. Do not copy the obsolete native pathname/URI opener, raw SQLite error strings or a bare-connection-returning helper from the original sample.
- Preserve original migration, future-version, permission repair, read-only, bounded busy, foreign-key and rollback behavior. Adapt the original busy fixture to D2's supervised native child; never overlap native and rooted connections on the same inode in one process. Use immutable borrowed connections inside the retained owner, immediate transactions and the amendment's explicit close/error precedence.
- Test absent state/database, empty file and zero schema separately from populated missing companions. Observation must leave the full crate-owned snapshot unchanged. Containment errors must survive closures that map SQL failures. Schema/version contents are unchanged; do not implement Task 12 repositories early.
- All fixtures are synthetic and owned. No live paths, third-party edits/system-call overrides, denied probes, broad process listings, native fallback, publication/install/apply or destructive cleanup. Verify buffer safety and use apply_patch.
- Preserve all prior leaves; compiling behavioral RED, exact compiled mutations, byte-identical restored controls and unique raw logs per attempt. Address survivors. Required Rust/release/staged-size/secrets gates apply; controller owns fresh committed-HEAD ship. Existing command-test deadline overruns are tracked as 6hc7MMRc2QhRm75g; preserve recurrence without retry loops or deadline increases.

## Original Task 11 contracts

- Consumes: `vpt_adapters::{Access, ContainedError, Kind, RootDir}`.

- Produces: `vpt_application::ports::LedgerError::{Busy, UnsupportedSchema(u32), Conflict(String),`
  `Corrupt(String), Io(String), PathEscape(PathBuf)}`;
  `vpt_adapters::{SqliteLedger, OpenError, SCHEMA_VERSION}` (`ledger/mod.rs` keeps `sqlite` private and
  re-exports these) with `OpenError::{Contained(ContainedError), Ledger(LedgerError)}` (`From` both ways
  in), `SqliteLedger::BUSY_TIMEOUT: Duration = Duration::from_secs(5)`,
  `SqliteLedger::open(state: &RootDir) -> Result<SqliteLedger, OpenError>`,
  `SqliteLedger::open_with_timeout(state: &RootDir, busy: Duration) -> Result<SqliteLedger, OpenError>`,
  `SqliteLedger::open_read_only(state_dir: &Path) -> Result<Option<SqliteLedger>, OpenError>`,
  `fn database_path(&self) -> &Path`, `fn schema_version(&self) -> Result<u32, LedgerError>`,
  `pub(crate) fn transaction<T>(&self, op: impl FnOnce(&rusqlite::Transaction<'_>) ->`
  `Result<T, LedgerError>) -> Result<T, LedgerError>` (an `Io` error on a read-only ledger),
  `pub(crate) fn read<T>(&self, op: impl FnOnce(&rusqlite::Connection) -> Result<T,`
  `LedgerError>) -> Result<T, LedgerError>`; `SCHEMA_VERSION: u32 = 1`;
  `pub(crate) fn map(error: rusqlite::Error) -> LedgerError` in `ledger::sqlite`.

## Exact version-1 schema

```rust
pub const VERSION: u32 = 1;

const SCHEMA_V1: &str = "
CREATE TABLE seen (
  path TEXT PRIMARY KEY,
  file_name TEXT NOT NULL,
  size INTEGER NOT NULL,
  mtime_secs INTEGER NOT NULL,
  mtime_nanos INTEGER NOT NULL,
  flags INTEGER NOT NULL,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  deferral_count INTEGER NOT NULL DEFAULT 0,
  deferral_reason TEXT,
  deferred_size INTEGER,
  source_gone_at INTEGER,
  recording TEXT
);
CREATE TABLE recordings (
  id TEXT PRIMARY KEY,
  source_path TEXT,
  digest TEXT NOT NULL UNIQUE,
  captured_at INTEGER NOT NULL,
  captured_offset INTEGER NOT NULL,
  duration_secs INTEGER NOT NULL,
  title TEXT,
  title_source TEXT NOT NULL,
  ingested_at INTEGER NOT NULL,
  audio_path TEXT NOT NULL,
  stage_transcribe TEXT NOT NULL,
  stage_note TEXT NOT NULL,
  stage_synthesis TEXT NOT NULL,
  transcript_note_path TEXT,
  analysis_note_path TEXT,
  engines TEXT,
  language TEXT,
  open_flags INTEGER NOT NULL DEFAULT 0,
  diagnostics INTEGER NOT NULL DEFAULT 0,
  audio_trashed_at INTEGER
);
CREATE TABLE transcripts (
  recording TEXT PRIMARY KEY REFERENCES recordings(id),
  engine TEXT NOT NULL,
  body TEXT NOT NULL,
  accepted_at INTEGER NOT NULL
);
CREATE TABLE proposals (
  recording TEXT PRIMARY KEY REFERENCES recordings(id),
  input_digest TEXT NOT NULL,
  body TEXT NOT NULL,
  accepted_at INTEGER NOT NULL
);
CREATE TABLE flags (
  identifier TEXT PRIMARY KEY,
  recording TEXT NOT NULL REFERENCES recordings(id),
  shape TEXT NOT NULL,
  class TEXT NOT NULL,
  ranges TEXT,
  artifact TEXT,
  claim_index INTEGER,
  claim_digest TEXT,
  record_text TEXT,
  alternative_text TEXT,
  confidence REAL,
  state TEXT NOT NULL,
  resolution_text TEXT,
  resolved_at INTEGER
);
CREATE TABLE occasions (
  id TEXT PRIMARY KEY,
  provider_key TEXT NOT NULL UNIQUE,
  source TEXT NOT NULL,
  at INTEGER NOT NULL,
  duration_secs INTEGER,
  title TEXT NOT NULL,
  participants TEXT NOT NULL,
  tags TEXT NOT NULL,
  pack TEXT,
  brief_path TEXT,
  briefed_at INTEGER
);
CREATE TABLE tags (
  recording TEXT NOT NULL REFERENCES recordings(id),
  tag TEXT NOT NULL,
  state TEXT NOT NULL,
  provenance TEXT NOT NULL,
  PRIMARY KEY (recording, tag)
);
CREATE TABLE relations (
  recording TEXT NOT NULL REFERENCES recordings(id),
  kind TEXT NOT NULL,
  target TEXT NOT NULL,
  state TEXT NOT NULL,
  provenance TEXT NOT NULL,
  rule TEXT,
  ranges TEXT,
  PRIMARY KEY (recording, kind, target)
);
CREATE TABLE releases (
  sequence INTEGER PRIMARY KEY AUTOINCREMENT,
  recording TEXT NOT NULL REFERENCES recordings(id),
  stage TEXT NOT NULL,
  destination TEXT NOT NULL,
  content_digest TEXT NOT NULL,
  source_digest TEXT NOT NULL,
  report_path TEXT NOT NULL,
  snapshot TEXT NOT NULL,
  released_at INTEGER NOT NULL
);
CREATE TABLE dirty_publications (
  target TEXT PRIMARY KEY,
  expected_previous TEXT,
  intended TEXT NOT NULL,
  recorded_at INTEGER NOT NULL
);
CREATE TABLE retention_intents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artifact_kind TEXT NOT NULL,
  recording TEXT,
  path TEXT NOT NULL,
  expected TEXT NOT NULL,
  recorded_at INTEGER NOT NULL,
  completed_at INTEGER
);
";
```

## Approved D5 task

## D5: Ledger integration and observational behavior

**Files:** Original Task 11's application error declaration, port exports, ledger module, schema,
connection and boundary tests; adapters `lib.rs`. Preserve the schema SQL and `SCHEMA_VERSION = 1` from
that task exactly. D1 through D4 replace its opening mechanism, not its tables or migration contract. Add
only test-configuration exports of `root` and `snapshot` at the end of `database/mod.rs` so the ledger
and title tests can reuse crate-owned fixtures. The production module stays private.

**Interfaces:** Keep all original Task 11 public signatures, including `OpenError`, `SqliteLedger`,
`BUSY_TIMEOUT`, `open`, `open_with_timeout`, `open_read_only`, `database_path`, `schema_version`, `read`
and `transaction`. Private
`connection::open(state: &RootDir, busy: Duration, policy: AccessPolicy) -> Result<Database, LedgerError>`
returns the retained owner. Implement `From<DatabaseError> for LedgerError`. Keep
`map(rusqlite::Error) -> LedgerError` for repository closures; it uses error codes and fixed safe
messages, never raw SQLite error text. `database_path()` remains diagnostic only. Change private
`migrations::migrate` to accept `&Connection`; it and `SqliteLedger::transaction` create their immediate
transaction with `rusqlite::Transaction::new_unchecked(connection, TransactionBehavior::Immediate)`. The
wrapper admits one operation at a time and SQLite rejects nested transactions. This keeps the connection
borrow immutable without changing the application contract.

- [ ] **Step 1: Write compiling red ledger tests.**

```rust
#[test]
fn observation_after_last_writer_close_changes_nothing() {
    let (_temp, root) = root();
    let ledger = SqliteLedger::open(&root).unwrap();
    assert_eq!(ledger.schema_version().unwrap(), SCHEMA_VERSION);
    drop(ledger);
    let before = snapshot(root.path());
    let observed = SqliteLedger::open_read_only(root.path()).unwrap().unwrap();
    assert_eq!(observed.schema_version().unwrap(), SCHEMA_VERSION);
    drop(observed);
    assert_eq!(snapshot(root.path()), before);
}

#[test]
fn populated_ledger_with_missing_companion_is_not_repaired() {
    let (_temp, root) = root();
    drop(SqliteLedger::open(&root).unwrap());
    root.unlink_file(Path::new("vpt.db-shm")).unwrap();
    let before = snapshot(root.path());
    assert!(SqliteLedger::open_read_only(root.path()).is_err());
    assert_eq!(snapshot(root.path()), before);
}
```

Reuse the crate-owned snapshot/fixture helpers through test-only curated exports, not a public production
module. Add original migration, future-version, rollback, privacy, busy and foreign-key tests with rooted
connection owners. Add separate absent state, absent database, empty file and zero-schema tests returning
`None` without changes. Root replacement after constructing a ledger must yield `PathEscape`, including
if the old pathname is now missing. Inject a containment failure during a query and verify it survives a
repository closure that already mapped the SQLite result.

- [ ] **Step 2: Run red.**

```bash
cargo test --locked -p vpt-adapters ledger::sqlite -- --nocapture
```

Expected: new tests compile and fail on the missing behavior. They must not accidentally call the old
native pathname opener.

- [ ] **Step 3: Compose operations through the retained owner.**

Writable open creates/repairs private state files through D1, opens with `WritableLedger`, enables
foreign keys and WAL, and runs original migrations in an immediate transaction. Observational open uses
`ObservationalLedger`, never writes pragmas that change journal format, and never migrates. Check version
through that connection; version zero yields `None`. Require existing regular WAL and shared-memory
companions for a populated ledger. Missing or zero-schema state retains the original empty behavior even
when companions do not yet exist. The initial inspection must itself obey the read-only policy.

Wrap each read/transaction in `Database::with_connection`, including migrations. Close explicitly after
the closure returns, on both success and failure. Preserve the original operation error when ordinary
cleanup also fails; a containment failure takes precedence so it cannot be disguised. Closing must finish
before registration is released. Use this combination rule in one private helper:

```rust
fn finish<T>(result: Result<T, LedgerError>, closed: Result<(), LedgerError>) -> Result<T, LedgerError> {
    match (result, closed) {
        (_, Err(error @ LedgerError::PathEscape(_))) => Err(error),
        (Err(error), _) => Err(error),
        (Ok(_), Err(error)) => Err(error),
        (Ok(value), Ok(())) => Ok(value),
    }
}
```

`transaction` retains the original immediate transaction and read-only refusal. Revalidate before commit;
rollback and close still use the acquired authority if that validation fails. Map containment to
`PathEscape`, busy/locked to `Busy`, constraints to `Conflict`, corruption/not-a-database to `Corrupt`,
and other storage failures to `Io`. Safe messages can name the operation and configured path but cannot
interpolate titles, SQL values or database content. Keep the original command exit mapping.

- [ ] **Step 4: Verify green and repository compatibility.**

Run the ledger tests and all database tests. Mutate policy selection to writable for observation, discard
the connection error latch, skip foreign keys, and bypass migration rollback one at a time. Each
corresponding behavioral test must fail. Restore controls. During original Task 12, run the same contract
against `MemoryLedger` and this durable ledger; retain the preflight's signed-integer, time and
path-encoding rejection cases. Repeat that shared contract when Task 31 adds retention repositories.

- [ ] **Step 5: Format, review and commit.**

```bash
cargo fmt --all
cargo test --locked -p vpt-adapters
git add crates/vpt-application/src/ports/ledger.rs crates/vpt-application/src/ports/mod.rs
git add crates/vpt-adapters/src/ledger crates/vpt-adapters/src/lib.rs
git add crates/vpt-adapters/src/database/mod.rs
git commit -m "feat(ledger): use contained database connections"
```
