# D6 query preflight

The original title query escapes wildcard characters but still uses ASCII-insensitive LIKE matching, as documented by [SQLite](https://www.sqlite.org/lang_expr.html). An exact filename can therefore receive another case variant's title.

On 2026-09-22 the controller ran only synthetic constant queries in an in-memory database, with startup configuration disabled and safe mode enabled. No source or destination file was opened. Command:

```bash
sqlite3 -noinit -safe -batch :memory: "SELECT sqlite_version(); WITH recording(path, title) AS (VALUES ('dir/A.m4a', 'upper')) SELECT count(*) AS sample_matches FROM recording WHERE path = 'a.m4a' OR path LIKE '%/a.m4a' ESCAPE '\'; WITH recording(path, title) AS (VALUES ('dir/A.m4a', 'upper')) SELECT count(*) AS exact_matches FROM recording WHERE path = 'a.m4a' COLLATE BINARY OR substr(path, -length('a.m4a') - 1) = ('/' || 'a.m4a') COLLATE BINARY;"
```

Observed output, exec chunk b2a00a, exit 0:

```text
3.54.0
1
0
```

This verifies the sample mismatch on the installed command-line SQLite, not VPT's locked library or its unimplemented title adapter.

During D6, reproduce through the real TitleCopy fixture first. Require exact-case positive and negative cases, including two titles whose basenames differ only by case. Preserve existing tests for percent, underscore, backslash and basename boundaries. Use a parameterized literal suffix comparison with binary equality instead of relying on LIKE escaping for exactness; keep table-name quoting and typed containment handling. No API change, new pragma, dependency or general matching policy is needed.
