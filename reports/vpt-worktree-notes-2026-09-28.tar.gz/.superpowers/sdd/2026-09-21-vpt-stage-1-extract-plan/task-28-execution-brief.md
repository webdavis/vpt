# Task 28 execution brief

Read task-28-brief.md completely and use the accepted adapters at `94351b5`. The independent
observation lane can proceed while history and logging are completed. Its real database fixtures
replace the sample's dependency on an unimplemented ingest command. The later ingest-to-show
acceptance case remains with Task 27.

## Ownership and prerequisites

One Sol writer owns application inventory and the Stores entries extension, its real filesystem
adapter, and the show/list/storage command routes. Pull forward only Task 27's read-only
RuntimeLedger composition, recording document and error mappings used by these commands. Do not
add publication/history/retention delegation, mutating Runtime, clock or hook composition yet.
Root owns cross-lane integration and the final combined gates.

Use the existing RecordingLedger, SqliteLedger::open_read_only, planned_directory, resolve_stores,
FilesystemStores::open_read_only and command parser. Show/list open only configuration and the
observational ledger. Storage opens only configuration and the named store capabilities. Neither
path creates directories, migrates state, repairs publications, writes history/logs or runs hooks.

Own the task's named source files plus compose/ledger.rs, compose/errors.rs and documents/record.rs
with their private module registrations. Keep narrow test support in a cohesive child module of
the existing command fixture. Preserve all accepted support, command and adapter leaves.

## Test-first corrections

Compile inert scaffolding before the first behavioral RED. Missing imports and compilation failures
are not RED. This includes document fields, error mapping, enum delegation and inventory helpers;
do not implement a small helper before its regression merely because it appears straightforward.

Seed synthetic recordings through the real accepted RootDir and SqliteLedger in private owned
fixtures, close the connection, then invoke the actual command. No helper, ingestion substitute,
live config/state or live audio is needed. Reuse existing process supervision and snapshots. Keep
unchanged fixtures quiescent while comparing bytes, modes and modification timestamps.

Cover inventory empty/sum/overflow and nanosecond ordering; entries depth-one, absent configured
root, unknown root, symlink refusal and replaced retained root; exact known recording output,
unknown/malformed identity, all three stage filters with mixed states, invalid stage, seven-store
inventory, fresh no-create, dirty-state no-write and capability independence. Operational errors
remain exit 1, usage errors exit 2 and path-containment refusals exit 3. Pin actual command wiring.

StoreEntry.path is the full contained path returned by RootDir::leaf. Use retained-root
operations and revalidation. Never follow a linked entry or silently convert an unconfigured root
to an empty result. Reject unrepresentable output through typed command errors rather than panic
or silently replace path bytes. Do not revive the sample's unsolicited docstrings or broad lint
allowances.

## Verification and handoff

Run focused RED/GREEN, compiling meaningful mutations with exact restored controls, and scoped
static checks. Share one native verification window directly with the history writer; source work
and review proceed in parallel. No timeout or runner/build parallelism overrides. Root runs one
committed integration ship/release/nightly packet. Keep a raw exact leaf census and evidence report.
Do not commit until root clears review. No installation, remote writes or destructive cleanup.

HERDR_ENV is unset at dispatch. Plain git worktree creation is permitted. If it becomes set to 1,
create through `herdr worktree create --cwd <repo-root> --branch <name> --no-focus`, never through
git worktree add.
