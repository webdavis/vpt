### Task 32: `vpt retention run`

**Files:**

- Create: `crates/vpt-application/src/retention/{mod,report,reconcile}.rs`.
- Modify: `crates/vpt-application/src/lib.rs`.
- Create: `crates/vpt-adapters/tests/retention_reconcile.rs`.
- Create: `crates/vpt/src/compose/recovery.rs`, `crates/vpt/src/commands/retention.rs`.
- Modify: `crates/vpt/src/compose.rs`, `crates/vpt/src/compose/runtime.rs`,
  `crates/vpt/src/commands/{mod,ingest}.rs`, `crates/vpt/src/lib.rs`.
- Test: `crates/vpt/tests/{retention,retention_startup}.rs`; `crates/vpt/tests/support/mod.rs` gains
  `set_mtime`.

**Interfaces:**

- Consumes `RecordingLedger::{recordings,by_id,set_audio_trashed}`, `RetentionJournal`,
  `Stores::{entries,validate_path,digest_of}`, `Trash::trash`, `Clock::now`, `RetentionSettings::hold`,
  `StorePaths::get`, `HelperClient::version`.
- Produces curated application exports:
  - `Retention<'a,L,J,S,T,C> { pub ledger:&'a L, pub journal:&'a J, pub stores:&'a S,`
    `pub trash:&'a T, pub clock:&'a C, pub settings:&'a RetentionSettings, pub paths:&'a StorePaths }`,
    with `L:RecordingLedger, J:RetentionJournal, S:Stores, T:Trash, C:Clock` and
    `run(&self,dry_run:bool,initial:ReconcileProgress)->Result<RetentionReport,RetentionFailure>`.
  - `Moved { pub recording:RecordingId, pub store:StoreKey, pub path:PathBuf }`.
  - `KeptReason::{Untracked,DigestMismatch}` with `as_str(self)->&'static str`;
    `Kept { pub path:PathBuf, pub reason:KeptReason }`.
  - `ReconcileProgress { pub moved:Vec<Moved>, pub completed:Vec<RecordingId> }`;
    `ReconcileFailure { pub error:RetentionError, pub progress:ReconcileProgress }`.
  - `RetentionReport { pub moved:Vec<Moved>, pub kept:Vec<Kept>,` `pub completed:Vec<RecordingId> }` and
    `RetentionFailure { pub error:RetentionError,` `pub report:RetentionReport }`.
  - `RetentionError::{Disabled,TargetModified(PathBuf),Ledger(LedgerError),Stores(StoreError),Trash(TrashError)}`.
  - `reconcile_intents<J:RetentionJournal,L:RecordingLedger,S:Stores,T:Trash,C:Clock>(`
    `journal:&J,ledger:&L,stores:&S,trash:&T,clock:&C,audio:&Path)`
    `->Result<ReconcileProgress,ReconcileFailure>`.
- Command composition:
  - `Operation::{Ingest,Retention}` and `AccessMode::{ReadOnly,Mutating}`.
  - `Runtime::load(environment:&Environment,config:Option<&Path>,access:AccessMode,operation:Operation)->Result<Runtime,Box<ErrorDocument>>`.
  - `Runtime.recorder:Option<VoiceMemosStore>`; only `Operation::Ingest` opens it.
  - `compose::errors::ledger_error(error:LedgerError)->ErrorDocument` maps
    `LedgerError::PathEscape(PathBuf)` to exit 3 `path_escape`.
  - `StartupFailure { pub error:ErrorDocument, pub progress:ReconcileProgress }`.
  - `Runtime::mutating(&self)->Result<ReconcileProgress,Box<StartupFailure>>`.
  - `Runtime::retention_notice(&self,moved:&[Moved])`.
  - `Runtime::finish_recovery(&self,outcome:Outcome,progress:&ReconcileProgress)->Outcome`.
  - `commands::retention::run(runtime:&Runtime,dry_run:bool)->Outcome`.
  - `Sandbox::set_mtime(&self,path:&Path,seconds_ago:u64)`.

Retention reports carry recording identities separately from paths. Recovery returns every successful
side effect even when a later intent fails. The command emits one retention event after combining
recovery with new moves, including on partial failure. Dry runs use the read-only runtime and never
reconcile.

- [ ] **Step 1: Write the failing tests**

Register the private `retention` application module and its curated exports before the red run. Register
`mod report; mod reconcile;` in `retention/mod.rs` and create those files before importing their types.
Integration tests are automatically selected by their explicit `--test` names.

`crates/vpt-adapters/tests/retention_reconcile.rs`:

```rust
use std::path::{Path, PathBuf};
use vpt_adapters::{FilesystemStores, MemoryLedger};
use vpt_application::ports::{
    ArtifactKind, Clock, LedgerCommit, LedgerError, NewIntent, RecordingLedger, RecordingRecord,
    RetentionIntent, RetentionJournal, StageStates, StoreError, Stores, TitleOrigin, Trash, TrashError,
};
use vpt_application::{ReconcileFailure, RetentionError, reconcile_intents};
use vpt_domain::identity::RecordingId;
use vpt_domain::time::{UtcInstant, UtcOffset};

struct FixedClock;
impl Clock for FixedClock {
    fn now(&self) -> UtcInstant { UtcInstant { secs: 1_787_690_916 } }
    fn offset_at(&self, _: UtcInstant) -> UtcOffset { UtcOffset { secs: 0 } }
}

struct LocalTrash {
    root: PathBuf,
    calls: std::cell::Cell<usize>,
}
impl Trash for LocalTrash {
    fn trash(&self, path: &Path) -> Result<PathBuf, TrashError> {
        self.calls.set(self.calls.get() + 1);
        let target = self.root.join(path.file_name().expect("fixture leaf"));
        std::fs::rename(path, &target).map_err(|e| TrashError::Failed(e.kind().to_string()))?;
        Ok(target)
    }
}

struct World {
    dir: tempfile::TempDir,
    audio: PathBuf,
    ledger: MemoryLedger,
    stores: FilesystemStores,
    trash: LocalTrash,
}
fn fixture_world() -> World {
    let dir = tempfile::tempdir().expect("dir");
    let audio = dir.path().join("audio");
    let trash = dir.path().join("trash");
    std::fs::create_dir(&audio).expect("audio");
    std::fs::create_dir(&trash).expect("trash");
    let audio = audio.canonicalize().expect("canonical audio root");
    World {
        stores: FilesystemStores::open(std::slice::from_ref(&audio)).expect("stores"),
        audio,
        ledger: MemoryLedger::new(),
        trash: LocalTrash { root: trash, calls: std::cell::Cell::new(0) },
        dir,
    }
}
fn intent(world: &World, path: PathBuf, bytes: &[u8], present: bool) -> RecordingId {
    if present { std::fs::write(&path, bytes).expect("fixture"); }
    let digest = world.stores.digest_bytes(bytes);
    let at = UtcInstant { secs: 1_787_604_456 };
    let offset = UtcOffset { secs: -21_600 };
    let id = RecordingId::derive(at, offset, &digest).expect("id");
    let record = RecordingRecord {
        id: id.clone(), source_path: None, digest, captured_at: at, captured_offset: offset,
        duration_secs: 3, title: None, title_source: TitleOrigin::Unavailable,
        ingested_at: at, audio_path: path.clone(), stages: StageStates::fresh(), audio_trashed_at: None,
    };
    world.ledger.commit(&LedgerCommit {
        recordings: vec![record], ..LedgerCommit::default()
    }).expect("record");
    world.ledger.record_intent(&NewIntent {
        kind: ArtifactKind::Audio, recording: id.clone(), path, expected: digest, recorded_at: at,
    }).expect("intent");
    id
}
fn reconcile(world: &World) -> Result<vpt_application::ReconcileProgress, ReconcileFailure> {
    reconcile_intents(&world.ledger, &world.ledger, &world.stores, &world.trash, &FixedClock, &world.audio)
}

#[test]
fn an_absent_path_completes_the_expiration_without_the_trash() {
    let world = fixture_world();
    let id = intent(&world, world.audio.join("gone.m4a"), b"gone", false);
    let report = reconcile(&world).expect("reconciled");
    assert!(report.moved.is_empty());
    assert_eq!(report.completed, vec![id.clone()]);
    assert_eq!(world.trash.calls.get(), 0);
    assert!(world.ledger.pending_intents().expect("pending").is_empty());
    assert!(world.ledger.by_id(&id).expect("row").expect("record").audio_trashed_at.is_some());
}

#[test]
fn an_unchanged_original_is_moved_again_and_completed() {
    let world = fixture_world();
    let path = world.audio.join("still.m4a");
    let id = intent(&world, path.clone(), b"still", true);
    let report = reconcile(&world).expect("reconciled");
    assert_eq!(report.completed, vec![id]);
    assert_eq!(report.moved[0].path, path);
    assert_eq!(world.trash.calls.get(), 1);
    assert!(world.trash.root.join("still.m4a").exists());
    assert!(world.ledger.pending_intents().expect("pending").is_empty());
}

#[test]
fn replaced_content_is_a_refusal_naming_the_path_and_stays_pending() {
    let world = fixture_world();
    let path = world.audio.join("changed.m4a");
    intent(&world, path.clone(), b"original", true);
    std::fs::write(&path, b"replacement").expect("replacement");
    let failure = reconcile(&world).expect_err("refused");
    assert_eq!(failure.error, RetentionError::TargetModified(path));
    assert!(failure.progress.completed.is_empty());
    assert_eq!(world.trash.calls.get(), 0);
    assert_eq!(world.ledger.pending_intents().expect("pending").len(), 1);
}

#[test]
fn a_later_refusal_retains_the_first_move_and_its_recording_identity() {
    let world = fixture_world();
    let first = world.audio.join("a.m4a");
    let id = intent(&world, first.clone(), b"first", true);
    let second = world.audio.join("b.m4a");
    intent(&world, second.clone(), b"second", true);
    std::fs::write(&second, b"changed").expect("replacement");
    let failure = reconcile(&world).expect_err("second refuses");
    assert_eq!(failure.error, RetentionError::TargetModified(second.clone()));
    assert_eq!(failure.progress.completed, vec![id]);
    assert_eq!(failure.progress.moved[0].path, first);
    assert!(!first.exists());
    assert!(second.exists());
    assert_eq!(world.ledger.pending_intents().expect("pending").len(), 1);
}

struct FailComplete<'a>(&'a MemoryLedger);
impl RetentionJournal for FailComplete<'_> {
    fn record_intent(&self, intent: &NewIntent) -> Result<i64, LedgerError> { self.0.record_intent(intent) }
    fn pending_intents(&self) -> Result<Vec<RetentionIntent>, LedgerError> { self.0.pending_intents() }
    fn complete_intent(&self, _: i64, _: UtcInstant) -> Result<(), LedgerError> {
        Err(LedgerError::Corrupt("injected completion failure".into()))
    }
}

#[test]
fn journal_failure_after_trash_retains_the_move_and_completed_id() {
    let world = fixture_world();
    let path = world.audio.join("a.m4a");
    let id = intent(&world, path.clone(), b"first", true);
    let failure = reconcile_intents(
        &FailComplete(&world.ledger), &world.ledger, &world.stores, &world.trash,
        &FixedClock, &world.audio,
    ).expect_err("completion fails");
    assert!(matches!(failure.error, RetentionError::Ledger(_)));
    assert_eq!(failure.progress.completed, vec![id]);
    assert_eq!(failure.progress.moved[0].path, path);
    assert!(!path.exists());
    assert_eq!(world.ledger.pending_intents().expect("pending").len(), 1);
}

#[test]
fn journal_paths_outside_audio_and_leaf_links_never_reach_trash() {
    let world = fixture_world();
    let outside = world.dir.path().join("outside.m4a");
    intent(&world, outside.clone(), b"outside", true);
    let failure = reconcile(&world).expect_err("escape");
    assert_eq!(failure.error, RetentionError::Stores(StoreError::Escape(outside.clone())));
    assert_eq!(std::fs::read(&outside).expect("untouched"), b"outside");
    assert_eq!(world.trash.calls.get(), 0);

    let world = fixture_world();
    let leaf = world.audio.join("link.m4a");
    intent(&world, leaf.clone(), b"link", false);
    std::os::unix::fs::symlink(&outside, &leaf).expect("symlink");
    assert!(matches!(reconcile(&world).expect_err("link").error, RetentionError::Stores(StoreError::Escape(_))));
    assert_eq!(world.trash.calls.get(), 0);
}

#[test]
fn replacing_the_audio_root_with_a_symlink_never_reaches_trash() {
    let world = fixture_world();
    let path = world.audio.join("a.m4a");
    intent(&world, path, b"original", true);
    let original = world.dir.path().join("original");
    std::fs::rename(&world.audio, &original).expect("move fixture root");
    std::os::unix::fs::symlink(&original, &world.audio).expect("root link");
    assert!(matches!(reconcile(&world).expect_err("root link").error, RetentionError::Stores(StoreError::Escape(_))));
    assert_eq!(world.trash.calls.get(), 0);
    assert_eq!(std::fs::read(original.join("a.m4a")).expect("untouched"), b"original");
}
```

`crates/vpt/tests/retention.rs`:

```rust
mod support;
use support::{Sandbox, run, stderr, stdout};
use vpt_domain::fixtures::m4a;

const CAPTURED: i64 = 1_787_604_456;
const ENABLED: &str = "[retention]\nenabled = true\ninclude_audio = true\n[retention.hold]\naudio = \"1d\"\n";

fn ingested(name: &str, extra: &str) -> (Sandbox, String, std::path::PathBuf) {
    let sandbox = Sandbox::new(name);
    sandbox.install_fake_helper();
    sandbox.write_config(extra);
    sandbox.add_recording("a.m4a", &m4a(CAPTURED, 3, b"audio"));
    let output = run(sandbox.vpt().args(["ingest", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    let id = document["ingested"][0]["id"].as_str().expect("id").to_owned();
    let clone = sandbox.path().join(format!("home/.vpt/audio/{id}.m4a"));
    sandbox.set_mtime(&clone, 0);
    (sandbox, id, clone)
}

#[test]
fn an_expired_clone_moves_to_the_trash_through_the_helper_and_the_ledger_records_it() {
    let (sandbox, id, clone) = ingested("retention-move", ENABLED);
    sandbox.set_mtime(&clone, 2 * 86_400);
    let output = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["moved"], serde_json::json!([{"store":"audio","path":clone}]));
    assert!(!clone.exists());
    assert!(sandbox.path().join(format!("trash/{id}.m4a")).exists());
    let shown = run(sandbox.vpt().args(["show", &id, "--json"]));
    let record: serde_json::Value = serde_json::from_str(&stdout(&shown)).expect("json");
    assert!(record["audio_trashed_at"].is_string());
    let intents: i64 = sandbox.ledger().query_row(
        "SELECT COUNT(*) FROM retention_intents WHERE completed_at IS NOT NULL", [], |r| r.get(0),
    ).expect("count");
    assert_eq!(intents, 1);
}

#[test]
fn an_untracked_file_in_a_store_survives_and_is_reported_kept() {
    let (sandbox, _, _) = ingested("retention-untracked", ENABLED);
    let stray = sandbox.path().join("home/.vpt/audio/stray.m4a");
    std::fs::write(&stray, b"not vpt's").expect("stray");
    sandbox.set_mtime(&stray, 30 * 86_400);
    let output = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert!(stray.exists());
    assert_eq!(document["kept"], serde_json::json!([{"path":stray,"reason":"untracked"}]));
    assert_eq!(document["moved"], serde_json::json!([]));
}

#[test]
fn audio_is_excluded_unless_include_audio_is_set() {
    let (sandbox, _, clone) = ingested("retention-exclude", "[retention]\nenabled = true\n[retention.hold]\naudio = \"1d\"\n");
    sandbox.set_mtime(&clone, 2 * 86_400);
    let output = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    assert!(clone.exists());
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["moved"], serde_json::json!([]));
}

#[test]
fn dry_run_lists_what_would_move_and_moves_nothing() {
    let (sandbox, _, clone) = ingested("retention-dry", ENABLED);
    sandbox.set_mtime(&clone, 2 * 86_400);
    let before = std::fs::read(sandbox.path().join("state/vpt/vpt.db")).expect("db");
    let output = run(sandbox.vpt().args(["retention", "run", "--dry-run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["moved"][0]["path"], clone.to_string_lossy().as_ref());
    assert!(clone.exists());
    assert_eq!(std::fs::read(sandbox.path().join("state/vpt/vpt.db")).expect("db"), before);
    let intents: i64 = sandbox.ledger().query_row("SELECT COUNT(*) FROM retention_intents", [], |r| r.get(0)).expect("count");
    assert_eq!(intents, 0);
    assert!(!sandbox.fake_log().exists());
}

#[test]
fn fresh_dry_run_creates_no_state_or_store_leaf() {
    let sandbox = Sandbox::new("retention-fresh-dry");
    sandbox.install_fake_helper();
    sandbox.write_config(ENABLED);
    let output = run(sandbox.vpt().args(["retention", "run", "--dry-run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    assert!(!sandbox.path().join("state/vpt").exists());
    assert!(!sandbox.path().join("home/.vpt/audio").exists());
    assert!(!sandbox.fake_log().exists());
}

#[test]
fn an_expired_clone_with_replaced_bytes_is_kept_without_an_intent() {
    let (sandbox, _, clone) = ingested("retention-replaced", ENABLED);
    std::fs::write(&clone, b"replacement").expect("replacement");
    sandbox.set_mtime(&clone, 2 * 86_400);
    let output = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["moved"], serde_json::json!([]));
    assert_eq!(document["kept"], serde_json::json!([{"path":clone,"reason":"digest_mismatch"}]));
    assert_eq!(std::fs::read(&clone).expect("preserved"), b"replacement");
    let count: i64 = sandbox.ledger().query_row(
        "SELECT COUNT(*) FROM retention_intents", [], |row| row.get(0),
    ).expect("count");
    assert_eq!(count, 0);
    assert!(!sandbox.fake_log().exists());
}

#[test]
fn disabled_absent_and_unvalidated_helpers_refuse_before_moves() {
    let (sandbox, _, _) = ingested("retention-disabled", "");
    assert_eq!(run(sandbox.vpt().args(["retention", "run"])).status.code(), Some(2));
    let (sandbox, _, clone) = ingested("retention-helper", ENABLED);
    sandbox.set_mtime(&clone, 2 * 86_400);
    for (version, code, rule) in [("2.0.0", 3, Some("helper_version")), ("bad", 1, None)] {
        let output = run(sandbox.vpt().args(["retention", "run", "--json"]).env("VPT_FAKE_VERSION", version));
        assert_eq!(output.status.code(), Some(code), "{}", stderr(&output));
        let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
        assert_eq!(document["error"]["rule"], serde_json::json!(rule));
        assert!(clone.exists());
    }
    std::fs::rename(sandbox.path().join("bin/vpt-macos"), sandbox.path().join("bin/helper-disabled")).expect("move fixture link");
    let output = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(output.status.code(), Some(3));
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    assert_eq!(document["error"]["rule"], "no_trash");
    assert!(clone.exists());
}
#[test]
fn retention_does_not_open_the_voice_memos_source() {
    let (sandbox, _, clone) = ingested("retention-without-source", ENABLED);
    sandbox.set_mtime(&clone, 2 * 86_400);
    std::fs::rename(sandbox.path().join("voice-memos"), sandbox.path().join("held-source")).expect("hide source");
    let before = support::state_snapshot(&sandbox);
    let dry = run(sandbox.vpt().args(["retention", "run", "--dry-run", "--json"]));
    assert_eq!(dry.status.code(), Some(0), "{}", stderr(&dry));
    let document: serde_json::Value = serde_json::from_str(&stdout(&dry)).expect("proposal");
    assert_eq!(document["moved"][0]["path"], clone.to_string_lossy().as_ref());
    assert_eq!(support::state_snapshot(&sandbox), before);
    assert!(!sandbox.fake_log().exists());
    let moved = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(moved.status.code(), Some(0), "{}", stderr(&moved));
    assert!(!clone.exists());
}

```

`crates/vpt/tests/retention_startup.rs`:

```rust
mod support;
use support::{Sandbox, run, stderr, stdout};
use vpt_domain::fixtures::m4a;

const ENABLED: &str = "[retention]\nenabled = true\ninclude_audio = true\n[retention.hold]\naudio = \"1d\"\n";
fn fixture(name: &str) -> (Sandbox, Vec<String>) {
    let sandbox = Sandbox::new(name);
    sandbox.install_fake_helper();
    sandbox.write_config(ENABLED);
    sandbox.add_recording("a.m4a", &m4a(1_787_604_456, 3, b"first"));
    sandbox.add_recording("b.m4a", &m4a(1_787_604_456, 3, b"second"));
    let output = run(sandbox.vpt().args(["ingest", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    let ids = document["ingested"].as_array().expect("records").iter()
        .map(|row| row["id"].as_str().expect("id").to_owned()).collect::<Vec<_>>();
    let text = std::fs::read_to_string(sandbox.config_path()).expect("config")
        .replace("mode = \"off\"", "mode = \"desktop\"");
    std::fs::write(sandbox.config_path(), text).expect("notify config");
    (sandbox, ids)
}
fn seed(sandbox: &Sandbox, id: &str) {
    sandbox.ledger().execute(
        "INSERT INTO retention_intents (artifact_kind,recording,path,expected,recorded_at)
         SELECT 'audio',id,audio_path,digest,1 FROM recordings WHERE id=?1", [id],
    ).expect("pending intent");
}
fn clone_path(sandbox: &Sandbox, id: &str) -> std::path::PathBuf {
    sandbox.path().join(format!("home/.vpt/audio/{id}.m4a"))
}
fn notifications(sandbox: &Sandbox) -> usize {
    std::fs::read_to_string(sandbox.fake_log()).unwrap_or_default().lines()
        .filter(|line| line.starts_with("notify\t")).count()
}

#[test]
fn retention_combines_recovery_and_new_moves_in_one_report_and_event() {
    let (sandbox, ids) = fixture("retention-recovery-event");
    seed(&sandbox, &ids[0]);
    sandbox.set_mtime(&clone_path(&sandbox, &ids[1]), 2 * 86_400);
    let output = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["moved"].as_array().expect("moves").len(), 2);
    assert_eq!(notifications(&sandbox), 1);
    let log = std::fs::read_to_string(sandbox.fake_log()).expect("log");
    assert!(log.contains("2 artifacts moved to the Trash"), "{log}");
}

#[test]
fn partial_startup_retains_completed_ids_and_one_event_on_retention_and_ingest() {
    for verb in ["retention", "ingest"] {
        let (sandbox, ids) = fixture(&format!("partial-{verb}"));
        seed(&sandbox, &ids[0]);
        seed(&sandbox, &ids[1]);
        std::fs::write(clone_path(&sandbox, &ids[1]), b"replacement").expect("replacement");
        let mut command = sandbox.vpt();
        command.arg(verb);
        if verb == "retention" { command.arg("run"); }
        let output = run(command.arg("--json"));
        assert_eq!(output.status.code(), Some(3), "{}", stderr(&output));
        assert!(stdout(&output).is_empty());
        let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
        assert_eq!(document["error"]["rule"], "retention_target_modified");
        assert_eq!(document["error"]["completed"], serde_json::json!([ids[0]]));
        assert!(!clone_path(&sandbox, &ids[0]).exists());
        assert!(clone_path(&sandbox, &ids[1]).exists());
        assert_eq!(notifications(&sandbox), 1);
    }
}

#[test]
fn a_ledger_failure_after_the_move_still_reports_its_recording_id() {
    let (sandbox, ids) = fixture("retention-row-failure");
    sandbox.set_mtime(&clone_path(&sandbox, &ids[0]), 2 * 86_400);
    sandbox.set_mtime(&clone_path(&sandbox, &ids[1]), 0);
    sandbox.ledger().execute_batch(
        "CREATE TRIGGER fail_trashed BEFORE UPDATE OF audio_trashed_at ON recordings
         BEGIN SELECT RAISE(FAIL,'injected row failure'); END;",
    ).expect("failure trigger");
    let output = run(sandbox.vpt().args(["retention", "run", "--json"]));
    assert_eq!(output.status.code(), Some(1), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    assert_eq!(document["error"]["completed"], serde_json::json!([ids[0]]));
    assert!(!clone_path(&sandbox, &ids[0]).exists());
    assert_eq!(notifications(&sandbox), 1);
    let pending: i64 = sandbox.ledger().query_row(
        "SELECT COUNT(*) FROM retention_intents WHERE completed_at IS NULL", [], |row| row.get(0),
    ).expect("pending");
    assert_eq!(pending, 1);
}

#[test]
fn incompatible_helper_blocks_reconciliation_without_a_trash_request() {
    let (sandbox, ids) = fixture("retention-recovery-version");
    seed(&sandbox, &ids[0]);
    let output = run(sandbox.vpt().args(["ingest", "--json"]).env("VPT_FAKE_VERSION", "2.0.0"));
    assert_eq!(output.status.code(), Some(3), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    assert_eq!(document["error"]["rule"], "helper_version");
    assert!(clone_path(&sandbox, &ids[0]).exists());
    assert!(!sandbox.fake_log().exists());
}

#[test]
fn dry_run_preserves_pending_intents_and_emits_no_event() {
    let (sandbox, ids) = fixture("retention-pending-dry");
    seed(&sandbox, &ids[0]);
    sandbox.set_mtime(&clone_path(&sandbox, &ids[0]), 2 * 86_400);
    let output = run(sandbox.vpt().args(["retention", "run", "--dry-run", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    assert!(clone_path(&sandbox, &ids[0]).exists());
    let pending: i64 = sandbox.ledger().query_row(
        "SELECT COUNT(*) FROM retention_intents WHERE completed_at IS NULL", [], |row| row.get(0),
    ).expect("pending");
    assert_eq!(pending, 1);
    assert!(!sandbox.fake_log().exists());
}
```

Support addition, using the same fixed clock Task 27 gives every child:

```rust
impl Sandbox {
    pub fn set_mtime(&self, path: &Path, seconds_ago: u64) {
        let seconds = u64::try_from(FIXED_NOW_SECS).expect("positive fixture clock")
            .checked_sub(seconds_ago).expect("fixture mtime after epoch");
        let when = std::time::UNIX_EPOCH + std::time::Duration::from_secs(seconds);
        let file = std::fs::File::options().write(true).open(path).expect("fixture file");
        file.set_times(std::fs::FileTimes::new().set_modified(when)).expect("fixture mtime");
    }
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run separately:

```bash
cargo test -p vpt-adapters --test retention_reconcile
cargo test -p vpt --features dev-tools --test retention --test retention_startup
```

Expected: missing retention exports cause the new test modules to fail compilation; once connected, the
new command cases fail behaviorally. Zero selected tests or a successful command does not satisfy the red
step. Record the leaf names selected.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-application/src/retention/report.rs`:

```rust
use crate::ports::{LedgerError, StoreError, TrashError};
use std::path::PathBuf;
use vpt_domain::identity::RecordingId;
use vpt_domain::layout::StoreKey;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Moved {
    pub recording: RecordingId,
    pub store: StoreKey,
    pub path: PathBuf,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KeptReason { Untracked, DigestMismatch }
impl KeptReason {
    pub fn as_str(self) -> &'static str {
        match self { Self::Untracked => "untracked", Self::DigestMismatch => "digest_mismatch" }
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Kept { pub path: PathBuf, pub reason: KeptReason }

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct ReconcileProgress {
    pub moved: Vec<Moved>,
    pub completed: Vec<RecordingId>,
}
impl ReconcileProgress {
    pub(super) fn complete(&mut self, id: &RecordingId) {
        if !self.completed.contains(id) { self.completed.push(id.clone()); }
    }
    pub(super) fn failure(&self, error: RetentionError) -> ReconcileFailure {
        ReconcileFailure { error, progress: self.clone() }
    }
}
#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct RetentionReport {
    pub moved: Vec<Moved>,
    pub kept: Vec<Kept>,
    pub completed: Vec<RecordingId>,
}
impl From<ReconcileProgress> for RetentionReport {
    fn from(progress: ReconcileProgress) -> Self {
        Self { moved: progress.moved, kept: vec![], completed: progress.completed }
    }
}
impl RetentionReport {
    pub(super) fn failure(&self, error: RetentionError) -> RetentionFailure {
        RetentionFailure { error, report: self.clone() }
    }
    pub(super) fn moved(&mut self, item: Moved, dry_run: bool) {
        if !dry_run && !self.completed.contains(&item.recording) {
            self.completed.push(item.recording.clone());
        }
        self.moved.push(item);
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RetentionError {
    Disabled,
    TargetModified(PathBuf),
    Ledger(LedgerError),
    Stores(StoreError),
    Trash(TrashError),
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReconcileFailure {
    pub error: RetentionError,
    pub progress: ReconcileProgress,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RetentionFailure {
    pub error: RetentionError,
    pub report: RetentionReport,
}
```

`crates/vpt-application/src/retention/reconcile.rs`:

```rust
use super::{Moved, ReconcileFailure, ReconcileProgress, RetentionError};
use crate::ports::{Clock, LedgerError, RecordingLedger, RetentionJournal, StoreError, Stores, Trash};
use std::path::Path;
use vpt_domain::layout::StoreKey;

pub fn reconcile_intents<J, L, S, T, C>(
    journal: &J, ledger: &L, stores: &S, trash: &T, clock: &C, audio: &Path,
) -> Result<ReconcileProgress, ReconcileFailure>
where
    J: RetentionJournal, L: RecordingLedger, S: Stores, T: Trash, C: Clock,
{
    let mut progress = ReconcileProgress::default();
    let intents = journal.pending_intents().map_err(|e| progress.failure(RetentionError::Ledger(e)))?;
    for intent in intents {
        if intent.path.parent() != Some(audio) {
            return Err(progress.failure(RetentionError::Stores(StoreError::Escape(intent.path))));
        }
        let record = ledger.by_id(&intent.recording)
            .map_err(|e| progress.failure(RetentionError::Ledger(e)))?
            .ok_or_else(|| progress.failure(RetentionError::Ledger(
                LedgerError::Corrupt("pending retention intent has no recording".into()),
            )))?;
        if record.audio_path != intent.path || record.digest != intent.expected {
            return Err(progress.failure(RetentionError::TargetModified(intent.path)));
        }
        stores.validate_path(&intent.path).map_err(|e| progress.failure(RetentionError::Stores(e)))?;
        match stores.digest_of(&intent.path).map_err(|e| progress.failure(RetentionError::Stores(e)))? {
            None => {}
            Some(digest) if digest == intent.expected => {
                stores.validate_path(&intent.path).map_err(|e| progress.failure(RetentionError::Stores(e)))?;
                trash.trash(&intent.path).map_err(|e| progress.failure(RetentionError::Trash(e)))?;
                progress.moved.push(Moved {
                    recording: intent.recording.clone(), store: StoreKey::Audio, path: intent.path.clone(),
                });
                progress.complete(&intent.recording);
            }
            Some(_) => return Err(progress.failure(RetentionError::TargetModified(intent.path))),
        }
        let now = clock.now();
        ledger.set_audio_trashed(&intent.recording, now)
            .map_err(|e| progress.failure(RetentionError::Ledger(e)))?;
        progress.complete(&intent.recording);
        journal.complete_intent(intent.id, now).map_err(|e| progress.failure(RetentionError::Ledger(e)))?;
    }
    Ok(progress)
}
```

`crates/vpt-application/src/retention/mod.rs`:

```rust
mod reconcile;
mod report;
pub use reconcile::reconcile_intents;
pub use report::{
    Kept, KeptReason, Moved, ReconcileFailure, ReconcileProgress, RetentionError,
    RetentionFailure, RetentionReport,
};

use crate::ports::{
    ArtifactKind, Clock, NewIntent, RecordingLedger, RecordingRecord, RetentionJournal,
    StoreEntry, StoreError, Stores, Trash,
};
use crate::{RetentionSettings, StorePaths};
use vpt_domain::layout::StoreKey;
use vpt_domain::retention::expired;

pub struct Retention<'a, L, J, S, T, C> {
    pub ledger: &'a L,
    pub journal: &'a J,
    pub stores: &'a S,
    pub trash: &'a T,
    pub clock: &'a C,
    pub settings: &'a RetentionSettings,
    pub paths: &'a StorePaths,
}
impl<L, J, S, T, C> Retention<'_, L, J, S, T, C>
where
    L: RecordingLedger, J: RetentionJournal, S: Stores, T: Trash, C: Clock,
{
    pub fn run(&self, dry_run: bool, initial: ReconcileProgress) -> Result<RetentionReport, RetentionFailure> {
        let mut report = RetentionReport::from(initial);
        if !self.settings.enabled { return Err(report.failure(RetentionError::Disabled)); }
        let owned = self.ledger.recordings().map_err(|e| report.failure(RetentionError::Ledger(e)))?;
        for key in StoreKey::all() {
            if key == StoreKey::Audio && !self.settings.include_audio { continue; }
            let hold = self.settings.hold(key);
            if hold.seconds() == 0 { continue; }
            let entries = self.stores.entries(self.paths.get(key))
                .map_err(|e| report.failure(RetentionError::Stores(e)))?;
            for entry in entries {
                let record = owned.iter().find(|record| {
                    key == StoreKey::Audio && record.audio_path == entry.path && record.audio_trashed_at.is_none()
                });
                let Some(record) = record else {
                    report.kept.push(Kept { path: entry.path, reason: KeptReason::Untracked });
                    continue;
                };
                if expired(entry.mtime, hold, self.clock.now()) {
                    self.expire(key, &entry, record, dry_run, &mut report)?;
                }
            }
        }
        Ok(report)
    }

    fn expire(
        &self, key: StoreKey, entry: &StoreEntry, record: &RecordingRecord,
        dry_run: bool, report: &mut RetentionReport,
    ) -> Result<(), RetentionFailure> {
        if entry.path.parent() != Some(self.paths.get(key)) {
            return Err(report.failure(RetentionError::Stores(StoreError::Escape(entry.path.clone()))));
        }
        self.stores.validate_path(&entry.path).map_err(|e| report.failure(RetentionError::Stores(e)))?;
        if self.stores.digest_of(&entry.path).map_err(|e| report.failure(RetentionError::Stores(e)))? != Some(record.digest) {
            report.kept.push(Kept { path: entry.path.clone(), reason: KeptReason::DigestMismatch });
            return Ok(());
        }
        let moved = Moved { recording: record.id.clone(), store: key, path: entry.path.clone() };
        if dry_run {
            report.moved(moved, true);
            return Ok(());
        }
        let now = self.clock.now();
        let intent = NewIntent {
            kind: ArtifactKind::Audio, recording: record.id.clone(), path: entry.path.clone(),
            expected: record.digest, recorded_at: now,
        };
        let id = self.journal.record_intent(&intent).map_err(|e| report.failure(RetentionError::Ledger(e)))?;
        self.stores.validate_path(&entry.path).map_err(|e| report.failure(RetentionError::Stores(e)))?;
        self.trash.trash(&entry.path).map_err(|e| report.failure(RetentionError::Trash(e)))?;
        report.moved(moved, false);
        self.ledger.set_audio_trashed(&record.id, now).map_err(|e| report.failure(RetentionError::Ledger(e)))?;
        self.journal.complete_intent(id, now).map_err(|e| report.failure(RetentionError::Ledger(e)))?;
        Ok(())
    }
}
```

Application `lib.rs` retains a private `mod retention;` and re-exports only:

```rust
pub use retention::{
    Kept, KeptReason, Moved, ReconcileFailure, ReconcileProgress, Retention,
    RetentionError, RetentionFailure, RetentionReport, reconcile_intents,
};
```

`Stores::validate_path` is Task 14's checked-root operation: it reopens the canonical root with
`O_NOFOLLOW_ANY`, compares device and inode to its held descriptor, and checks the leaf without following
a symbolic link. A journal path is checked against the audio root and the recording's pinned path before
any content open, and checked again immediately before the helper call.

Replace `Runtime::mutating` in `compose/runtime.rs` and remove its now-unused `RepairReport` import:

```rust
    pub(crate) fn mutating(&self) -> Result<ReconcileProgress, Box<StartupFailure>> {
        if self._lock.is_none() {
            return Err(Box::new(StartupFailure {
                error: ErrorDocument::new(ErrorKind::Ledger, "mutating startup requires the write lock"),
                progress: ReconcileProgress::default(),
            }));
        }
        repair_publications(&self.ledger, &self.stores, |_| None).map_err(|error| StartupFailure {
            error: repair_error(error), progress: ReconcileProgress::default(),
        })?;
        reconcile_intents(
            &self.ledger, &self.ledger, &self.stores, &self.helper, &self.clock, &self.roots.stores.audio,
        ).map_err(|failure| Box::new(StartupFailure {
            error: retention_error(failure.error), progress: failure.progress,
        }))
    }
```

Add the private composition module and curated imports to `compose.rs`:

```rust
mod recovery;
pub(crate) use recovery::{StartupFailure, retention_error};
```

In `compose/runtime.rs`, add `use super::{StartupFailure, retention_error};` and replace its application
import with:

```rust
use vpt_application::{ReconcileProgress, reconcile_intents, repair_publications};
```

`crates/vpt/src/compose/recovery.rs`:

```rust
use super::Runtime;
use crate::cli::output::Outcome;
use serde_json::json;
use vpt_application::ports::{Clock, StoreError, TrashError};
use vpt_application::{Moved, ReconcileProgress, RetentionError};
use vpt_domain::notification::{EventKind, Notification};
use vpt_protocol::error::{ErrorDocument, ErrorKind};

pub(crate) struct StartupFailure {
    pub error: ErrorDocument,
    pub progress: ReconcileProgress,
}

pub(crate) fn retention_error(error: RetentionError) -> ErrorDocument {
    match error {
        RetentionError::Disabled => ErrorDocument::new(ErrorKind::Usage, "retention.enabled is false"),
        RetentionError::TargetModified(path) => ErrorDocument::new(
            ErrorKind::Refused, format!("{} changed since its retention intent was recorded", path.display()),
        ).rule("retention_target_modified"),
        RetentionError::Ledger(error) => crate::compose::errors::ledger_error(error),
        RetentionError::Stores(StoreError::Escape(path)) => ErrorDocument::new(
            ErrorKind::Refused, format!("{} escapes its store root", path.display()),
        ).rule("path_escape"),
        RetentionError::Stores(StoreError::Io(detail)) => ErrorDocument::new(ErrorKind::Store, detail),
        RetentionError::Trash(TrashError::HelperAbsent) => ErrorDocument::new(
            ErrorKind::Refused, "the helper is absent, so nothing can reach the Trash",
        ).rule("no_trash"),
        RetentionError::Trash(TrashError::HelperVersion { found }) => ErrorDocument::new(
            ErrorKind::Refused, format!("the helper is major version {found}; this build needs 1"),
        ).rule("helper_version"),
        RetentionError::Trash(error) => ErrorDocument::new(ErrorKind::Helper, format!("{error:?}")),
    }
}
impl Runtime {
    pub(crate) fn retention_notice(&self, moved: &[Moved]) {
        if moved.is_empty() { return; }
        let mut counts: Vec<(String, u64)> = vec![];
        for item in moved {
            if let Some((_, count)) = counts.iter_mut().find(|(key, _)| key == item.store.key_name()) {
                *count += 1;
            } else {
                counts.push((item.store.key_name().into(), 1));
            }
        }
        self.notifier.deliver(&Notification::done(
            EventKind::Retention, format!("{} artifacts moved to the Trash", moved.len()), counts, self.clock.now(),
        ));
    }

    pub(crate) fn finish_recovery(&self, mut outcome: Outcome, progress: &ReconcileProgress) -> Outcome {
        self.retention_notice(&progress.moved);
        let lines: Vec<String> = progress.moved.iter()
            .map(|item| format!("moved {} ({})", item.path.display(), item.store.key_name())).collect();
        match &mut outcome {
            Outcome::Success { human, document } => {
                for line in &lines { human.push_str(line); human.push('\n'); }
                if !lines.is_empty() {
                    human.push_str(&format!("retention moved {}\n", lines.len()));
                    document["retention_moved"] = json!(progress.moved.iter().map(|item| {
                        json!({"store":item.store.key_name(),"path":item.path})
                    }).collect::<Vec<_>>());
                }
                let diagnostics = self.diagnostics();
                for line in &diagnostics { human.push_str(&format!("note: {line}\n")); }
                if !diagnostics.is_empty() { document["diagnostics"] = json!(diagnostics); }
            }
            Outcome::Failure(error) | Outcome::FailedReport { error, .. } => {
                for id in &progress.completed {
                    if !error.completed.iter().any(|known| known == id.as_str()) {
                        error.completed.push(id.as_str().to_owned());
                    }
                }
                error.diagnostics.extend(lines);
                error.diagnostics.extend(self.diagnostics());
            }
        }
        outcome
    }
}
```

Replace only `run` in `crates/vpt/src/commands/ingest.rs`; retain its Task 27 output functions and add
`use vpt_application::ReconcileProgress;`:

```rust
pub fn run(runtime: &Runtime, dry_run: bool, once: Option<PathBuf>) -> Outcome {
    let Some(recorder) = runtime.recorder.as_ref() else {
        return Outcome::Failure(ErrorDocument::new(ErrorKind::Config, "ingest composition has no recording source"));
    };
    let progress = if dry_run {
        ReconcileProgress::default()
    } else {
        match runtime.mutating() {
            Ok(progress) => progress,
            Err(failure) => return runtime.finish_recovery(Outcome::Failure(failure.error), &failure.progress),
        }
    };
    let ingest = Ingest {
        recorder,
        archive: &runtime.archive,
        ledger: &runtime.ledger,
        clock: &runtime.clock,
        trash: runtime.trash(),
        notifier: runtime.notifier.as_ref(),
        settings: &runtime.settings.source,
    };
    let mode = Mode { dry_run, once };
    let outcome = match ingest.run(&mode) {
        Ok(mut report) => {
            report.log.extend(runtime.diagnostics());
            Outcome::Success { human: human(&report), document: document("ingest", body(&report)) }
        }
        Err(mut error) => {
            error.log.extend(runtime.diagnostics());
            Outcome::Failure(failure(*error))
        }
    };
    runtime.finish_recovery(outcome, &progress)
}
```

`crates/vpt/src/commands/retention.rs`:

```rust
use crate::cli::output::Outcome;
use crate::compose::{Runtime, retention_error};
use serde_json::json;
use vpt_adapters::{BUILT_AGAINST_MAJOR, HelperError};
use vpt_application::{ReconcileProgress, Retention, RetentionReport};
use vpt_protocol::error::{ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

pub(crate) fn run(runtime: &Runtime, dry_run: bool) -> Outcome {
    if !runtime.settings.retention.enabled {
        return Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, "retention.enabled is false"));
    }
    let preflight = match runtime.helper.version() {
        Ok(_) => Ok(()),
        Err(HelperError::Absent) => Err(ErrorDocument::new(
            ErrorKind::Refused, "the helper is absent, so nothing can reach the Trash",
        ).rule("no_trash")),
        Err(HelperError::MajorMismatch { found }) => Err(ErrorDocument::new(
            ErrorKind::Refused, format!("the helper is major version {found}; this build needs {BUILT_AGAINST_MAJOR}"),
        ).rule("helper_version")),
        Err(_) => Err(ErrorDocument::new(ErrorKind::Helper, "the helper version could not be validated")),
    };
    if let Err(error) = preflight {
        return Outcome::Failure(error.diagnostics(runtime.diagnostics()));
    }
    let initial = if dry_run {
        ReconcileProgress::default()
    } else {
        match runtime.mutating() {
            Ok(progress) => progress,
            Err(failure) => return runtime.finish_recovery(Outcome::Failure(failure.error), &failure.progress),
        }
    };
    let retention = Retention {
        ledger: &runtime.ledger, journal: &runtime.ledger, stores: &runtime.stores,
        trash: &runtime.helper, clock: &runtime.clock,
        settings: &runtime.settings.retention, paths: &runtime.roots.stores,
    };
    match retention.run(dry_run, initial) {
        Ok(report) => finish(runtime, report, None, dry_run),
        Err(failure) => finish(runtime, failure.report, Some(retention_error(failure.error)), dry_run),
    }
}

fn finish(runtime: &Runtime, report: RetentionReport, error: Option<ErrorDocument>, dry_run: bool) -> Outcome {
    if !dry_run { runtime.retention_notice(&report.moved); }
    let mut diagnostics = runtime.diagnostics();
    match error {
        Some(error) => {
            diagnostics.extend(report.moved.iter().map(|item| format!("moved {} ({})", item.path.display(), item.store.key_name())));
            diagnostics.push(format!("moved {}, kept {}", report.moved.len(), report.kept.len()));
            Outcome::Failure(error.completed(report.completed.iter().map(|id| id.as_str().to_owned()).collect()).diagnostics(diagnostics))
        }
        None => {
            let mut human = human(&report, dry_run);
            for line in &diagnostics { human.push_str(&format!("note: {line}\n")); }
            let mut body = body(&report);
            if !diagnostics.is_empty() { body["diagnostics"] = json!(diagnostics); }
            Outcome::Success { human, document: document("retention run", body) }
        }
    }
}
fn body(report: &RetentionReport) -> serde_json::Value {
    json!({
        "moved": report.moved.iter().map(|item| json!({"store":item.store.key_name(),"path":item.path})).collect::<Vec<_>>(),
        "kept": report.kept.iter().map(|item| json!({"path":item.path,"reason":item.reason.as_str()})).collect::<Vec<_>>(),
    })
}
fn human(report: &RetentionReport, dry_run: bool) -> String {
    let verb = if dry_run { "would move" } else { "moved" };
    let mut lines: Vec<String> = report.moved.iter().map(|item| format!("{verb} {} ({})", item.path.display(), item.store.key_name())).collect();
    lines.extend(report.kept.iter().map(|item| format!("kept {} ({})", item.path.display(), item.reason.as_str())));
    lines.push(format!("{verb} {}, kept {}", report.moved.len(), report.kept.len()));
    lines.join("\n") + "\n"
}
```

Dispatch in `crates/vpt/src/lib.rs`:

```rust
        Verb::RetentionRun { dry_run } => {
            let access = if *dry_run { AccessMode::ReadOnly } else { AccessMode::Mutating };
            match Runtime::load(&environment, invocation.config.as_deref(), access, Operation::Retention) {
                Ok(runtime) => commands::retention::run(&runtime, *dry_run),
                Err(error) => Outcome::Failure(*error),
            }
        }
```

Add `pub(crate) mod retention;` to `commands/mod.rs`. The runtime's private lock remains owned until the
command returns; retention obtains no second lock. A helper version failure ends the command before
reconciliation or new moves. The helper also validates its version on its first Trash call, covering
recovery entered through ingest.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

```bash
cargo test -p vpt-adapters --test retention_reconcile
cargo test -p vpt --features dev-tools --test retention --test retention_startup --test ingest
cargo test --workspace --features dev-tools
cargo clippy --workspace --all-targets --features dev-tools -- -D warnings
just file-size
```

Expected: the named recovery cases, command cases and ingest regressions pass; no warnings and no file
over its hard limit. Record test names and measured results, not a predicted count.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(retention): journal Trash moves and retain partial recovery results"
```

______________________________________________________________________

