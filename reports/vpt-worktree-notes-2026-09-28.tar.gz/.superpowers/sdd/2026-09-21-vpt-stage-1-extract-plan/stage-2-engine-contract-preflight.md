# Stage 2 engine contract preflight

Read-only check against the approved spec, installed Whisply package, and active macOS SDK. No audio
was transcribed and no engine was run.

## Whisply 0.14.2

- Installed package source root: `/Users/stephen/.local/share/uv/tools/whisply/lib/python3.13/site-packages/whisply/`.
- The spec's invocation at `docs/superpowers/specs/2026-09-20-vpt-design.md:589-591` matches the
  installed CLI: `whisply run -f <path> -o <dir> -d <device> -m <model> -l <lang> -e json`. Confirmed
  with `/Users/stephen/.local/bin/whisply run --help` and installed
  `cli.py:18-53,91-96`.
- `-e json` writes `<output_dir>/<audio-stem>/<audio-stem>.json`: `set_output_dir` creates a
  per-input-stem directory (`little_helper.py:378-381`), then `save_results` appends the stem and
  `.json`. It does not return the transcript JSON on stdout.
  `output_utils.py:406-411` writes the JSON file, and `transcription.py:1133-1152` builds and saves
  the outer document. Progress/status output is printed separately. The adapter should read the file
  from its private output directory.
- Actual document shape: top-level `id`, `created`, `input_filepath`, `output_filepath`,
  `written_files`, `device`, `model`, and `transcription`; `transcription` maps language tags to
  objects containing `text` and `segments`. Each segment has `start`, `end`, `text`, and `words`.
  Faster-Whisper word entries have `word`, `start`, `end`, and `score`. There is no `schema`, engine
  family, or locality field; the vpt adapter must validate/extract the nested transcription and add
  its own `vpt.engine/1` envelope. Sources: `transcription.py:1133-1144`,
  `transcription.py:868-890`, `output_utils.py:406-411`.
- For the spec's plain invocation (no annotation/subtitle switches), CPU selects Faster-Whisper and
  writes each word's `score` from `i.probability` (`transcription.py:1089-1114,868-890`). MLX calls
  `mlx_whisper.transcribe(..., word_timestamps=True)`, converts available timing chunks, and emits no
  score (`transcription.py:698-731,324-373`). Mapping CPU `score` to vpt `confidence` and leaving
  MLX confidence absent matches spec lines 584-591. Whisply's optional WhisperX route does assign a
  fallback score of `0.5` for missing word scores (`transcription.py:375-432`); the planned command
  does not enable that route, but future use of `--annotate` or `--subtitle` must not treat that
  fallback as a genuine confidence value.
- The installed CLI also accepts long forms (`--files`, `--output_dir`, `--device`, `--model`,
  `--language`, `--export`); the spec's short forms are valid and avoid relying on those spellings.

## Apple Speech API

- Active toolchain: Xcode 27.0 (build 27A266a), macOS 27.0 host; `xcrun --sdk macosx --show-sdk-path`
  resolves to `/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.0.sdk`.
- Interface source:
  `/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.0.sdk/System/Library/Frameworks/Speech.framework/Versions/A/Modules/Speech.swiftmodule/arm64e-apple-macos.swiftinterface`.
- Its Speech Swift interface declares `SpeechAnalyzer` and `SpeechTranscriber` available on
  `anyAppleOS 26` (interface lines 226-228, 344-348).
  `SpeechTranscriber.Result.text` is `Foundation.AttributedString`, and its `Result.range` is a
  `CoreMedia.CMTimeRange` (`:427-433`).
- `SpeechTranscriber`'s initializer accepts `attributeOptions: Set<ResultAttributeOption>`;
  `.audioTimeRange` and `.transcriptionConfidence` are supported cases (`:346-348,393-400`). The
  Speech attribute scope exposes `audioTimeRange` as `CMTimeRange` and `transcriptionConfidence` as
  `Double` (`:190-204`), also marked macOS 26+ (`:190-195`). These signatures support extracting
  attributed runs and converting their audio ranges to seconds and confidence to vpt's `[0,1]` word
  values.
- Local headers establish the symbols, availability, types, and initializer signature. They do not
  establish runtime attribute coverage, confidence calibration, or one-run-per-token behavior; those
  need a later SDK/runtime fixture check without real memo audio. The spec's macOS 26+ claim in
  `:226-232` is consistent with the installed interface. A deployment target below macOS 26 would
  require availability handling, but the Stage 2 helper target was not checked here.

## Unverified

- No Whisply transcription was run, so emitted JSON was inferred from the installed writer and
  producer methods, not observed from a generated artifact.
- No Apple model/download availability, locale support, result timing, or confidence values were
  exercised. This preflight confirms compile-time SDK surface only.
- Exact mapping of attributed speech runs to whitespace/token boundaries, and time-range values at
  punctuation or partial results, remains a Stage 2 implementation check.
