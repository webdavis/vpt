# Stage 2 Unicode preflight

## Recommendation

No dependency in the VPT lockfile/manifests currently provides the needed operations; the only locked Unicode-named crate is `unicode-ident` 1.0.26. In the local source cache, the smallest verified API pairing that provides both operations is `icu_normalizer` 2.3.0 (default `compiled_data`, `ComposingNormalizerBorrowed::new_nfkc().normalize(...)`) followed by `unicase` 2.9.0 (`UniCase::new(...).to_folded_case()`). These crates are cached but not locked in this worktree. No single inspected cached crate provides both NFKC and full case folding.

For known-term matching, use only full folding on each original whole token, for example `unicase::UniCase::new(token).to_folded_case()`. `unicase`'s full folding maps U+00DF (`ß`) to `ss`; its tests assert `Maße` equals `MASSE`, and `to_folded_case()` returns `masse`. Therefore `Straße` and `STRASSE` fold to the same key, while `23rd` remains distinct from `23`; punctuation is retained because this API only maps case-fold equivalents and does not drop token characters. Do not run NFKC or the lossy alignment cleanup on known terms.

`unicode-normalization-alignments` 0.1.12 is a smaller cached NFKC-only alternative, but its embedded normalization tables identify Unicode 9.0.0. The ICU normalizer is the fresher cached NFKC primitive; its version is 2.3.0, though the inspected source did not state its Unicode data version. `unicase` 2.9.0 documents and tests full folding but does not declare the Unicode CaseFolding data version in its inspected source. These data-version details remain the main uncertainty against the spec's desire to pin the Unicode version.

## Myers inventory

`similar` 2.7.0 is cached, not locked. Its `Algorithm::Myers` is divide-and-conquer Myers with O(N+M) working space and two frontier vectors sized from the combined input length; it does not retain a quadratic traceback history. It has no edit-distance-ratio cutoff API: its optional deadline is a time bound and falls back to an approximation when reached. The source also documents O((N+M)D) time and pathological behavior on fully distinct sequences. It is a plausible linear-memory base, but does not itself implement Stage 2's configured divergence cutoff.

## Source references

- Spec 6.4 confines lossy normalization to alignment: `docs/superpowers/specs/2026-09-20-vpt-design.md:618-626`.
- Stage 2 normalization API and expanding-case tests: `.superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/stage-2-plan-draft.md:95-101`.
- Controller note requires case-fold-only known-term matching and `23rd`/`23` distinction: same draft, lines 187-193.
- No matching Unicode case-fold or normalization dependency in lock/manifests; `unicode-ident` 1.0.26 is at `Cargo.lock:469-473`.
- Cached `unicase` 2.9.0 API: `~/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicase-2.9.0/src/lib.rs:131-142`; full-fold examples/tests: `.../src/unicode/mod.rs:192-200`; `ß` to `ss` mapping: `.../src/unicode/map.rs:21-28`.
- Cached `icu_normalizer` 2.3.0 NFKC API: `~/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/icu_normalizer-2.3.0/src/lib.rs:2899-2906`; NFKC is one of its four supported forms at lines 24-29; default `compiled_data` feature at `.../Cargo.toml:59-78`.
- Cached `unicode-normalization-alignments` 0.1.12 NFKC API: `~/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-normalization-alignments-0.1.12/src/lib.rs:94-105`; Unicode version 9.0.0: `.../src/tables.rs:17-18`.
- Cached `similar` 2.7.0 Myers complexity/deadline caveat: `~/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/similar-2.7.0/src/algorithms/myers.rs:1-18`; frontier allocation at lines 67-70 and 91-101; divide-and-conquer recursion at lines 300-323.

## Upstream comparison (follow-up)

The smaller sound choice is `unicode-normalization` 0.1.24 plus `caseless` 0.2.2, with both Unicode tables at 16.0.0. The upstream release history says 0.1.24 updated normalization tables to Unicode 16.0.0; caseless' upstream source exports `UNICODE_VERSION` and its table is Unicode 16.0.0. Pin the normalizer to 0.1.24 in the lockfile. Current `unicode-normalization` 0.1.25 moved to Unicode 17.0.0, so allowing the resolver to select it would make table versions differ.

The APIs compose directly for alignment: collect `text.nfkc()` using `unicode_normalization::UnicodeNormalization`, then pass the result to `caseless::default_case_fold_str`. For known terms, use `caseless::default_case_fold_str` on each unnormalized whole token only. The upstream `caseless` test asserts `straße` folds to `strasse`, which also establishes the `Straße`/`STRASSE` match; its fold iterator returns an unmapped character unchanged, so ASCII digits, `r`, `d`, and punctuation are not stripped. `23rd` therefore remains different from `23`.

`caseless` has one dependency, `unicode-normalization = "0.1"`; `unicode-normalization` has one normal dependency, `tinyvec`. Although caseless also offers `compatibility_caseless_match_str`, it performs a compatibility/canonical caseless sequence, not the requested materialized NFKC-then-fold key, and is not the API to use here. The separate `unicode-casefold` 0.2.0 has no dependencies and a concise `case_fold()` full, non-Turkic API, but its source tables are Unicode 9.0.0, so it is not a better current primitive.

This supersedes the cached ICU/unicase pairing above: that pairing remains locally available and API-verified, but the docs.rs/upstream combination is smaller and publishes matching Unicode 16 tables. Neither recommended crate is currently in this worktree's Cargo cache or lockfile, and no build or install was performed. Confirm the project's exact interpretation of “one Unicode version pinned by the lockfile”; Unicode's stability policy guarantees `toCasefold(toNFKC(S))` stability across versions for characters assigned in the earlier version, but the selected matching 16.0 tables avoid depending on that cross-version guarantee for Stage 2.

Upstream references:

- `unicode-normalization` 0.1.25 NFKC trait/API and current `UNICODE_VERSION`: <https://docs.rs/unicode-normalization/0.1.25/unicode_normalization/trait.UnicodeNormalization.html>, <https://github.com/unicode-rs/unicode-normalization/blob/master/src/tables.rs>.
- Upstream 0.1.24 release commit states Unicode 16.0.0 and version bump: <https://github.com/unicode-rs/unicode-normalization/commit/fdfe8e0>.
- `caseless` 0.2.2 APIs, full-fold test (`straße` -> `strasse`), and iterator's unchanged-character path: <https://docs.rs/caseless/latest/src/caseless/lib.rs.html>.
- `caseless` dependency declaration: <https://github.com/unicode-rs/rust-caseless/blob/master/Cargo.toml>; exported table version 16.0.0 and `ß` -> `ss`: <https://github.com/unicode-rs/rust-caseless/blob/master/src/case_folding_data.rs>.
- `unicode-normalization` default dependency `tinyvec`: <https://docs.rs/crate/unicode-normalization/0.1.25>.
- `unicode-casefold` 0.2.0 full-fold/default-non-Turkic API: <https://docs.rs/unicode-casefold/0.2.0/unicode_casefold/trait.UnicodeCaseFold.html>; its Unicode 9.0.0 source table: <https://github.com/lambda-fairy/unicode-casefold/blob/master/src/tables.rs>.
- Unicode normalization/case-fold stability policy and the exact NFKC-then-fold guarantee: <https://unicode.org/policies/stability_policy.html#Case_Folding_Stability>.
