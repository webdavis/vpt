### Task 25: The helper client and the bounded document reader

**Files:**

- Create: `crates/vpt-protocol/src/limits.rs`, `crates/vpt-protocol/src/limits/visitor.rs`,
  `crates/vpt-protocol/src/limits/tests.rs`, `crates/vpt-protocol/src/helper.rs`.
- Create: `crates/vpt-adapters/src/helper.rs`, `crates/vpt-adapters/src/helper/reply.rs`,
  `crates/vpt-adapters/src/helper/tests.rs`.
- Modify: `crates/vpt-protocol/src/lib.rs`, `crates/vpt-adapters/src/lib.rs`,
  `crates/vpt-adapters/Cargo.toml`, `crates/vpt/src/lib.rs`, `crates/vpt/src/commands/version.rs`.
- Test: `crates/vpt/tests/helper_client.rs`, `crates/vpt/tests/version.rs`,
  `crates/vpt/tests/support/mod.rs`.

**Interfaces:**

- Consumes:
  `spawn::run_with_env(argv: &[String], stdin: &[u8], deadline: Duration, output_limit: usize, env: &[(&str, &str)]) -> Result<spawn::Outcome, spawn::SpawnError>`;
  `Outcome { status: Status, stdout: Vec<u8>, stderr: Vec<u8>, group: libc::pid_t }`;
  `Status::{Exited(i32), Signaled(i32), DeadlineExceeded, Interrupted}`;
  `SpawnError::{NotFound(String), Io(String)}`;
  `Trash::trash(&self, path: &Path) -> Result<PathBuf, TrashError>` and
  `Trash::take_diagnostics(&self) -> Vec<String>`;
  `TrashError::{HelperAbsent, HelperVersion { found: u32 }, Failed(String), Unknown(String)}`.

- Consumes: `config::load_file(path: &Path) -> Result<toml::Table, ConfigError>`,
  `config::from_table(table: &toml::Table, home: &Path) -> Result<Settings, ConfigError>`;
  `Settings::helper_path: PathBuf`;
  `Environment::{config_path(&self) -> PathBuf, home_dir(&self) -> PathBuf}`;
  `Invocation::config: Option<PathBuf>`.

- Produces protocol root exports:
  `Limits { pub bytes: usize, pub depth: usize, pub text_chars: usize, pub array_len: usize }`,
  `Limits::incoming() -> Limits`,
  `LimitViolation::{Bytes(usize), Depth(usize), Text(usize), Array(usize), Syntax(String)}`,
  `read_bounded(bytes: &[u8], limits: &Limits) -> Result<serde_json::Value, LimitViolation>`. Check depth
  before descending; refuse array entry `array_len + 1` before decoding or appending it; validate decoded
  strings and keys before retaining them; finish with `Deserializer::end()`.

- Produces protocol root exports: `HELPER_SCHEMA: &str = "vpt.helper/1"`,
  `HelperVersion { pub schema: String, pub version: String }`,
  `HelperVersion::major(&self) -> Option<u32>`, `Posted { pub posted: bool }`,
  `Trashed { pub trashed: String }`, each reply implementing `Deserialize`.

- Produces adapter root exports: `HelperClient::new(path: PathBuf) -> HelperClient`,
  `HelperClient::with_deadline(self, deadline: Duration) -> HelperClient`,
  `HelperClient::version(&self) -> Result<String, HelperError>`,
  `HelperClient::version_with_env(&self, env: &[(&str, &str)]) -> Result<String, HelperError>`,
  `HelperClient::notify(&self, title: &str, body: &str) -> Result<(), HelperError>`,
  `HelperClient::notify_with_env(&self, title: &str, body: &str, env: &[(&str, &str)]) -> Result<(), HelperError>`,
  `HelperClient::trash_with_env(&self, path: &Path, env: &[(&str, &str)]) -> Result<PathBuf, TrashError>`,
  `HelperClient::take_diagnostics(&self) -> Vec<String>`, `impl Trash for HelperClient`,
  `CALL_DEADLINE: Duration = Duration::from_secs(5)`, `BUILT_AGAINST_MAJOR: u32 = 1`,
  `HelperError::{Absent, MajorMismatch { found: u32 }, Failed(String), Unknown(String)}`. The first
  notify or Trash request validates the configured helper. Only successful compatibility is cached.
  Unknown additive field names enter the drainable diagnostics queue; values never do. A caller keeps the
  client and test environment fixed for one command.

- Produces
  `commands::version::{run(environment: &Environment, config: Option<&Path>) -> Outcome, document(helper_version: Option<&str>) -> serde_json::Value, human(helper_version: Option<&str>) -> String}`.
  Version uses the selected configuration, including `--config` and `VPT_CONFIG`; only an absent
  configuration permits the default `vpt-macos`. An unreadable or invalid existing configuration, or an
  unidentified selected helper, produces `helper_version: null` with exit 0.

- Test support: `FAKE_ENGINE: &str`, `Sandbox::install_fake_helper(&self)`,
  `Sandbox::fake_log(&self) -> PathBuf`. Every integration call selects the fake or a missing sandbox
  path.

- [ ] **Step 1: Register and write the failing tests**

Add `serde = "1.0.229"` under `[dependencies]` in `crates/vpt-adapters/Cargo.toml`. The helper decoder
names serde's deserialization trait directly.

Add these private modules and curated exports to `crates/vpt-protocol/src/lib.rs`:

```rust
mod limits;
mod helper;
pub use limits::{LimitViolation, Limits, read_bounded};
pub use helper::{HELPER_SCHEMA, HelperVersion, Posted, Trashed};
```

Add to `crates/vpt-adapters/src/lib.rs`:

```rust
mod helper;
pub use helper::{BUILT_AGAINST_MAJOR, CALL_DEADLINE, HelperClient, HelperError};
```

Create `crates/vpt-protocol/src/limits.rs` and `crates/vpt-adapters/src/helper.rs` with this test
declaration in each:

```rust
#[cfg(test)]
mod tests;
```

Create `crates/vpt-protocol/src/helper.rs` as an empty file. The unresolved reply exports participate in
the red build.

`crates/vpt-protocol/src/limits/tests.rs`:

```rust
use super::*;

#[test]
fn valid_document_and_unicode_text_at_the_limit_parse() {
    assert_eq!(
        read_bounded(br#"{"version":"1.0.0"}"#, &Limits::incoming()).expect("document")["version"],
        "1.0.0"
    );
    let limits = Limits {
        text_chars: 2,
        ..Limits::incoming()
    };
    assert!(read_bounded(br#"["\u00e9\u00e9"]"#, &limits).is_ok());
}

#[test]
fn byte_limit_includes_the_sentinel_and_trailing_whitespace() {
    let limits = Limits {
        bytes: 2,
        ..Limits::incoming()
    };
    assert!(read_bounded(b"{}", &limits).is_ok());
    assert_eq!(read_bounded(b"{} ", &limits), Err(LimitViolation::Bytes(3)));
}

#[test]
fn depth_is_checked_before_reading_children() {
    let limits = Limits {
        depth: 1,
        ..Limits::incoming()
    };
    assert!(read_bounded(b"[1]", &limits).is_ok());
    assert_eq!(
        read_bounded(b"[[broken", &limits),
        Err(LimitViolation::Depth(2))
    );
    assert!(read_bounded(br#"{"t":"[[[[[[[[[[[["}"#, &limits).is_ok());
}

#[test]
fn decoded_text_and_keys_are_checked_before_retaining_them() {
    let limits = Limits {
        text_chars: 2,
        ..Limits::incoming()
    };
    assert_eq!(
        read_bounded(br#"["\u00e9\u00e9\u00e9"]"#, &limits),
        Err(LimitViolation::Text(3))
    );
    assert_eq!(
        read_bounded(br#"{"abc":null}"#, &limits),
        Err(LimitViolation::Text(3))
    );
}

#[test]
fn array_overflow_is_refused_before_decoding_the_extra_element() {
    let limits = Limits {
        array_len: 2,
        ..Limits::incoming()
    };
    assert!(read_bounded(b"[1,2]", &limits).is_ok());
    assert_eq!(
        read_bounded(b"[1,2,{broken", &limits),
        Err(LimitViolation::Array(3))
    );
    let zero = Limits {
        array_len: 0,
        ..Limits::incoming()
    };
    assert!(read_bounded(b"[]", &zero).is_ok());
    assert_eq!(
        read_bounded(b"[true]", &zero),
        Err(LimitViolation::Array(1))
    );
}

#[test]
fn malformed_and_trailing_documents_have_fixed_diagnostics() {
    for bytes in [b"{".as_slice(), b"{} {}", b"CANARY-RAW-JSON"] {
        assert_eq!(
            read_bounded(bytes, &Limits::incoming()),
            Err(LimitViolation::Syntax("invalid JSON document".into()))
        );
    }
}
```

`crates/vpt-adapters/src/helper/tests.rs`:

```rust
use super::*;
use serde_json::json;

fn client() -> HelperClient {
    HelperClient::new(PathBuf::from("/sandbox/fake-helper"))
}

fn version() -> Value {
    json!({"schema":"vpt.helper/1", "version":"1.0.0"})
}

#[test]
fn compatibility_is_checked_once_before_notify_and_trash() {
    let client = client();
    let calls = RefCell::new(Vec::new());
    let call = |argv: &[String]| {
        calls.borrow_mut().push(argv[0].clone());
        Ok(match argv[0].as_str() {
            "--version" => version(),
            "notify" => json!({"posted":true}),
            "trash" => json!({"trashed":argv[1]}),
            _ => panic!("unexpected operation"),
        })
    };
    assert_eq!(client.notify_using("title", "body", &call), Ok(()));
    let path = Path::new("/sandbox/file");
    assert_eq!(client.trash_using(path, &call), Ok(path.into()));
    assert_eq!(*calls.borrow(), ["--version", "notify", "trash"]);
}

#[test]
fn incompatible_version_never_receives_notify_or_trash() {
    let client = client();
    let calls = RefCell::new(Vec::new());
    let call = |argv: &[String]| {
        calls.borrow_mut().push(argv[0].clone());
        Ok(json!({"schema":"vpt.helper/1", "version":"2.3.0"}))
    };
    assert_eq!(
        client.notify_using("title", "body", &call),
        Err(HelperError::MajorMismatch { found: 2 })
    );
    assert_eq!(
        client.trash_using(Path::new("/sandbox/file"), &call),
        Err(TrashError::HelperVersion { found: 2 })
    );
    assert_eq!(*calls.borrow(), ["--version", "--version"]);
}

#[test]
fn trash_confirms_the_exact_requested_path() {
    let client = client();
    let call = |argv: &[String]| {
        Ok(if argv[0] == "--version" {
            version()
        } else {
            json!({"trashed":"/sandbox/another"})
        })
    };
    assert_eq!(
        client.trash_using(Path::new("/sandbox/file"), &call),
        Err(TrashError::Unknown(
            "the helper trash reply names another path".into()
        ))
    );
}

#[test]
fn additive_names_survive_all_replies_without_their_values() {
    let client = client();
    let call = |argv: &[String]| {
        let mut value = match argv[0].as_str() {
            "--version" => version(),
            "notify" => json!({"posted":true}),
            _ => json!({"trashed":argv[1]}),
        };
        value["capabilities"] = json!("CANARY-ADDITIVE-VALUE");
        Ok(value)
    };
    client.notify_using("title", "body", &call).expect("notify");
    client
        .trash_using(Path::new("/sandbox/file"), &call)
        .expect("trash");
    assert_eq!(
        client.take_diagnostics(),
        vec!["unknown additive helper field: capabilities"; 3]
    );
    assert!(client.take_diagnostics().is_empty());
}

#[test]
fn wrong_types_and_schemas_never_quote_child_values() {
    let client = client();
    for schema in [json!("CANARY-SCHEMA"), json!({"private":"CANARY-SCHEMA"})] {
        let value = json!({"schema":schema, "version":"1.0.0"});
        assert_eq!(
            client.version_using(&|_| Ok(value.clone())),
            Err(HelperError::Unknown("invalid helper schema".into()))
        );
    }
    assert_eq!(
        client.version_using(&|_| Ok(json!({"schema":"vpt.helper/9", "version":"CANARY"}))),
        Err(HelperError::Unknown(
            "unsupported helper schema major 9".into()
        ))
    );
    for value in [json!("1.0.0+CANARY\nSECRET"), json!({"private":"CANARY"})] {
        assert_eq!(
            client.version_using(&|_| Ok(json!({"schema":"vpt.helper/1", "version":value}))),
            Err(HelperError::Unknown(
                "invalid helper version document".into()
            ))
        );
    }
    let notify = |argv: &[String]| {
        Ok(if argv[0] == "--version" {
            version()
        } else {
            json!({"posted":"CANARY-NOTIFY"})
        })
    };
    assert_eq!(
        client.notify_using("title", "body", &notify),
        Err(HelperError::Unknown(
            "invalid helper notify document".into()
        ))
    );
    assert_eq!(
        client.trash_using(Path::new("/sandbox/file"), &|_| Ok(
            json!({"trashed":["CANARY-TRASH"]})
        )),
        Err(TrashError::Unknown("invalid helper trash document".into()))
    );
}

#[test]
fn oversized_valid_prefix_retains_the_rejection_sentinel() {
    let client = client();
    let result = client.call_using(&["--version".into()], &[], |_, _, _, limit, _| {
        assert_eq!(limit, 65_537);
        let mut stdout = serde_json::to_vec(&version()).expect("json");
        stdout.resize(65_540, b' ');
        stdout.truncate(limit);
        Ok(spawn::Outcome {
            status: Status::Exited(0),
            stdout,
            stderr: vec![],
            group: 0,
        })
    });
    assert_eq!(
        result,
        Err(HelperError::Unknown(
            "invalid or oversized helper document".into()
        ))
    );
}

#[test]
fn spawn_and_timeout_errors_are_fixed_and_absence_is_typed() {
    let client = client();
    assert_eq!(
        client.call_using(&[], &[], |_, _, _, _, _| Err(SpawnError::Io(
            "CANARY".into()
        ))),
        Err(HelperError::Failed("the helper could not start".into()))
    );
    assert_eq!(
        client.call_using(&[], &[], |_, _, _, _, _| Err(SpawnError::NotFound(
            "CANARY".into()
        ))),
        Err(HelperError::Absent)
    );
    assert_eq!(
        client.call_using(&[], &[], |_, _, _, _, _| Ok(spawn::Outcome {
            status: Status::DeadlineExceeded,
            stdout: b"CANARY".to_vec(),
            stderr: vec![],
            group: 0,
        })),
        Err(HelperError::Unknown(
            "the helper exceeded its deadline".into()
        ))
    );
}
```

`crates/vpt/tests/helper_client.rs`:

```rust
mod support;

use support::Sandbox;
use vpt_adapters::{BUILT_AGAINST_MAJOR, HelperClient, HelperError};
use vpt_application::ports::{Trash, TrashError};

#[test]
fn helper_version_and_major_refusal_are_read_from_the_fake() {
    let sandbox = Sandbox::new("helper-version");
    sandbox.install_fake_helper();
    let path = sandbox.path().join("bin/vpt-macos");
    assert_eq!(
        HelperClient::new(path.clone()).version().expect("version"),
        "1.0.0"
    );
    assert_eq!(BUILT_AGAINST_MAJOR, 1);
    assert_eq!(
        HelperClient::new(path).version_with_env(&[("VPT_FAKE_VERSION", "2.3.0")]),
        Err(HelperError::MajorMismatch { found: 2 })
    );
}

#[test]
fn absent_helper_has_a_typed_error_without_touching_the_target() {
    let sandbox = Sandbox::new("helper-absent");
    let client = HelperClient::new(sandbox.path().join("missing-helper"));
    assert_eq!(client.version(), Err(HelperError::Absent));
    assert_eq!(
        client.trash(&sandbox.path().join("victim")),
        Err(TrashError::HelperAbsent)
    );
    assert!(!sandbox.fake_log().exists());
}

#[test]
fn trash_uses_the_fake_and_confirms_the_same_requested_path() {
    let sandbox = Sandbox::new("helper-trash");
    sandbox.install_fake_helper();
    let victim = sandbox.path().join("victim.txt");
    std::fs::write(&victim, b"fixture").expect("victim");
    let client = HelperClient::new(sandbox.path().join("bin/vpt-macos"));
    let trash = sandbox.path().join("trash");
    assert_eq!(
        client.trash_with_env(
            &victim,
            &[("VPT_FAKE_TRASH", trash.to_str().expect("utf8"))]
        ),
        Ok(victim.clone())
    );
    assert!(!victim.exists());
    assert_eq!(
        std::fs::read(trash.join("victim.txt")).expect("fake trash"),
        b"fixture"
    );
}

#[test]
fn mismatched_helper_does_not_move_a_file() {
    let sandbox = Sandbox::new("helper-refused-trash");
    sandbox.install_fake_helper();
    let victim = sandbox.path().join("victim.txt");
    std::fs::write(&victim, b"fixture").expect("victim");
    let client = HelperClient::new(sandbox.path().join("bin/vpt-macos"));
    let trash = sandbox.path().join("trash");
    assert_eq!(
        client.trash_with_env(
            &victim,
            &[
                ("VPT_FAKE_VERSION", "2.0.0"),
                ("VPT_FAKE_TRASH", trash.to_str().expect("utf8"))
            ]
        ),
        Err(TrashError::HelperVersion { found: 2 })
    );
    assert_eq!(std::fs::read(&victim).expect("unmoved"), b"fixture");
    assert!(!trash.join("victim.txt").exists());
}
```

Append these tests to `crates/vpt/tests/version.rs`, whose existing imports provide `Sandbox`, `run` and
`stdout`:

```rust
#[test]
fn version_uses_path_only_when_the_selected_configuration_is_absent() {
    let sandbox = Sandbox::new("version-fallback");
    sandbox.install_fake_helper();
    let output = run(sandbox.vpt().args(["--version", "--json"]));
    assert_eq!(output.status.code(), Some(0));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["helper_version"], "1.0.0");
}

#[test]
fn version_honours_environment_config_and_explicit_override() {
    let sandbox = Sandbox::new("version-selected");
    sandbox.install_fake_helper();
    std::fs::create_dir_all(sandbox.config_path().parent().expect("parent")).expect("config dir");
    let missing = sandbox.path().join("missing-helper");
    let settings = format!(
        "config_version = 1\n[helper]\npath = {}\n",
        serde_json::to_string(&missing.to_str().expect("utf8")).expect("path")
    );
    std::fs::write(sandbox.config_path(), settings).expect("selected config");
    let configured = run(sandbox.vpt().args(["--version", "--json"]));
    assert_eq!(configured.status.code(), Some(0));
    let document: serde_json::Value = serde_json::from_str(&stdout(&configured)).expect("json");
    assert!(
        document["helper_version"].is_null(),
        "the configured helper must win over PATH"
    );

    let alternate = sandbox.path().join("alternate.toml");
    let helper = sandbox.path().join("bin/vpt-macos");
    let settings = format!(
        "config_version = 1\n[helper]\npath = {}\n",
        serde_json::to_string(&helper.to_str().expect("utf8")).expect("path")
    );
    std::fs::write(&alternate, settings).expect("alternate config");
    let output = run(sandbox
        .vpt()
        .args(["--version", "--json", "--config"])
        .arg(&alternate));
    assert_eq!(output.status.code(), Some(0));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["helper_version"], "1.0.0");
}

#[test]
fn invalid_existing_configuration_keeps_version_success_without_a_path_fallback() {
    let sandbox = Sandbox::new("version-invalid-config");
    sandbox.install_fake_helper();
    std::fs::create_dir_all(sandbox.config_path().parent().expect("parent")).expect("config dir");
    std::fs::write(sandbox.config_path(), "CANARY-INVALID-CONFIG\n[").expect("invalid config");
    let output = run(sandbox.vpt().args(["--version", "--json"]));
    assert_eq!(output.status.code(), Some(0));
    let text = stdout(&output);
    let document: serde_json::Value = serde_json::from_str(&text).expect("json");
    assert!(document["helper_version"].is_null());
    assert!(!text.contains("CANARY"));
}
```

Add this support to `crates/vpt/tests/support/mod.rs`:

```rust
pub const FAKE_ENGINE: &str = env!("CARGO_BIN_EXE_vpt-fake-engine");

impl Sandbox {
    pub fn install_fake_helper(&self) {
        std::os::unix::fs::symlink(FAKE_ENGINE, self.root.join("bin/vpt-macos")).expect("fake helper");
        std::fs::create_dir_all(self.root.join("trash")).expect("fake trash");
    }

    pub fn fake_log(&self) -> PathBuf {
        self.root.join("fake.log")
    }
}
```

In `Sandbox::vpt`, replace the final `.env("PATH", self.root.join("bin"));` with these chained calls,
keeping its existing session isolation and cleared environment:

```rust
            .env("PATH", self.root.join("bin"))
            .env("VPT_FAKE_TRASH", self.root.join("trash"))
            .env("VPT_FAKE_LOG", self.fake_log());
```

- [ ] **Step 2: Run each red command**

`cargo test -p vpt-protocol limits`

`cargo test -p vpt-adapters helper`

`cargo test -p vpt --features dev-tools --test helper_client --test version`

Expected: the registered tests fail to compile because the bounded reader and helper client are absent.
After the client exists, the version selection tests remain red until the command uses the selected
configuration. The new test modules must be compiled and selected. Zero selected tests or a successful
command does not satisfy this step.

- [ ] **Step 3: Implement the bounded reader, helper client and version command**

`crates/vpt-protocol/src/limits.rs`:

```rust
mod visitor;

use serde::de::DeserializeSeed;
use serde_json::Value;
use std::cell::RefCell;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Limits {
    pub bytes: usize,
    pub depth: usize,
    pub text_chars: usize,
    pub array_len: usize,
}

impl Limits {
    pub fn incoming() -> Self {
        Self {
            bytes: 65_536,
            depth: 8,
            text_chars: 65_536,
            array_len: 256,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LimitViolation {
    Bytes(usize),
    Depth(usize),
    Text(usize),
    Array(usize),
    Syntax(String),
}

pub fn read_bounded(bytes: &[u8], limits: &Limits) -> Result<Value, LimitViolation> {
    if bytes.len() > limits.bytes {
        return Err(LimitViolation::Bytes(bytes.len()));
    }
    let context = visitor::Context {
        limits,
        violation: RefCell::new(None),
    };
    let mut decoder = serde_json::Deserializer::from_slice(bytes);
    let value = visitor::Node {
        context: &context,
        depth: 0,
        overflow: None,
    }
    .deserialize(&mut decoder)
    .and_then(|value| decoder.end().map(|()| value));
    value.map_err(|_| {
        context
            .violation
            .into_inner()
            .unwrap_or_else(|| LimitViolation::Syntax("invalid JSON document".into()))
    })
}

#[cfg(test)]
mod tests;
```

`crates/vpt-protocol/src/limits/visitor.rs`:

```rust
use super::{LimitViolation, Limits};
use serde::de::{self, DeserializeSeed, MapAccess, SeqAccess, Visitor};
use serde_json::{Map, Number, Value};
use std::cell::RefCell;
use std::fmt;

pub(super) struct Context<'a> {
    pub limits: &'a Limits,
    pub violation: RefCell<Option<LimitViolation>>,
}

impl Context<'_> {
    fn reject<E: de::Error>(&self, violation: LimitViolation) -> E {
        *self.violation.borrow_mut() = Some(violation);
        E::custom("document limit exceeded")
    }

    fn text<E: de::Error>(&self, value: &str) -> Result<(), E> {
        let length = value.chars().count();
        if length > self.limits.text_chars {
            return Err(self.reject(LimitViolation::Text(length)));
        }
        Ok(())
    }
}

pub(super) struct Node<'a, 'b> {
    pub context: &'a Context<'b>,
    pub depth: usize,
    pub overflow: Option<usize>,
}

impl<'de> DeserializeSeed<'de> for Node<'_, '_> {
    type Value = Value;

    fn deserialize<D: de::Deserializer<'de>>(self, decoder: D) -> Result<Value, D::Error> {
        if let Some(length) = self.overflow {
            return Err(self.context.reject(LimitViolation::Array(length)));
        }
        decoder.deserialize_any(self)
    }
}

impl Node<'_, '_> {
    fn enter<E: de::Error>(&self) -> Result<usize, E> {
        let depth = self.depth + 1;
        if depth > self.context.limits.depth {
            return Err(self.context.reject(LimitViolation::Depth(depth)));
        }
        Ok(depth)
    }
}

impl<'de> Visitor<'de> for Node<'_, '_> {
    type Value = Value;

    fn expecting(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("a bounded JSON value")
    }

    fn visit_bool<E: de::Error>(self, value: bool) -> Result<Value, E> {
        Ok(Value::Bool(value))
    }

    fn visit_i64<E: de::Error>(self, value: i64) -> Result<Value, E> {
        Ok(Value::Number(value.into()))
    }

    fn visit_u64<E: de::Error>(self, value: u64) -> Result<Value, E> {
        Ok(Value::Number(value.into()))
    }

    fn visit_f64<E: de::Error>(self, value: f64) -> Result<Value, E> {
        Number::from_f64(value)
            .map(Value::Number)
            .ok_or_else(|| E::custom("invalid JSON number"))
    }

    fn visit_unit<E: de::Error>(self) -> Result<Value, E> {
        Ok(Value::Null)
    }

    fn visit_str<E: de::Error>(self, value: &str) -> Result<Value, E> {
        self.context.text(value)?;
        Ok(Value::String(value.to_owned()))
    }

    fn visit_string<E: de::Error>(self, value: String) -> Result<Value, E> {
        self.context.text(&value)?;
        Ok(Value::String(value))
    }

    fn visit_seq<A: SeqAccess<'de>>(self, mut sequence: A) -> Result<Value, A::Error> {
        let depth = self.enter()?;
        let mut items = Vec::new();
        loop {
            let overflow =
                (items.len() >= self.context.limits.array_len).then_some(items.len() + 1);
            let next = sequence.next_element_seed(Node {
                context: self.context,
                depth,
                overflow,
            })?;
            match next {
                Some(value) => items.push(value),
                None => return Ok(Value::Array(items)),
            }
        }
    }

    fn visit_map<A: MapAccess<'de>>(self, mut object: A) -> Result<Value, A::Error> {
        let depth = self.enter()?;
        let mut fields = Map::new();
        while let Some(key) = object.next_key_seed(Key(self.context))? {
            let value = object.next_value_seed(Node {
                context: self.context,
                depth,
                overflow: None,
            })?;
            fields.insert(key, value);
        }
        Ok(Value::Object(fields))
    }
}

struct Key<'a, 'b>(&'a Context<'b>);

impl<'de> DeserializeSeed<'de> for Key<'_, '_> {
    type Value = String;

    fn deserialize<D: de::Deserializer<'de>>(self, decoder: D) -> Result<String, D::Error> {
        decoder.deserialize_str(self)
    }
}

impl<'de> Visitor<'de> for Key<'_, '_> {
    type Value = String;

    fn expecting(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("a bounded object key")
    }

    fn visit_str<E: de::Error>(self, value: &str) -> Result<String, E> {
        self.0.text(value)?;
        Ok(value.to_owned())
    }
}
```

`crates/vpt-protocol/src/helper.rs`:

```rust
use serde::Deserialize;

pub const HELPER_SCHEMA: &str = "vpt.helper/1";

#[derive(Debug, Clone, Deserialize, PartialEq, Eq)]
pub struct HelperVersion {
    pub schema: String,
    pub version: String,
}

impl HelperVersion {
    pub fn major(&self) -> Option<u32> {
        let mut core = self.version.as_str();
        if let Some((prefix, build)) = core.split_once('+') {
            if !identifiers(build, false) {
                return None;
            }
            core = prefix;
        }
        if let Some((prefix, pre)) = core.split_once('-') {
            if !identifiers(pre, true) {
                return None;
            }
            core = prefix;
        }
        let parts: Vec<_> = core.split('.').collect();
        if parts.len() != 3
            || parts.iter().any(|part| {
                part.is_empty()
                    || !part.bytes().all(|byte| byte.is_ascii_digit())
                    || (part.len() > 1 && part.starts_with('0'))
            })
        {
            return None;
        }
        parts[0].parse().ok()
    }
}

fn identifiers(value: &str, prerelease: bool) -> bool {
    value.split('.').all(|part| {
        !part.is_empty()
            && part
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-')
            && !(prerelease
                && part.len() > 1
                && part.starts_with('0')
                && part.bytes().all(|byte| byte.is_ascii_digit()))
    })
}

#[derive(Debug, Clone, Deserialize, PartialEq, Eq)]
pub struct Posted {
    pub posted: bool,
}

#[derive(Debug, Clone, Deserialize, PartialEq, Eq)]
pub struct Trashed {
    pub trashed: String,
}
```

`crates/vpt-adapters/src/helper.rs`:

```rust
mod reply;
use crate::spawn::{self, SpawnError, Status};
use serde::de::DeserializeOwned;
use serde_json::Value;
use std::cell::RefCell;
use std::path::{Path, PathBuf};
use std::time::Duration;
use vpt_application::ports::{Trash, TrashError};
use vpt_protocol::{HelperVersion, Limits, Posted, Trashed, read_bounded};

pub const CALL_DEADLINE: Duration = Duration::from_secs(5);
pub const BUILT_AGAINST_MAJOR: u32 = 1;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HelperError {
    Absent,
    MajorMismatch { found: u32 },
    Failed(String),
    Unknown(String),
}

pub struct HelperClient {
    path: PathBuf,
    deadline: Duration,
    version: RefCell<Option<String>>,
    diagnostics: RefCell<Vec<String>>,
}

impl HelperClient {
    pub fn new(path: PathBuf) -> Self {
        Self {
            path,
            deadline: CALL_DEADLINE,
            version: RefCell::new(None),
            diagnostics: RefCell::new(vec![]),
        }
    }

    pub fn with_deadline(mut self, deadline: Duration) -> Self {
        self.deadline = deadline;
        self
    }

    pub fn take_diagnostics(&self) -> Vec<String> {
        std::mem::take(&mut *self.diagnostics.borrow_mut())
    }

    pub fn version(&self) -> Result<String, HelperError> {
        self.version_with_env(&[])
    }

    pub fn version_with_env(&self, env: &[(&str, &str)]) -> Result<String, HelperError> {
        self.version_using(&|argv| self.call(argv, env))
    }

    fn version_using(
        &self,
        call: &impl Fn(&[String]) -> Result<Value, HelperError>,
    ) -> Result<String, HelperError> {
        if let Some(version) = self.version.borrow().clone() {
            return Ok(version);
        }
        let value = call(&["--version".into()])?;
        reply::schema(&value)?;
        let document: HelperVersion = self.decode(
            value,
            &["schema", "version"],
            "invalid helper version document",
        )?;
        let major = document
            .major()
            .ok_or_else(|| HelperError::Unknown("invalid helper version document".into()))?;
        if major != BUILT_AGAINST_MAJOR {
            return Err(HelperError::MajorMismatch { found: major });
        }
        *self.version.borrow_mut() = Some(document.version.clone());
        Ok(document.version)
    }

    pub fn notify(&self, title: &str, body: &str) -> Result<(), HelperError> {
        self.notify_with_env(title, body, &[])
    }

    pub fn notify_with_env(
        &self,
        title: &str,
        body: &str,
        env: &[(&str, &str)],
    ) -> Result<(), HelperError> {
        self.notify_using(title, body, &|argv| self.call(argv, env))
    }

    fn notify_using(
        &self,
        title: &str,
        body: &str,
        call: &impl Fn(&[String]) -> Result<Value, HelperError>,
    ) -> Result<(), HelperError> {
        self.version_using(call)?;
        let argv = ["notify", "--title", title, "--body", body].map(str::to_owned);
        let reply: Posted =
            self.decode(call(&argv)?, &["posted"], "invalid helper notify document")?;
        if reply.posted {
            Ok(())
        } else {
            Err(HelperError::Failed("the helper did not post".into()))
        }
    }

    pub fn trash_with_env(&self, path: &Path, env: &[(&str, &str)]) -> Result<PathBuf, TrashError> {
        self.trash_using(path, &|argv| self.call(argv, env))
    }

    fn trash_using(
        &self,
        path: &Path,
        call: &impl Fn(&[String]) -> Result<Value, HelperError>,
    ) -> Result<PathBuf, TrashError> {
        self.version_using(call).map_err(reply::trash_error)?;
        let path_text = path
            .to_str()
            .ok_or_else(|| TrashError::Failed("the Trash path is not UTF-8".into()))?;
        let argv = ["trash".to_owned(), path_text.to_owned()];
        let reply: Trashed = self
            .decode(
                call(&argv).map_err(reply::trash_error)?,
                &["trashed"],
                "invalid helper trash document",
            )
            .map_err(reply::trash_error)?;
        if Path::new(&reply.trashed) != path {
            return Err(TrashError::Unknown(
                "the helper trash reply names another path".into(),
            ));
        }
        Ok(path.to_path_buf())
    }

    fn decode<T: DeserializeOwned>(
        &self,
        value: Value,
        supported: &[&str],
        invalid: &str,
    ) -> Result<T, HelperError> {
        let fields = value
            .as_object()
            .ok_or_else(|| HelperError::Unknown(invalid.into()))?;
        self.diagnostics.borrow_mut().extend(
            fields
                .keys()
                .filter(|key| !supported.contains(&key.as_str()))
                .map(|key| {
                    format!(
                        "unknown additive helper field: {}",
                        key.chars()
                            .flat_map(char::escape_default)
                            .collect::<String>()
                    )
                }),
        );
        serde_json::from_value(value).map_err(|_| HelperError::Unknown(invalid.into()))
    }

    fn call(&self, argv: &[String], env: &[(&str, &str)]) -> Result<Value, HelperError> {
        self.call_using(argv, env, spawn::run_with_env)
    }

    fn call_using(
        &self,
        argv: &[String],
        env: &[(&str, &str)],
        run: impl FnOnce(
            &[String],
            &[u8],
            Duration,
            usize,
            &[(&str, &str)],
        ) -> Result<spawn::Outcome, SpawnError>,
    ) -> Result<Value, HelperError> {
        let path = self
            .path
            .to_str()
            .ok_or_else(|| HelperError::Failed("the helper path is not UTF-8".into()))?;
        let mut full = vec![path.to_owned()];
        full.extend_from_slice(argv);
        let limits = Limits::incoming();
        let outcome = run(
            &full,
            b"",
            self.deadline,
            limits.bytes.saturating_add(1),
            env,
        )
        .map_err(|error| match error {
            SpawnError::NotFound(_) => HelperError::Absent,
            SpawnError::Io(_) => HelperError::Failed("the helper could not start".into()),
        })?;
        match outcome.status {
            Status::Exited(0) => read_bounded(&outcome.stdout, &limits)
                .map_err(|_| HelperError::Unknown("invalid or oversized helper document".into())),
            Status::Exited(code) => Err(HelperError::Failed(format!("the helper exited {code}"))),
            Status::Signaled(signal) => Err(HelperError::Failed(format!(
                "the helper died on signal {signal}"
            ))),
            Status::DeadlineExceeded => Err(HelperError::Unknown(
                "the helper exceeded its deadline".into(),
            )),
            Status::Interrupted => Err(HelperError::Unknown("interrupted".into())),
        }
    }
}

impl Trash for HelperClient {
    fn trash(&self, path: &Path) -> Result<PathBuf, TrashError> {
        self.trash_with_env(path, &[])
    }

    fn take_diagnostics(&self) -> Vec<String> {
        HelperClient::take_diagnostics(self)
    }
}

#[cfg(test)]
mod tests;
```

`crates/vpt-adapters/src/helper/reply.rs`:

```rust
use super::HelperError;
use serde_json::Value;
use vpt_application::ports::TrashError;
use vpt_protocol::HELPER_SCHEMA;

pub(super) fn schema(value: &Value) -> Result<(), HelperError> {
    let Some(schema) = value.get("schema").and_then(Value::as_str) else {
        return Err(HelperError::Unknown("invalid helper schema".into()));
    };
    if schema == HELPER_SCHEMA {
        return Ok(());
    }
    let major = schema
        .strip_prefix("vpt.helper/")
        .filter(|part| !part.is_empty() && part.bytes().all(|byte| byte.is_ascii_digit()))
        .and_then(|part| part.parse::<u32>().ok());
    match major {
        Some(found) => Err(HelperError::Unknown(format!(
            "unsupported helper schema major {found}"
        ))),
        None => Err(HelperError::Unknown("invalid helper schema".into())),
    }
}

pub(super) fn trash_error(error: HelperError) -> TrashError {
    match error {
        HelperError::Absent => TrashError::HelperAbsent,
        HelperError::MajorMismatch { found } => TrashError::HelperVersion { found },
        HelperError::Failed(detail) => TrashError::Failed(detail),
        HelperError::Unknown(detail) => TrashError::Unknown(detail),
    }
}
```

`crates/vpt/src/commands/version.rs`:

```rust
use crate::cli::output::Outcome;
use crate::compose::Environment;
use serde_json::{Value, json};
use std::path::{Path, PathBuf};
use vpt_adapters::HelperClient;
use vpt_adapters::config::{ConfigError, from_table, load_file};

pub const VERSION: &str = env!("CARGO_PKG_VERSION");

pub fn document(helper_version: Option<&str>) -> Value {
    json!({"schema":"vpt.result/1", "command":"version", "version":VERSION, "helper_version":helper_version})
}

pub fn human(helper_version: Option<&str>) -> String {
    match helper_version {
        Some(helper) => format!("vpt {VERSION} (helper {helper})\n"),
        None => format!("vpt {VERSION} (helper absent)\n"),
    }
}

pub fn run(environment: &Environment, config: Option<&Path>) -> Outcome {
    let selected = config
        .map(Path::to_path_buf)
        .unwrap_or_else(|| environment.config_path());
    let helper_path = match load_file(&selected) {
        Ok(table) => from_table(&table, &environment.home_dir())
            .ok()
            .map(|settings| settings.helper_path),
        Err(ConfigError::Missing(_)) => Some(PathBuf::from("vpt-macos")),
        Err(_) => None,
    };
    let helper = helper_path.map(HelperClient::new);
    let version = helper.as_ref().and_then(|helper| helper.version().ok());
    let diagnostics = helper
        .as_ref()
        .map(HelperClient::take_diagnostics)
        .unwrap_or_default();
    let mut result = document(version.as_deref());
    let mut text = human(version.as_deref());
    if !diagnostics.is_empty() {
        result["diagnostics"] = json!(diagnostics);
        for diagnostic in &diagnostics {
            text.push_str(diagnostic);
            text.push('\n');
        }
    }
    Outcome::Success {
        document: result,
        human: text,
    }
}
```

In `crates/vpt/src/lib.rs`, use this dispatch arm with its existing `environment`:

```rust
        Verb::Version => commands::version::run(&environment, invocation.config.as_deref()),
```

In `crates/vpt/src/lib.rs`, insert this as the first statement of `pub fn run() -> !`, before reading
arguments or constructing the environment. Retain it in every later replacement of that function:

```rust
    vpt_adapters::install_interrupt_handlers();
```

Commands collect `Trash::take_diagnostics` after cleanup or reconciliation. `HelperVersion { found }`
remains typed through the application and maps to exit 3, rule `helper_version`, when Trash is required.

- [ ] **Step 4: Verify green and the guards**

Run: `cargo fmt --all`

Run `cargo test --workspace --features dev-tools`, `cargo fmt --all -- --check` and
`cargo clippy --workspace --all-targets --features dev-tools -- -D warnings`. Expected: all tests pass.
Reader and client unit tests use private injected operations; integration tests spawn only the
development fake. No helper test uses wall-clock assertions or a real helper.

Mutation-check the array overflow guard, the depth guard, the extra stdout byte, the compatibility
preflight and the returned Trash path check. Verify each changed line before running its named test; each
mutant must fail, then restore the implementation and rerun green. Count physical lines after rustfmt;
the private child files keep every handwritten Rust file below 500 lines.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(helper): validate replies and cache compatible helper versions"
```

______________________________________________________________________

