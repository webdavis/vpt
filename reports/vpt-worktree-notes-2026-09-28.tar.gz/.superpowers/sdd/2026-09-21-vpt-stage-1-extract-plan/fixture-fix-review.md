Finding verdict: Fixed. crates/vpt/tests/support/mod.rs:12 disables the writer with Shutdown::Write; all seven callers retain the peer, and both-stream tests clone the disabled descriptor. Existing assertions remain intact.

Evidence: The controlled RED and Shutdown::Read mutant both return 2 versus expected 1. Restoring Shutdown::Write passes. fixture-fix-tests.log records all 32 leaves passing, including the retained-peer regression at crates/vpt/tests/harness.rs:8. This proves the fixture condition, not the historical fork interleaving.

New breakage: None found. The diff changes only four test files.

Out-of-scope observations: The Task 3 dead-code warning at crates/vpt-adapters/src/config/schema/types.rs:33 remains visible. Full workspace gates remain deferred, not claimed green.

Approval: Approved for the fixture-only follow-up by /root/vpt_build_review_2.
