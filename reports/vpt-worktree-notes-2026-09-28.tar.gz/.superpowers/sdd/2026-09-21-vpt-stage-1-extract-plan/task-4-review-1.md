### Spec Compliance

Compliant. All Task 4 files and behaviors are present; no Task 5 work or unrelated changes found.

### Strengths

- `crates/vpt-domain/src/duration.rs:9`: pure standard-library parser, character-safe suffix handling, strict decimal syntax, and checked parse/multiplication overflow.
- `crates/vpt-adapters/src/config/validate.rs:19`: uses the authoritative schema for every leaf and refuses missing kinds without a permissive fallback.
- `crates/vpt-adapters/src/config/validate.rs:34`: type and range errors retain only the key and expected rule.
- `crates/vpt-adapters/src/config/load.rs:68`: validation runs after merging defaults and propagates failure.
- `crates/vpt-adapters/src/config/validate/tests.rs:3`: tests exercise `load_text` and discard successful tables before assertions, protecting configuration contents in failure output.
- Recorded compiling RED runs and sampled mutation/control logs demonstrate behavioral failures, including wrapping overflow and ignored loader validation. The controller's fresh `just ship` passed all 77 tests and found no secrets.
- Changed files meet the size targets; validation tests occupy a private child module.

### Issues

- Critical: none.
- Important: none.
- Minor: none.

### Cannot verify from diff

- Final command-level exit 2 and diagnostic rendering are outside this loader change. Later command integration must preserve these errors.

### Considered and set aside

- Empty-table validation bypass: the diff cuts off `refuse_unknown_keys`, so its continuation was inspected. `crates/vpt-adapters/src/config/load.rs:83` rejects tables at scalar keys before merging. No bypass found.
- Integer overflow losing its key: `crates/vpt-adapters/src/config/validate/tests.rs:134` covers the positive signed 64-bit TOML range. Values exceeding the format's integer range follow the existing redacted document-parse failure policy; no valid decoded integer bypasses the keyed range checks.
- Public duration module: `crates/vpt-domain/src/lib.rs:1` exposes only the explicitly named duration capability. The plan permits named capability APIs.
- Size warnings: the controller log reports only inherited `schema.rs` and loader-test warnings. Neither was enlarged by this task.

### Assessment

Task quality: Approved. Cohesive implementation, private validation internals, effective boundary tests, and credible restored-control evidence. No extra tests or mutations were run during review.
