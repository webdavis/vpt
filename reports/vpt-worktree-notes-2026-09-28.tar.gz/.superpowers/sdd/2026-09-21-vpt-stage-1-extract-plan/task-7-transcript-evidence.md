# Task 7 transcript evidence

These are verbatim copies of command output already returned by the task's tools. They were copied from the live transcript for durable review, not rerun. Tool locators and exit codes are outside the output blocks.

## Compiled test-first RED

Tool: `functions.exec` nested `exec_command`, chunk `a51380`; command: `cargo test -p vpt-domain --lib`; exit code: `101`.

```text
   Compiling vpt-domain v0.1.0 (/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract/crates/vpt-domain)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.74s
     Running unittests src/lib.rs (target/debug/deps/vpt_domain-5bc354f3ff9fb91b)

running 25 tests
test digest::tests::full_length_malformed_and_non_ascii_hex_are_refused ... ok
test duration::tests::a_count_above_64_bits_is_refused ... ok
test digest::tests::hex_round_trips_with_exact_prefixes ... FAILED
test duration::tests::each_unit_converts_to_seconds ... ok
test duration::tests::a_positive_number_without_a_unit_is_refused ... ok
test duration::tests::an_unknown_unit_is_refused ... ok
test duration::tests::leading_zeroes_do_not_change_a_positive_count ... ok
test duration::tests::zero_means_never_and_needs_no_unit ... ok
test duration::tests::malformed_counts_are_refused ... ok
test duration::tests::multiplication_overflow_is_refused ... ok
test duration::tests::the_largest_seconds_value_is_accepted ... ok
test layout::tests::home_and_config_cannot_descend_from_the_source_container ... ok
test layout::tests::home_and_config_cannot_equal_the_source_container ... ok
test layout::tests::home_and_config_may_be_ancestors_or_unrelated_to_the_source ... ok
test layout::tests::released_cannot_overlap_private_stores_state_or_config ... ok
test time::tests::civil_round_trips_at_positive_and_negative_offsets ... FAILED
test layout::tests::stores_and_state_cannot_overlap_the_source_in_either_direction ... ok
test layout::tests::stores_are_pairwise_disjoint ... ok
test layout::tests::the_home_may_contain_its_stores ... ok
test time::tests::file_age_floors_fractional_seconds_and_saturates ... FAILED
test time::tests::extreme_instants_convert_and_out_of_range_civil_is_refused ... FAILED
test time::tests::epoch_and_negative_instant_render ... FAILED
test time::tests::gregorian_calendar_and_clock_bounds_are_validated ... FAILED
test time::tests::leap_day_and_negative_years_round_trip ... FAILED
test time::tests::offsets_shift_civil_time_and_keep_their_sign ... FAILED

failures:

---- digest::tests::hex_round_trips_with_exact_prefixes stdout ----

thread 'digest::tests::hex_round_trips_with_exact_prefixes' (239949585) panicked at crates/vpt-domain/src/digest.rs:21:9:
assertion `left == right` failed
  left: 0
 right: 64
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace

---- time::tests::civil_round_trips_at_positive_and_negative_offsets stdout ----

thread 'time::tests::civil_round_trips_at_positive_and_negative_offsets' (239949603) panicked at crates/vpt-domain/src/time.rs:72:13:
assertion `left == right` failed
  left: None
 right: Some(UtcInstant { secs: 1787604456 })

---- time::tests::file_age_floors_fractional_seconds_and_saturates stdout ----

thread 'time::tests::file_age_floors_fractional_seconds_and_saturates' (239949606) panicked at crates/vpt-domain/src/time.rs:104:9:
assertion `left == right` failed
  left: 0
 right: 29

---- time::tests::extreme_instants_convert_and_out_of_range_civil_is_refused stdout ----

thread 'time::tests::extreme_instants_convert_and_out_of_range_civil_is_refused' (239949605) panicked at crates/vpt-domain/src/time.rs:80:9:
assertion failed: late.year > early.year

---- time::tests::epoch_and_negative_instant_render stdout ----

thread 'time::tests::epoch_and_negative_instant_render' (239949604) panicked at crates/vpt-domain/src/time.rs:45:9:
assertion `left == right` failed
  left: ""
 right: "1970-01-01T00:00:00Z"

---- time::tests::gregorian_calendar_and_clock_bounds_are_validated stdout ----

thread 'time::tests::gregorian_calendar_and_clock_bounds_are_validated' (239949607) panicked at crates/vpt-domain/src/time.rs:89:9:
assertion failed: base.is_valid()

---- time::tests::leap_day_and_negative_years_round_trip stdout ----

thread 'time::tests::leap_day_and_negative_years_round_trip' (239949608) panicked at crates/vpt-domain/src/time.rs:61:9:
assertion `left == right` failed
  left: (0, 0, 0)
 right: (2024, 2, 29)

---- time::tests::offsets_shift_civil_time_and_keep_their_sign stdout ----

thread 'time::tests::offsets_shift_civil_time_and_keep_their_sign' (239949609) panicked at crates/vpt-domain/src/time.rs:52:9:
assertion `left == right` failed
  left: ""
 right: "2026-08-24T20:47:36Z"


failures:
    digest::tests::hex_round_trips_with_exact_prefixes
    time::tests::civil_round_trips_at_positive_and_negative_offsets
    time::tests::epoch_and_negative_instant_render
    time::tests::extreme_instants_convert_and_out_of_range_civil_is_refused
    time::tests::file_age_floors_fractional_seconds_and_saturates
    time::tests::gregorian_calendar_and_clock_bounds_are_validated
    time::tests::leap_day_and_negative_years_round_trip
    time::tests::offsets_shift_civil_time_and_keep_their_sign

test result: FAILED. 17 passed; 8 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p vpt-domain --lib`
```

## Surviving age-divisor mutant

Tool: `functions.exec` cell `30`, first `time-age-floor` mutant item. Exact source edit: `.div_euclid(NANOS_PER_SECOND)` to `.div_euclid(NANOS_PER_SECOND - 1)`. Command: `shasum -a 256 crates/vpt-domain/src/time.rs; cargo test -p vpt-domain --lib time::tests::file_age_floors_fractional_seconds_and_saturates 2>&1 | tee .superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/task-7-time-age-floor-mutant.log; test ${PIPESTATUS[0]} -ne 0`. Cargo test exited `0`; the wrapper exited `1` because it expected failure. The command log path was overwritten by the later, effective truncation mutant, so this preserved transcript copy is the evidence for the survivor.

```text
ef5697b03fd1d9375356cd5d2fac5b8906038b2b54575b3489a981a8e73164ae  crates/vpt-domain/src/time.rs
   Compiling vpt-domain v0.1.0 (/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract/crates/vpt-domain)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.09s
     Running unittests src/lib.rs (target/debug/deps/vpt_domain-5bc354f3ff9fb91b)

running 1 test
test time::tests::file_age_floors_fractional_seconds_and_saturates ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 24 filtered out; finished in 0.00s

```
