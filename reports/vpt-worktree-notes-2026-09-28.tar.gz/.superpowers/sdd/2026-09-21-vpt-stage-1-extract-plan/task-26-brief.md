### Task 26: Notifications: `vpt.event/1` and the three modes

**Files:**

- Create: `crates/vpt-protocol/src/event.rs`.
- Create: `crates/vpt-adapters/src/notify/mod.rs`, `crates/vpt-adapters/src/notify/tests.rs`,
  `crates/vpt-adapters/src/notify/delivery.rs`, `crates/vpt-adapters/src/notify/delivery/tests.rs`.
- Modify: `crates/vpt-protocol/src/lib.rs`, `crates/vpt-adapters/src/lib.rs`.
- Test: `crates/vpt/tests/notify.rs`.

**Interfaces:**

- Consumes:
  `Notification { pub event: EventKind, pub state: EventState, pub recording: Option<RecordingId>, pub detail: String, pub counts: Vec<(String, u64)>, pub paths: Vec<(String, PathBuf)>, pub occurred_at: UtcInstant }`;
  `EventKind::as_str(self) -> &'static str`, `EventState::as_str(self) -> &'static str`,
  `RecordingId::as_str(&self) -> &str`, `UtcInstant::rfc3339(self) -> String`.

- Consumes: `Notifier::deliver(&self, notification: &Notification) -> DeliveryOutcome`,
  `Notifier::take_diagnostics(&self) -> Vec<String>`,
  `DeliveryOutcome::{Delivered, Suppressed, Failed(String)}`;
  `HelperClient::notify_with_env(&self, title: &str, body: &str, env: &[(&str, &str)]) -> Result<(), HelperError>`,
  `HelperClient::take_diagnostics(&self) -> Vec<String>`;
  `spawn::run_with_env(argv: &[String], stdin: &[u8], deadline: Duration, output_limit: usize, env: &[(&str, &str)]) -> Result<spawn::Outcome, spawn::SpawnError>`.

- Produces protocol root exports: `EVENT_SCHEMA: &str = "vpt.event/1"`,
  `EventDocument { pub schema: String, pub event: String, pub state: String, pub recording: Option<String>, pub detail: String, pub counts: serde_json::Map<String, serde_json::Value>, pub paths: serde_json::Map<String, serde_json::Value>, pub occurred_at: String }`,
  implementing `Serialize`.

- Produces adapter root exports: `notification_document(notification: &Notification) -> EventDocument`,
  `notification_tokens(notification: &Notification, argv: &[String]) -> Vec<String>`,
  `DesktopNotifier::new(helper: HelperClient) -> DesktopNotifier`,
  `DesktopNotifier::with_env(self, env: Vec<(String, String)>) -> DesktopNotifier`,
  `CommandNotifier::new(argv: Vec<String>, fallback: DesktopNotifier) -> CommandNotifier`,
  `CommandNotifier::with_env(self, env: Vec<(String, String)>) -> CommandNotifier`, `OffNotifier`,
  `NOTIFY_DEADLINE: Duration = Duration::from_secs(5)`. All three implement `Notifier`. The desktop and
  command implementations retain diagnostics until drained. An absent desktop helper disables subsequent
  attempts for that command and records exactly `desktop notifications disabled: helper absent` once.
  Command failure is recorded before one fallback attempt, including its exit code when available.
  Delivery never changes the work's exit. Production command paths drain diagnostics on success and
  failure into their final result or error.

- [ ] **Step 1: Register and write the failing tests**

Add this private module and its curated exports to the adapters crate root:

```rust
mod notify;
pub use notify::{CommandNotifier, DesktopNotifier, NOTIFY_DEADLINE, OffNotifier,
    document as notification_document, tokens as notification_tokens};
```

Create `crates/vpt-adapters/src/notify/mod.rs` with:

```rust
mod delivery;
pub use delivery::{CommandNotifier, DesktopNotifier, NOTIFY_DEADLINE, OffNotifier};

#[cfg(test)]
mod tests;
```

Create `crates/vpt-adapters/src/notify/delivery.rs` with:

```rust
#[cfg(test)]
mod tests;
```

`crates/vpt-adapters/src/notify/tests.rs`:

```rust
use super::*;
use std::path::PathBuf;
use vpt_domain::identity::RecordingId;
use vpt_domain::notification::{EventKind, Notification};
use vpt_domain::time::UtcInstant;

fn review_needed() -> Notification {
    Notification::attention(
        EventKind::ReviewNeeded,
        Some(RecordingId::parse("2026-08-24T144736-4f3ab19c02de").expect("id")),
        "6 spans to review".into(),
        vec![("note".into(), PathBuf::from("/sandbox/transcripts/a.md"))],
        UtcInstant {
            secs: 1_789_599_200,
        },
    )
}

#[test]
fn event_document_contains_the_spec_fields_and_correct_utc_timestamp() {
    let mut notification = review_needed();
    notification.counts = vec![("numeric".into(), 3), ("diagnostics".into(), 0)];
    let json = serde_json::to_value(document(&notification)).expect("json");
    assert_eq!(json["schema"], "vpt.event/1");
    assert_eq!(json["event"], "review_needed");
    assert_eq!(json["state"], "needs_attention");
    assert_eq!(json["recording"], "2026-08-24T144736-4f3ab19c02de");
    assert_eq!(json["counts"]["numeric"], 3);
    assert_eq!(json["paths"]["note"], "/sandbox/transcripts/a.md");
    assert_eq!(json["occurred_at"], "2026-09-16T22:53:20Z");
}

#[test]
fn all_tokens_are_replaced_and_inserted_values_are_never_scanned() {
    let mut notification = review_needed();
    notification.detail = "use {count}".into();
    notification.counts = vec![("numeric".into(), 3), ("other".into(), 2)];
    assert_eq!(tokens(&notification, &["{detail}".into()]), ["use {count}"]);
    let argv = [
        "notify-command",
        "{event}/{state}/{id}/{count}/{path}",
        "é{unknown}{detail}",
    ]
    .map(str::to_owned);
    assert_eq!(
        tokens(&notification, &argv),
        [
            "notify-command",
            "review_needed/needs_attention/2026-08-24T144736-4f3ab19c02de/5//sandbox/transcripts/a.md",
            "é{unknown}use {count}"
        ]
    );
    let bare = Notification::failed(
        EventKind::IngestFailed,
        "boom".into(),
        UtcInstant { secs: 0 },
    );
    assert_eq!(
        tokens(&bare, &["{id}".into(), "{path}".into(), "{detail}".into()]),
        ["", "", "boom"]
    );
}
```

`crates/vpt-adapters/src/notify/delivery/tests.rs`:

```rust
use super::*;
use std::path::PathBuf;
use vpt_domain::notification::EventKind;
use vpt_domain::time::UtcInstant;

fn event() -> Notification {
    Notification::failed(
        EventKind::IngestFailed,
        "unreadable source".into(),
        UtcInstant { secs: 7 },
    )
}

fn desktop() -> DesktopNotifier {
    DesktopNotifier::new(HelperClient::new(PathBuf::from("/sandbox/fake-helper")))
}

#[test]
fn absent_desktop_helper_is_reported_once_and_subsequent_attempts_are_suppressed() {
    let notifier = desktop();
    let attempts = Cell::new(0);
    for _ in 0..2 {
        assert_eq!(
            notifier.deliver_using(|| {
                attempts.set(attempts.get() + 1);
                Err(HelperError::Absent)
            }),
            DeliveryOutcome::Suppressed
        );
    }
    assert_eq!(attempts.get(), 1);
    assert_eq!(
        notifier.take_diagnostics(),
        ["desktop notifications disabled: helper absent"]
    );
    assert!(notifier.take_diagnostics().is_empty());
}

#[test]
fn failed_command_is_recorded_before_one_fallback_and_keeps_its_status() {
    let notifier = CommandNotifier::new(vec!["notify-command".into()], desktop());
    let attempts = Cell::new(0);
    let result = notifier.deliver_using(
        &event(),
        |_, _, _, _, _| {
            Ok(spawn::Outcome {
                status: Status::Exited(7),
                stdout: b"CANARY-STDOUT".to_vec(),
                stderr: b"CANARY-STDERR".to_vec(),
                group: 0,
            })
        },
        || {
            attempts.set(attempts.get() + 1);
            assert_eq!(*notifier.diagnostics.borrow(), ["notify command exited 7"]);
            notifier.fallback.deliver_using(|| Err(HelperError::Absent))
        },
    );
    assert_eq!(attempts.get(), 1);
    assert_eq!(
        result,
        DeliveryOutcome::Failed("notify command exited 7".into())
    );
    assert_eq!(
        notifier.take_diagnostics(),
        [
            "notify command exited 7",
            "desktop notifications disabled: helper absent"
        ]
    );
}

#[test]
fn command_sends_substituted_argv_and_event_stdin_together_without_fallback() {
    let notifier = CommandNotifier::new(vec!["notify-command".into(), "{event}".into()], desktop());
    let result = notifier.deliver_using(
        &event(),
        |argv, stdin, deadline, limit, _| {
            assert_eq!(argv, ["notify-command", "ingest_failed"]);
            assert_eq!(
                serde_json::from_slice::<serde_json::Value>(stdin).expect("event")["schema"],
                "vpt.event/1"
            );
            assert_eq!(deadline, Duration::from_secs(5));
            assert_eq!(limit, spawn::OUTPUT_LIMIT);
            Ok(spawn::Outcome {
                status: Status::Exited(0),
                stdout: vec![],
                stderr: vec![],
                group: 0,
            })
        },
        || panic!("unexpected fallback"),
    );
    assert_eq!(result, DeliveryOutcome::Delivered);
    assert!(notifier.take_diagnostics().is_empty());
}

#[test]
fn spawn_failure_diagnostics_never_copy_untrusted_details() {
    let notifier = CommandNotifier::new(vec![], desktop());
    let result = notifier.deliver_using(
        &event(),
        |_, _, _, _, _| Err(SpawnError::Io("CANARY".into())),
        || DeliveryOutcome::Delivered,
    );
    assert_eq!(
        result,
        DeliveryOutcome::Failed("notify command could not start".into())
    );
    assert_eq!(
        notifier.take_diagnostics(),
        ["notify command could not start"]
    );
}

#[test]
fn incompatible_desktop_helper_is_diagnostic_and_off_has_no_diagnostics() {
    let notifier = desktop();
    assert!(matches!(
        notifier.deliver_using(|| Err(HelperError::MajorMismatch { found: 2 })),
        DeliveryOutcome::Failed(_)
    ));
    assert_eq!(
        notifier.take_diagnostics(),
        ["desktop notification refused: helper major version 2"]
    );
    assert_eq!(OffNotifier.deliver(&event()), DeliveryOutcome::Suppressed);
    assert!(OffNotifier.take_diagnostics().is_empty());
}
```

`crates/vpt/tests/notify.rs`:

```rust
mod support;

use std::path::Path;
use support::{FAKE_ENGINE, Sandbox};
use vpt_adapters::{CommandNotifier, DesktopNotifier, HelperClient};
use vpt_application::ports::{DeliveryOutcome, Notifier};
use vpt_domain::notification::{EventKind, Notification};
use vpt_domain::time::UtcInstant;

fn event() -> Notification {
    Notification::failed(
        EventKind::IngestFailed,
        "the recordings directory is unreadable".into(),
        UtcInstant { secs: 7 },
    )
}

fn lines(path: &Path) -> Vec<String> {
    std::fs::read_to_string(path)
        .unwrap_or_default()
        .lines()
        .map(str::to_owned)
        .collect()
}

fn env(sandbox: &Sandbox) -> Vec<(String, String)> {
    vec![(
        "VPT_FAKE_LOG".into(),
        sandbox.fake_log().to_string_lossy().into_owned(),
    )]
}

#[test]
fn desktop_posts_through_the_fake_and_retains_absence_diagnostics() {
    let sandbox = Sandbox::new("notify-desktop");
    sandbox.install_fake_helper();
    let notifier = DesktopNotifier::new(HelperClient::new(sandbox.path().join("bin/vpt-macos")))
        .with_env(env(&sandbox));
    assert_eq!(notifier.deliver(&event()), DeliveryOutcome::Delivered);
    assert_eq!(
        lines(&sandbox.fake_log()),
        ["notify\tvpt: ingest_failed\tthe recordings directory is unreadable"]
    );
    let absent = DesktopNotifier::new(HelperClient::new(sandbox.path().join("missing")));
    assert_eq!(absent.deliver(&event()), DeliveryOutcome::Suppressed);
    assert_eq!(absent.deliver(&event()), DeliveryOutcome::Suppressed);
    assert_eq!(
        absent.take_diagnostics(),
        ["desktop notifications disabled: helper absent"]
    );
}

#[test]
fn command_gets_tokens_and_json_and_nonzero_falls_back_once() {
    let sandbox = Sandbox::new("notify-command");
    sandbox.install_fake_helper();
    let desktop = DesktopNotifier::new(HelperClient::new(sandbox.path().join("bin/vpt-macos")));
    let argv = [
        FAKE_ENGINE,
        "command-sink",
        "--event",
        "{event}",
        "--state",
        "{state}",
    ]
    .map(str::to_owned)
    .to_vec();
    let mut child_env = env(&sandbox);
    child_env.push(("VPT_FAKE_EXIT".into(), "7".into()));
    let notifier = CommandNotifier::new(argv, desktop).with_env(child_env);
    assert_eq!(
        notifier.deliver(&event()),
        DeliveryOutcome::Failed("notify command exited 7".into())
    );
    assert_eq!(notifier.take_diagnostics(), ["notify command exited 7"]);
    let lines = lines(&sandbox.fake_log());
    assert_eq!(lines.len(), 2);
    let fields: Vec<_> = lines[0].splitn(3, '\t').collect();
    assert_eq!(fields[0], "command-sink");
    assert_eq!(fields[1], "--event ingest_failed --state failed");
    assert_eq!(
        serde_json::from_str::<serde_json::Value>(fields[2]).expect("event")["schema"],
        "vpt.event/1"
    );
    assert_eq!(
        lines[1],
        "notify\tvpt: ingest_failed\tthe recordings directory is unreadable"
    );
}
```

- [ ] **Step 2: Run each red command**

`cargo test -p vpt-adapters notify`

`cargo test -p vpt --features dev-tools --test notify`

Expected: compile errors name the absent document conversion, token substitution and notifier types. The
new test modules must be compiled and selected. Zero selected tests or a successful command does not
satisfy this step.

- [ ] **Step 3: Implement event encoding, token substitution and delivery**

Add `mod event; pub use event::{EVENT_SCHEMA, EventDocument};` to the protocol crate root.

`crates/vpt-protocol/src/event.rs`:

```rust
use serde::Serialize;
use serde_json::{Map, Value};

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct EventDocument {
    pub schema: String,
    pub event: String,
    pub state: String,
    pub recording: Option<String>,
    pub detail: String,
    pub counts: Map<String, Value>,
    pub paths: Map<String, Value>,
    pub occurred_at: String,
}

pub const EVENT_SCHEMA: &str = "vpt.event/1";
```

`crates/vpt-adapters/src/notify/mod.rs`:

```rust
mod delivery;
pub use delivery::{CommandNotifier, DesktopNotifier, NOTIFY_DEADLINE, OffNotifier};

use serde_json::{Map, Value};
use vpt_domain::notification::Notification;
use vpt_protocol::{EVENT_SCHEMA, EventDocument};

pub fn document(notification: &Notification) -> EventDocument {
    let counts = notification
        .counts
        .iter()
        .map(|(key, count)| (key.clone(), Value::from(*count)))
        .collect::<Map<_, _>>();
    let paths = notification
        .paths
        .iter()
        .map(|(key, path)| {
            (
                key.clone(),
                Value::String(path.to_string_lossy().into_owned()),
            )
        })
        .collect::<Map<_, _>>();
    EventDocument {
        schema: EVENT_SCHEMA.into(),
        event: notification.event.as_str().into(),
        state: notification.state.as_str().into(),
        recording: notification
            .recording
            .as_ref()
            .map(|id| id.as_str().to_owned()),
        detail: notification.detail.clone(),
        counts,
        paths,
        occurred_at: notification.occurred_at.rfc3339(),
    }
}

pub fn tokens(notification: &Notification, argv: &[String]) -> Vec<String> {
    let count = notification
        .counts
        .iter()
        .map(|(_, count)| u128::from(*count))
        .sum::<u128>()
        .to_string();
    let path = notification
        .paths
        .first()
        .map(|(_, path)| path.to_string_lossy().into_owned())
        .unwrap_or_default();
    let id = notification
        .recording
        .as_ref()
        .map(|id| id.as_str())
        .unwrap_or_default();
    let replacements = [
        ("{event}", notification.event.as_str()),
        ("{state}", notification.state.as_str()),
        ("{id}", id),
        ("{detail}", &notification.detail),
        ("{count}", &count),
        ("{path}", &path),
    ];
    argv.iter()
        .map(|word| {
            let mut output = String::new();
            let mut remaining = word.as_str();
            while !remaining.is_empty() {
                if let Some((token, value)) = replacements
                    .iter()
                    .find(|(token, _)| remaining.starts_with(token))
                {
                    output.push_str(value);
                    remaining = &remaining[token.len()..];
                } else if let Some(character) = remaining.chars().next() {
                    output.push(character);
                    remaining = &remaining[character.len_utf8()..];
                }
            }
            output
        })
        .collect()
}

#[cfg(test)]
mod tests;
```

`crates/vpt-adapters/src/notify/delivery.rs`:

```rust
use super::{document, tokens};
use crate::helper::{HelperClient, HelperError};
use crate::spawn::{self, SpawnError, Status};
use std::cell::{Cell, RefCell};
use std::time::Duration;
use vpt_application::ports::{DeliveryOutcome, Notifier};
use vpt_domain::notification::Notification;

pub const NOTIFY_DEADLINE: Duration = Duration::from_secs(5);

pub struct DesktopNotifier {
    helper: HelperClient,
    env: Vec<(String, String)>,
    disabled: Cell<bool>,
    diagnostics: RefCell<Vec<String>>,
}

impl DesktopNotifier {
    pub fn new(helper: HelperClient) -> Self {
        Self {
            helper,
            env: vec![],
            disabled: Cell::new(false),
            diagnostics: RefCell::new(vec![]),
        }
    }

    pub fn with_env(mut self, env: Vec<(String, String)>) -> Self {
        self.env = env;
        self
    }

    fn deliver_using(&self, call: impl FnOnce() -> Result<(), HelperError>) -> DeliveryOutcome {
        if self.disabled.get() {
            return DeliveryOutcome::Suppressed;
        }
        let result = call();
        self.diagnostics
            .borrow_mut()
            .extend(self.helper.take_diagnostics());
        match result {
            Ok(()) => DeliveryOutcome::Delivered,
            Err(HelperError::Absent) => {
                self.disabled.set(true);
                self.diagnostics
                    .borrow_mut()
                    .push("desktop notifications disabled: helper absent".into());
                DeliveryOutcome::Suppressed
            }
            Err(HelperError::MajorMismatch { found }) => {
                let detail = format!("desktop notification refused: helper major version {found}");
                self.diagnostics.borrow_mut().push(detail.clone());
                DeliveryOutcome::Failed(detail)
            }
            Err(HelperError::Failed(detail) | HelperError::Unknown(detail)) => {
                self.diagnostics.borrow_mut().push(detail.clone());
                DeliveryOutcome::Failed(detail)
            }
        }
    }
}

fn borrowed(env: &[(String, String)]) -> Vec<(&str, &str)> {
    env.iter()
        .map(|(key, value)| (key.as_str(), value.as_str()))
        .collect()
}

impl Notifier for DesktopNotifier {
    fn deliver(&self, notification: &Notification) -> DeliveryOutcome {
        let title = format!("vpt: {}", notification.event.as_str());
        self.deliver_using(|| {
            self.helper
                .notify_with_env(&title, &notification.detail, &borrowed(&self.env))
        })
    }

    fn take_diagnostics(&self) -> Vec<String> {
        std::mem::take(&mut *self.diagnostics.borrow_mut())
    }
}

pub struct CommandNotifier {
    argv: Vec<String>,
    fallback: DesktopNotifier,
    env: Vec<(String, String)>,
    diagnostics: RefCell<Vec<String>>,
}

impl CommandNotifier {
    pub fn new(argv: Vec<String>, fallback: DesktopNotifier) -> Self {
        Self {
            argv,
            fallback,
            env: vec![],
            diagnostics: RefCell::new(vec![]),
        }
    }

    pub fn with_env(mut self, env: Vec<(String, String)>) -> Self {
        self.fallback.env = env.clone();
        self.env = env;
        self
    }

    fn deliver_using(
        &self,
        notification: &Notification,
        run: impl FnOnce(
            &[String],
            &[u8],
            Duration,
            usize,
            &[(&str, &str)],
        ) -> Result<spawn::Outcome, SpawnError>,
        fallback: impl FnOnce() -> DeliveryOutcome,
    ) -> DeliveryOutcome {
        let argv = tokens(notification, &self.argv);
        let result = match serde_json::to_vec(&document(notification)) {
            Ok(body) => run(
                &argv,
                &body,
                NOTIFY_DEADLINE,
                spawn::OUTPUT_LIMIT,
                &borrowed(&self.env),
            ),
            Err(_) => return self.failed("notify event could not be encoded".into(), fallback),
        };
        let detail = match result {
            Ok(outcome) => match outcome.status {
                Status::Exited(0) => return DeliveryOutcome::Delivered,
                Status::Exited(code) => format!("notify command exited {code}"),
                Status::Signaled(signal) => format!("notify command died on signal {signal}"),
                Status::DeadlineExceeded => "notify command exceeded its deadline".into(),
                Status::Interrupted => "notify command interrupted".into(),
            },
            Err(_) => "notify command could not start".into(),
        };
        self.failed(detail, fallback)
    }

    fn failed(
        &self,
        detail: String,
        fallback: impl FnOnce() -> DeliveryOutcome,
    ) -> DeliveryOutcome {
        self.diagnostics.borrow_mut().push(detail.clone());
        let _ = fallback();
        self.diagnostics
            .borrow_mut()
            .extend(self.fallback.take_diagnostics());
        DeliveryOutcome::Failed(detail)
    }
}

impl Notifier for CommandNotifier {
    fn deliver(&self, notification: &Notification) -> DeliveryOutcome {
        self.deliver_using(notification, spawn::run_with_env, || {
            self.fallback.deliver(notification)
        })
    }

    fn take_diagnostics(&self) -> Vec<String> {
        std::mem::take(&mut *self.diagnostics.borrow_mut())
    }
}

pub struct OffNotifier;

impl Notifier for OffNotifier {
    fn deliver(&self, _notification: &Notification) -> DeliveryOutcome {
        DeliveryOutcome::Suppressed
    }
}

#[cfg(test)]
mod tests;
```

The diagnostic queue records the command failure before fallback; the command layer emits those messages
in its final document or run log. This preserves the single-document JSON output contract. All consumers,
including config refusal, ingest and retention, drain `take_diagnostics`; the returned `DeliveryOutcome`
does not replace the work's result.

- [ ] **Step 4: Verify green and diagnostic retention**

Run: `cargo fmt --all`

Run `cargo test --workspace --features dev-tools`, `cargo fmt --all -- --check` and
`cargo clippy --workspace --all-targets --features dev-tools -- -D warnings`. Expected: all tests pass.
Mutate substitution to rescan an inserted `{count}`, disable the missing-helper suppression, and drop the
queued command error in turn; each corresponding test must fail. Restore the source between mutants and
rerun green. Production composition tests in Tasks 27 and 32 assert that these diagnostics reach output
while the underlying work keeps its own exit status.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(notify): retain delivery diagnostics and substitute tokens once"
```

______________________________________________________________________

