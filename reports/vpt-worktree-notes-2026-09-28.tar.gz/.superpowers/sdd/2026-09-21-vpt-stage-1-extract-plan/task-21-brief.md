### Task 21: Duplicates, recovery and the archive collision

**Files:**

- Modify: `crates/vpt-application/src/ingest/publish.rs`
- Test: `crates/vpt-adapters/tests/support/fakes.rs`, `crates/vpt-adapters/tests/ingest_duplicates.rs`

**Interfaces:**

- Consumes: `Archive::{digest, sync_existing}`, `RecordingLedger::{by_digest, by_id, commit,`
  `set_source_path}`.

- Produces: `Ingest::known_bytes` and `Ingest::resolve_existing` (private to the module). Test support in
  `support/fakes.rs`: `FaultyArchive<'a>::new(inner: &'a ClonefileArchive) -> FaultyArchive` implementing
  `Archive` over the real archive with `pub fault: Cell<ArchiveFault>` and
  `pub reject_trash: Cell<bool>`, `ArchiveFault::{None, NoSpaceAfterCreate, FileSync, DirectorySync}`.

- [ ] **Step 1: Write the failing tests**

Append to `crates/vpt-adapters/tests/support/fakes.rs`:

```rust
use vpt_adapters::{ClonefileArchive, STAGING_PREFIX};
use vpt_application::ports::{Archive, ArchiveError, Published, StageFailure, Staged};
use vpt_domain::digest::Sha256Digest;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ArchiveFault {
    None,
    NoSpaceAfterCreate,
    FileSync,
    DirectorySync,
}

pub struct FaultyArchive<'a> {
    inner: &'a ClonefileArchive,
    pub fault: Cell<ArchiveFault>,
    pub reject_trash: Cell<bool>,
}

impl<'a> FaultyArchive<'a> {
    pub fn new(inner: &'a ClonefileArchive) -> FaultyArchive<'a> {
        FaultyArchive { inner, fault: Cell::new(ArchiveFault::None), reject_trash: Cell::new(false) }
    }
}

impl Archive for FaultyArchive<'_> {
    type Handle = File;

    fn stage<C>(&self, clone: C) -> Result<Staged, StageFailure>
    where
        C: FnOnce(&Path, (u64, u64), &str) -> Result<CloneKind, CloneError>,
    {
        if self.fault.get() != ArchiveFault::NoSpaceAfterCreate {
            return self.inner.stage(clone);
        }
        let path = self.inner.target(&format!("{STAGING_PREFIX}{}-fault.m4a", std::process::id()));
        let mut partial = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&path).expect("partial staging");
        partial.write_all(b"partial").expect("partial bytes");
        Err(StageFailure { cause: ArchiveError::NoSpace, owned_staging: Some(path) })
    }

    fn open(&self, path: &Path) -> Result<File, ArchiveError> {
        self.inner.open(path)
    }

    fn size(&self, handle: &File) -> Result<u64, ArchiveError> {
        self.inner.size(handle)
    }

    fn read_at(&self, handle: &File, offset: u64, buf: &mut [u8]) -> Result<(), ReadFailure> {
        self.inner.read_at(handle, offset, buf)
    }

    fn digest(&self, path: &Path) -> Result<Sha256Digest, ArchiveError> {
        self.inner.digest(path)
    }

    fn validate_trash_path(&self, path: &Path) -> Result<(), ArchiveError> {
        if self.reject_trash.get() { return Err(ArchiveError::Escape(path.to_path_buf())); }
        self.inner.validate_trash_path(path)
    }

    fn target(&self, name: &str) -> std::path::PathBuf {
        self.inner.target(name)
    }

    fn archived(&self) -> Result<Vec<std::path::PathBuf>, ArchiveError> {
        self.inner.archived()
    }

    fn staged_leftovers(&self) -> Result<Vec<std::path::PathBuf>, ArchiveError> {
        self.inner.staged_leftovers()
    }

    fn publish(&self, staged: &Path, target_name: &str) -> Result<Published, ArchiveError> {
        match self.fault.get() {
            ArchiveFault::FileSync => Err(ArchiveError::Sync("staged file".into())),
            ArchiveFault::DirectorySync => {
                self.inner.publish(staged, target_name)?;
                Err(ArchiveError::PlacedUnsynced(self.inner.target(target_name)))
            }
            ArchiveFault::None | ArchiveFault::NoSpaceAfterCreate => self.inner.publish(staged, target_name),
        }
    }

    fn sync_existing(&self, path: &Path) -> Result<(), ArchiveError> {
        self.inner.sync_existing(path)
    }
}
```

`crates/vpt-adapters/tests/ingest_duplicates.rs`:

```rust
mod support;

use std::os::unix::fs::PermissionsExt;
use support::fakes::{ArchiveFault, CloneBehaviour, FaultyArchive, ProbeStore};
use support::{CAPTURED, Fixture, Parts};
use vpt_application::ports::{Archive, RecordingLedger};
use vpt_application::{Ingest, IngestError, IngestFailure, IngestReport, Mode};
use vpt_domain::fixtures::m4a;
use vpt_domain::notification::EventKind;

fn lose_the_ledger(fixture: &Fixture) {
    for name in ["vpt.db", "vpt.db-wal", "vpt.db-shm"] {
        let _ = std::fs::remove_file(fixture.state.join(name));
    }
}

fn with_archive(parts: &Parts, archive: &FaultyArchive<'_>) -> Result<IngestReport, Box<IngestError>> {
    let ingest = Ingest {
        recorder: &parts.store,
        archive,
        ledger: &parts.ledger,
        clock: &parts.clock,
        trash: &parts.trash,
        notifier: &parts.notifier,
        settings: &parts.settings,
    };
    ingest.run(&Mode::default())
}

#[test]
fn the_same_bytes_at_a_second_path_are_one_recording_whose_source_path_moves() {
    let fixture = Fixture::new();
    fixture.add_recording("first.m4a", &m4a(CAPTURED, 1, b"same"));
    let parts = fixture.parts();
    parts.ingest().run(&Mode::default()).expect("first");
    std::fs::rename(fixture.recordings.join("first.m4a"), fixture.recordings.join("renamed.m4a")).expect("rename");

    let report = parts.ingest().run(&Mode::default()).expect("second");

    assert_eq!(report.already_ingested.len(), 1);
    assert!(report.ingested.is_empty());
    let record = parts.ledger.recordings().expect("list").remove(0);
    assert_eq!(record.source_path, Some(fixture.recordings.join("renamed.m4a")));
    assert_eq!(parts.archive.archived().expect("archived").len(), 1);
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert_eq!(parts.trash.moved.borrow().len(), 1, "the staged duplicate went to the Trash");
    assert!(parts.events().is_empty());
}

#[test]
fn an_archive_without_a_ledger_row_is_recovered_on_publish_and_reported_as_already_ingested() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"orphan"));
    let first = fixture.parts().ingest().run(&Mode::default()).expect("first");
    let id = first.ingested[0].id.clone();
    lose_the_ledger(&fixture);
    let parts = fixture.parts();

    let report = parts.ingest().run(&Mode::default()).expect("second");

    assert!(report.already_ingested.contains(&id) || report.recovered.contains(&id), "{report:?}");
    assert!(parts.ledger.by_id(&id).expect("read").is_some());
    assert_eq!(parts.archive.archived().expect("archived").len(), 1);
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
}

#[test]
fn a_target_with_different_bytes_is_an_archive_collision_and_nothing_is_replaced() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"real"));
    let first = fixture.parts().ingest().run(&Mode::default()).expect("first");
    let record = first.ingested[0].clone();
    std::fs::write(&record.audio_path, b"tampered").expect("tamper the archive in the test only");
    lose_the_ledger(&fixture);
    let parts = fixture.parts();

    let error = parts.ingest().run(&Mode::default()).unwrap_err();

    assert!(matches!(error.failure, IngestFailure::ArchiveCollision { .. }), "{error:?}");
    assert_eq!(std::fs::read(&record.audio_path).expect("read"), b"tampered");
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert_eq!(parts.trash.moved.borrow().len(), 1);
    assert!(parts.ledger.recordings().expect("list").is_empty());
    assert_eq!(parts.events(), vec![EventKind::IngestFailed]);
}

#[test]
fn exdev_uses_bounded_copy() {
    let fixture = Fixture::new();
    let bytes = m4a(CAPTURED, 1, b"other volume");
    fixture.add_recording("a.m4a", &bytes);
    let parts = fixture.parts();
    let probe = ProbeStore::new(&parts.store);
    probe.clone.set(CloneBehaviour::ByteCopy);
    let ingest = Ingest {
        recorder: &probe,
        archive: &parts.archive,
        ledger: &parts.ledger,
        clock: &parts.clock,
        trash: &parts.trash,
        notifier: &parts.notifier,
        settings: &parts.settings,
    };

    let report = ingest.run(&Mode::default()).expect("sweep");

    assert_eq!(report.ingested.len(), 1);
    let record = &report.ingested[0];
    assert_eq!(std::fs::read(&record.audio_path).expect("archive"), bytes);
    assert_eq!(std::fs::metadata(&record.audio_path).expect("meta").permissions().mode() & 0o777, 0o600);
    assert!(report.log.iter().any(|line| line.contains("not copy-on-write")), "{:?}", report.log);
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert!(parts.events().is_empty());
}

#[test]
fn enospc_aborts_without_row() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    let parts = fixture.parts();
    let archive = FaultyArchive::new(&parts.archive);
    archive.fault.set(ArchiveFault::NoSpaceAfterCreate);

    let error = with_archive(&parts, &archive).unwrap_err();

    assert_eq!(error.failure, IngestFailure::NoSpace);
    assert!(parts.ledger.recordings().expect("list").is_empty());
    assert_eq!(parts.trash.moved.borrow().len(), 1, "the partial staging this run created was trashed");
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert_eq!(parts.events(), vec![EventKind::IngestFailed]);
}

#[test]
fn stage_sync_failure_commits_no_row() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    let parts = fixture.parts();
    let archive = FaultyArchive::new(&parts.archive);
    archive.fault.set(ArchiveFault::FileSync);

    let error = with_archive(&parts, &archive).unwrap_err();

    assert_eq!(error.failure, IngestFailure::Sync("staged file".into()));
    assert!(parts.ledger.recordings().expect("list").is_empty());
    assert!(parts.archive.archived().expect("archived").is_empty());
    assert_eq!(parts.trash.moved.borrow().len(), 1);
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert_eq!(parts.events(), vec![EventKind::IngestFailed]);
}

#[test]
fn directory_sync_failure_commits_no_row() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    let parts = fixture.parts();
    let archive = FaultyArchive::new(&parts.archive);
    archive.fault.set(ArchiveFault::DirectorySync);

    let error = with_archive(&parts, &archive).unwrap_err();

    assert!(matches!(error.failure, IngestFailure::Sync(_)), "{error:?}");
    assert!(parts.ledger.recordings().expect("list").is_empty());
    assert_eq!(parts.archive.archived().expect("archived").len(), 1, "the placed file stays for recovery");
    assert!(parts.trash.moved.borrow().is_empty());
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert_eq!(parts.events(), vec![EventKind::IngestFailed]);
}
#[test]
fn a_known_digest_keeps_its_identity_when_the_new_zone_cannot_form_an_id() {
    let fixture = Fixture::new();
    let mut bytes = vpt_domain::fixtures::box_of(b"ftyp", b"M4A ");
    bytes.extend(vpt_domain::fixtures::box_of(b"mdat", b"audio"));
    bytes.extend(vpt_domain::fixtures::box_of(b"moov", &vpt_domain::fixtures::mvhd_v1(253_402_300_800, 1)));
    let source = fixture.add_recording("first.m4a", &bytes);
    let mut parts = fixture.parts();
    parts.clock.offset = vpt_domain::time::UtcOffset { secs: -3_600 };
    let first = parts.ingest().run(&Mode::default()).expect("first");
    let id = first.ingested[0].id.clone();
    std::fs::rename(source, fixture.recordings.join("renamed.m4a")).expect("rename");
    parts.clock.offset = vpt_domain::time::UtcOffset { secs: 0 };
    let report = parts.ingest().run(&Mode::default()).expect("known bytes");
    assert_eq!(report.already_ingested, vec![id]);
    assert!(report.deferred.is_empty());
    assert_eq!(parts.ledger.recordings().expect("list").len(), 1);
}

#[test]
fn invalid_staging_is_never_sent_to_trash_when_archive_validation_refuses_it() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"whole source"));
    let parts = fixture.parts();
    let probe = ProbeStore::new(&parts.store);
    probe.clone.set(CloneBehaviour::Truncated);
    let archive = FaultyArchive::new(&parts.archive);
    archive.reject_trash.set(true);
    let error = Ingest {
        recorder: &probe, archive: &archive, ledger: &parts.ledger, clock: &parts.clock,
        trash: &parts.trash, notifier: &parts.notifier, settings: &parts.settings,
    }.run(&Mode::default()).expect_err("path refused");
    assert!(matches!(error.failure, IngestFailure::PathEscape(_)));
    assert!(parts.trash.moved.borrow().is_empty());
    assert_eq!(parts.archive.staged_leftovers().expect("staging").len(), 1);
}

```

The recovery and collision tests delete database files, which the spec forbids vpt itself from doing; the
test harness may, because it is simulating a lost ledger inside a temporary directory the test owns.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters --test ingest_duplicates`

Expected: the rename test FAILS (the sweep reports `Archive("... exists")` because the same bytes derive
the same identity); the recovery test FAILS the same way; the collision test FAILS because the failure is
`Archive`, not `ArchiveCollision`; the four fault tests PASS already on the Task 19 cleanup contract and
stay as regression guards.

- [ ] **Step 3: Write the minimal implementation**

In `crates/vpt-application/src/ingest/publish.rs`, remove the earlier `let offset` and `let Ok(id)` block
added by Task 20. Insert this complete block after the copy-on-write diagnostic and before
`archive.publish`; known digests return before any timezone-dependent identity derivation:

```rust
        let existing = self.owned(&staged.path, self.ledger.by_digest(&staged.digest).map_err(ledger_failure), report)?;
        if let Some(existing) = existing {
            return self.known_bytes(candidate, existing, &staged, seen, now, report);
        }
        let offset = self.clock.offset_at(container.creation_time);
        let Ok(id) = RecordingId::derive(container.creation_time, offset, &staged.digest) else {
            self.discard(&staged.path, report)?;
            return self.defer(candidate, seen, DeferralReason::InvalidContainer, now, mode, report);
        };
```

Replace the `Published::Exists` arm:

```rust
            Ok(Published::Exists(audio_path)) => {
                self.resolve_existing(candidate, id, container, offset, &staged, audio_path, seen, now, report)
            }
```

and add the two methods to the `impl` block:

```rust
    /// Known bytes at a new path: the recording keeps its identity, its
    /// source path follows, the staged duplicate goes to the Trash.
    fn known_bytes(
        &self,
        candidate: &Candidate,
        existing: RecordingRecord,
        staged: &Staged,
        seen: Option<SeenRow>,
        now: UtcInstant,
        report: &mut IngestReport,
    ) -> Result<(), IngestFailure> {
        if existing.source_path.as_deref() != Some(candidate.path.as_path()) {
            let moved = self.ledger.set_source_path(&existing.id, &candidate.path).map_err(ledger_failure);
            self.owned(&staged.path, moved, report)?;
            report.log.push(format!("{}: known bytes at a new path, source path updated", existing.id));
        }
        let row = ingested_seen(candidate, seen, &existing.id, now);
        self.owned(&staged.path, self.ledger.record_seen(&row).map_err(ledger_failure), report)?;
        self.discard(&staged.path, report)?;
        report.already_ingested.push(existing.id);
        Ok(())
    }

    /// `<id>.m4a` already exists: verify it byte for byte, sync it, recover
    /// any missing rows, trash the staged duplicate.
    #[allow(clippy::too_many_arguments)]
    fn resolve_existing(
        &self,
        candidate: &Candidate,
        id: RecordingId,
        container: Container,
        offset: UtcOffset,
        staged: &Staged,
        audio_path: PathBuf,
        seen: Option<SeenRow>,
        now: UtcInstant,
        report: &mut IngestReport,
    ) -> Result<(), IngestFailure> {
        let existing = self.owned(&staged.path, self.archive.digest(&audio_path).map_err(archive_failure), report)?;
        let valid = self.owned(&staged.path, self.inspect_archive(&audio_path), report)?.is_ok();
        if existing != staged.digest || !valid {
            self.discard(&staged.path, report)?;
            return Err(IngestFailure::ArchiveCollision { target: audio_path, staged: staged.digest, existing });
        }
        self.owned(&staged.path, self.archive.sync_existing(&audio_path).map_err(archive_failure), report)?;
        let known = self.owned(&staged.path, self.ledger.by_id(&id).map_err(ledger_failure), report)?;
        let row = ingested_seen(candidate, seen, &id, now);
        if known.is_none() {
            let (title, title_source) = lookup_title(self.recorder.title(&candidate.file_name));
            let record = RecordingRecord {
                id: id.clone(),
                source_path: Some(candidate.path.clone()),
                digest: staged.digest,
                captured_at: container.creation_time,
                captured_offset: offset,
                duration_secs: container.duration_secs,
                title,
                title_source,
                ingested_at: now,
                audio_path,
                stages: StageStates::fresh(),
                audio_trashed_at: None,
            };
            let batch = LedgerCommit { recordings: vec![record], seen: vec![row], publications: vec![] };
            self.owned(&staged.path, self.ledger.commit(&batch).map_err(ledger_failure), report)?;
            report.recovered.push(id.clone());
        } else {
            self.owned(&staged.path, self.ledger.record_seen(&row).map_err(ledger_failure), report)?;
        }
        self.discard(&staged.path, report)?;
        report.already_ingested.push(id);
        Ok(())
    }
```

with these imports added to `publish.rs`: `Staged` in the `crate::ports` list, `use std::path::PathBuf;`
(beside `Path`), and `use vpt_domain::time::UtcOffset;` beside `UtcInstant`.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters --test ingest_duplicates`

Expected: 9 duplicate and cleanup tests PASS. Run
`cargo clippy --workspace --all-targets --features dev-tools -- -D warnings` and expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(ingest): duplicates recover their rows and a collision refuses"
```

______________________________________________________________________

