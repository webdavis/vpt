# Task 6 fix round 1 review, c60a01c

Reviewer: /root/vpt_review_task_6, gpt-6-astra xhigh. Fix tree comparison 1170704cafefe388b241e807d4bdf442d1cfc40b to c60a01c9c165df7df7fcb6eb492e11921cb1035d. Read-only scoped review, no tests, live probes or mutations.

## Finding verdicts

- F1, existing config-parent chmod: ADDRESSED. config/write/directory.rs:60 checks an existing parent during preparation; line 68 rechecks before writing without chmod. Managed-directory repair remains at line 52. Regressions cover initial refusal, changed permissions and a shared parent appearing after preparation.
- F2, writable hard-link source alias: ADDRESSED. config/write.rs:78 checks opened-descriptor link count before chmod or truncation. The synthetic-source regression preserves bytes, permissions, link count and timestamps. This closes the reported alias case, without proving protection against concurrent link creation after the check.
- F3, inherited fixture environment: ADDRESSED. tests/harness.rs:167 clears inherited environment and installs sandbox values. The fixture records sentinel absence and owned HOME/PATH, which the test asserts. Removing env_clear is caught in task-6-review-1-fix-evidence.log:20.
- M1, JSON terminal output: ADDRESSED. tests/setup.rs:46 exercises real terminal success with --json, parses stdout as one result document and requires empty stderr. The prompt-to-stdout mutation fails JSON parsing, recorded in task-6-review-1-fix-evidence.log:23.

## Checks

- Checked contained/directory.rs:14 for the creation contract reused by F1: newly created directories receive 0700; existing directories open without permission repair.
- Read the fix diff once and preserved evidence. Five caught mutations have passing restored controls. task-6-review-1-final-ship.log:2 records exit 0 with the covering tests passing; release-build success is recorded in the fix evidence at line 34.

## Verdict

All findings addressed, no new Critical or Important breakage. No out-of-scope observations.
