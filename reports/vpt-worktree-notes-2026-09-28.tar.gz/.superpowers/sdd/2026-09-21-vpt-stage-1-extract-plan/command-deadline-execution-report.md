# Command watchdog follow-up execution report

Base: `c84df8aba6f1154e77b11f9aa7f107d9b39f0889`. The worktree has only the six VPT test fixture and acceptance files listed below as product changes. No commit, publication, installation, live destination probe, database edit or process-lifecycle redesign occurred. Main retains progress tracking and acceptance.

## Behavior

The command collector checks the 500 ms deadline before driving or polling an already expired command, then checks it again before accepting a completed child and closed pipes. It retains the 900 ms absolute cleanup deadline and 50 ms termination grace. Normal parallel test execution remains enabled.

The normal timeout and post-loop one-second failure paths format a bounded record after owned cleanup. It gives offsets for actual caller-observed spawn return when supplied, completed polling phases, first child exit, actual pipe EOF, deadline detection and cleanup completion. It also gives child status, final pipe states, maximum between-poll gap, maximum active step, byte counts and at most 64 escaped source bytes per output prefix. A missing pipe has `eof=none`. Direct collectors without a spawn-return observation report `spawn_return=none`. Capture remains uncapped and unchanged; only formatting is bounded. A panic inside `ProcessGroup::drop` can still precede this record.

The owned terminal helper reports child status and bounded escaped terminal, stdout and stderr evidence when no prompt appears. The answer-timeout leaf now accepts only a panic whose leading label is `command exceeded 500 ms deadline:`. A version exit before a prompt and a shell emitting long control-byte output pin the other failure path. The fake-engine source did not change.

## Compiling RED and mutation evidence

All five initial focused REDs compiled before their fixes:

| Leaf | Captured RED |
| --- | --- |
| `late_completion_observed_after_deadline_is_rejected` | Existing completion-first collector returned `Output { status: ExitStatus(unix_wait_status(0)), stdout: "", stderr: "" }` at 501 ms. |
| `watchdog_timeout_reports_bounded_capture_and_phase` | Existing timeout panic was only `command exceeded 500 ms deadline`, without the record. |
| `setup_terminal_exit_before_prompt_reports_status_and_output` | Existing panic was `prompt not observed: ` without child status or captured output. |
| `setup_terminal_timeout_assertion_rejects_pre_prompt_exit` | Existing any-panic predicate classified an early version exit as a timeout. |
| `setup_terminal_missing_prompt_escapes_and_bounds_captured_bytes` | Existing panic emitted an unbounded raw terminal prefix and lacked byte-count fields. |

Two later boundary leaves have exact source-mutation REDs: a completion that crosses 500 ms inside a poll was accepted with completion-first ordering, and an absent stdout pipe was incorrectly timestamped as EOF when the piped-stream guard was removed. Both restored controls pass. Tests reap short children before inducing their expected failure. Live stdin-blocked direct children have an independent exact-group KILL and bounded waitpid backstop before assertions; the passing cleanup path proves `ESRCH` for the group and `ECHILD` for the direct child.

Each row below changed the named source bytes, compiled, failed its named leaf for the stated assertion, restored the exact prior SHA-256, and passed the same leaf as control. The RED and mutation observations were transcribed from this session's tool results, but their raw output was not retained on disk. The [evidence provenance](command-watchdog-evidence-provenance.md) identifies the original result chunks and distinguishes them from the exported final-gate output. The separate [full harness failure log](command-watchdog-harness-green-failure.log) preserves the naturally observed spawn delay.

| Source and mutation | Mutant SHA-256 | Restored SHA-256 | Named failure |
| --- | --- | --- | --- |
| `support/mod.rs`: remove pre-poll deadline guard | `411bdea40edfae0e881d639d91152e82aefd9a9c38692374bb2cea52ef4f15e1` | `14b8fbbeb565951807e11eda31dfcf68ddb21d52b561fe32153f70d58fa3cc0a` | Expired command drove the terminal. |
| `support/mod.rs`: accept completion before post-poll deadline | `c43526d741f29efc5fb4a50adb23b732c2cc34bbb7ff7c5771c5549c04587a89` | `14b8fbbeb565951807e11eda31dfcf68ddb21d52b561fe32153f70d58fa3cc0a` | Completed output returned after 501 ms. |
| `support/diagnostic.rs`: preview 65 source bytes | `4a04e5ebe643617b142d75cf02a7bac33c9ef070393170be102853fca6904007` | `7d3e8b6199ffdb6bc539f20f23fdb57672721390980581991328cfb59fbe3462` | The 64th repeated source byte appeared. |
| `support/diagnostic.rs`: raw control bytes | `13ee6cc9a75833c51031f0babc8555045ad9f3b8bf8dd7be28e8fb7596c1dc2a` | `7d3e8b6199ffdb6bc539f20f23fdb57672721390980581991328cfb59fbe3462` | Escaped prefix assertion failed. |
| `support/diagnostic.rs`: omit driver phase | `bccd3ef6f2746e89992839193e95966a0b4200bdbcf42d20446b50ac796acac0` | `7d3e8b6199ffdb6bc539f20f23fdb57672721390980581991328cfb59fbe3462` | Required `driver=` field missing. |
| `setup/terminal.rs`: omit child status | `5128ca9f39059b1ae6728517ef8a10eaf95871e378af98654b39a65bf309aae3` | `39edfc48e6ec8ea03bab5f7ea8093a0fd12a632d8e165e102d124655344c8cd2` | Pre-prompt leaf required `status=Some(0)`. |
| `setup/terminal.rs`: preview 65 source bytes | `852ab59be3d6c560b57e96d96930b9323a5ab75a562d8fc1ab6287f60a653d0c` | `39edfc48e6ec8ea03bab5f7ea8093a0fd12a632d8e165e102d124655344c8cd2` | The 64th repeated source byte appeared. |
| `setup/terminal.rs`: raw control bytes | `71a050d17ffcdb4879e669be84611a8d72a81002d8159c7d290fc89957e4ba3a` | `39edfc48e6ec8ea03bab5f7ea8093a0fd12a632d8e165e102d124655344c8cd2` | Escaped terminal prefix assertion failed. |
| `setup.rs`: route answer-timeout leaf to early version exit | `a5bb65fc106f34f5733c3f0e2439efdc07a438977804d6df0476d31ec284c783` | `9f5f2cc01298d1c4707c3485ad5c60921bc784813c6bbc782d97646e9cc38471` | Deadline classifier refused missing-prompt panic. |
| `support/mod.rs`: timestamp absent stdout as EOF | `50b5e398465758f3cbe8f2a23255b2e85e83783ab6fd5deb7a2ed57eda4065a5` | `4d4d4471267478e42deccaf9d14023eeb856a8d9620c832447c466307cc906fc` | Expected `stdout_eof=none`, observed an offset. |

## Gates and named leaves

Final stable `just ship` exited 0 with formatting, Clippy at `-D warnings`, workspace tests, documentation, history secret scan and file-size gate. It ran 325 passing named leaves. The accepted D4 baseline has 318 names; all 318 remain, and the seven new names are the four harness and three setup leaves above. A final installed VPT-local nightly run used command-local `RUSTUP_HOME` and `RUSTUP_AUTO_INSTALL=0` with `-Z unstable-options --report-time`. It exited 0 with the same 325 names; the slowest measured leaf was 0.574 s. The final all-target workspace check, default-feature release build, `git diff --check` and `gitleaks dir --redact --no-banner crates/vpt/tests` each exited 0. The working-tree scan found no leaks. No handwritten changed Rust file exceeds 300 physical lines.

During the first nine-leaf harness GREEN attempt, `runner_captures_output_and_exit_status` failed with `spawn_return=501.1675ms`, before any poll. `run` sampled `started` immediately before `spawn`, so the parent had not observed spawn return within the 500 ms budget. That record cannot separate operating-system spawn work from parent descheduling. Its [raw log](command-watchdog-harness-green-failure.log) and source hashes remain intact. Later normal-parallel green runs do not establish that this intermittent failure is impossible. The collector still cannot interrupt a blocked spawn, a long polling step or a descheduled thread; those are the documented bounds of this test fixture.

## Final source hashes and review state

| VPT path under `crates/vpt/tests/` | SHA-256 | Lines |
| --- | --- | ---: |
| `support/mod.rs` | `4d4d4471267478e42deccaf9d14023eeb856a8d9620c832447c466307cc906fc` | 184 |
| `support/diagnostic.rs` | `7d3e8b6199ffdb6bc539f20f23fdb57672721390980581991328cfb59fbe3462` | 130 |
| `harness.rs` | `6c283617043c957c8b606484b280b4a3e811c1a979b0252e2a173763321afd57` | 294 |
| `harness/deadline.rs` | `8468560f5b00156381e33ec8587df2106d0ce350c65efef73d151d1d9c9b370d` | 119 |
| `setup.rs` | `75133032199864c5cc101ef7e8ca4b8e7c753da31415b544f04a3b2674ac6e22` | 283 |
| `setup/terminal.rs` | `39edfc48e6ec8ea03bab5f7ea8093a0fd12a632d8e165e102d124655344c8cd2` | 120 |

The source is uncommitted and awaits the controller's independent review and acceptance. A committed-HEAD ship run belongs after that review and commit.
