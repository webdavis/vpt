# D7 command-integration addendum

## Controller execution constraints

- This is a cross-cutting addendum, not a standalone task. Integrate it into original Tasks 27, 28, 30, 31 and 32 after their actual prerequisites pass review. Do not introduce stub commands early to complete this checklist.
- Read each owning original task fully before preparing its execution brief. The controller has read this amendment, but this preparation is not evidence that the later command implementations or fixtures exist.
- Preserve the original command documents, error envelopes, streams and exit codes. Doctor remains an aggregate 18-check command, storage remains stores-only, and dry run opens no title database.
- Keep native fixture writers in separate owned child processes whenever a rooted connection could otherwise share the same inode in one process. Preserve WAL companions and close ordinary fixture writers before snapshots.
- Fault injection belongs to private adapter tests and typed composition tests, not production environment variables. Use only owned fixture paths; any native-fallback mutation must prove every filename and the child's working directory remain inside that fixture first.
- One product writer at a time. Main owns progress and Todoist. Use Astra for final high-risk cross-cutting review. Never retry the denied SQLite system-call override or broad process-list probes.
- Preserve compiling RED, all existing leaf names, unique mutant/control evidence and the existing command deadlines. Report any recurrence of 6hc7MMRc2QhRm75g without retry loops or loosening a deadline. Keep follow-up resolution separate from command behavior.
- Final acceptance requires fresh full gates and independent whole-branch review. Installation, live recordings, live notifications, push, pull request, merge, apply and destructive cleanup are not authorized.

## Approved amendment

## D7: Command integration and final evidence

Execute these steps with the owning original tasks, after their non-database prerequisites are ready. Do
not add stub commands early solely to finish this checklist.

**Files:** `crates/vpt/src/compose/ledger.rs`, `compose/runtime.rs`, `compose/observations.rs`,
`compose/errors.rs`, `compose/tests.rs`, `commands/ingest.rs`, `commands/show.rs`, `commands/list.rs`,
`commands/retention.rs`, `doctor/probes.rs`; existing command tests `crates/vpt/tests/ingest.rs`,
`show_list_storage.rs`, `doctor.rs`, `retention.rs` and `retention_startup.rs`; adapt the existing
`tests/support/mod.rs` only where a bounded fixture needs it.

**Interfaces:** Consume the unchanged ledger/recorder ports and D5/D6's typed adapters. Keep existing
command documents, refusal rule tokens, output streams and exit codes. Mutating commands alone acquire
the existing application `write.lock`; observations never acquire it.

Original Task 27's test-only `Sandbox::ledger() -> rusqlite::Connection` must preserve native WAL
companions too, or fixture updates would remove files that observation correctly requires. Before
returning that native fixture connection, call this private helper in the same test support file:

```rust
fn preserve_wal(connection: &rusqlite::Connection) {
    let mut enabled: std::ffi::c_int = 1;
    // SAFETY: the connection and integer remain valid throughout the call.
    let result = unsafe {
        rusqlite::ffi::sqlite3_file_control(
            connection.handle(), c"main".as_ptr(), rusqlite::ffi::SQLITE_FCNTL_PERSIST_WAL,
            (&mut enabled as *mut std::ffi::c_int).cast(),
        )
    };
    assert_eq!(result, rusqlite::ffi::SQLITE_OK);
}
```

Close fixture writers before snapshot comparisons. They may overlap a VPT command subprocess for the
explicit concurrency cases, but may not overlap a rooted connection in the fixture's own process.

- [ ] **Step 1: Add compiling command-level red regressions in the owning task.**

Use the existing `Sandbox` and bounded `run` helper. The acceptance table is the assertion contract:

Add this leaf to original Task 28's `show_list_storage.rs`. Its `ingested` fixture is defined in that
task. Extend `support::state_snapshot` to include entry kinds, device/inode, link count, size, ctime and
flags alongside its existing bytes, modes and mtime fields; exclude atime. Keep the snapshot code inside
the command crate's own test support.

```rust
#[test]
fn list_after_the_ingest_writer_exits_changes_no_state() {
    let (sandbox, id) = ingested("list-after-writer-exit");
    let before = support::state_snapshot(&sandbox);
    let output = run(sandbox.vpt().args(["list", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    assert!(output.stderr.is_empty());
    let result: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(result["command"], "list");
    assert_eq!(result["recordings"][0]["id"], id);
    assert_eq!(support::state_snapshot(&sandbox), before);
}
```

| Command scenario                                      | Assertions                                                                                                |
| ----------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `show`, `list`, `storage`, read-only `doctor`         | Existing command result/verdict; no state creation, permission repair or database metadata changes        |
| Ingest dry run                                        | No title database open/refresh; no ledger or source writes                                                |
| `show`/`list` with populated ledger missing companion | Exit 1, empty stdout in JSON mode, safe error on stderr; unchanged tree                                   |
| Root/companion containment refusal                    | Exit 3, `path_escape` rule, empty JSON stdout, unchanged replacement/source tree                          |
| Another process holds a database write transaction    | Observations still read committed state where SQLite permits; mutating contention remains bounded         |
| Another command holds application `write.lock`        | Read-only commands never wait on that application lock                                                    |
| Failed storage/sync/constraint/corruption operation   | Distinct ledger classification reaches the established exit-1 error document without titles or row values |
| Retention repositories                                | In-memory and durable implementations pass the same contract before command acceptance                    |

Preserve doctor's aggregate contract: it runs all 18 checks and reports failures with exit 3 and
`doctor_checks`. A ledger containment or storage error must appear in the relevant check without turning
doctor into an early-exit ledger command. Storage remains stores-only and never opens a ledger. For
errors that need D3/D4's private fault injection, command composition unit tests feed the resulting typed
`LedgerError` through the existing converter and emitter; do not add production environment variables or
fault controls to the command binary. Add tests to the command suite using the original task's concrete
fixture builders and assertions. For JSON refusals, preserve the already implemented `vpt.error/1` parser
and assert the whole envelope, not a substring of human text. Reuse D4's native child pattern when a
second process must hold a SQLite transaction; a test may not keep a native and rooted connection on the
same inode in one process.

- [ ] **Step 2: Run each new named test red before routing changes.**

```bash
cargo test --locked -p vpt --features dev-tools --test show_list_storage
cargo test --locked -p vpt --features dev-tools --test doctor
cargo test --locked -p vpt --features dev-tools --test ingest
cargo test --locked -p vpt --features dev-tools --test retention
cargo test --locked -p vpt --features dev-tools --test retention_startup
```

Run only test targets already introduced by their original task. Record the exact discovered leaf and its
intended failed assertion; a missing target is not red evidence.

- [ ] **Step 3: Route composition through the strengthened adapter.**

```text
mutating runtime -> checked state -> application write.lock -> SqliteLedger::open
observational runtime -> SqliteLedger::open_read_only -> durable or empty memory ledger
title refresh -> checked private state -> TitleCopy::refresh_at
existing title observation -> typed TitleCopy::existing result
dry-run runtime -> no title-copy opener
```

Remove every production native database opener outside `database/owner.rs`. Keep native fixture opens
only under test configuration. Adapt actual `TitleCopy` result callers explicitly; do not introduce
title-database work into doctor or dry run. Containment becomes `path_escape` where a command reports the
operation, optional title unavailability remains optional, and doctor keeps its aggregate check contract.
No command should derive a writable path from `database_path()`.

- [ ] **Step 4: Verify green and the full Stage 1 gates.**

Run each command target and the shared ledger contracts. Mutate the common observation composition to
writable and the shared error conversion to exit 1 for containment. The acceptance tests must fail;
restore controls. Search all production connection construction and descriptor/path operations for a
missed route. This source inspection supplements the tests, it does not replace them.

```bash
just test-rust
just lint-check
just ship
cargo check --locked --workspace --all-targets --features dev-tools
```

Measure every new test leaf under the workspace run, including parallel contention. Every leaf must
finish below one second. Run the clean-code Rust file-size command after staging owned files so new files
are included, and verify the command entry point is below 150 lines. Do not claim an installed binary,
live Voice Memos processing or notifications from these sandboxed tests.

- [ ] **Step 5: Commit with the owning command tasks and request whole-branch review.**

Keep logically distinct original tasks in separate commits. Request the established independent
whole-branch review with explicit attention to callback storage lifetime, shared-memory initialization,
native lock interoperability, read-only snapshots, source isolation and failure cleanup. Supply red,
green, mutation/control, timing and full-gate evidence. Resolve findings and rerun affected tests before
calling the Stage 1 build complete. No push, pull request or installation is part of this plan.

## Acceptance coverage and plan self-review

| Approved requirement                                           | Implementation and evidence                                      |
| -------------------------------------------------------------- | ---------------------------------------------------------------- |
| Root and ancestor replacement; all companions and cleanup      | D1 checked operations, D3 callback route and lifetime tests      |
| Exact names/roles, no attachment or disk temporary fallback    | D1 policy, D3 filename/authorizer tests                          |
| Private permissions, no-follow/type/link checks                | D1 descriptor tests, D6 exclusive refresh checks                 |
| Stable registration, failed open, busy close, no unwind        | D3 owner and supervised callback/lifetime tests                  |
| Database locks, native interoperability, independent close     | D2 lock transitions and D4 separate-process WAL tests            |
| Shared-memory initialization, barrier, mapping and recovery    | D4 protocol and read-only/recovery leaves                        |
| Write/sync/crash failures and durability                       | D3 error propagation, D4 failure injection and crash recovery    |
| Four access policies, five-second production timeout           | D1 policy table, D5 ledger, D6 title integration                 |
| Absent/zero-schema state; populated missing companions         | D5 empty-state and observational snapshot tests                  |
| Source read-only, WAL-only title, dry run, title refresh lease | D6 title/source snapshots and D7 command acceptance              |
| Typed containment, distinct ledger errors, safe diagnostics    | D3 local latch, D5 mapping, D7 output/exit assertions            |
| Existing application contracts and schema                      | D5 original migration contract, Tasks 12/31 shared contract      |
| Test-first, mutations, bounded children, file sizes and review | Every task's red/green/control steps, D2 watchdog, D7 full gates |

Before handing this plan to the operator, the controller checks every spec section against this table,
scans for placeholders, checks signatures across tasks and verifies all five Review Focus cases have
owning tests. The plan is not runtime evidence. Product implementation waits for the operator's plan
review, then resumes with the existing implementer/reviewer workflow.
