### Task 17: The archive: staging clones and digests

The archive holds the `audio` store as a root descriptor. Staging is the archive's operation: it chooses
a private name below its root and hands the root's path, device/inode identity and that name to a clone
closure the use case builds from the recorder port, so the archive port never names the recorder's handle
type and neither port names a file type. A staging failure says whether this invocation created the
staged file, because every ingest exit before publication trashes what it owns and nothing else.

**Files:**

- Create: `crates/vpt-adapters/src/archive/tests.rs`

- Create: `crates/vpt-application/src/ports/archive.rs`

- Modify: `crates/vpt-application/src/ports/mod.rs`

- Create: `crates/vpt-adapters/src/archive/mod.rs`

- Modify: `crates/vpt-adapters/src/lib.rs`

**Interfaces:**

- Consumes: `CloneKind`, `CloneError`, `vpt_domain::container::ReadFailure`, `vpt_adapters::digest_open`,
  `vpt_adapters::{Access, ContainedError, Kind, RootDir}`.

- Produces, in `vpt_application::ports` (from the private file `ports/archive.rs`):
  `Staged { pub path: PathBuf, pub digest: Sha256Digest, pub size: u64, pub copy_on_write: bool }`;
  `ArchiveError::{NoSpace, Sync(String), PlacedUnsynced(PathBuf), Escape(PathBuf), Io(String)}`
  (`PlacedUnsynced` is Task 18's directory sync failing after the target was placed: no row is recorded
  and the next sweep recovers the file);
  `StageFailure { pub cause: ArchiveError, pub owned_staging: Option<PathBuf> }` (`owned_staging` is set
  only when this invocation created the staged file; a name that was already taken is never claimed);
  `trait Archive { type Handle; fn stage<C>(&self, clone: C) -> Result<Staged, StageFailure>`
  `where C: FnOnce(&Path, (u64, u64), &str) -> Result<CloneKind, CloneError>;`
  `fn open(&self, path: &Path) -> Result<Self::Handle, ArchiveError>;`
  `fn size(&self, handle: &Self::Handle) -> Result<u64, ArchiveError>;`
  `fn read_at(&self, handle: &Self::Handle, offset: u64, buf: &mut [u8]) -> Result<(), ReadFailure>;`
  `fn validate_trash_path(&self, path: &Path) -> Result<(), ArchiveError>;`
  `fn digest(&self, path: &Path) -> Result<Sha256Digest, ArchiveError>; fn target(&self, name: &str)`
  `-> PathBuf; fn archived(&self) -> Result<Vec<PathBuf>, ArchiveError>;`
  `fn staged_leftovers(&self) -> Result<Vec<PathBuf>, ArchiveError>; }` (Task 18 adds `publish` and
  `sync_existing`); `vpt_adapters::{ClonefileArchive, STAGING_PREFIX}` with
  `ClonefileArchive::open(audio_store: &Path) -> Result<ClonefileArchive, ContainedError>`,
  `ClonefileArchive::open_read_only(audio_store: &Path) -> Result<ClonefileArchive, ContainedError>` (an
  absent root yields empty listings and stays absent), `type Handle = std::fs::File`,
  `STAGING_PREFIX: &str = ".vpt-staging-"`.

- [ ] **Step 1: Write the failing tests**

Declare first: `crates/vpt-application/src/ports/mod.rs` gains `mod archive;` and
`pub use archive::{Archive, ArchiveError, StageFailure, Staged};`; `crates/vpt-adapters/src/lib.rs` gains
`mod archive;` and `pub use archive::{ClonefileArchive, STAGING_PREFIX};`.
`crates/vpt-adapters/src/archive/mod.rs` starts with the registered test child below. Create the child
before the red run:

```rust
#[cfg(test)]
mod tests;
```

`crates/vpt-adapters/src/archive/tests.rs`:

```rust
use super::*;
use crate::voice_memos::VoiceMemosStore;
use std::os::unix::fs::PermissionsExt;
use std::path::PathBuf;
use vpt_application::ports::{CloneError, RecorderStore};
use vpt_domain::container::inspect;
use vpt_domain::fixtures::m4a;

fn source(bytes: &[u8]) -> (tempfile::TempDir, PathBuf, VoiceMemosStore, File) {
    let temp = tempfile::tempdir().expect("temp");
    let base = temp.path().canonicalize().expect("canonical");
    std::fs::create_dir_all(base.join("Recordings")).expect("recordings");
    std::fs::create_dir_all(base.join("audio")).expect("audio");
    std::fs::write(base.join("Recordings/a.m4a"), bytes).expect("fixture");
    let store = VoiceMemosStore::open(&base.join("Recordings")).expect("store");
    let handle = store.open(&base.join("Recordings/a.m4a")).expect("open");
    (temp, base.join("audio"), store, handle)
}

#[test]
fn staging_produces_a_0600_private_copy_with_the_bytes_digest_and_size() {
    let bytes = m4a(1_787_604_456, 5, b"payload");
    let (_temp, audio, store, handle) = source(&bytes);
    let archive = ClonefileArchive::open(&audio).expect("archive");

    let staged = archive.stage(|directory, directory_identity, name| store.clone_into(&handle, directory, directory_identity, name)).expect("staged");

    assert_eq!(staged.path.parent(), Some(audio.as_path()));
    assert!(staged.path.file_name().expect("name").to_string_lossy().starts_with(STAGING_PREFIX));
    assert_eq!(std::fs::read(&staged.path).expect("read"), bytes);
    assert_eq!(std::fs::metadata(&staged.path).expect("meta").permissions().mode() & 0o777, 0o600);
    assert_eq!(staged.size, bytes.len() as u64);
    assert_eq!(archive.digest(&staged.path).expect("digest"), staged.digest);
    assert!(staged.copy_on_write);
}

#[test]
fn a_staged_file_can_be_opened_for_the_wholeness_gate() {
    let (_temp, audio, store, handle) = source(&m4a(1_787_604_456, 5, b"payload"));
    let archive = ClonefileArchive::open(&audio).expect("archive");
    let staged = archive.stage(|directory, directory_identity, name| store.clone_into(&handle, directory, directory_identity, name)).expect("staged");
    let opened = archive.open(&staged.path).expect("open");
    let len = archive.size(&opened).expect("size");
    let container = inspect(len, |offset, buf: &mut [u8]| archive.read_at(&opened, offset, buf)).expect("whole");
    assert_eq!(container.duration_secs, 5);
}

#[test]
fn a_clone_that_created_nothing_owns_no_staging_name() {
    let (_temp, audio, _store, _handle) = source(b"x");
    let archive = ClonefileArchive::open(&audio).expect("archive");
    let failure = archive.stage(|_directory, _directory_identity, _name| Err(CloneError::Io("boom".into()))).unwrap_err();
    assert_eq!(failure.cause, ArchiveError::Io("boom".into()));
    assert_eq!(failure.owned_staging, None);
    assert!(archive.staged_leftovers().expect("list").is_empty());
}

#[test]
fn a_failure_after_the_file_was_created_owns_it_at_mode_0600() {
    let (_temp, audio, _store, _handle) = source(b"x");
    let archive = ClonefileArchive::open(&audio).expect("archive");
    let failure = archive
        .stage(|directory, _directory_identity, name| {
            std::fs::write(directory.join(name), b"partial").expect("partial");
            Err(CloneError::NoSpace)
        })
        .unwrap_err();
    assert_eq!(failure.cause, ArchiveError::NoSpace);
    let owned = failure.owned_staging.expect("owned");
    assert_eq!(owned.parent(), Some(audio.as_path()));
    assert_eq!(std::fs::metadata(&owned).expect("kept").permissions().mode() & 0o777, 0o600);
    assert_eq!(archive.staged_leftovers().expect("list"), vec![owned]);
}

#[test]
fn a_name_that_was_already_taken_is_never_claimed() {
    let (_temp, audio, _store, _handle) = source(b"x");
    let archive = ClonefileArchive::open(&audio).expect("archive");
    let failure = archive
        .stage(|directory, _directory_identity, name| {
            std::fs::write(directory.join(name), b"someone else's").expect("collision");
            Err(CloneError::Exists)
        })
        .unwrap_err();
    assert_eq!(failure.owned_staging, None);
    assert!(matches!(failure.cause, ArchiveError::Io(_)), "{:?}", failure.cause);
}

#[test]
fn archived_lists_only_m4a_files_and_leftovers_only_staging_names() {
    let (_temp, audio, _store, _handle) = source(b"x");
    std::fs::write(audio.join("2026-08-24T144736-4f3ab19c02de.m4a"), b"x").expect("archived");
    std::fs::write(audio.join(format!("{STAGING_PREFIX}123.m4a")), b"y").expect("leftover");
    std::fs::write(audio.join("notes.txt"), b"z").expect("other");
    std::os::unix::fs::symlink(audio.join("notes.txt"), audio.join("link.m4a")).expect("link");
    let archive = ClonefileArchive::open(&audio).expect("archive");
    assert_eq!(archive.archived().expect("list"), vec![audio.join("2026-08-24T144736-4f3ab19c02de.m4a")]);
    assert_eq!(archive.staged_leftovers().expect("list"), vec![audio.join(format!("{STAGING_PREFIX}123.m4a"))]);
    assert_eq!(archive.target("abc.m4a"), audio.join("abc.m4a"));
}

#[test]
fn open_and_digest_refuse_a_link_and_a_path_outside_the_store() {
    let (temp, audio, _store, _handle) = source(b"x");
    std::fs::write(audio.join("real.m4a"), b"x").expect("real");
    std::os::unix::fs::symlink(audio.join("real.m4a"), audio.join("link.m4a")).expect("link");
    let archive = ClonefileArchive::open(&audio).expect("archive");
    assert_eq!(archive.open(&audio.join("link.m4a")).err(), Some(ArchiveError::Escape(audio.join("link.m4a"))));
    let outside = temp.path().canonicalize().expect("canonical").join("Recordings/a.m4a");
    assert_eq!(archive.digest(&outside), Err(ArchiveError::Escape(outside)));
    let absent = archive.open(&audio.join("absent.m4a"));
    assert!(matches!(absent, Err(ArchiveError::Io(_))), "{absent:?}");
}

#[test]
fn reading_an_absent_archive_lists_nothing_and_never_creates_it() {
    let temp = tempfile::tempdir().expect("temp");
    let audio = temp.path().canonicalize().expect("canonical").join("audio");
    let archive = ClonefileArchive::open_read_only(&audio).expect("read only");
    assert!(archive.archived().expect("archives").is_empty());
    assert!(archive.staged_leftovers().expect("staging").is_empty());
    assert_eq!(archive.target("id.m4a"), audio.join("id.m4a"));
    let result = archive.stage(|_, _, _| panic!("an absent root cannot stage"));
    assert!(result.is_err());
    assert!(!audio.exists());
}
#[test]
fn a_root_replaced_during_staging_never_returns_a_cleanup_path() {
    let (_temp, audio, store, handle) = source(b"audio");
    let archive = ClonefileArchive::open(&audio).expect("archive");
    let saved = audio.with_extension("saved");
    let failure = archive.stage(|directory, identity, name| {
        let kind = store.clone_into(&handle, directory, identity, name)?;
        std::fs::rename(&audio, &saved).expect("move root");
        std::fs::create_dir(&audio).expect("replacement");
        std::fs::write(audio.join(name), b"unowned replacement").expect("unowned");
        Ok(kind)
    }).expect_err("root changed");
    assert_eq!(failure.cause, ArchiveError::Escape(audio.clone()));
    assert_eq!(failure.owned_staging, None);
    assert_eq!(std::fs::read_dir(&saved).expect("saved").count(), 1);
    assert_eq!(std::fs::read_dir(&audio).expect("replacement").count(), 1);
}

#[test]
fn cleanup_validation_refuses_links_and_replaced_archive_roots() {
    let (_temp, audio, _store, _handle) = source(b"audio");
    let archive = ClonefileArchive::open(&audio).expect("archive");
    let path = audio.join(".vpt-staging-test.m4a");
    std::fs::write(audio.join("unowned.m4a"), b"kept").expect("unowned");
    std::os::unix::fs::symlink(audio.join("unowned.m4a"), &path).expect("link");
    assert_eq!(archive.validate_trash_path(&path), Err(ArchiveError::Escape(path.clone())));
    std::fs::rename(&audio, audio.with_extension("saved")).expect("move root");
    std::fs::create_dir(&audio).expect("replacement");
    std::fs::write(&path, b"replacement").expect("replacement file");
    assert_eq!(archive.validate_trash_path(&path), Err(ArchiveError::Escape(audio)));
    assert_eq!(std::fs::read(path).expect("untouched"), b"replacement");
}

```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters archive`

Expected: the build fails with `unresolved import` for the archive names in `ports/mod.rs` and
`cannot find` for `ClonefileArchive` and `STAGING_PREFIX`.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-application/src/ports/archive.rs`:

```rust
//! The audio archive: staging below its root, bounded reads, digests, and
//! (from Task 18) exclusive publication.

use super::recorder::{CloneError, CloneKind};
use std::path::{Path, PathBuf};
use vpt_domain::container::ReadFailure;
use vpt_domain::digest::Sha256Digest;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Staged {
    pub path: PathBuf,
    pub digest: Sha256Digest,
    pub size: u64,
    pub copy_on_write: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ArchiveError {
    NoSpace,
    Sync(String),
    /// The target was placed and then its directory failed to sync: nothing is
    /// staged any more, no row is recorded, the next sweep recovers the file.
    PlacedUnsynced(PathBuf),
    /// Below no archive root, nested, or reached through a link: exit 3, `path_escape`.
    Escape(PathBuf),
    Io(String),
}

/// A staging failure, with the staged name when this invocation created it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StageFailure {
    pub cause: ArchiveError,
    pub owned_staging: Option<PathBuf>,
}

pub trait Archive {
    /// The open read-only descriptor of one archive file.
    type Handle;

    /// Stage into a private name below the root: `clone` receives the root's
    /// path and the name and clones the source there.
    fn stage<C>(&self, clone: C) -> Result<Staged, StageFailure>
    where
        C: FnOnce(&Path, (u64, u64), &str) -> Result<CloneKind, CloneError>;
    fn open(&self, path: &Path) -> Result<Self::Handle, ArchiveError>;
    fn size(&self, handle: &Self::Handle) -> Result<u64, ArchiveError>;
    /// Fill `buf` from `offset`, or fail; the wholeness gate's read callback.
    fn read_at(&self, handle: &Self::Handle, offset: u64, buf: &mut [u8]) -> Result<(), ReadFailure>;
    fn digest(&self, path: &Path) -> Result<Sha256Digest, ArchiveError>;
    fn validate_trash_path(&self, path: &Path) -> Result<(), ArchiveError>;
    fn target(&self, name: &str) -> PathBuf;
    fn archived(&self) -> Result<Vec<PathBuf>, ArchiveError>;
    fn staged_leftovers(&self) -> Result<Vec<PathBuf>, ArchiveError>;
}
```

`crates/vpt-adapters/src/archive/mod.rs`, above its test module:

```rust
//! The archive on disk: staging from the source descriptor into a private
//! name below the `audio` root, digests in 64 KiB buffers.

use crate::contained::{Access, ContainedError, Kind, RootDir};
use crate::stores::digest_open;
use std::fs::File;
use std::os::unix::fs::{FileExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use vpt_application::ports::{Archive, ArchiveError, CloneError, CloneKind, StageFailure, Staged};
use vpt_domain::container::ReadFailure;
use vpt_domain::digest::Sha256Digest;

pub const STAGING_PREFIX: &str = ".vpt-staging-";

pub struct ClonefileArchive {
    directory: PathBuf,
    root: Option<RootDir>,
    sequence: AtomicU64,
}

pub(crate) fn io(error: &std::io::Error) -> ArchiveError {
    if error.kind() == std::io::ErrorKind::StorageFull { ArchiveError::NoSpace } else { ArchiveError::Io(error.kind().to_string()) }
}

pub(crate) fn archive_error(path: &Path, error: ContainedError) -> ArchiveError {
    match error {
        ContainedError::Io { kind: std::io::ErrorKind::StorageFull, .. } => ArchiveError::NoSpace,
        ContainedError::Io { kind, .. } => ArchiveError::Io(kind.to_string()),
        ContainedError::Escape { .. } | ContainedError::NotRegular(_) | ContainedError::NotADirectory(_) => {
            ArchiveError::Escape(path.to_path_buf())
        }
    }
}

fn clone_error(error: CloneError) -> ArchiveError {
    match error {
        CloneError::NoSpace => ArchiveError::NoSpace,
        CloneError::Exists => ArchiveError::Io("staging name already exists".into()),
        CloneError::Escape(path) => ArchiveError::Escape(path),
        CloneError::Io(detail) => ArchiveError::Io(detail),
    }
}

impl ClonefileArchive {
    pub fn open(audio_store: &Path) -> Result<ClonefileArchive, ContainedError> {
        Ok(ClonefileArchive { directory: audio_store.to_path_buf(), root: Some(RootDir::open(audio_store)?), sequence: AtomicU64::new(0) })
    }

    pub fn open_read_only(audio_store: &Path) -> Result<ClonefileArchive, ContainedError> {
        match Self::open(audio_store) {
            Ok(archive) => Ok(archive),
            Err(ContainedError::Io { kind: std::io::ErrorKind::NotFound, .. }) => {
                Ok(ClonefileArchive { directory: audio_store.to_path_buf(), root: None, sequence: AtomicU64::new(0) })
            }
            Err(error) => Err(error),
        }
    }

    fn root(&self) -> Result<&RootDir, ArchiveError> {
        let root = self.root.as_ref().ok_or_else(|| ArchiveError::Io("the audio store is absent".into()))?;
        root.revalidate().map_err(|_| ArchiveError::Escape(self.directory.clone()))?;
        Ok(root)
    }

    fn staging_name(&self) -> String {
        format!("{STAGING_PREFIX}{}-{}.m4a", std::process::id(), self.sequence.fetch_add(1, Ordering::Relaxed))
    }

    /// Mode 0600, digest and size of a file this invocation just staged.
    fn finish(&self, name: &str, kind: CloneKind) -> Result<Staged, ArchiveError> {
        let root = self.root()?;
        let path = root.path().join(name);
        let mut file = root.open_file(Path::new(name), Access::Read).map_err(|error| archive_error(&path, error))?;
        file.set_permissions(std::fs::Permissions::from_mode(0o600)).map_err(|error| io(&error))?;
        let digest = digest_open(&mut file).map_err(|error| io(&error))?;
        let size = file.metadata().map_err(|error| io(&error))?.len();
        Ok(Staged { path, digest, size, copy_on_write: kind == CloneKind::CopyOnWrite })
    }

    /// A staged file this invocation created and cannot use: keep it private
    /// for the owned cleanup and report it.
    fn owned_failure(&self, name: &str, cause: ArchiveError) -> StageFailure {
        if let Some(root) = &self.root
            && let Ok(file) = root.open_file(Path::new(name), Access::Read) {
            let _ = file.set_permissions(std::fs::Permissions::from_mode(0o600));
        }
        StageFailure { cause, owned_staging: Some(self.directory.join(name)) }
    }

    fn list(&self, keep: impl Fn(&str) -> bool) -> Result<Vec<PathBuf>, ArchiveError> {
        let Some(root) = &self.root else { return Ok(Vec::new()); };
        let names = root.names().map_err(|error| archive_error(root.path(), error))?;
        let mut paths = Vec::new();
        for name in names.into_iter().filter(|name| keep(name)) {
            if matches!(root.stat(Path::new(&name)), Ok(stat) if stat.kind == Kind::File) {
                paths.push(root.path().join(name));
            }
        }
        Ok(paths)
    }
}

impl Archive for ClonefileArchive {
    type Handle = File;

    fn stage<C>(&self, clone: C) -> Result<Staged, StageFailure>
    where
        C: FnOnce(&Path, (u64, u64), &str) -> Result<CloneKind, CloneError>,
    {
        let root = self.root().map_err(|cause| StageFailure { cause, owned_staging: None })?;
        let lost_root = || StageFailure { cause: ArchiveError::Escape(root.path().to_path_buf()), owned_staging: None };
        let name = self.staging_name();
        let identity = root.identity().map_err(|error| StageFailure {
            cause: archive_error(root.path(), error), owned_staging: None,
        })?;
        let result = match clone(root.path(), identity, &name) {
            Ok(kind) => self.finish(&name, kind).map_err(|cause| self.owned_failure(&name, cause)),
            Err(CloneError::Exists) => Err(StageFailure { cause: clone_error(CloneError::Exists), owned_staging: None }),
            Err(error) => {
                let created = matches!(root.stat(Path::new(&name)), Ok(stat) if stat.kind == Kind::File);
                if created {
                    Err(self.owned_failure(&name, clone_error(error)))
                } else {
                    Err(StageFailure { cause: clone_error(error), owned_staging: None })
                }
            }
        };
        root.revalidate().map_err(|_| lost_root())?;
        result
    }

    fn open(&self, path: &Path) -> Result<File, ArchiveError> {
        self.root()?.open_file(path, Access::Read).map_err(|error| archive_error(path, error))
    }

    fn size(&self, handle: &File) -> Result<u64, ArchiveError> {
        handle.metadata().map(|metadata| metadata.len()).map_err(|error| io(&error))
    }

    fn read_at(&self, handle: &File, offset: u64, buf: &mut [u8]) -> Result<(), ReadFailure> {
        handle.read_exact_at(buf, offset).map_err(|_| ReadFailure)
    }

    fn digest(&self, path: &Path) -> Result<Sha256Digest, ArchiveError> {
        let mut file = self.open(path)?;
        digest_open(&mut file).map_err(|error| io(&error))
    }

    fn validate_trash_path(&self, path: &Path) -> Result<(), ArchiveError> {
        self.root()?.regular(path).map_err(|error| archive_error(path, error))?;
        Ok(())
    }

    fn target(&self, name: &str) -> PathBuf {
        self.directory.join(name)
    }

    fn archived(&self) -> Result<Vec<PathBuf>, ArchiveError> {
        self.list(|name| name.ends_with(".m4a") && !name.starts_with('.'))
    }

    fn staged_leftovers(&self) -> Result<Vec<PathBuf>, ArchiveError> {
        self.list(|name| name.starts_with(STAGING_PREFIX))
    }
}
```

A clone that reports `Exists` found the name taken, so the file there is someone else's and is never
owned. Any other clone failure owns the name exactly when a regular file now stands there, which is the
byte copy that ran out of space part way; the digest, mode and size steps after a successful clone own it
unconditionally. Nothing here removes a file.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters archive`

Expected: all 10 staging tests PASS. Run `cargo clippy -p vpt-adapters --all-targets -- -D warnings` and
expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(archive): staging below the audio root with an owned-cleanup contract"
```

______________________________________________________________________

