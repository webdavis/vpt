# Task 29 execution brief

Read task-29-brief.md completely. Main checked spec sections 4.1 and 4.2 and the current settings and
RootDir APIs. Dispatched to root in the VPT-local managed-links worktree at f57112a on 2026-09-27.
This feature depends only on accepted configuration and filesystem adapters. Implement the narrow
settings_from loader from Task 27 here, test-first, for later command reuse. Other Task 27 runtime
composition stays deferred. This supersedes the original serial command-task scheduling prerequisite.

- Own the managed-link adapter, command wiring and focused tests. You are not alone; preserve others'
  work. One product writer, no subagents. Main owns the ledger and task tracker.
- Establish compiling behavioral RED for each branch instead of the sample's missing-symbol errors.
  Keep tests below production code and private; no sample module docstrings or unnecessary API growth.
- Preserve this task's settings-only startup: no general runtime, ledger, helper or unrelated source
  dependency. Retain the accepted config rule requiring default home when symlink_target is set.
- Deploy refuses occupied files/directories and different links without replacing them. It creates
  only a missing target leaf under an existing parent, through accepted checked-root operations.
  Preserve existing parent permissions. A relative equivalent link remains byte-identical on deploy.
- Verify never creates a leaf, repairs a link or changes permissions. Cover absent, wrong, dangling,
  unreadable and non-directory cases with the existing complete snapshot helper where applicable.
  Do not treat two unresolved paths as evidence that their targets are equal.
- Check both verbs when symlink_target is unset, explicit config selection, and success/error JSON
  and exit mapping. A filesystem failure stays a safe typed store error; avoid broad Debug formatting
  of adapter errors where an explicit safe operation/kind mapping exists.
- Preserve the permitted home symlink and no-follow rules below resolved roots. No widening to
  automatic link replacement, recursive parent creation or repairing unrelated root configuration.
- Keep every accepted leaf and add compiled mutations for equivalence, no-replacement and read-only
  verification, with exact restored controls. Report chronology, logs, hashes, timing/size audit and
  normal-hook commits in task-29-report.md. Main owns review and final ship. No live link changes,
  installation, publication or destructive evidence cleanup.
