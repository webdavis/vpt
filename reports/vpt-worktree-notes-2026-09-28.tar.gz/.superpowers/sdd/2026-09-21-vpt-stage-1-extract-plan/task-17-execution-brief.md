# Task 17 execution brief

Read `task-17-brief.md` completely. It is the approved archive-staging task; these controller constraints correct its historical samples and carry current boundaries.

- Dispatch from the reviewed integrated `f770c4c` tree. Task 15 is accepted; Task 14 and D6 passed
  independent review and are integrated, with combined verification pending the unrelated Task 24
  fixture diagnosis. Actual interface inspection confirms no title-copy dependency: staging consumes
  Task 15's unchanged clone signature, Task 14's digest helper and the existing checked root.
  Implementation may proceed in isolation; acceptance still requires all integrated checks.
  Reconcile those actual interfaces before editing. Do not copy obsolete sample imports.
- Own only the archive capability, concrete staging adapter, curated exports and focused tests named in the task. Main owns progress.md and Todoist. You are not alone; preserve other work. One product writer, no subagents or new worktree, no early publication/ingest implementation.
- Every behavior starts with a compiling failing leaf against the smallest unsupported stub. A missing type/import is not RED evidence. Capture the behavior-to-leaf mapping before implementation; future test-first work has no exception.
- Preserve the source's read-only descriptors and metadata. The archive chooses the staging name and supplies the checked directory identity to the recorder closure. Do not add filesystem types or recorder handles to the archive capability.
- A successful stage records the entire file's digest and size, private mode and the actual clone kind. Cover both reported clone kinds without requiring every host volume to support copy-on-write. Use completed Task 15's synthetic owned fixtures and recorder behavior.
- Preserve ownership in every failure result. A collision owns nothing and changes no existing bytes or mode. A partial copy or failed finalization owns only this invocation's staged file. A replaced root returns no cleanup pathname that could address the replacement. The adapter itself performs no Trash or unlink.
- Keep the absent read-only archive absent, with empty listings and a staging refusal before invoking the closure. Cover the archive capability itself, not only private helpers. Preserve safe error categories and typed containment through listing, opening, digesting and cleanup validation.
- Retain the approved root-replacement, link refusal and final staging revalidation tests. All directories, file data, clone failures and later cleanup paths are synthetic and owned. Never patch a third-party clone operation or invoke a live helper.
- Omit sample module docstrings and conversation/rationale comments. Private implementation modules and cohesive splits must meet the Rust limits. Reuse the existing checked-root and digest implementations.
- Mutation-check privacy, ownership on collision/partial failure, digest/size, clone-kind reporting and root replacement, with exact edits, unique logs and byte-identical passing controls. No deadline increases, retries of unexplained failures, broad process probes, installation, publication, apply or destructive cleanup.
- Verify buffer safety and use apply_patch. Preserve all prior leaves; run required Rust, release, staged-size and secrets gates. Commit only this task's files with normal hooks. Write `task-17-report.md`; independent review and controller committed-HEAD verification precede Task 18.
