# Task 30 execution brief

Dispatched on 2026-09-27 in `feat/doctor` from accepted
`a66dbacf98165958ebdd7a6fd010c4881876f0c7`. Task 29, the helper client and Task 28's read-only
composition are accepted. Read `task-30-brief.md` completely, then `task-D7-integration-addendum.md`.
The controller read both complete sources again on 2026-09-27 and checked the current output,
environment, helper and observational ledger interfaces. Refresh the final Task 28 source at dispatch.

- Own Task 30's doctor modules, git-tree adapter, output addition and focused tests, plus its ignored report and evidence. Main owns progress and Todoist. Preserve others' work; one product writer, no new worktree or subagents.
- Emit all 18 exact Stage 1 check names on every invocation. Unavailable prerequisites produce the specified dependent not-run check, not an early exit. Root, ledger or helper failures do not suppress independent checks. JSON failure remains one `vpt.error/1` document on stderr, empty stdout, exit 3 and `doctor_checks`.
- Route `source_gone` through the common observational ledger wrapper. An absent ledger remains empty; populated missing-companion state fails only that check. Containment, corruption and storage errors stay typed and safe, without row values or raw database messages, while the doctor verdict remains aggregate.
- Doctor never opens or refreshes the title database, takes the application write lock, creates state or store leaves, changes permissions, repairs a publication or cleans a staged file. Helper version observation is allowed; notification and Trash execution are not.
- Use D7's expanded snapshot with kinds, identities, link counts, bytes, permissions, size, mtime, ctime and flags, excluding atime. Close companion-preserving native fixture writers before snapshots. Native and rooted connections never overlap on one inode in the same process.
- Add compiling RED for the D7 observational and error cases before routing. Include populated-ledger missing companions and unsafe replacements, full unchanged snapshots, and a held application write lock that does not delay doctor. Preserve the original independent-check tests and safe helper additive diagnostics.
- Mutate observational composition to writable and the probe to an early-return path. The observation and full-census tests must catch them; restore exact bytes and run passing controls. Preserve all baseline leaves and existing command deadlines. A recurrence under `6hc7MMRc2QhRm75g` is evidence to report, not permission to retry or relax the deadline.
- Follow clean-code-rust, buffer safety, apply_patch, normal commit hooks and required final-source Rust/release/staged-size gates. Main owns fresh committed-HEAD ship and independent review. Synthetic fixtures only; no live paths, installation, publication, apply, third-party changes or destructive cleanup.

## Current-source corrections

- Preserve `Outcome::ParseFailure`, parser help, existing diagnostic formatting and exit 1 when
  standard error cannot be written. The sample's replacement output implementation drops those
  accepted behaviors. Add only `FailedReport` and the private writer seam needed to test both streams.
  Pin successful and failed reports in both output modes, including broken output streams, before
  implementing the new variant.
- `Environment::selected_config` does not exist. Use the explicit config path or the existing fallible
  `config_path()` method. Keep path-selection errors in the aggregate result. Missing configuration
  must explain that `vpt setup` is needed without echoing unparsed configuration contents.
- Seed synthetic ledger rows through `RootDir` and `SqliteLedger`, then close the writer before
  observations. Reuse Task 28's checked fixtures and expanded snapshots where their final shape fits.
  The sample's ingest-to-doctor and ingest-dry-run scenarios remain with Task 27's integrated command
  checks; the doctor slice must prove the same observational behavior against real seeded state now.
- The git-tree probe must distinguish absence from an unreadable ancestor. Use
  `enclosing_git_tree(path: &Path) -> std::io::Result<Option<PathBuf>>`: only `NotFound` continues the
  walk, any `.git` entry is a match, and other errors fail that check with a safe error-kind detail.
  Add compiling RED for the distinction, nearest nested repository, a `.git` file and no repository.
  This corrects the sample's false "not in a git tree" result on inspection failure.
- Test temporary directories may themselves live inside this repository. Pin an owned nearest `.git`
  entry for native ancestry cases; prove the no-entry walk with a private inspection seam rather than
  assuming the fixture's external ancestors have no repository metadata.
- Preserve independent git-tree checks through a resolved home link when another store fails. Do not
  touch the Voice Memos title database or call helper operations other than version. Fake helper
  output must exercise additive diagnostics and incompatible versions without exposing child streams.
- `VoiceMemosStore` has no `recordings_dir()` getter. Retain the already canonicalized source path
  beside the opened store for independent child probes; add no recorder port for this observation.
  `Sandbox::write_config` also does not exist. Use explicit owned config, source, state and helper
  paths, reusing the accepted observation fixture and whole-tree snapshot.
