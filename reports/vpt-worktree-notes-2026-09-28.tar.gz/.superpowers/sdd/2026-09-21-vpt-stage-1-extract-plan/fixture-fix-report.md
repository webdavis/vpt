# Broken-output fixture fix

Base: `9de4402468dcc9f35704dbfdce5f963a86b6c67e`. Commit: `0a08d7bc405167de7e3682e00c515ceaea2b2dd1`.

The seven broken-output fixtures now use one helper that shuts down the writer's write direction before handing its descriptor to the child. The helper returns the peer too, and callers retain it throughout execution. Both-stream tests duplicate the disabled writer descriptor. Product behavior is unchanged.

## Evidence and confidence

`task-3-baseline.log` records `json_usage_with_broken_stderr_exits_one` returning 2 instead of 1. The product's shared emitter returns 2 for a usage error when its stderr write succeeds, and 1 when that write fails.

The controlled reproducer duplicated the peer, dropped the original peer, and ran the actual JSON usage command with the writer as stderr. It reproduced exit 2 instead of 1 in 0.01 seconds. Closing one peer descriptor therefore does not establish the fixture's required write failure while another peer reference survives. Concurrent spawning retaining a peer across the close is a plausible explanation for the historical flake. That exact interleaving was not observed or proven.

The local `shutdown(2)` manual says SHUT_WR disables further sends. The [Rust UnixStream shutdown documentation](https://doc.rust-lang.org/std/os/unix/net/struct.UnixStream.html#method.shutdown) specifies shutdown of the selected connection direction; its [try_clone documentation](https://doc.rust-lang.org/std/os/unix/net/struct.UnixStream.html#method.try_clone) describes independently owned handles to the same stream. The new regression retains a duplicated peer deliberately and verifies exit 1. This establishes the required failure even while a peer survives, without timing assumptions or serializing the suite.

Confidence is high that the fixture now establishes its intended condition. Attribution of the earlier intermittent event to a particular fork schedule remains unproven. No evidence justified changing product code, and none was changed.

## Test-first and mutation results

All logs below are under `.superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/`. Commands ran with `set -o pipefail`, redirecting combined output through tee to preserve their exit codes.

| Log | Command or probe | Exit and result |
| --- | --- | --- |
| `fixture-fix-red.log` | `cargo test --offline --locked -p vpt --test harness broken_output_rejects_writes_while_a_peer_copy_survives -- --exact` against the original close-only fixture with a retained duplicate | 101; one named test fails, actual 2 versus expected 1, 0.01 s |
| `fixture-fix-first-green.log` | Same command using the shared write-shutdown fixture | 0; one test passes, 0.01 s |
| `fixture-fix-mutant.log` | Same command after changing `Shutdown::Write` to `Shutdown::Read` | 101; same actual 2 versus expected 1 failure, 0.01 s |
| `fixture-fix-control.log` | Same command after restoring `Shutdown::Write` | 0; one test passes, 0.01 s |
| `fixture-fix-tests.log` | `cargo test --offline --locked -p vpt -p vpt-protocol --no-fail-fast --features dev-tools` | 0; 32 tests pass, zero failed or ignored |
| `fixture-fix-clippy.log` | `cargo clippy --offline --locked -p vpt -p vpt-protocol --all-targets --features dev-tools --no-deps -- -D warnings` | 0; selected crates pass; existing Task 3 dependency warning remains visible |
| `fixture-fix-format.log` | `rustfmt --edition 2024 --check crates/vpt/tests/support/mod.rs crates/vpt/tests/usage.rs crates/vpt/tests/version.rs crates/vpt/tests/harness.rs` | 0; no formatting differences, empty log |
| `fixture-fix-size.log` | Exact clean-code-rust git-ls-files/awk audit after staging the four owned files | 0; all files below targets |

The mutation and restored-control logs begin with `rg -n -F` output confirming the source bytes before execution. Both versions compile. The mutation failure is behavioral, not a compiler failure.

All 31 prior command/protocol leaf names and assertions remain. The only added leaf is `broken_output_rejects_writes_while_a_peer_copy_survives`. The complete named inventory is in `fixture-fix-tests.log`. In that run, the three harness tests total 0.51 s, usage totals 0.02 s, version totals 0.01 s, and command/protocol unit suites each total 0.00 s. The runner retains its 500 ms command deadline and one-second outer assertion. No retry loop, arbitrary sleep, serialization, or new timeout was introduced.

The four changed files have 136, 81, 73, and 58 total lines respectively for support, version, harness, and usage. They are test-only files, so the prescribed audit reports zero implementation lines. `git diff --cached --check` passes.

## Ownership and verification limits

Only `crates/vpt/tests/support/mod.rs`, `usage.rs`, `version.rs`, and `harness.rs` are staged. Task 3's adapter stubs are intentionally unfinished and remain untouched. The adapter diff hash and all six config-file hashes match the values captured before this fix. The existing `schema/types.rs::key` dead-code warning is visible in scoped test and Clippy logs; no lint suppression was added. The controller reports 20 intentionally failing Task 3 tests. Full workspace tests, workspace Clippy, and ship are therefore not claimed green for this fixture-only change.

The global pre-commit hook dispatches only to an executable repository `.githooks/pre-commit`; this worktree has no such executable. The normal commit path remains available. The commit uses `SKIP_AI_COMMIT=1` and does not bypass checks.

The normal-hook commit exited 0 and contains exactly the four owned test files. The post-commit index is empty. Worktree status shows only Task 3's modified adapter lib.rs and untracked config directory.

The first local manual lookup invoked the configured Neovim pager and encountered sandbox write errors. That owned lookup was interrupted, then repeated successfully with `MANPAGER=cat PAGER=cat`. The installed Rust source component was absent, so the standard-library API was verified against the official documentation. No tool source, system configuration, live destination, or other agent's file was changed.

Controller verification: committed-HEAD `gitleaks git --redact --no-banner --no-color .` exited 0, scanning 85 commits with no leaks found. Raw output is in `fixture-fix-post-commit-secrets.log`. Independent scoped review approved the repair in `fixture-fix-review.md`.
