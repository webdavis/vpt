# Task 6 review, 1170704

Reviewer: /root/vpt_review_task_6, gpt-6-astra xhigh. Reviewed original base 1661c1227b5a19498efe4d94d3a4523730a67cba through 1170704cafefe388b241e807d4bdf442d1cfc40b, including the separate runner repair. Product review was read-only; no tests, Git mutations, filesystem probes or live destination access.

## Spec compliance

Issues found. Three Important findings and one Minor finding. Release build and controller final committed-HEAD checks remain due. The reviewer subsequently confirmed the source-containment RED in task-6-command-all-red.log:63-80 and withdrew its initial evidence limitation; no tests were regenerated.

## Strengths

- commands/setup.rs:25 resolves environment and paths before opening the terminal. compose.rs:32 preserves precedence and privately rejects selected invalid UTF-8 values.
- adapters/prompt.rs:38 distinguishes terminal EOF from an empty answer. tests/setup/source.rs:37 checks the complete owned source fixture after refusal.
- tests/harness.rs:13 now catches removal of stderr completion. support/process.rs:16 preserves bounded TERM/grace/KILL cleanup; harness.rs:158 requires an explicit descendant-reaping record and group disappearance.

## Important findings

### F1: Existing arbitrary config parents are chmod targets

crates/vpt-adapters/src/config/write/directory.rs:64 applies 0700 even when the selected directory was an existing anchor. A custom config inside a user-owned shared directory disjoint from home and stores passes resolution, then loses group/other access. /config.toml is blocked by released-store overlap; unrelated shared directories are not. /tmp/file.toml is not inherently overlap-blocked, though ordinary-user ownership restrictions can make chmod fail. No runtime chmod was observed.

This was plan-mandated. The operator approved requiring an existing config parent to be private already, refusing before prompting and without chmod. Preserve repair of managed home/state/store directories and private creation of new config directories. Revalidate the policy before writing.

### F2: Force can overwrite a source inode through a hard link

crates/vpt-adapters/src/config/write.rs:67 opens a regular file, then changes its mode and truncates it at lines 78 and 81. A selected config outside the source can be a hard link to a source recording or database file. Directory validation passes and both names reference the inode being overwritten, violating the source read-only contract at docs/superpowers/specs/2026-09-20-vpt-design.md:423.

Refuse multiply linked existing config files using opened-descriptor metadata before changing permissions or content. Add an owned synthetic-source hard-link regression proving refusal and unchanged source content and metadata. This is a source-derived failure path, not an observed live write.

### F3: Descendant fixture inherits the operator environment

crates/vpt/tests/harness.rs:160 constructs the fake-engine command without env_clear and sandbox environment values. Its helper and /bin/cat inherit real HOME, PATH and configuration variables, contrary to task-6-execution-brief.md. Current code does not consume those paths; no live config read is claimed. Apply the owned environment setup used by adjacent fixtures.

## Minor finding

### M1: Real terminal success does not assert JSON-only stdout

crates/vpt/tests/setup.rs:13 covers success without --json. Use the existing terminal fixture to verify the explicit JSON output contract in the design at line 1332.

## Focused checks

- Config-parent reachability: config/roots.rs:29, config/roots/directory.rs:56 and domain/layout.rs:93. Canonicalization and overlap checks do not establish ownership of an arbitrary config parent.
- Hard-link reachability: contained/file.rs:66 checks symbolic-link traversal and regular-file type, without a link-count guard.
- Read preserved RED and mutation/control logs. Final ship log records exit 0; the committed secrets scan covers 93 commits without leaks. The size warnings are inherited.
- Controller's named-leaf comparison records baseline 125, final 156, missing 0.

## Assessment

Task quality: Needs fixes. The setup composition and bounded harness are coherent, but both filesystem write paths and fixture environment must be corrected before acceptance.
