# Task 4: value rules and duration syntax

Status: complete and committed.
Base: `da93d643044cc3a6ed40ad94a6907ec5487e4a2c`.
Branch: `feat/stage-1-extract`.
All evidence paths below are relative to this report.

## Result and scope

`load_text` validates the merged table using the existing key kinds. It rejects wrong types,
integer and ratio range violations, invalid enum members, malformed durations, and non-string
list elements. Errors identify the key and rule without retaining rejected values.
`ConfigError::key` exposes keys on keyed refusals and returns none for file, parse, and version errors.

The pure domain parser accepts `0` or positive decimal counts with `s`, `m`, `h`, or `d`,
checks parsing and multiplication overflow, and handles a multibyte trailing character.
The intentional public capability is `vpt_domain::duration::{parse_duration, DurationError}`.
Validation and its tests remain private, with `pub(super)` limited to loader collaboration.

Dependency direction remains `vpt -> vpt-adapters -> vpt-application -> vpt-domain`, with
`vpt-protocol` independent. Only the adapters import the duration capability. No manifests,
commands, protocols, persistence, or external consumers changed. Task 5 and the database amendment
remain outside this change.

## Decisions against the sample

- Used compiling stubs for RED, as required by the execution brief. No unresolved-name failure counted.
- Used `spec_for` for every leaf, including retention keys. A missing kind refuses the key; there is
  no fallback that silently treats it as text.
- Kept `source.max_audio_bytes` in the positive signed 64-bit range exposed by the existing TOML
  value type and the brief's implementation contract. The test accepts `i64::MAX`, refuses zero
  and negative numbers, and records the parser refusal for `i64::MAX + 1`.
- Expanded the example tests into 9 duration and 13 validation leaves. The tests cover every
  positive/count key, exact boundaries, non-finite numbers, dynamic keys, and canary privacy.
- Kept the 287-line validation suite in a private child. No broad lint suppressions or docstrings added.

## Test-first evidence

| Run | Command | Result | Evidence |
| --- | --- | --- | --- |
| Baseline | `cargo test --locked --workspace --no-fail-fast --features dev-tools` | exit 0, 55 passed | [baseline](task-4-baseline.log) |
| Duration RED | `cargo test --locked -p vpt-domain duration` | exit 101, 9 selected, 8 assertion failures | [duration RED](task-4-red-duration.log) |
| Validation RED | `cargo test --locked -p vpt-adapters validate` | exit 101, 13 selected, 11 assertion failures | [validation RED](task-4-red-validation.log) |
| GREEN | `cargo test --locked --workspace --no-fail-fast --features dev-tools` | exit 0, 77 passed | [GREEN](task-4-green.log) |

The duration stub returned `NotAPositiveInteger`: all duration leaves except
`malformed_counts_are_refused` failed their assertions. The validation stub accepted every value,
and the key accessor returned none: all validation leaves except
`a_ratio_accepts_integer_and_float_endpoints` and
`the_divergence_ratio_accepts_values_above_zero_through_one` failed their assertions.
Those three initial passing leaves are preserved acceptance/refusal controls; the guard mutations
below provide their relevant failure evidence where applicable.

[The test-name map](task-4-test-name-map.log) lists each of the 55 baseline leaves with an identical
successor name and passing baseline/restored results. No baseline test was removed, renamed, or replaced.
The final suite contains 77 leaves, including all 19 existing loader regressions and 4 renderer tests.

Added leaves:

```text
config::validate::tests::a_ratio_accepts_integer_and_float_endpoints
config::validate::tests::a_ratio_refuses_values_outside_its_closed_range
config::validate::tests::audio_bytes_accepts_the_positive_64_bit_toml_range
config::validate::tests::counts_gaps_and_lookbacks_enforce_the_32_bit_endpoints
config::validate::tests::durations_accept_zero_and_checked_unit_forms
config::validate::tests::dynamic_engine_and_language_values_use_their_declared_kinds
config::validate::tests::enum_values_are_limited_to_the_declared_options
config::validate::tests::lists_and_argv_require_string_elements
config::validate::tests::positive_integers_enforce_the_32_bit_endpoints
config::validate::tests::refusals_without_a_key_report_none
config::validate::tests::the_divergence_ratio_accepts_values_above_zero_through_one
config::validate::tests::the_divergence_ratio_refuses_zero_and_outside_values
config::validate::tests::wrong_scalar_types_name_the_key_and_expected_type
duration::tests::a_count_above_64_bits_is_refused
duration::tests::a_positive_number_without_a_unit_is_refused
duration::tests::an_unknown_unit_is_refused
duration::tests::each_unit_converts_to_seconds
duration::tests::leading_zeroes_do_not_change_a_positive_count
duration::tests::malformed_counts_are_refused
duration::tests::multiplication_overflow_is_refused
duration::tests::the_largest_seconds_value_is_accepted
duration::tests::zero_means_never_and_needs_no_unit
```

## Mutation evidence

Each row is one source mutation, run serially. The edited lines were checked on disk before testing.
Every listed mutant compiled, failed the named behavior test, and exited 101. Every paired control
restored the production source and exited 0. The composition probe selected all 13 validation leaves;
10 refusals failed, proving the public loader enforces validation.

The links contain the exact command, verified source bytes, complete file hash, selected leaf names,
assertion failures, and exit code. The table also records the literal before/after edit. Hashes use
SHA-256 (Secure Hash Algorithm 256-bit).

| Probe and evidence | Exact edit | Mutant hash | Failing leaves |
| --- | --- | --- | --- |
| [duration-zero](task-4-duration-zero-mutant.log), [control](task-4-duration-zero-control.log) | `if text == "0" {` to `if text == "00" {` | `feb817213b7e1ef97eb5ea7dcebe57d44dd04dec06109aadf6bbd5ab7ea7d46f` | `duration::tests::zero_means_never_and_needs_no_unit` |
| [duration-unit](task-4-duration-unit-mutant.log), [control](task-4-duration-unit-control.log) | `'m' => 60,` to `'m' => 61,` | `792087a2c9a79c23c886d53825f55d3914a675fe9985b5e84db2b59d6cc56cd3` | `duration::tests::each_unit_converts_to_seconds` |
| [duration-missing-unit-confirmed](task-4-duration-missing-unit-confirmed-mutant.log), [control](task-4-duration-missing-unit-confirmed-control.log) | `if unit.is_ascii_digit() {         return Err(DurationError::MissingUnit);     }` to `if unit.is_ascii_digit() {         return Err(DurationError::NotAPositiveInteger);     }` | `6bb14060fcdbe2bd8763bd000759b8766d1475e100056b031633ef2ee8b39008` | `duration::tests::a_positive_number_without_a_unit_is_refused` |
| [duration-unknown-unit](task-4-duration-unknown-unit-mutant.log), [control](task-4-duration-unknown-unit-control.log) | `other => return Err(DurationError::UnknownUnit(other)),` to `_ => return Ok(count),` | `1dde22e8278f5fcd3cf50fc2a70e2088c7776d964f0150346e59c8e523dc6463` | `duration::tests::an_unknown_unit_is_refused` |
| [duration-syntax](task-4-duration-syntax-mutant.log), [control](task-4-duration-syntax-control.log) | `if digits.is_empty() \|\| !digits.bytes().all(\|byte\| byte.is_ascii_digit()) {` to `if digits.is_empty() {` | `869d66ee94dc238d67a9a56679ef9d364323a0a111f3c543856b3eb350a46897` | `duration::tests::malformed_counts_are_refused` |
| [duration-positive](task-4-duration-positive-mutant.log), [control](task-4-duration-positive-control.log) | `if count == 0 {` to `if count == u64::MAX {` | `6c2dfea35d1ec8d0770ede9828d6f987a77ec837e6df64e38159e14d07a94cf2` | `duration::tests::malformed_counts_are_refused` |
| [duration-parse-overflow](task-4-duration-parse-overflow-mutant.log), [control](task-4-duration-parse-overflow-control.log) | `let count: u64 = digits.parse().map_err(\|_\| DurationError::Overflow)?;` to `let count: u64 = digits.parse().map_err(\|_\| DurationError::NotAPositiveInteger)?;` | `35472e907e22118315f955e56221615557b5b2a32fa57473b9bcf9f4ab98a84c` | `duration::tests::a_count_above_64_bits_is_refused` |
| [duration-multiply-overflow](task-4-duration-multiply-overflow-mutant.log), [control](task-4-duration-multiply-overflow-control.log) | `count.checked_mul(multiplier).ok_or(DurationError::Overflow)` to `Ok(count.wrapping_mul(multiplier))` | `0b1c8c9ade1b2e275903786bc39e0d426d1a6a3c50684ae23caf32cd17f16c43` | `duration::tests::multiplication_overflow_is_refused` |
| [loader-composition](task-4-loader-composition-mutant.log), [control](task-4-loader-composition-control.log) | `super::validate::validate(&merged)?;` to `let _ = super::validate::validate(&merged);` | `66813e426625423dac5e9865c9584cf5c961c84155b4c62e25b6966926dd2439` | `config::validate::tests::a_ratio_refuses_values_outside_its_closed_range`<br>`config::validate::tests::enum_values_are_limited_to_the_declared_options`<br>`config::validate::tests::audio_bytes_accepts_the_positive_64_bit_toml_range`<br>`config::validate::tests::dynamic_engine_and_language_values_use_their_declared_kinds`<br>`config::validate::tests::the_divergence_ratio_refuses_zero_and_outside_values`<br>`config::validate::tests::lists_and_argv_require_string_elements`<br>`config::validate::tests::durations_accept_zero_and_checked_unit_forms`<br>`config::validate::tests::counts_gaps_and_lookbacks_enforce_the_32_bit_endpoints`<br>`config::validate::tests::positive_integers_enforce_the_32_bit_endpoints`<br>`config::validate::tests::wrong_scalar_types_name_the_key_and_expected_type` |
| [integer-upper-bounds](task-4-integer-upper-bounds-mutant.log), [control](task-4-integer-upper-bounds-control.log) | `Some(n) if (1..=i64::from(u32::MAX)).contains(&n) => Ok(()),             Some(_) => Err(range("a positive 32-bit integer")),` to `Some(n) if n >= 1 => Ok(()),             Some(_) => Err(range("a positive 32-bit integer")),` | `30bed4bd6b53ab31348d5a6bea2d9577348187e796d60fdd6662a653add35190` | `config::validate::tests::positive_integers_enforce_the_32_bit_endpoints` |
| [count-upper-bound](task-4-count-upper-bound-mutant.log), [control](task-4-count-upper-bound-control.log) | `Some(n) if (0..=i64::from(u32::MAX)).contains(&n) => Ok(()),` to `Some(n) if n >= 0 => Ok(()),` | `18d0b4b5c5f541b37d337adbfb4da408c7024599430c5fc9a0a12421b786b6a2` | `config::validate::tests::counts_gaps_and_lookbacks_enforce_the_32_bit_endpoints` |
| [integer-lower-bound](task-4-integer-lower-bound-mutant.log), [control](task-4-integer-lower-bound-control.log) | `Some(n) if (1..=i64::from(u32::MAX)).contains(&n) => Ok(()),` to `Some(n) if (0..=i64::from(u32::MAX)).contains(&n) => Ok(()),` | `ad8659139d888d1a31032b1d45d153af26089d0303334b00d90bdba8c8fc6aef` | `config::validate::tests::positive_integers_enforce_the_32_bit_endpoints` |
| [count-lower-bound](task-4-count-lower-bound-mutant.log), [control](task-4-count-lower-bound-control.log) | `Some(n) if (0..=i64::from(u32::MAX)).contains(&n) => Ok(()),` to `Some(n) if (-1..=i64::from(u32::MAX)).contains(&n) => Ok(()),` | `55555fe75f335a6485d0d2a7a822a817d7ed3f918fbbf0420820d29d36ab9703` | `config::validate::tests::counts_gaps_and_lookbacks_enforce_the_32_bit_endpoints` |
| [audio-positive](task-4-audio-positive-mutant.log), [control](task-4-audio-positive-control.log) | `Some(n) if n >= 1 => Ok(()),` to `Some(n) if n >= 0 => Ok(()),` | `283c901a17f78557926855439c709a800da36be9248c59ac855c7258d7841ee3` | `config::validate::tests::audio_bytes_accepts_the_positive_64_bit_toml_range` |
| [ratio-upper-bound](task-4-ratio-upper-bound-mutant.log), [control](task-4-ratio-upper-bound-control.log) | `Some(f) if f.is_finite() && (0.0..=1.0).contains(&f) => Ok(()),` to `Some(f) if f.is_finite() && f >= 0.0 => Ok(()),` | `e59cf71adc49da1c6bf66ce9ebac328e95f4cf6e23c814aab813500cd4394fcf` | `config::validate::tests::a_ratio_refuses_values_outside_its_closed_range` |
| [ratio-non-finite](task-4-ratio-non-finite-mutant.log), [control](task-4-ratio-non-finite-control.log) | `Some(f) if f.is_finite() && (0.0..=1.0).contains(&f) => Ok(()),` to `Some(f) if !f.is_finite() \|\| (0.0..=1.0).contains(&f) => Ok(()),` | `7c757b6c73f9a854a59f548b2727bc3b14330b3abc96c0f80282a7e11d4f3262` | `config::validate::tests::a_ratio_refuses_values_outside_its_closed_range` |
| [divergence-zero](task-4-divergence-zero-mutant.log), [control](task-4-divergence-zero-control.log) | `Some(f) if f.is_finite() && f > 0.0 && f <= 1.0 => Ok(()),` to `Some(f) if f.is_finite() && f >= 0.0 && f <= 1.0 => Ok(()),` | `7f7ce3091f1152bc4f671c34969f7102f136572e8095419d67cf5584284c570e` | `config::validate::tests::the_divergence_ratio_refuses_zero_and_outside_values` |
| [duration-integer](task-4-duration-integer-mutant.log), [control](task-4-duration-integer-control.log) | `Value::Integer(0) => Ok(()),` to `Value::Integer(_) => Ok(()),` | `75c00378dce52fe25d341706a4387bb6d9c6e7e20d81c9569cdb34c82801ea04` | `config::validate::tests::durations_accept_zero_and_checked_unit_forms` |
| [enum-membership](task-4-enum-membership-mutant.log), [control](task-4-enum-membership-control.log) | `Some(text) if options.contains(&text) => Ok(()),` to `Some(_) if !options.is_empty() => Ok(()),` | `23dffbd92bfcd745e933506fb2622ae0454448c81fbd828d7b20e645a9d219bc` | `config::validate::tests::enum_values_are_limited_to_the_declared_options` |
| [list-elements](task-4-list-elements-mutant.log), [control](task-4-list-elements-control.log) | `Some(items) if items.iter().all(Value::is_str) => Ok(()),` to `Some(_) => Ok(()),` | `8347fd58f728aef258524880492abfc19f8d73a75bdc621a30bf1fcb799a905a` | `config::validate::tests::lists_and_argv_require_string_elements` |
| [text-secret-types](task-4-text-secret-types-mutant.log), [control](task-4-text-secret-types-control.log) | `Kind::Text \| Kind::Secret => value.as_str().map(\|_\| ()).ok_or_else(wrong),` to `Kind::Text \| Kind::Secret => Ok(()),` | `d7d213110d83f3119541b62244a8b3f215a1e9872ecf66a404436864762356cd` | `config::validate::tests::wrong_scalar_types_name_the_key_and_expected_type` |
| [boolean-types](task-4-boolean-types-mutant.log), [control](task-4-boolean-types-control.log) | `Kind::Bool => value.as_bool().map(\|_\| ()).ok_or_else(wrong),` to `Kind::Bool => Ok(()),` | `5787ca5396733a53898555a4fc35696444178f0d5834d4b90da569ca6fc33bd1` | `config::validate::tests::dynamic_engine_and_language_values_use_their_declared_kinds` |
| [error-key](task-4-error-key-mutant.log), [control](task-4-error-key-control.log) | `Some(key)` to `None` | `e2e59de68a9e9024b3879cb99160f0e6752018adad53b2427b5a39e7ad32b5f9` | `config::validate::tests::refusals_without_a_key_report_none` |

A restoration issue occurred during the first missing-unit probe. Its inverse patch matched the
same error statement in the empty-input branch. The control failed, and its hash was
`f119678ac2ae4d96746d04bfbb95ba52838c2dbbb8c6888831a5228965b08810`.
The evidence is retained in [the failed control](task-4-duration-missing-unit-control.log).
The two branches were restored with their surrounding conditions, and all 9 duration tests passed
in [the repair control](task-4-restoration-repair.log). The probe was repeated as
`duration-missing-unit-confirmed`. Subsequent controls required byte-for-byte full-file hash equality
with their original source before running tests.

The final restored source hashes are:

| File | Hash |
| --- | --- |
| `crates/vpt-domain/src/duration.rs` | `adf477ee71a7769a6e551c5bc07151c34bbc90f5184b2261c009540bb301bc04` |
| `crates/vpt-adapters/src/config/load.rs` | `bf04e523bc30d030d37a5f7a94e566b6bacfffa5bf5ce6b5e0aa8dc99aeaec5e` |
| `crates/vpt-adapters/src/config/validate.rs` | `a3f3be632ddf965e1abbbc4c3f9832afcc1fa1911099c1c2082bff2e4e939031` |

## Restored gates and timing

| Command | Result | Evidence |
| --- | --- | --- |
| `cargo fmt --all` | exit 0 | formatted staged source |
| `just ship` | exit 0, 9.00 seconds wall time | [full ship control](task-4-ship.log) |
| `cargo check --locked --workspace --all-targets --features dev-tools` | exit 0 | [workspace check](task-4-check.log) |
| `cargo build --locked --release --workspace` | exit 0, 1.80 seconds wall time | [release build](task-4-release.log) |
| `git diff --cached --check` | exit 0 | staged diff inspection |

`just ship` ran formatting checks, Clippy with warnings denied and development tools enabled,
the full workspace suite with no fail-fast, documentation with warnings denied, secret scanning,
and file-size checks. These include the commands behind `just lint-check` and `just test-rust`.
Secret scanning inspected 88 commits and found no leaks.

In the final parallel workspace run, the 36 adapter tests finished in 0.07 seconds and the 9 duration
tests in 0.00 seconds. Every test binary finished below one second; the slowest existing process
harness finished in 0.51 seconds. These suite elapsed times bound every individual leaf below the
one-second ceiling under the normal parallel runner. Tests added here call only pure parsing and
in-memory configuration loading. Existing process tests continue to use their sandbox harness.

## Exact file-size audit

Ran the clean-code-rust skill's `git ls-files 'crates/*.rs'` and literal awk pipeline after formatting
and staging all new source files. [The complete inventory](task-4-size-audit.log) includes every
tracked Rust file. No test marker precedes production code.

| Owned file | Implementation | Total |
| --- | ---: | ---: |
| `crates/vpt-domain/src/lib.rs` | 1 | 1 |
| `crates/vpt-domain/src/duration.rs` | 36 | 119 |
| `crates/vpt-adapters/src/config/mod.rs` | 8 | 8 |
| `crates/vpt-adapters/src/config/load.rs` | 132 | 134 |
| `crates/vpt-adapters/src/config/validate.rs` | 89 | 91 |
| `crates/vpt-adapters/src/config/validate/tests.rs` | 0 | 287 |

All owned files meet the 200 implementation / 300 total targets. The unchanged
`config/schema.rs` is 471/471, a single declaration table inherited from Task 3.
The unchanged `config/load/tests.rs` is 0/304. Both warnings appear in the full gate and
remain outside this task's ownership. No Rust file exceeds the 500-line hard ceiling.

## Self-review and limits

Reviewed the full staged diff: six owned files, 511 insertions and one removed blank line.
The parser handles empty text before indexing, uses a character boundary for the suffix, restricts
counts to decimal ASCII digits, and checks both overflow sites. Validation uses the existing schema,
runs after the defaults merge, and reports only the key and rule. The input boundary follows the
OWASP allowlist and private-error guidance. Canary checks cover rejected secrets, enum values,
duration strings, and list members; success tables are reduced to unit before refusal assertions,
so a failing assertion does not print the merged configuration.

No Task 4 correctness defect remains from this self-review. Cross-field settings rules, path
resolution, database containment, installation, and live verification belong to later tasks.
No live user configuration, state, destinations, installation, push, pull request, or merge was used.
The initial sandbox refused an evidence-log write outside its default writable root; authorized
worktree operations then ran through normal escalation. No automatic approval rejection occurred,
and no safeguard or test hook was bypassed. Neovim discovery reported no target for this pane.
Progress and task tracking remain owned by the controller.

## Commit

Commit: `2858751a6161df5c41fd90c93a55afac6b46f979`.
Subject: `feat(config): validate value rules and duration syntax`.
The commit contains exactly the six owned Rust files. Normal hooks were enabled;
`SKIP_AI_COMMIT=1` selected the required authored message. Git returned exit 0, and
`git status --short` was empty after the commit. This report and its evidence remain
in the plan's ignored workspace for controller review.
