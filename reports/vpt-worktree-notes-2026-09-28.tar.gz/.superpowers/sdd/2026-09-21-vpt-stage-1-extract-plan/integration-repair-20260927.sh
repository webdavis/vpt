#!/bin/bash
set -euo pipefail
umask 077

test "$#" -ge 2
repair_label="$1"
shift
case "$repair_label" in *[!a-z0-9-]*|'') exit 2 ;; esac
repair_lane=/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract
cd "$repair_lane" || exit 2
repair_evidence="$repair_lane/.superpowers/integration-20260927/$repair_label"
test ! -e "$repair_evidence"
mkdir -p "$repair_evidence/home" "$repair_evidence/config" "$repair_evidence/data" \
  "$repair_evidence/state" "$repair_evidence/cache" "$repair_evidence/tmp" \
  "$repair_evidence/runtime" "$repair_evidence/config-dirs" "$repair_evidence/data-dirs"
git -c core.fsmonitor=false ls-files --cached --others --exclude-standard > "$repair_evidence/paths"
while IFS= read -r repair_file; do
  shasum -a 256 "$repair_file"
done < "$repair_evidence/paths" > "$repair_evidence/before.sha256"
repair_command=(
  /usr/bin/env -u RUST_TEST_THREADS -u CARGO_BUILD_JOBS -u RUSTUP_TOOLCHAIN
  DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
  "HOME=$repair_evidence/home" "XDG_CONFIG_HOME=$repair_evidence/config"
  "XDG_DATA_HOME=$repair_evidence/data" "XDG_STATE_HOME=$repair_evidence/state"
  "XDG_CACHE_HOME=$repair_evidence/cache" "TMPDIR=$repair_evidence/tmp"
  "XDG_RUNTIME_DIR=$repair_evidence/runtime"
  "XDG_CONFIG_DIRS=$repair_evidence/config-dirs" "XDG_DATA_DIRS=$repair_evidence/data-dirs"
  "VPT_CONFIG=$repair_evidence/config/vpt.toml"
  CARGO_HOME=/Users/stephen/.cargo RUSTUP_HOME=/Users/stephen/.rustup
  RUSTUP_AUTO_INSTALL=0 CARGO_NET_OFFLINE=true CARGO_TERM_COLOR=never
  "CARGO_TARGET_DIR=$repair_lane/target"
  GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=core.fsmonitor GIT_CONFIG_VALUE_0=false
  PATH=/Users/stephen/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin
  "$@"
)
printf '%q ' "${repair_command[@]}" > "$repair_evidence/command"
printf '\n' >> "$repair_evidence/command"
TIMEFORMAT='real_seconds=%R user_seconds=%U system_seconds=%S'
if { time "${repair_command[@]}" > "$repair_evidence/stdout" 2> "$repair_evidence/stderr"; } 2> "$repair_evidence/timing"; then
  repair_status=0
else
  repair_status=$?
fi
printf 'exit_status=%s\n' "$repair_status" > "$repair_evidence/result"
if shasum -a 256 -c "$repair_evidence/before.sha256" > "$repair_evidence/hashes-after" 2>&1; then
  repair_hash_status=0
else
  repair_hash_status=$?
fi
printf 'hash_check_status=%s\n' "$repair_hash_status" >> "$repair_evidence/result"
cat "$repair_evidence/result" "$repair_evidence/timing" "$repair_evidence/stdout" "$repair_evidence/stderr"
test "$repair_hash_status" -eq 0
exit "$repair_status"
