# Task 9 format preflight

The controller checked sections 4.2 and 8.2.2 of the [2012 base media file format standard](https://ossrs.io/lts/zh-cn/assets/files/ISO_IEC_14496-12-base-format-2012-b70dd5f101daecd072700609842c9649.pdf) on 2026-09-22, following Luna's lookup. This is authored standard text on a public mirror, not verification of the latest edition.

- Box size includes its header. Size 1 introduces a 64-bit size; size 0 extends to the file end.
- Creation, modification, timescale and duration have body-relative offsets 4/8/12/16 with 32-bit widths in version 0. Version 1 uses offsets 4/12/20/24 and widths 64/64/32/64.
- Creation describes the presentation, using the 1904 epoch in Coordinated Universal Time. Capture-time interpretation is VPT's choice.
- Duration uses timescale units; all-one bits mean unknown duration. Whole-second flooring is VPT's conversion choice.

Controller corrections, source-derived and not runtime observations:

1. The sample resolves size 0 against a containing-box boundary. A zero-size child inside a movie followed by another top-level box must not be shortened to fit that movie. Test the counterexample first; preserve file-end semantics and parent-bound checks.
2. Refuse unknown-duration sentinels in both versions as InvalidMvhd instead of returning enormous durations. Test these before implementation.

Keep the approved bounded wholeness gate. Do not expand it into general media validation.
