### Task 29: The managed symlink: `vpt symlink deploy` and `vpt symlink verify`

**Files:**

- Create: `crates/vpt-adapters/src/symlink.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`
- Create: `crates/vpt/src/commands/symlink.rs`
- Modify: `crates/vpt/src/commands/mod.rs`, `crates/vpt/src/lib.rs`
- Test: `crates/vpt/tests/symlink.rs`

**Interfaces:**

- Consumes
  `settings_from(environment: &Environment, config: Option<&Path>) -> Result<Settings, Box<ErrorDocument>>`,
  `Settings.home: PathBuf`, `Settings.symlink_target: Option<PathBuf>`,
  `RootDir::open(path: &Path) -> Result<RootDir, ContainedError>`, and
  `RootDir::subdirectory(&self, name: &str) -> Result<RootDir, ContainedError>`.

- Adapter root exports: `LinkState::{Absent, LinkTo(PathBuf), Other(String), Unreadable(String)}`;
  `SymlinkError::{Occupied(String), TargetParentMissing, TargetNotDirectory, TargetMissing, Missing, WrongTarget(PathBuf), Io(String)}`;
  `inspect_symlink(link: &Path) -> LinkState`;
  `deploy_symlink(link: &Path, target: &Path) -> Result<(), SymlinkError>`;
  `verify_symlink(link: &Path, target: &Path) -> Result<(), SymlinkError>`.

- Command-private functions `deploy(environment: &Environment, config: Option<&Path>) -> Outcome` and
  `verify(environment: &Environment, config: Option<&Path>) -> Outcome`.

- [ ] **Step 1: Write the failing tests**

In adapter `lib.rs`, register `mod symlink;` and
`pub use symlink::{LinkState, SymlinkError, deploy as deploy_symlink, inspect as inspect_symlink, verify as verify_symlink};`.
The file starts with the test module. Register `pub(crate) mod symlink;` in `commands/mod.rs` and create
that command file empty.

`crates/vpt-adapters/src/symlink.rs`, test section:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    fn setup() -> (tempfile::TempDir, std::path::PathBuf, std::path::PathBuf) {
        let dir = tempfile::tempdir().expect("dir");
        let root = dir.path().canonicalize().expect("canonical");
        std::fs::create_dir(root.join("notes")).expect("parent");
        let link = root.join(".vpt");
        let target = root.join("notes/vpt");
        (dir, link, target)
    }

    #[test]
    fn deploy_creates_a_missing_leaf_and_the_link_and_verify_then_passes() {
        let (_dir, link, target) = setup();
        deploy(&link, &target).expect("deployed");
        assert!(target.is_dir());
        assert_eq!(std::fs::read_link(&link).expect("link"), target);
        assert_eq!(verify(&link, &target), Ok(()));
    }

    #[test]
    fn deploy_is_idempotent_over_its_own_link() {
        let (_dir, link, target) = setup();
        deploy(&link, &target).expect("first");
        assert_eq!(deploy(&link, &target), Ok(()));
    }

    #[test]
    fn deploy_refuses_a_directory_in_the_way_naming_what_is_there() {
        let (_dir, link, target) = setup();
        std::fs::create_dir(&link).expect("dir in the way");
        assert_eq!(deploy(&link, &target), Err(SymlinkError::Occupied("a directory".into())));
    }

    #[test]
    fn deploy_refuses_a_link_to_somewhere_else_and_a_missing_target_parent() {
        let (dir, link, target) = setup();
        std::os::unix::fs::symlink(dir.path().join("elsewhere"), &link).expect("other link");
        assert!(matches!(deploy(&link, &target), Err(SymlinkError::Occupied(_))));
        let orphan = dir.path().join("missing/parent/vpt");
        assert_eq!(deploy(&dir.path().join("other"), &orphan), Err(SymlinkError::TargetParentMissing));
    }

    #[test]
    fn verify_names_a_missing_link_and_a_wrong_target_and_writes_nothing() {
        let (dir, link, target) = setup();
        assert_eq!(verify(&link, &target), Err(SymlinkError::Missing));
        std::os::unix::fs::symlink(dir.path().join("notes"), &link).expect("wrong link");
        assert_eq!(verify(&link, &target), Err(SymlinkError::WrongTarget(dir.path().join("notes"))));
        assert!(!target.exists());
    }

    #[test]
    fn relative_equivalent_links_verify_and_deploy() {
        let (_dir, link, target) = setup();
        std::fs::create_dir(&target).expect("target");
        std::os::unix::fs::symlink("notes/vpt", &link).expect("relative");
        assert_eq!(verify(&link, &target), Ok(()));
        assert_eq!(deploy(&link, &target), Ok(()));
        assert_eq!(std::fs::read_link(&link).expect("preserved"), PathBuf::from("notes/vpt"));
    }

    #[test]
    fn matching_dangling_link_fails_verification_and_deploy_creates_the_leaf() {
        let (_dir, link, target) = setup();
        std::os::unix::fs::symlink("notes/vpt", &link).expect("relative");
        assert_eq!(verify(&link, &target), Err(SymlinkError::TargetMissing));
        assert!(!target.exists());
        assert_eq!(deploy(&link, &target), Ok(()));
        assert!(target.is_dir());
        assert_eq!(verify(&link, &target), Ok(()));
    }

    #[test]
    fn regular_file_target_is_refused_without_replacing_its_bytes() {
        let (_dir, link, target) = setup();
        std::fs::write(&target, b"owned by operator").expect("file");
        std::os::unix::fs::symlink(&target, &link).expect("link");
        assert_eq!(verify(&link, &target), Err(SymlinkError::TargetNotDirectory));
        assert_eq!(deploy(&link, &target), Err(SymlinkError::TargetNotDirectory));
        assert_eq!(std::fs::read(&target).expect("untouched"), b"owned by operator");
    }

}
```

`crates/vpt/tests/symlink.rs`:

```rust
mod support;

use support::{Sandbox, run, stderr, stdout};

fn configured(name: &str) -> (Sandbox, std::path::PathBuf) {
    let sandbox = Sandbox::new(name);
    std::fs::create_dir_all(sandbox.path().join("home/notes")).expect("vault");
    let target = sandbox.path().join("home/notes/vpt");
    let config = format!(
        "config_version = 1\n[home]\nsymlink_target = \"{}\"\nstate_dir = \"{}\"\n[source]\nrecordings_dir = \"{}\"\n",
        target.display(),
        sandbox.path().join("state/vpt").display(),
        sandbox.path().join("voice-memos/Recordings").display()
    );
    std::fs::create_dir_all(sandbox.config_path().parent().expect("dir")).expect("config dir");
    std::fs::write(sandbox.config_path(), config).expect("config");
    (sandbox, target)
}

#[test]
fn deploy_creates_the_link_at_the_default_home_and_verify_passes() {
    let (sandbox, target) = configured("symlink-deploy");

    let output = run(sandbox.vpt().args(["symlink", "deploy", "--json"]));

    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["link"], sandbox.path().join("home/.vpt").to_string_lossy());
    assert_eq!(document["target"], target.to_string_lossy());
    assert_eq!(document["ok"], true);
    let verify = run(sandbox.vpt().args(["symlink", "verify"]));
    assert_eq!(verify.status.code(), Some(0));
}

#[test]
fn verify_exits_3_naming_the_discrepancy_and_deploy_refuses_an_occupied_path() {
    let (sandbox, _target) = configured("symlink-verify");
    std::fs::create_dir(sandbox.path().join("home/.vpt")).expect("directory in the way");

    let verify = run(sandbox.vpt().args(["symlink", "verify", "--json"]));
    assert_eq!(verify.status.code(), Some(3));
    let error: serde_json::Value = serde_json::from_str(&stderr(&verify)).expect("json");
    assert_eq!(error["error"]["rule"], "symlink_verify");

    let deploy = run(sandbox.vpt().args(["symlink", "deploy"]));
    assert_eq!(deploy.status.code(), Some(3));
    assert!(stderr(&deploy).contains("a directory"), "{}", stderr(&deploy));
}

#[test]
fn without_a_symlink_target_both_verbs_are_usage_errors() {
    let sandbox = Sandbox::new("symlink-unset");
    sandbox.write_config("");

    let output = run(sandbox.vpt().args(["symlink", "verify", "--json"]));

    assert_eq!(output.status.code(), Some(2));
    assert!(stderr(&output).contains("symlink_target"), "{}", stderr(&output));
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run separately: `cargo test -p vpt-adapters symlink` and
`cargo test -p vpt --features dev-tools --test symlink`. Expected: compile errors naming `deploy` and
`verify`; the command tests FAIL with exit 2. Both new test modules must be compiled and selected; zero
selected tests or a successful command does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-adapters/src/symlink.rs`:

```rust
use std::path::{Path, PathBuf};
use crate::{ContainedError, RootDir};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LinkState {
    Absent,
    LinkTo(PathBuf),
    Other(String),
    Unreadable(String),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SymlinkError {
    Occupied(String),
    TargetParentMissing,
    TargetNotDirectory,
    TargetMissing,
    Missing,
    WrongTarget(PathBuf),
    Io(String),
}

pub fn inspect(link: &Path) -> LinkState {
    match std::fs::symlink_metadata(link) {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => LinkState::Absent,
        Err(error) => LinkState::Unreadable(error.kind().to_string()),
        Ok(metadata) if metadata.file_type().is_symlink() => {
            std::fs::read_link(link).map_or_else(
                |error| LinkState::Unreadable(error.kind().to_string()), LinkState::LinkTo,
            )
        }
        Ok(metadata) if metadata.is_dir() => LinkState::Other("a directory".into()),
        Ok(_) => LinkState::Other("a file".into()),
    }
}

fn destination(link: &Path, value: &Path) -> PathBuf {
    if value.is_absolute() { value.to_path_buf() } else { link.parent().unwrap_or(Path::new(".")).join(value) }
}

fn resolved_directory(path: &Path) -> Result<PathBuf, SymlinkError> {
    let resolved = path.canonicalize().map_err(|error| {
        if error.kind() == std::io::ErrorKind::NotFound { SymlinkError::TargetMissing }
        else { SymlinkError::Io(error.kind().to_string()) }
    })?;
    let metadata = resolved.metadata().map_err(|error| SymlinkError::Io(error.kind().to_string()))?;
    if !metadata.is_dir() {
        return Err(SymlinkError::TargetNotDirectory);
    }
    Ok(resolved)
}

fn ensure_target(target: &Path) -> Result<PathBuf, SymlinkError> {
    match resolved_directory(target) {
        Ok(path) => Ok(path),
        Err(SymlinkError::TargetMissing) => {
            let parent = target.parent().ok_or(SymlinkError::TargetParentMissing)?;
            let parent = resolved_directory(parent).map_err(|_| SymlinkError::TargetParentMissing)?;
            let leaf = target.file_name().and_then(|name| name.to_str()).ok_or(SymlinkError::TargetNotDirectory)?;
            let parent = RootDir::open(&parent).map_err(contained)?;
            parent.subdirectory(leaf).map(|root| root.path().to_path_buf()).map_err(contained)
        }
        Err(error) => Err(error),
    }
}

fn contained(error: ContainedError) -> SymlinkError {
    match error {
        ContainedError::NotADirectory(_) | ContainedError::NotRegular(_) => SymlinkError::TargetNotDirectory,
        error => SymlinkError::Io(format!("{error:?}")),
    }
}

fn prospective(path: &Path) -> Option<PathBuf> {
    if let Ok(path) = path.canonicalize() { return Some(path); }
    Some(path.parent()?.canonicalize().ok()?.join(path.file_name()?))
}

pub fn deploy(link: &Path, target: &Path) -> Result<(), SymlinkError> {
    let existing = match inspect(link) {
        LinkState::LinkTo(value) => {
            let destination = destination(link, &value);
            if prospective(&destination) != prospective(target) || prospective(target).is_none() {
                return Err(SymlinkError::Occupied(format!("a link to {}", value.display())));
            }
            true
        }
        LinkState::Other(what) => return Err(SymlinkError::Occupied(what)),
        LinkState::Unreadable(detail) => return Err(SymlinkError::Io(detail)),
        LinkState::Absent => false,
    };
    let target = ensure_target(target)?;
    if existing {
        return verify(link, &target);
    }
    std::os::unix::fs::symlink(target, link).map_err(|error| SymlinkError::Io(error.kind().to_string()))
}

pub fn verify(link: &Path, target: &Path) -> Result<(), SymlinkError> {
    match inspect(link) {
        LinkState::LinkTo(value) => {
            if prospective(&destination(link, &value)) != prospective(target) {
                return Err(SymlinkError::WrongTarget(value));
            }
            let expected = resolved_directory(target)?;
            let found = resolved_directory(&destination(link, &value))?;
            if found == expected { Ok(()) } else { Err(SymlinkError::WrongTarget(value)) }
        }
        LinkState::Absent => Err(SymlinkError::Missing),
        LinkState::Other(what) => Err(SymlinkError::Occupied(what)),
        LinkState::Unreadable(detail) => Err(SymlinkError::Io(detail)),
    }
}
```

Add `mod symlink;` and
`pub use symlink::{LinkState, SymlinkError, deploy as deploy_symlink, inspect as inspect_symlink, verify as verify_symlink};`
to the adapters `lib.rs` in Step 1. `crates/vpt/src/commands/symlink.rs`:

```rust
//! `vpt symlink deploy` and `vpt symlink verify`.

use crate::cli::output::Outcome;
use crate::compose::{Environment, settings_from};
use serde_json::json;
use std::path::{Path, PathBuf};
use vpt_adapters::{SymlinkError, deploy_symlink as deploy_link, verify_symlink as verify_link};
use vpt_protocol::error::{ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

fn link_and_target(environment: &Environment, config: Option<&Path>) -> Result<(PathBuf, PathBuf), Box<ErrorDocument>> {
    let settings = settings_from(environment, config)?;
    let target = settings.symlink_target.ok_or_else(|| ErrorDocument::new(ErrorKind::Usage, "home.symlink_target is not set"))?;
    if !settings.home.is_absolute() || !target.is_absolute() {
        return Err(Box::new(ErrorDocument::new(ErrorKind::Config, "home.path and home.symlink_target must be absolute")));
    }
    Ok((settings.home, target))
}

fn describe(error: &SymlinkError, link: &Path, target: &Path) -> String {
    match error {
        SymlinkError::Occupied(what) => format!("{} exists and is {what}", link.display()),
        SymlinkError::TargetParentMissing => format!("the parent of {} does not exist", target.display()),
        SymlinkError::TargetNotDirectory => format!("{} is not a directory", target.display()),
        SymlinkError::TargetMissing => format!("{} does not exist", target.display()),
        SymlinkError::Missing => format!("{} does not exist", link.display()),
        SymlinkError::WrongTarget(existing) => format!("{} points at {} rather than {}", link.display(), existing.display(), target.display()),
        SymlinkError::Io(detail) => detail.clone(),
    }
}

fn outcome(verb: &str, rule: &str, result: Result<(), SymlinkError>, link: &Path, target: &Path) -> Outcome {
    match result {
        Ok(()) => Outcome::Success {
            human: format!("{} -> {}\n", link.display(), target.display()),
            document: document(verb, json!({"link": link, "target": target, "ok": true})),
        },
        Err(SymlinkError::Io(detail)) => Outcome::Failure(ErrorDocument::new(ErrorKind::Store, detail)),
        Err(error) => Outcome::Failure(ErrorDocument::new(ErrorKind::Refused, describe(&error, link, target)).rule(rule)),
    }
}

pub fn deploy(environment: &Environment, config: Option<&Path>) -> Outcome {
    match link_and_target(environment, config) {
        Ok((link, target)) => outcome("symlink deploy", "symlink_deploy", deploy_link(&link, &target), &link, &target),
        Err(error) => Outcome::Failure(*error),
    }
}

pub fn verify(environment: &Environment, config: Option<&Path>) -> Outcome {
    match link_and_target(environment, config) {
        Ok((link, target)) => outcome("symlink verify", "symlink_verify", verify_link(&link, &target), &link, &target),
        Err(error) => Outcome::Failure(*error),
    }
}
```

`settings_from` (Task 27) is the only startup step these verbs take: no roots, no ledger, no helper.
Dispatch arms:

```rust
        Verb::SymlinkDeploy => commands::symlink::deploy(&environment, invocation.config.as_deref()),
        Verb::SymlinkVerify => commands::symlink::verify(&environment, invocation.config.as_deref()),
```

and `commands/mod.rs` gains `symlink`.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test --workspace --features dev-tools`

Expected: all PASS.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(symlink): vpt symlink deploy and verify over the default home"
```

______________________________________________________________________

