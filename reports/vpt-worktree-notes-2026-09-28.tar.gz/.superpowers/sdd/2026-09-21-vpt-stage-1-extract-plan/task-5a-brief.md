### Task 5a: Checked access below a root

## Controller execution constraints

- Read the ledger's Task 5a enumeration ruling and preserve the accepted public API. names() must enumerate through the held descriptor using an independent directory stream, not the absolute path, with correct ownership, EOF/error distinction and sorting. Preserve the sample's invalid-UTF-8-name skip policy.
- Add the deterministic private-helper substitution test described in the ledger: retain and revalidate A, replace its path with a link to B, enumerate A completely twice. Keep public pre-existing substitution refusal coverage. Mutating back to path-based enumeration must fail the named leaf.
- The FIFO open rejection test must have a real deadline and complete owned-process cleanup. The sample's direct blocking call would hang after removing O_NONBLOCK. Prove that exact mutation fails within one second without an unbounded thread join or arbitrary synchronization sleep.
- Verify native API signatures and flags against installed headers or official documentation. Do not implement an unreviewed directory-stream abstraction or use global test hooks.
- Test-first means compiling behavioral failures, not missing-symbol errors. Preserve all existing configuration structural/value/root tests and prior command regressions.
- Follow clean-code-rust limits by a natural filesystem responsibility split, not oversized files, code golf or blanket lint exceptions. No unsolicited docstrings; unsafe comments must state the exact safety invariant.
- Run raw RED/GREEN and mutation/control evidence, current full gates, timings, staged-file size audit and committed-HEAD gitleaks. Write task-5a-report.md.
- No subagents, new worktree, unrelated edits, push, pull request, installation, live paths or destructive cleanup.


Spec section 4.1: below a resolved root, a path that traverses a symbolic link in any component, or that
escapes the root, is refused when it is opened or published, exit 3 `path_escape`. Stage 1 owns that rule
from its first file operation, and it owns it through directory descriptors: a resolved root is opened
once as a directory handle, and every leaf below it is judged, opened, created, renamed or synced
relative to that handle with no-follow semantics, so a component swapped for a link after resolution
changes nothing. Every root is canonical when Task 5 resolves it, and this module admits exactly one
normal component below it. The ledger, the lock, the title copy, the archive, publication and retention
all go through it; a ledger row or a journal entry is validated with `leaf_below` before anything reads,
writes or hands its path to the helper.

**Files:**

- Create: `crates/vpt-adapters/src/contained.rs`, `crates/vpt-adapters/src/contained/tests.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`, `crates/vpt-adapters/src/config/roots.rs`,
  `crates/vpt-adapters/src/config/roots/tests.rs`, `crates/vpt-adapters/src/config/load.rs`

**Interfaces:**

- Consumes: `config::{RootError, Roots}` and its private
  `private_dir(path: &Path, key: &str) -> Result<(), RootError>` creator from Task 5.

- Produces: descriptor-relative creation behind `Roots::create_state_dir` and `Roots::create_leaves`;
  links introduced after resolution return `RootError::PathEscape { key }`.

- Produces, re-exported from `vpt_adapters`:
  `ContainedError::{Escape { root: PathBuf, path: PathBuf }, NotRegular(PathBuf),`
  `NotADirectory(PathBuf),` `Io { path: PathBuf, kind: std::io::ErrorKind }}`;
  `Access::{Read, Write, ReadWrite}`; `Kind::{File, Directory, Link, Other}`;
  `Stat { pub kind: Kind, pub size: u64, pub mtime_secs: i64, pub mtime_nanos: u32, pub flags: u32 }`
  (the leaf's own attributes, a link judged as a link);
  `leaf_below(root: &Path, path: &Path) -> Result<PathBuf, ContainedError>` (a bare file name or
  `<root>/<name>`, one normal component, never `.`, `..` or a nested path); `RootDir` (`Debug`), the open
  directory descriptor of one canonical root, with
  `RootDir::open(path: &Path) -> Result<RootDir, ContainedError>` (a link in any component or a
  non-directory is `NotADirectory`), `fn path(&self) -> &Path`,
  `fn try_clone(&self) -> Result<RootDir, ContainedError>` (duplicate the retained descriptor),
  `fn identity(&self) -> Result<(u64, u64), ContainedError>` (device and inode of that descriptor),
  `fn revalidate(&self) -> Result<(), ContainedError>` (reopen without following links and require the
  same device and inode before handing an absolute path to another process),
  `fn leaf(&self, path: &Path) -> Result<PathBuf, ContainedError>` (`leaf_below` against this root),
  `fn stat(&self, path: &Path) -> Result<Stat, ContainedError>` (`fstatat` without following),
  `fn regular(&self, path: &Path) -> Result<PathBuf, ContainedError>` (an existing regular file, a link
  refused as `NotRegular`),
  `fn open_file(&self, path: &Path, access: Access) -> Result<File, ContainedError>` (`openat` with
  `O_NOFOLLOW`, `O_CLOEXEC` and `O_NONBLOCK`; a link or a non-file at the leaf is `NotRegular`),
  `fn create_file(&self, path: &Path, mode: u32) -> Result<File, ContainedError>` (exclusive creation at
  that mode, an existing name is `Io` with kind `AlreadyExists`),
  `fn subdirectory(&self, name: &str) -> Result<RootDir, ContainedError>` (a mode-0700 directory, created
  when missing, opened as its own handle; a link or a file there is `NotADirectory`),
  `fn open_subdirectory(&self, name: &str) -> Result<RootDir, ContainedError>` (descriptor-relative,
  read-only traversal; never creates a missing directory),
  `fn rename_over(&self, from: &Path, to: &Path) -> Result<(), ContainedError>` (replaces the target),
  `fn rename_exclusive(&self, from: &Path, to: &Path) -> Result<bool, ContainedError>` (`false` when the
  target exists, nothing moved), `fn sync(&self) -> Result<(), ContainedError>` (the directory itself),
  `fn names(&self) -> Result<Vec<String>, ContainedError>` (every entry name in sorted order; a name that
  is not UTF-8 is skipped, and every name is judged through `stat` or `open_file` before use),
  `fn c_name(&self, path: &Path) -> Result<CString, ContainedError>` (the validated leaf's file name as a
  C string); `RootDir` implements `std::os::fd::AsFd`, so a caller that clones into the root with
  `fclonefileat` names it by descriptor.

- Produces: `ConfigError::PathEscape(String)`;
  `load_file(path: &Path) -> Result<toml::Table, ConfigError>` opens the selected leaf read-only below a
  checked configuration directory.

- [ ] **Step 1: Write the failing tests**

`crates/vpt-adapters/src/lib.rs` gains `mod contained;` and
`pub use contained::{Access, ContainedError, Kind, RootDir, Stat, leaf_below};`.
`crates/vpt-adapters/src/contained.rs` starts with:

```rust
#[cfg(test)]
mod tests;
```

`crates/vpt-adapters/src/contained/tests.rs`:

```rust
use super::*;
use std::os::unix::fs::PermissionsExt;

fn root() -> (tempfile::TempDir, RootDir) {
    let temp = tempfile::tempdir().expect("temp");
    let path = temp.path().canonicalize().expect("canonical");
    std::fs::write(path.join("plain.m4a"), b"bytes").expect("plain");
    std::fs::create_dir(path.join("sub")).expect("sub");
    std::os::unix::fs::symlink(path.join("plain.m4a"), path.join("link.m4a")).expect("link");
    std::os::unix::fs::symlink(path.join("sub"), path.join("dirlink")).expect("dir link");
    let root = RootDir::open(&path).expect("root");
    (temp, root)
}

#[test]
fn a_bare_name_or_the_root_joined_with_it_is_the_one_accepted_shape() {
    let (_temp, root) = root();
    let expected = root.path().join("plain.m4a");
    assert_eq!(root.leaf(Path::new("plain.m4a")), Ok(expected.clone()));
    assert_eq!(root.leaf(&expected), Ok(expected.clone()));
    assert_eq!(leaf_below(root.path(), Path::new("plain.m4a")), Ok(expected));
}

#[test]
fn escapes_and_nested_paths_are_refused_naming_root_and_path() {
    let (_temp, root) = root();
    for path in ["..", "../x", "sub/x", ".", "", "/etc/passwd"] {
        let outcome = root.leaf(Path::new(path));
        assert!(matches!(outcome, Err(ContainedError::Escape { .. })), "{path}: {outcome:?}");
    }
    let elsewhere = root.path().parent().expect("parent").join("plain.m4a");
    assert_eq!(
        root.leaf(&elsewhere),
        Err(ContainedError::Escape { root: root.path().to_path_buf(), path: elsewhere })
    );
}

#[test]
fn a_root_must_be_a_directory_reached_through_no_link() {
    let (_temp, root) = root();
    let through_link = root.path().join("dirlink");
    assert_eq!(RootDir::open(&through_link).err(), Some(ContainedError::NotADirectory(through_link)));
    let file = root.path().join("plain.m4a");
    assert_eq!(RootDir::open(&file).err(), Some(ContainedError::NotADirectory(file)));
    assert!(RootDir::open(&root.path().join("sub")).is_ok());
}

#[test]
fn stat_judges_the_leaf_itself_and_regular_refuses_a_link() {
    let (_temp, root) = root();
    let plain = root.stat(Path::new("plain.m4a")).expect("stat");
    assert_eq!((plain.kind, plain.size), (Kind::File, 5));
    assert!(plain.mtime_secs > 0 && plain.mtime_nanos < 1_000_000_000);
    assert_eq!(root.stat(Path::new("link.m4a")).expect("stat").kind, Kind::Link);
    assert_eq!(root.stat(Path::new("sub")).expect("stat").kind, Kind::Directory);
    assert_eq!(root.regular(Path::new("plain.m4a")), Ok(root.path().join("plain.m4a")));
    assert_eq!(root.regular(Path::new("link.m4a")), Err(ContainedError::NotRegular(root.path().join("link.m4a"))));
    let absent = root.stat(Path::new("absent.m4a"));
    assert!(matches!(absent, Err(ContainedError::Io { kind: std::io::ErrorKind::NotFound, .. })), "{absent:?}");
}

#[test]
fn open_file_refuses_a_link_and_a_directory_at_the_leaf() {
    let (_temp, root) = root();
    assert!(root.open_file(Path::new("plain.m4a"), Access::Read).is_ok());
    let link = root.open_file(Path::new("link.m4a"), Access::Read).err();
    assert_eq!(link, Some(ContainedError::NotRegular(root.path().join("link.m4a"))));
    let directory = root.open_file(Path::new("sub"), Access::Read).err();
    assert_eq!(directory, Some(ContainedError::NotRegular(root.path().join("sub"))));
}

#[test]
fn create_file_is_exclusive_and_sets_the_mode() {
    let (_temp, root) = root();
    let file = root.create_file(Path::new("new.m4a"), 0o600).expect("created");
    assert_eq!(file.metadata().expect("meta").permissions().mode() & 0o777, 0o600);
    let again = root.create_file(Path::new("new.m4a"), 0o600).err();
    assert!(matches!(again, Some(ContainedError::Io { kind: std::io::ErrorKind::AlreadyExists, .. })), "{again:?}");
    assert!(root.create_file(Path::new("link.m4a"), 0o600).is_err());
    assert_eq!(std::fs::read(root.path().join("plain.m4a")).expect("untouched"), b"bytes");
}

#[test]
fn subdirectory_creates_0700_once_and_refuses_a_link_or_a_file() {
    let (_temp, root) = root();
    let made = root.subdirectory("title-copy").expect("made");
    assert_eq!(made.path(), root.path().join("title-copy"));
    assert_eq!(std::fs::metadata(made.path()).expect("meta").permissions().mode() & 0o777, 0o700);
    assert_eq!(root.subdirectory("title-copy").expect("again").path(), made.path());
    assert_eq!(root.subdirectory("dirlink").err(), Some(ContainedError::NotADirectory(root.path().join("dirlink"))));
    assert_eq!(root.subdirectory("plain.m4a").err(), Some(ContainedError::NotADirectory(root.path().join("plain.m4a"))));
}

#[test]
fn rename_exclusive_keeps_an_existing_target_and_rename_over_replaces_it() {
    let (_temp, root) = root();
    std::fs::write(root.path().join("a"), b"A").expect("a");
    std::fs::write(root.path().join("b"), b"B").expect("b");
    assert_eq!(root.rename_exclusive(Path::new("a"), Path::new("b")), Ok(false));
    assert_eq!(std::fs::read(root.path().join("b")).expect("kept"), b"B");
    assert!(root.path().join("a").exists());
    assert_eq!(root.rename_exclusive(Path::new("a"), Path::new("c")), Ok(true));
    assert!(!root.path().join("a").exists());
    assert_eq!(root.rename_over(Path::new("c"), Path::new("b")), Ok(()));
    assert_eq!(std::fs::read(root.path().join("b")).expect("replaced"), b"A");
    assert!(!root.path().join("c").exists());
    assert!(matches!(root.rename_over(Path::new("../x"), Path::new("b")), Err(ContainedError::Escape { .. })));
}

#[test]
fn names_lists_every_entry_sorted_and_sync_succeeds() {
    let (_temp, root) = root();
    assert_eq!(root.names().expect("names"), vec!["dirlink", "link.m4a", "plain.m4a", "sub"]);
    assert_eq!(root.sync(), Ok(()));
    assert_eq!(root.c_name(Path::new("plain.m4a")).expect("name").as_bytes(), b"plain.m4a");
    assert!(matches!(root.c_name(Path::new("sub/x")), Err(ContainedError::Escape { .. })));
}

#[test]
fn revalidation_refuses_a_replaced_root_directory() {
    let temp = tempfile::tempdir().expect("temp");
    let base = temp.path().canonicalize().expect("canonical");
    let audio = base.join("audio");
    std::fs::create_dir(&audio).expect("audio");
    let root = RootDir::open(&audio).expect("root");
    assert_eq!(root.revalidate(), Ok(()));
    std::fs::rename(&audio, base.join("original")).expect("move");
    std::fs::create_dir(&audio).expect("replacement");
    assert!(matches!(root.names(), Err(ContainedError::Escape { .. })));
    assert!(matches!(root.revalidate(), Err(ContainedError::Escape { .. })));
}

#[test]
fn reading_a_subdirectory_creates_nothing_and_refuses_a_link() {
    let (_temp, root) = root();
    assert!(root.open_subdirectory("sub").is_ok());
    assert!(root.open_subdirectory("dirlink").is_err());
    assert!(root.open_subdirectory("missing").is_err());
    assert!(!root.path().join("missing").exists());
}

#[test]
fn opening_a_fifo_returns_not_regular_without_a_writer() {
    let temp = tempfile::tempdir().expect("temp");
    let path = temp.path().canonicalize().expect("canonical");
    let root = RootDir::open(&path).expect("root");
    let fifo = path.join("fifo");
    let name = c_string(&fifo).expect("name");
    // SAFETY: the temporary path is NUL-terminated and outlives the call.
    assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
    assert!(matches!(
        root.open_file(&fifo, Access::Read),
        Err(ContainedError::NotRegular(_))
    ));
}

#[test]
fn a_cloned_root_retains_its_identity_and_refuses_replacement() {
    let temp = tempfile::tempdir().expect("temp");
    let base = temp.path().canonicalize().expect("canonical");
    let path = base.join("root");
    std::fs::create_dir(&path).expect("root");
    let root = RootDir::open(&path).expect("open");
    let clone = root.try_clone().expect("clone");
    assert_eq!(
        root.identity().expect("identity"),
        clone.identity().expect("identity")
    );
    std::fs::rename(&path, base.join("held")).expect("move");
    std::fs::create_dir(&path).expect("replacement");
    assert!(clone.revalidate().is_err());
}
```

Append to `config/roots/tests.rs`:

```rust
#[test]
fn creating_roots_refuses_a_link_added_after_resolution() {
    let temp = fixture();
    let roots = resolve(&settings_in(temp.path(), ""), &temp.path().join("cfg")).expect("roots");
    let before = entries(&roots.container);
    std::os::unix::fs::symlink(&roots.container, &roots.state_dir).expect("state link");
    assert_eq!(roots.create_state_dir(), Err(RootError::PathEscape { key: "home.state_dir".into() }));
    std::fs::rename(&roots.home, temp.path().join("original-home")).expect("move home");
    std::os::unix::fs::symlink(&roots.container, &roots.home).expect("home link");
    assert_eq!(roots.create_leaves(), Err(RootError::PathEscape { key: "home.path".into() }));
    assert_eq!(entries(&roots.container), before);
}
```

Add `PathEscape(String)` to `ConfigError` before this red run. Add this test inside the existing private
test module in `config/load.rs`:

```rust
#[test]
fn a_configuration_leaf_symlink_is_refused() {
    let temp = tempfile::tempdir().expect("temp");
    let target = temp.path().join("target.toml");
    let selected = temp.path().join("config.toml");
    std::fs::write(&target, "config_version = 1\n").expect("target");
    std::os::unix::fs::symlink(&target, &selected).expect("link");

    assert_eq!(
        load_file(&selected),
        Err(ConfigError::PathEscape(selected.display().to_string()))
    );
    assert_eq!(
        std::fs::read_to_string(target).expect("unchanged"),
        "config_version = 1\n"
    );
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters contained`

Expected: the build of the `contained::tests` module fails with `cannot find` for `RootDir`,
`leaf_below`, `ContainedError`, `Access` and `Kind`. The module is compiled and selected; a run that
selects zero tests, or that succeeds, does not satisfy this step. Also run
`cargo test -p vpt-adapters creating_roots_refuses_a_link_added_after_resolution`; once the new module
compiles, it must fail because the old creator accepts the state link. Run
`cargo test -p vpt-adapters a_configuration_leaf_symlink_is_refused` independently and require the
current raw loader to fail this regression.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-adapters/src/contained.rs`, above the existing private test-module declaration:

```rust
//! Checked access below a resolved root through its directory descriptor:
//! exactly one normal component, and a leaf that is never followed through a
//! symbolic link.

use std::ffi::CString;
use std::fs::File;
use std::os::fd::{AsFd, AsRawFd, BorrowedFd, FromRawFd, OwnedFd};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::PermissionsExt;
use std::path::{Component, Path, PathBuf};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ContainedError {
    Escape {
        root: PathBuf,
        path: PathBuf,
    },
    NotRegular(PathBuf),
    NotADirectory(PathBuf),
    Io {
        path: PathBuf,
        kind: std::io::ErrorKind,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Access {
    Read,
    Write,
    ReadWrite,
}

impl Access {
    fn flags(self) -> libc::c_int {
        match self {
            Access::Read => libc::O_RDONLY,
            Access::Write => libc::O_WRONLY,
            Access::ReadWrite => libc::O_RDWR,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    File,
    Directory,
    Link,
    Other,
}

/// The leaf's own attributes: a link is reported as a link, never followed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Stat {
    pub kind: Kind,
    pub size: u64,
    pub mtime_secs: i64,
    pub mtime_nanos: u32,
    pub flags: u32,
}

/// The open directory descriptor of one canonical root.
#[derive(Debug)]
pub struct RootDir {
    fd: OwnedFd,
    path: PathBuf,
}

const NO_FOLLOW: libc::c_int = libc::O_NOFOLLOW | libc::O_CLOEXEC;

fn escape(root: &Path, path: &Path) -> ContainedError {
    ContainedError::Escape {
        root: root.to_path_buf(),
        path: path.to_path_buf(),
    }
}

fn io(path: &Path, error: &std::io::Error) -> ContainedError {
    ContainedError::Io {
        path: path.to_path_buf(),
        kind: error.kind(),
    }
}

fn c_string(path: &Path) -> Result<CString, ContainedError> {
    CString::new(path.as_os_str().as_bytes()).map_err(|_| {
        io(
            path,
            &std::io::Error::from(std::io::ErrorKind::InvalidInput),
        )
    })
}

/// The file name of a validated leaf, as the C string `openat` and friends take.
fn c_name(leaf: &Path) -> Result<CString, ContainedError> {
    let name = leaf.file_name().ok_or_else(|| {
        io(
            leaf,
            &std::io::Error::from(std::io::ErrorKind::InvalidInput),
        )
    })?;
    c_string(Path::new(name))
}

/// `<root>/<name>` for a bare name, or the path itself when it already is exactly that.
pub fn leaf_below(root: &Path, path: &Path) -> Result<PathBuf, ContainedError> {
    let relative = if path.is_absolute() {
        path.strip_prefix(root).map_err(|_| escape(root, path))?
    } else {
        path
    };
    let mut components = relative.components();
    match (components.next(), components.next()) {
        (Some(Component::Normal(name)), None) if !name.is_empty() => Ok(root.join(name)),
        _ => Err(escape(root, path)),
    }
}

impl RootDir {
    /// Open a canonical root; a link in any component or a non-directory is refused.
    pub fn open(path: &Path) -> Result<RootDir, ContainedError> {
        let c_path = c_string(path)?;
        let flags = libc::O_RDONLY | libc::O_DIRECTORY | libc::O_NOFOLLOW_ANY | libc::O_CLOEXEC;
        // SAFETY: `c_path` is NUL-terminated and outlives the call; no other pointer is passed.
        let fd = unsafe { libc::open(c_path.as_ptr(), flags) };
        if fd < 0 {
            let error = std::io::Error::last_os_error();
            return Err(match error.raw_os_error() {
                Some(libc::ELOOP) | Some(libc::ENOTDIR) => {
                    ContainedError::NotADirectory(path.to_path_buf())
                }
                _ => io(path, &error),
            });
        }
        // SAFETY: `fd` is a fresh descriptor this value now owns.
        Ok(RootDir {
            fd: unsafe { OwnedFd::from_raw_fd(fd) },
            path: path.to_path_buf(),
        })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn try_clone(&self) -> Result<Self, ContainedError> {
        Ok(Self {
            fd: self
                .fd
                .try_clone()
                .map_err(|error| io(&self.path, &error))?,
            path: self.path.clone(),
        })
    }

    pub fn identity(&self) -> Result<(u64, u64), ContainedError> {
        use std::os::unix::fs::MetadataExt;
        let file = File::from(
            self.fd
                .try_clone()
                .map_err(|error| io(&self.path, &error))?,
        );
        let metadata = file.metadata().map_err(|error| io(&self.path, &error))?;
        Ok((metadata.dev(), metadata.ino()))
    }

    pub fn revalidate(&self) -> Result<(), ContainedError> {
        use std::os::unix::fs::MetadataExt;
        let current = Self::open(&self.path)?;
        let held = File::from(
            self.fd
                .try_clone()
                .map_err(|error| io(&self.path, &error))?,
        )
        .metadata()
        .map_err(|error| io(&self.path, &error))?;
        let observed = File::from(current.fd)
            .metadata()
            .map_err(|error| io(&self.path, &error))?;
        if (held.dev(), held.ino()) != (observed.dev(), observed.ino()) {
            return Err(escape(&self.path, &self.path));
        }
        Ok(())
    }

    pub fn leaf(&self, path: &Path) -> Result<PathBuf, ContainedError> {
        leaf_below(&self.path, path)
    }

    /// The validated leaf's file name, as the C string `openat` and friends take.
    pub fn c_name(&self, path: &Path) -> Result<CString, ContainedError> {
        c_name(&self.leaf(path)?)
    }

    pub fn open_subdirectory(&self, name: &str) -> Result<RootDir, ContainedError> {
        let path = self.leaf(Path::new(name))?;
        let file = self.open_at(&path, libc::O_RDONLY | libc::O_DIRECTORY | NO_FOLLOW, 0)?;
        Ok(RootDir {
            fd: file.into(),
            path,
        })
    }

    /// `openat` relative to the root; ELOOP at the leaf is a link and is refused.
    fn open_at(&self, leaf: &Path, flags: libc::c_int, mode: u32) -> Result<File, ContainedError> {
        let name = c_name(leaf)?;
        // SAFETY: `name` is NUL-terminated and outlives the call; the directory
        // descriptor stays open for the lifetime of `self`.
        let fd = unsafe {
            libc::openat(
                self.fd.as_raw_fd(),
                name.as_ptr(),
                flags,
                mode as libc::c_uint,
            )
        };
        if fd < 0 {
            let error = std::io::Error::last_os_error();
            return Err(match error.raw_os_error() {
                Some(libc::ELOOP) => ContainedError::NotRegular(leaf.to_path_buf()),
                _ => io(leaf, &error),
            });
        }
        // SAFETY: `fd` is a fresh descriptor the `File` now owns.
        Ok(unsafe { File::from_raw_fd(fd) })
    }

    pub fn stat(&self, path: &Path) -> Result<Stat, ContainedError> {
        let leaf = self.leaf(path)?;
        let name = c_name(&leaf)?;
        // SAFETY: `raw` is a plain-data struct the call fills in; `name` is
        // NUL-terminated and outlives the call.
        let mut raw: libc::stat = unsafe { std::mem::zeroed() };
        let outcome = unsafe {
            libc::fstatat(
                self.fd.as_raw_fd(),
                name.as_ptr(),
                &mut raw,
                libc::AT_SYMLINK_NOFOLLOW,
            )
        };
        if outcome != 0 {
            return Err(io(&leaf, &std::io::Error::last_os_error()));
        }
        let kind = match raw.st_mode & libc::S_IFMT {
            libc::S_IFREG => Kind::File,
            libc::S_IFDIR => Kind::Directory,
            libc::S_IFLNK => Kind::Link,
            _ => Kind::Other,
        };
        Ok(Stat {
            kind,
            size: u64::try_from(raw.st_size).unwrap_or(0),
            mtime_secs: raw.st_mtime,
            mtime_nanos: u32::try_from(raw.st_mtime_nsec).unwrap_or(0),
            flags: raw.st_flags,
        })
    }

    /// An existing regular file at the leaf, judged without following a link.
    pub fn regular(&self, path: &Path) -> Result<PathBuf, ContainedError> {
        let leaf = self.leaf(path)?;
        match self.stat(&leaf)?.kind {
            Kind::File => Ok(leaf),
            _ => Err(ContainedError::NotRegular(leaf)),
        }
    }

    /// Open the leaf without following a link; a non-file at the leaf is refused.
    pub fn open_file(&self, path: &Path, access: Access) -> Result<File, ContainedError> {
        let leaf = self.leaf(path)?;
        let file = self.open_at(&leaf, access.flags() | NO_FOLLOW | libc::O_NONBLOCK, 0)?;
        let metadata = file.metadata().map_err(|error| io(&leaf, &error))?;
        if !metadata.is_file() {
            return Err(ContainedError::NotRegular(leaf));
        }
        Ok(file)
    }

    /// Create the leaf exclusively at `mode`; nothing is ever replaced.
    pub fn create_file(&self, path: &Path, mode: u32) -> Result<File, ContainedError> {
        let leaf = self.leaf(path)?;
        let file = self.open_at(
            &leaf,
            libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL | NO_FOLLOW,
            mode,
        )?;
        file.set_permissions(std::fs::Permissions::from_mode(mode))
            .map_err(|error| io(&leaf, &error))?;
        Ok(file)
    }

    /// A private directory at `<root>/<name>`, created when missing, as its own handle.
    pub fn subdirectory(&self, name: &str) -> Result<RootDir, ContainedError> {
        let leaf = self.leaf(Path::new(name))?;
        let c_leaf = c_name(&leaf)?;
        // SAFETY: `c_leaf` is NUL-terminated and outlives both calls; the
        // directory descriptor stays open for the lifetime of `self`.
        let made = unsafe { libc::mkdirat(self.fd.as_raw_fd(), c_leaf.as_ptr(), 0o700) };
        if made != 0 {
            let error = std::io::Error::last_os_error();
            if error.kind() != std::io::ErrorKind::AlreadyExists {
                return Err(io(&leaf, &error));
            }
        }
        let flags = libc::O_RDONLY | libc::O_DIRECTORY | NO_FOLLOW;
        let fd = unsafe { libc::openat(self.fd.as_raw_fd(), c_leaf.as_ptr(), flags) };
        if fd < 0 {
            let error = std::io::Error::last_os_error();
            return Err(match error.raw_os_error() {
                Some(libc::ELOOP) | Some(libc::ENOTDIR) => ContainedError::NotADirectory(leaf),
                _ => io(&leaf, &error),
            });
        }
        // SAFETY: `fd` is a fresh descriptor this value now owns.
        let directory = RootDir {
            fd: unsafe { OwnedFd::from_raw_fd(fd) },
            path: leaf,
        };
        if made == 0 {
            let handle = File::from(
                directory
                    .fd
                    .try_clone()
                    .map_err(|error| io(&directory.path, &error))?,
            );
            handle
                .set_permissions(std::fs::Permissions::from_mode(0o700))
                .map_err(|error| io(&directory.path, &error))?;
        }
        Ok(directory)
    }

    fn rename(&self, from: &Path, to: &Path, flags: libc::c_uint) -> Result<(), std::io::Error> {
        let from =
            c_name(from).map_err(|_| std::io::Error::from(std::io::ErrorKind::InvalidInput))?;
        let to = c_name(to).map_err(|_| std::io::Error::from(std::io::ErrorKind::InvalidInput))?;
        // SAFETY: both names are NUL-terminated and outlive the call; the
        // directory descriptor stays open for the lifetime of `self`.
        let outcome = unsafe {
            libc::renameatx_np(
                self.fd.as_raw_fd(),
                from.as_ptr(),
                self.fd.as_raw_fd(),
                to.as_ptr(),
                flags,
            )
        };
        if outcome == 0 {
            Ok(())
        } else {
            Err(std::io::Error::last_os_error())
        }
    }

    /// Move `from` onto `to`, replacing whatever `to` held.
    pub fn rename_over(&self, from: &Path, to: &Path) -> Result<(), ContainedError> {
        let (from, to) = (self.leaf(from)?, self.leaf(to)?);
        self.rename(&from, &to, 0).map_err(|error| io(&to, &error))
    }

    /// Move `from` to `to` only when `to` is absent; `false` leaves both untouched.
    pub fn rename_exclusive(&self, from: &Path, to: &Path) -> Result<bool, ContainedError> {
        let (from, to) = (self.leaf(from)?, self.leaf(to)?);
        match self.rename(&from, &to, libc::RENAME_EXCL) {
            Ok(()) => Ok(true),
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => Ok(false),
            Err(error) => Err(io(&to, &error)),
        }
    }

    /// Flush the directory itself, so a rename or a creation is durable.
    pub fn sync(&self) -> Result<(), ContainedError> {
        let handle = File::from(
            self.fd
                .try_clone()
                .map_err(|error| io(&self.path, &error))?,
        );
        handle.sync_all().map_err(|error| io(&self.path, &error))
    }

    /// Every entry name in sorted order; each is judged through `stat` or `open_file` before use.
    pub fn names(&self) -> Result<Vec<String>, ContainedError> {
        self.revalidate()?;
        let entries = std::fs::read_dir(&self.path).map_err(|error| io(&self.path, &error))?;
        let mut names = Vec::new();
        for entry in entries {
            let entry = entry.map_err(|error| io(&self.path, &error))?;
            if let Ok(name) = entry.file_name().into_string() {
                names.push(name);
            }
        }
        names.sort();
        Ok(names)
    }
}

impl AsFd for RootDir {
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.fd.as_fd()
    }
}
```

`O_NOFOLLOW_ANY` refuses a link in any component when the root itself is opened, and `O_NOFOLLOW` on
every `openat` refuses one at the leaf, which is the only component below a root this module admits;
together they cover every symbolic link a path below a root can traverse, whether it was there at
resolution or arrived later. `renameatx_np` with `RENAME_EXCL` is the platform's exclusive rename, the
primitive Task 18's probe verifies. A canonical root has no link in it, so the tests canonicalize their
temporary directories before opening them. Every later task maps a `ContainedError` to exit 3, rule
`path_escape`, at the composition root.

Replace `private_dir` in `config/roots.rs` with the body below. Remove its `DirBuilder` and
`DirBuilderExt` imports and add `use crate::{ContainedError, RootDir};`.

```rust
fn private_dir(path: &Path, key: &str) -> Result<(), RootError> {
    let parent = path.parent().ok_or_else(|| RootError::NotAbsolute { key: key.into() })?;
    let name = path.file_name().and_then(|name| name.to_str())
        .ok_or_else(|| RootError::NotAbsolute { key: key.into() })?;
    let map = |error| match error {
        ContainedError::Io { kind, .. } => RootError::Io { key: key.into(), detail: kind.to_string() },
        _ => RootError::PathEscape { key: key.into() },
    };
    let directory = RootDir::open(parent).map_err(map)?;
    directory.subdirectory(name).map(|_| ()).map_err(map)
}
```

In `config/load.rs`, add these imports and replace `load_file` with the checked implementation and its
error helpers below. Keep `load_text` and its tests unchanged.

```rust
use crate::contained::{Access, ContainedError, RootDir};
use std::io::Read;
```

```rust
pub fn load_file(path: &Path) -> Result<Table, ConfigError> {
    let parent = path
        .parent()
        .filter(|parent| !parent.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    let parent = parent
        .canonicalize()
        .map_err(|error| config_io(path, error))?;
    let root = RootDir::open(&parent)
        .map_err(|error| config_contained(path, error))?;
    let name = path.file_name().ok_or_else(|| ConfigError::Unreadable {
        path: path.display().to_string(),
        detail: std::io::ErrorKind::InvalidInput.to_string(),
    })?;
    let mut file = root
        .open_file(Path::new(name), Access::Read)
        .map_err(|error| config_contained(path, error))?;
    let mut text = String::new();
    file.read_to_string(&mut text)
        .map_err(|error| config_io(path, error))?;
    load_text(&text)
}

fn config_io(path: &Path, error: std::io::Error) -> ConfigError {
    if error.kind() == std::io::ErrorKind::NotFound {
        ConfigError::Missing(path.display().to_string())
    } else {
        ConfigError::Unreadable {
            path: path.display().to_string(),
            detail: error.kind().to_string(),
        }
    }
}

fn config_contained(path: &Path, error: ContainedError) -> ConfigError {
    match error {
        ContainedError::Io { kind, .. } => {
            config_io(path, std::io::Error::from(kind))
        }
        _ => ConfigError::PathEscape(path.display().to_string()),
    }
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters contained`

Expected: all 13 contained-access tests PASS. Also run `cargo test -p vpt-adapters config::roots` and
require the root-creation regression to pass. Run
`cargo test -p vpt-adapters a_configuration_leaf_symlink_is_refused` and require it to pass. Run
`cargo clippy -p vpt-adapters --all-targets -- -D warnings` and expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates/vpt-adapters
SKIP_AI_COMMIT=1 git commit -m "feat(adapters): checked access below a resolved root through its descriptor"
```

______________________________________________________________________


