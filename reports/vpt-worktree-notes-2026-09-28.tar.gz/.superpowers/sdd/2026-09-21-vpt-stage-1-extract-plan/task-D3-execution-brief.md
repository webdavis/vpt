# D3 execution brief

## Controller constraints

- Current D2 preflight at 338dc9ca3806e69990c1b59056466e88ba6c4719: database/locks.rs supplies pub(crate) LockKind/set_record_lock and pub(super) DatabaseLocks with new/lock/unlock/reserved/file/level. DatabaseLocks owns the File; do not clone its descriptor or rebuild its protocol in callbacks. The controller read the complete lock implementation and child harness.
- Reuse database/tests/children.rs and its private capture/process/scenarios children. child(scenario, directory) takes the outer owned temporary directory, not its state subdirectory; the exact child entry point opens directory/state. It clears the environment and sets the child's current directory to the outer owned tree. ready/send/finish share a 500 ms deadline; forced cleanup is capped at 900 ms from the start. Both output captures are bounded and nonblocking. Extend the fixed scenario match only for this task's owned cases, without another subprocess framework.
- A deliberate invalid-owner child must prove it reached the intended live-statement/owner state before triggering Drop and distinguish the required fail-stop result from an unrelated fixture panic, watchdog timeout or crash. Reuse the existing ready/continue handshake and inspect the child's actual termination status. Disable core dumps only within that dedicated child, as the approved task requires.
- D2 adds 11 narrowly scoped staging expectations, authorized against task-D2-incremental-clippy-01.log: four lock constants, LockKind, set_record_lock, has_conflict, record_lock, DatabaseLocks, its impl and invalid. D3 callbacks/controls are their actual consumers, including file() and level(). Remove these expectations as the real flow uses them; D4/D6 also using an API is not grounds to keep a redundant annotation. If a transitive private-owner staging warning genuinely remains, preserve its exact diagnostic for a fresh scoped ruling, never add an artificial caller or expose internals. Existing follow-up 6hc7x7wMwxF8R9rg tracks the full inventory.
- Honor D1's removal contract: checked unlink is followed by retained-directory synchronization when the callback requests it. D1's bool remains meaningful. Use this task's private fault injection to verify the requested directory-sync route and propagated failure; do not add native/pathname fallbacks. Remove D1's inventoried staging expect(dead_code) annotations as actual owner/file consumers make them unnecessary.
- Dispatch only after D2 is independently accepted. Read the actual D1/D2 APIs and approved containment design. This is unsafe callback and connection ownership work: Astra implementation and independent Astra review.
- Own only the database owner, registration, callbacks, connection-local faults and focused tests named below, plus D3 report/evidence. Main owns progress.md and Todoist. You are not alone; preserve others' work. One product writer, no subagents or new worktree.
- Verify the locked rusqlite and bundled SQLite APIs from local primary sources. Preserve private ownership and explicit callback lifetime invariants. Do not add dependencies, broaden visibility to silence warnings, or implement D4-D7 early. Report a concrete staging problem for a scoped ruling.
- All deliberate failure and invalid-lifetime cases must use synthetic owned fixtures and an independent watchdog. Before a native-path-delegation mutation, establish that every possible filename, including relative registration tokens, resolves inside an owned temporary directory. Set the supervised child's working directory accordingly. Never run that mutation against the repository working directory or a live path. If containment cannot be demonstrated, report the test limitation instead of running it.
- Do not modify third-party source, override SQLite system calls, rerun denied probes, use a broad process listing or access live source/destination/database paths. Test replacement at VPT's own callback/helper boundary only.
- Preserve all prior leaves; compiling behavioral RED, exact compiled mutations, byte-identical restored controls and unique raw logs per attempt. Address valid-input survivors. Required Rust/release/staged-size/secrets gates apply; controller owns fresh committed-HEAD ship.
- Existing command-test deadline overruns are tracked as 6hc7MMRc2QhRm75g. Preserve recurrence without retry loops or increased deadlines. No install, push, pull request, merge, apply or destructive cleanup. Verify buffer safety and use apply_patch.

## Approved D3 task

## D3: Registered filesystem, connection lifetime and rollback transactions

**Files:** Create `database/owner.rs`, `database/registration.rs`, `database/io.rs`, `database/faults.rs`
and `database/tests/owner.rs`; modify D1's files and test support as required by the interfaces below.

**Interfaces:** Produce the concrete crate-private owner:

```rust
pub(crate) struct Database {
    connection: Option<rusqlite::Connection>,
    registration: Option<Registration>,
    not_send_or_sync: std::marker::PhantomData<std::rc::Rc<()>>,
}

impl Database {
    pub(crate) fn open(
        root: RootDir, leaf: &Path, policy: AccessPolicy, busy: Duration,
    ) -> Result<Self, DatabaseError>;
    pub(crate) fn with_connection<T, E>(
        &mut self, operation: impl FnOnce(&rusqlite::Connection) -> Result<T, E>,
    ) -> Result<T, E> where E: From<DatabaseError>;
    pub(crate) fn try_close(&mut self) -> Result<(), DatabaseError>;
}
```

`Registration` owns pinned backing storage for `sqlite3_vfs`, its NUL-terminated unique name,
`DatabaseFiles`, the connection-local error latch and callback state. Name allocation uses an atomic
counter, checked for overflow. Registration is non-default and scoped to one database. The owner has no
bare-connection, raw-handle, statement, backup or blob export. Statements stay inside the borrowing
operation; the existing dependency features remain unchanged. Its constructor is
`Registration::new(root: RootDir, leaf: &Path, policy: AccessPolicy) -> Result<Self, DatabaseError>` and
`name(&self) -> &std::ffi::CStr` supplies the raw opener's explicit selection. Both remain private to the
database module. Lend only `&Connection`: lending `&mut Connection` would let a caller replace it and
extract the registered connection. The closure's output type cannot borrow from its connection argument.

For failure tests, define test-only `Fault::{Write, FileSync, DirectorySync, Truncate}`,
`Database::fail_next(&mut self, fault: Fault)` and `Database::short_write_next(&mut self, bytes: usize)`.
The next matching VPT operation returns `EIO` before performing it and disarms; the short-write case
writes the specified prefix before returning `EIO`. A test-only consumed flag proves the intended
operation was reached. Use one concrete `FaultState` slot in the connection's state. In `faults.rs`, its
non-test definition is a zero-sized no-op, followed by its test-only state and behavior. Put `cfg(test)`
declarations after production items so the size audit still counts production code. No public fault API,
production trait or global injection is needed.

The private opener separates registration from adoption with
`Database::open_registered(registration: Registration, busy: Duration) -> Result<Self, DatabaseError>`.
Production `open` constructs its registration then calls this method. Tests can arm a registration-local
fault before this call to cover failed open; `Registration::fail_next(&mut self, fault: Fault)` is
test-only. Keep that helper and `open_registered` visible only inside `database`.

- [ ] **Step 1: Add compiling red transaction and lifetime tests.**

```rust
#[test]
fn a_rollback_transaction_uses_only_authorized_files() {
    let (_temp, root) = root();
    let path = root.path().to_path_buf();
    let mut db = Database::open(root, Path::new("vpt.db"), AccessPolicy::WritableLedger,
        Duration::from_millis(20)).expect("open");
    db.with_connection::<_, DatabaseError>(|connection| {
        connection.execute_batch("CREATE TABLE item(value INTEGER); BEGIN IMMEDIATE;
            INSERT INTO item VALUES (7); ROLLBACK;")?;
        let count: i64 = connection.query_row("SELECT count(*) FROM item", [], |row| row.get(0))?;
        assert_eq!(count, 0);
        Ok(())
    }).unwrap();
    db.try_close().unwrap();
    let names: Vec<_> = std::fs::read_dir(path).unwrap()
        .map(|entry| entry.unwrap().file_name()).collect();
    assert_eq!(names, [std::ffi::OsString::from("vpt.db")]);
}

#[test]
fn an_attached_database_cannot_select_the_native_filesystem() {
    let (temp, root) = root();
    let outside = temp.path().join("outside.db");
    let mut db = Database::open(root, Path::new("vpt.db"), AccessPolicy::WritableLedger,
        Duration::from_millis(20)).unwrap();
    let uri = format!("file:{}?vfs=unix", outside.display());
    let result = db.with_connection::<_, DatabaseError>(|connection| {
        connection.execute("ATTACH DATABASE ?1 AS outside", [&uri])?;
        Ok(())
    });
    assert!(result.is_err());
    assert!(!outside.exists());
    db.try_close().unwrap();
}
```

Add separate leaves for: short read zero-filling; partial writes; invalid offsets; failed open after a
file was acquired; refusing disk temporary requests and unknown companion/open flags; directory
replacement during lazy journal access and final cleanup; independent connection error latches; and a
callback panic converted to failure without crossing the C boundary. Root-switch tests call VPT's
production callback/helper directly after a completed validation, without a global hook or third-party
system-call override.

For the lifetime regression, prepare a statement through a test-only raw handle and intentionally keep it
alive while calling `try_close`. Assert SQLite busy, the registration still discoverable by its internal
name, and the connection still usable after finalizing that statement. Retry close and assert
registration removal and released locks. A separate supervised child drops this deliberately invalid
owner without finalizing; it must terminate safely rather than free live callback storage.

- [ ] **Step 2: Run the selected owner tests red.**

```bash
cargo test --locked -p vpt-adapters database::tests::owner -- --nocapture
```

Expected: named behavior assertions fail against a compiling unsupported opener. Every blocking or
deliberately invalid-lifetime case runs under D2's independent watchdog.

- [ ] **Step 3: Implement registration, open and close ownership.**

Allocate registration storage before passing its address to `sqlite3_vfs_register`; retain stable
addresses until unregister completes. Use `iVersion = 2` for the filesystem and file-method tables;
database-page fetch/unfetch remain disabled. Files use an initialized `#[repr(C)]` header followed by a
pointer to an owned Rust file state. Set `pMethods` only after successful initialization. Failed opens
leave `pMethods` null and release any partially acquired state. Static method tables outlive every file.

Use raw `sqlite3_open_v2` with the selected registration name so failed-open handles stay owned. When it
succeeds, adopt the handle with `Connection::from_handle_owned`; the raw guard relinquishes ownership
only after adoption succeeds. On failure, close a non-null handle while registration remains alive, then
return the latched typed failure or the numeric SQLite error. Do not format SQLite's message text. Do not
call an unavailable `sqlite3_close_v2` binding or change the dependency to acquire one.

Check `sqlite3_threadsafe()` and `sqlite3_initialize()` before registration, fail closed on an unsafe
build or initialization failure, and keep the owner confined to one thread. VPT does not change SQLite's
process-wide threading configuration. Pass `SQLITE_OPEN_NOMUTEX` and `SQLITE_OPEN_EXRESCODE`, then check
extended-result setup and the supplied busy timeout. Set `temp_store=MEMORY` and `mmap_size=0`. Omit URI
opening, do not enable extension loading, and install an authorizer with `sqlite3_set_authorizer` that
denies `SQLITE_ATTACH`. This blocks an attachment that names another filesystem before its opener can
run. Unexpected disk temporary requests also fail at `xOpen`, regardless of later pragma changes.

Before any database work, disable checkpoint-on-close for all three policies whose main database is
read-only. The pinned pager otherwise attempts an exclusive lock during close, even on a read-only
descriptor. Check the result of this supported setting:

```rust
if policy != AccessPolicy::WritableLedger {
    connection.set_db_config(rusqlite::config::DbConfig::SQLITE_DBCONFIG_NO_CKPT_ON_CLOSE, true)?;
}
```

Latch definitive containment, storage and durability failures. SQLite's expected busy, read-only mapping,
read-only-uninitialized and short-read/zero-fill protocol results are not latched faults; SQLite may
handle them and complete the operation successfully. Keep unexpected descriptor errors visible rather
than exempting all errors from a callback.

The owner uses this operation order:

```text
with_connection:
  refuse a closed owner
  revalidate the retained root; clear this operation's error latch
  lend the connection to the closure
  read the latch even if the closure returned success or mapped its SQL error
  prefer a latched containment/IO failure; otherwise retain the closure result
  revalidate before returning a successful result

try_close:
  take the Connection; keep Registration owned
  call Connection::close
  on any close failure: restore Connection and return the typed error
  on success: collect callback errors, unregister, release backing storage
  repeated close of an already closed owner succeeds
```

`Drop` attempts the same synchronous close. If that leaves a connection open, abort before freeing
registration storage. This detects an internal ownership-invariant violation, including a forgotten
statement; scoped Rust borrowing alone does not make `mem::forget` impossible. Ordinary query contention,
filesystem errors and invalid database contents are returned by operations. If close has completed but
its callbacks recorded an input/output error, the owner can release its storage normally; explicit
callers still receive that error. Apply the fail-stop rule to a raw failed-open guard whose handle cannot
be closed too. Disable core dumps in the dedicated invariant test child. Do not walk and finalize
arbitrary `sqlite3_next_stmt` results: bundled virtual-table modules can own those statements.

Every C callback checks counts, offsets, required non-null pointers and initialized state before use;
buffer validity otherwise follows SQLite's documented calling contract. Contain Rust unwinding with a
small `catch_unwind` boundary. On panic, latch an internal failure and poison further operations. Status
callbacks return their operation-specific SQLite error; count, pointer or void callbacks return their
contract's zero/null/no-value failure form. The outer owner still observes the latch. Cleanup releases
its owned state. `xClose` clears its file-state pointer once and drops that state once. Document these
pointer and lifetime invariants beside the unsafe operations.

- [ ] **Step 4: Implement file methods and explicit filesystem dispatch.**

Use one internal filename token per registration. `xFullPathname` copies the token with a checked output
length; `xOpen`, `xAccess` and `xDelete` accept only that token and its three known suffixes with
matching roles. Neither the token nor SQLite's incoming filename reaches a native pathname opener. Null
temporary names, super-journals, attached databases and unrecognized mode bits are refused.

| Callback                                 | Implementation                                                                                                                                            |
| ---------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `xRead`                                  | Checked nonnegative offset and length; `FileExt::read_at` loop; retry interrupted reads; zero any unread tail and return `SQLITE_IOERR_SHORT_READ` on EOF |
| `xWrite`                                 | Refuse non-writable role; `FileExt::write_at` loop with checked offset advancement; zero progress is `WriteZero`; propagate failure                       |
| `xTruncate`, `xFileSize`                 | Descriptor `set_len`/metadata, checked integer conversion, policy enforcement before truncation                                                           |
| `xSync`                                  | Honor data-only versus full sync; honor full durability with macOS `F_FULLFSYNC` when requested; propagate failure, including pending directory sync      |
| `xLock`, `xUnlock`, `xCheckReservedLock` | D2's protocol; operation-specific SQLite errors for operating-system failures                                                                             |
| `xFileControl`                           | Implement lock state, persistent WAL flag and moved-file detection; return `SQLITE_NOTFOUND` for unsupported controls                                     |
| `xSectorSize`, `xDeviceCharacteristics`  | Use the pinned Unix default of 4096 bytes; advertise zero optional device capabilities                                                                    |
| `xDelete`                                | D1's exact-role removal and requested directory sync; writable ledger only                                                                                |
| `xAccess`                                | Descriptor-relative no-follow metadata plus policy-aware existence/read/write answer; refuse unsafe entries                                               |
| `xRandomness`, `xSleep`, time callbacks  | Delegate only these path-free services to the installed native implementation                                                                             |
| Dynamic loading callbacks                | Unavailable; no library pathname opening                                                                                                                  |

Set the persistent WAL file-control flag on writable ledgers before WAL initialization. Support querying
it and changing it through the documented integer argument. A moved-file check compares the open file
identity with its descriptor-relative directory entry and reports substitution without following it.

- [ ] **Step 5: Verify green, cleanup and mutations.**

Run the owner test command, then all `database` tests. Inject write and file/directory synchronization
failures only at VPT's own operation boundary using connection-local test state; no global injection.
Assert the outer operation returns failure. Mutations: native pathname delegation, ignored sync result,
missing attach denial, lost error latch and unregister-before-close. The lifetime mutation runs in a
supervised child so a bad foreign pointer cannot crash or hang the whole suite. Restore exact bytes and
run each control.

- [ ] **Step 6: Format, review and commit.**

```bash
cargo fmt --all
cargo clippy --locked -p vpt-adapters --all-targets -- -D warnings
cargo test --locked -p vpt-adapters database
git add crates/vpt-adapters/src/database
git commit -m "feat(database): own contained SQLite connections"
```
