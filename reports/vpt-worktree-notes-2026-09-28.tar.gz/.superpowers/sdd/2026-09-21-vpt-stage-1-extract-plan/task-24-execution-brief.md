# Task 24 execution brief

## Cleanup contract clarification, 2026-09-27

Spec section 3.5 defines the operation deadline, one-second termination grace, then force-kill and
reap-before-return. It sets no additional production wall-clock limit on the operating system's
completion of cleanup. The 750, 850 and 900 millisecond bounds belong to cooperative test fixtures.
Reaping assumes ordinary kernel progress and permission to signal the owned group; a successful
signal call alone does not prove that a child has already exited.

Retain the exact child through the last group signal. Revoke shared signal authority under its lock
and join every signal-capable registration before consuming the child's status. A failed
non-consuming observation must still allow independent cleanup through the retained child handle.
Preserve that first error and report it after successful reaping. Interrupted waits retain ownership;
loss of child identity permanently revokes authority and is reported without reacquiring a numeric
process identifier. Do not return an ordinary completed outcome or silently drop a pending owner.

The controller and an independent Astra reviewer checked this against the approved spec, task
interfaces, original final-wait sample and installed process APIs. An observed persistent native
cleanup failure requires preserved evidence and diagnosis. No detached reaper, abort policy,
abandonment policy, additional production timeout or public ownership-transfer interface is approved.

## Parallel scheduling amendment, 2026-09-26

The controller reread all of `task-24-brief.md`, `task-24-preflight.md`, the existing fake binary,
crate manifests and spec section 3.5. Task 24 explicitly consumes no earlier task interface. Its
process implementation uses installed workspace dependencies and the existing dev-tools binary;
it has no ingest or ledger dependency. The former wait for preceding ingest tasks is withdrawn for
an isolated lane under the operator's parallel-work request. Root creates that lane, coordinates
verification windows and reconciles shared exports at integration. This is preparation, not dispatch.

Read both task artifacts completely and inspect the actual fake binary and local process fixtures
before writing. Preserve every accepted fixture route. The report/alert amendment governs fake
command behavior as described below.

## Ownership and verification

- Own the bounded process adapter, its tests and the dev-tools fake additions. You are not alone;
  preserve others' work. One product writer, no subagents. Main owns the ledger and task tracker.
- Process groups, cancellation, unsafe signal operations and deadline cleanup require Astra
  implementation and independent Astra review. Keep the approved private controls, not a new process
  framework, shared fixture crate or dependency. Reuse local nonblocking I/O patterns where useful.
- Replace the sample's missing-symbol compile failure with compiling, reachable behavioral RED for
  every new group. Cover the public argv/environment wrapper as well as the private executor. Shell
  metacharacters remain literal argv data; every test invocation uses owned temporary environment.
- Preserve the existing reap-descendant and terminal-exec fake routes and all their caller tests.
  Add Task 24's version, trash and command-sink routes test-first under dev-tools. The old `notify`
  fake route is withdrawn with built-in notification delivery and must not be added. Stage 2
  Task 5 owns the engine-envelope fixture selection and fail/empty/hang/transcribe modes before its
  adapter tests; Stage 2 Task 11 consumes them. Do not claim the full engine fixture complete here.
- Ruling: the deadline budget starts immediately before spawn, so elapsed spawn/setup time counts
  when control returns. Synchronous spawn itself is not preemptible; make no stronger claim. Check
  cancellation and elapsed deadline before accepting observed completion, including equality at the
  deadline. A late first observation cannot be reported successful. Use private virtual controls and
  readiness handshakes to establish this boundary, without changing production timeouts or retries.
- Ruling: genuine pipe read/write failure is a typed safe I/O failure, not successful partial delivery.
  Retry Interrupted reads/writes; ordinary EOF is completion. Preserve the explicit timeout or
  interruption outcome during its cleanup rather than replacing it with cleanup-induced pipe errors.
  Cover early stdin closure with unwritten input and an injected reader failure at the private seam.
- Force simultaneous stdin, stdout and stderr pressure. Bound retained bytes per stream while draining
  the child. Do not expose captured bytes in production Debug/errors/logs; diagnostics name safe
  operation/status/count information. Synthetic fixture-only failure previews remain small and bounded.
- The command-sink fixture must preserve argv boundaries in its capture so tests can distinguish a
  space-containing argument from two arguments. The old joined-string sample alone cannot prove this.
  Use a small structured fixture record and reconcile later unshipped test consumers; no compatibility
  parser is needed. Encode fake version/path documents with the existing JSON serializer so hostile
  values exercise the intended protocol rather than malformed string construction.
- Preserve whole-group TERM/grace/KILL behavior and leader reaping on every return path. Test a
  TERM-resistant descendant, a leader exited with retained pipes, and a descendant with closed pipes.
  The independent watchdog must fail a disabled bound; its cleanup cannot turn the mutation green.
- Keep the approved one-second production grace and virtual grace test. Measure complete leaves under
  one second. Do not serialize the suite, add retries, inflate deadlines or infer the historical setup
  timeout's cause from a green rerun. That separate fixture-diagnostic follow-up remains open.
- Retain all accepted leaves, exact compiled mutations and byte-identical restored controls; satisfy
  Rust size/lint and normal-hook gates. Report chronology, hashes, logs and self-review in
  task-24-report.md. Main owns independent review and fresh committed-HEAD ship. No live commands,
  real Trash, notifications, installations, publication or destructive evidence cleanup.
