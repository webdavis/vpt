### Task 6: `vpt setup`

## Controller execution constraints

- Operator-approved permission correction: an existing selected config parent must already have private 0700 permissions. Refuse before prompting and without chmod; revalidate before writing. Newly created config directories remain 0700, and explicitly managed home/state/store directories retain their existing-mode repair contract. This supersedes the sample's blanket config-parent repair. Do not hardcode a list of broad directories.
- The source read-only contract also covers hard-link aliases: refuse multiply linked existing config files from opened-descriptor metadata before any chmod or truncation. Exercise this only against owned synthetic-source fixtures. Keep harness commands in the owned sandbox environment, including the cooperative descendant fixture. Verify JSON-only stdout during real terminal success.
- Read the ledger's source read-only, harness-integration, environment-boundary and Task 4 error-privacy rulings. Existing bounded command-test support takes precedence over replacement samples.
- Setup refuses a selected config parent equal to or below the synthetic Voice Memos container before prompting or writing. Assert the entire fixture source tree remains unchanged.
- Do not layer setsid onto process_group(0). Establish session/group ownership once. Replace the unbounded script/wait_with_output sample with a bounded owned pseudoterminal fixture; verify cleanup of its command and descendants even on timeout or failure.
- Read task-6-terminal-preflight.md. Its source-backed flow uses the existing dev-tools-only fake engine for post-exec terminal acquisition, preserving stdout/stderr fixtures. Your scope includes that fixture branch and necessary feature wiring, with no new dependency package. Own session creation at the shared runner, atomic close-on-exec terminal allocation, and one deadline through terminal driving and output collection. Reproduce the existing reader-join/final-wait risk with a bounded owned fixture before fixing it; never run an unbounded old-runner hang probe.
- Keep the existing runner's deadline repair in a separate commit from new setup behavior. The task report and review cover both commits from the recorded task base, with test-first and mutation evidence for each change.
- Read task-6-terminal-cleanup-followup.md. Preserve the existing TERM/50 ms grace/KILL sequence. The descendant fixture uses a cooperative parent, requires its explicit reaping record, and checks group disappearance. Test KILL escalation with a direct child with no children. Keep the 500 ms command deadline, and bound all collection and cleanup by one absolute final deadline below one second, for example 900 ms from runner entry. A timeout remains a timeout after successful cooperative cleanup. No arbitrary-grandchild reaping guarantee or intentionally orphaned fixture.
- Environment access tolerates unrelated non-UTF-8 OS strings. An invalid selected configured value is refused without quoting it or choosing a fallback. Do not use std::env::vars().collect(). Add bounded command regressions. Preserve selection precedence: a valid --config overrides an invalid VPT_CONFIG, and a valid VPT_CONFIG overrides an invalid XDG_CONFIG_HOME. Validate only values actually selected by the command; HOME and state defaults are still required where consumed.
- Preserve Task 3 structural validation, Task 4 value errors and duration syntax, actual Task 5 settings APIs, Task 5a checked access and prior output/hang regressions. Key-only configuration errors map to exit 2 where applicable, and never expose the configuration table. Adapt samples to existing modules rather than replacing them wholesale.
- Use compiling behavioral RED, exact mutations and byte-identical restored controls, full gates, timings, staged-file size audit and committed-HEAD secrets scan. Record a compact report with raw evidence links in task-6-report.md.
- Every HOME, config, state, PATH, source-container and terminal fixture is owned by its test. No operator setup, source scan, notification, Trash, installation or deployment. Database D1 remains after Task 10.
- You own only this task's prompt/setup use case, setup writer, command composition, required exports and focused acceptance harness changes, plus your report/evidence. You are not alone: preserve all other work. Main owns progress.md and Todoist.
- No subagents, new worktree, unsolicited docstrings, broad lint suppression, unrelated edits, push, pull request, merge or destructive cleanup. Check buffer safety and use apply_patch. No third-party modification and no bypassing a denied safeguard.

**Files:**

- Create: `crates/vpt-application/src/ports/mod.rs`, `crates/vpt-application/src/ports/prompt.rs`,
  `crates/vpt-application/src/setup.rs`
- Modify: `crates/vpt-application/src/lib.rs`
- Create: `crates/vpt-adapters/src/prompt.rs`, `crates/vpt-adapters/src/config/write.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`, `crates/vpt-adapters/src/config/mod.rs`
- Create: `crates/vpt/src/commands/setup.rs`, `crates/vpt/src/compose.rs`
- Modify: `crates/vpt/src/lib.rs`, `crates/vpt/src/commands/mod.rs`, `crates/vpt/Cargo.toml`
- Test: `crates/vpt/tests/setup.rs`; `crates/vpt/tests/support/mod.rs` (`vpt()` detaches from the
  terminal)

**Interfaces:**

- Consumes: `config::{template, config_path, default_state_dir, from_table, load_text, resolve}`,
  `RootDir::{try_clone, revalidate, open_file, create_file, subdirectory, sync}`.

- Produces:

  - `vpt_application::ports::{Prompt, PromptError}` (the files below `ports/` are private modules):
    `PromptError::{NoTerminal, Closed}`; `trait Prompt { fn choose(&mut self, question: &str,`
    `options: &[&str], preselected: usize) -> Result<usize, PromptError>; }`.
  - `vpt_application::{Setup, SetupWriter, SetupError, SetupOutcome}`:
    `SetupError::{NoTerminal, Exists(PathBuf), PathEscape(PathBuf), Io(String)}`;
    `trait SetupWriter { fn config_path(&self) -> PathBuf; fn config_exists(&self) -> bool;`
    `fn write_config(&self, text: &str, force: bool) -> Result<PathBuf, SetupError>;`
    `fn create_private_dir(&self, path: &Path) -> Result<(), SetupError>; }`;
    `SetupOutcome { pub written: PathBuf, pub main_engine: String }` (`Debug`);
    `Setup<R: Fn(&str) -> String> { pub engines: Vec<String>, pub render: R,`
    `pub directories: Vec<PathBuf> }` with
    `run<P: Prompt, W: SetupWriter>(&self, prompt: &mut P, writer: &W, force: bool) ->`
    `Result<SetupOutcome, SetupError>`.
  - `vpt_adapters::TtyPrompt::open() -> Result<TtyPrompt, PromptError>` (implements `Prompt`; end of file
    on the terminal is `Closed`, never a default choice).
  - `vpt_adapters::config::FilesystemSetupWriter::new(config_path: PathBuf, directories: &[PathBuf]) ->`
    `Result<FilesystemSetupWriter, SetupError>` (retains checked existing ancestors without writing;
    implements `SetupWriter`, file mode 0600 and prepared directory mode 0700, existing modes repaired).
  - `compose::Environment::from_process() -> Environment` with
    `var(&self, name: &str) -> Option<String>`, `config_path(&self) -> PathBuf`,
    `home_dir(&self) -> PathBuf`, `state_dir_default(&self) -> String`.
  - `commands::setup::run(environment: &Environment, config: Option<&Path>, force: bool) -> Outcome`.
  - Test support: `Sandbox::vpt()` now starts the binary in a new session, so no test can reach the
    operator's terminal; the interactive test attaches to a pseudoterminal it creates itself.

- [ ] **Step 1: Write the failing tests**

Declare the modules first. `crates/vpt-application/src/lib.rs`:

```rust
//! Use cases and the ports they own.

pub mod ports;
mod settings;
mod setup;

pub use settings::{NotifyMode, NotifySettings, RetentionSettings, Settings, SourceSettings, StorePaths};
pub use setup::{Setup, SetupError, SetupOutcome, SetupWriter};
```

`crates/vpt-application/src/ports/mod.rs`:

```rust
//! The external capabilities the use cases consume, one trait each. The files
//! below are private; every port is re-exported here.

mod prompt;

pub use prompt::{Prompt, PromptError};
```

`crates/vpt-adapters/src/lib.rs` gains `mod prompt;` and `pub use prompt::{TtyPrompt};`;
`crates/vpt-adapters/src/config/mod.rs` gains `mod write;` and `pub use write::FilesystemSetupWriter;`;
`crates/vpt/src/lib.rs` gains `mod compose;`; `crates/vpt/src/commands/mod.rs` gains
`pub(crate) mod setup;`. `ports/prompt.rs`, `prompt.rs`, `compose.rs` and `commands/setup.rs` start as
their doc lines. `crates/vpt/Cargo.toml` gains `libc = "0.2.189"` under `[dev-dependencies]`.

`crates/vpt-application/src/setup.rs` starts as its test module alone:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::cell::RefCell;

    struct FakePrompt(Option<usize>);
    impl Prompt for FakePrompt {
        fn choose(&mut self, _question: &str, _options: &[&str], _preselected: usize) -> Result<usize, PromptError> {
            self.0.ok_or(PromptError::NoTerminal)
        }
    }

    struct FakeWriter {
        exists: bool,
        written: RefCell<Vec<(String, bool)>>,
        dirs: RefCell<Vec<PathBuf>>,
    }
    impl SetupWriter for FakeWriter {
        fn config_path(&self) -> PathBuf {
            PathBuf::from("/c/config.toml")
        }
        fn config_exists(&self) -> bool {
            self.exists
        }
        fn write_config(&self, text: &str, force: bool) -> Result<PathBuf, SetupError> {
            self.written.borrow_mut().push((text.to_owned(), force));
            Ok(PathBuf::from("/c/config.toml"))
        }
        fn create_private_dir(&self, path: &Path) -> Result<(), SetupError> {
            self.dirs.borrow_mut().push(path.to_owned());
            Ok(())
        }
    }

    fn setup() -> Setup<impl Fn(&str) -> String> {
        Setup {
            engines: vec!["apple".into(), "whisply".into()],
            render: |engine: &str| format!("main = \"{engine}\"\n"),
            directories: vec![PathBuf::from("/h"), PathBuf::from("/s"), PathBuf::from("/h/audio")],
        }
    }

    fn writer(exists: bool) -> FakeWriter {
        FakeWriter { exists, written: RefCell::new(vec![]), dirs: RefCell::new(vec![]) }
    }

    #[test]
    fn the_chosen_engine_is_rendered_and_every_directory_is_created() {
        let writer = writer(false);
        let outcome = setup().run(&mut FakePrompt(Some(1)), &writer, false).expect("setup");
        assert_eq!(outcome.main_engine, "whisply");
        assert_eq!(writer.written.borrow().as_slice(), [("main = \"whisply\"\n".to_owned(), false)]);
        assert_eq!(writer.dirs.borrow().len(), 3);
    }

    #[test]
    fn apple_is_preselected_so_an_empty_answer_picks_it() {
        let writer = writer(false);
        let outcome = setup().run(&mut FakePrompt(Some(0)), &writer, false).expect("setup");
        assert_eq!(outcome.main_engine, "apple");
    }

    #[test]
    fn an_existing_config_is_refused_without_force_and_nothing_is_written() {
        let writer = writer(true);
        let error = setup().run(&mut FakePrompt(Some(0)), &writer, false).unwrap_err();
        assert_eq!(error, SetupError::Exists(PathBuf::from("/c/config.toml")));
        assert!(writer.written.borrow().is_empty());
        assert!(writer.dirs.borrow().is_empty());
    }

    #[test]
    fn force_overwrites_an_existing_config_and_says_so_to_the_writer() {
        let writer = writer(true);
        assert!(setup().run(&mut FakePrompt(Some(0)), &writer, true).is_ok());
        assert_eq!(writer.written.borrow().as_slice(), [("main = \"apple\"\n".to_owned(), true)]);
    }

    #[test]
    fn no_terminal_writes_nothing() {
        let writer = writer(false);
        assert_eq!(setup().run(&mut FakePrompt(None), &writer, false).unwrap_err(), SetupError::NoTerminal);
        assert!(writer.written.borrow().is_empty());
    }
}
```

`crates/vpt-adapters/src/config/write.rs` starts as its test module alone:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::PermissionsExt;

    fn mode(path: &Path) -> u32 {
        std::fs::metadata(path).expect("meta").permissions().mode() & 0o777
    }

    #[test]
    fn a_replaced_config_parent_is_refused_without_writing_either_directory() {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let parent = base.join("config");
        let outside = base.join("outside");
        std::fs::create_dir(&parent).expect("parent");
        std::fs::create_dir(&outside).expect("outside");
        let writer = FilesystemSetupWriter::new(parent.join("config.toml"), &[]).expect("prepared");
        std::fs::rename(&parent, base.join("held")).expect("move");
        std::os::unix::fs::symlink(&outside, &parent).expect("replacement");
        assert!(matches!(
            writer.write_config("replace", true),
            Err(SetupError::PathEscape(_))
        ));
        assert!(!outside.join("config.toml").exists());
        assert!(!base.join("held/config.toml").exists());
    }

    #[test]
    fn prepared_missing_ancestors_are_created_only_when_writing() {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let directories = vec![base.join("home/.vpt"), base.join("state/local/vpt")];
        let writer = FilesystemSetupWriter::new(base.join("config/vpt/config.toml"), &directories)
            .expect("prepared");
        assert!(!base.join("config").exists());
        assert!(!base.join("home").exists());
        assert!(!base.join("state").exists());
        writer
            .write_config("config_version = 1", false)
            .expect("config");
        for directory in &directories {
            writer.create_private_dir(directory).expect("directory");
            assert_eq!(mode(directory), 0o700);
        }
    }

    #[test]
    fn a_new_config_is_0600_inside_a_0700_directory() {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let writer =
            FilesystemSetupWriter::new(base.join("vpt/config.toml"), &[]).expect("prepared");
        let written = writer
            .write_config("config_version = 1\n", false)
            .expect("written");
        assert_eq!(mode(&written), 0o600);
        assert_eq!(mode(&base.join("vpt")), 0o700);
    }

    #[test]
    fn without_force_an_existing_file_is_exists_even_when_created_after_the_check() {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let path = base.join("config.toml");
        std::fs::write(&path, b"old").expect("existing");
        let writer = FilesystemSetupWriter::new(path.clone(), &[]).expect("prepared");
        assert_eq!(
            writer.write_config("new", false).unwrap_err(),
            SetupError::Exists(path.clone())
        );
        assert_eq!(std::fs::read(&path).expect("kept"), b"old");
    }

    #[test]
    fn force_replaces_the_text_and_repairs_a_permissive_mode() {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let path = base.join("config.toml");
        std::fs::write(&path, b"old").expect("existing");
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644))
            .expect("permissive");
        let writer = FilesystemSetupWriter::new(path.clone(), &[]).expect("prepared");
        writer.write_config("new", true).expect("replaced");
        assert_eq!(std::fs::read(&path).expect("read"), b"new");
        assert_eq!(mode(&path), 0o600);
    }

    #[test]
    fn an_existing_permissive_directory_is_repaired_to_0700() {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let dir = base.join("home");
        std::fs::create_dir(&dir).expect("dir");
        std::fs::set_permissions(&dir, std::fs::Permissions::from_mode(0o755)).expect("permissive");
        FilesystemSetupWriter::new(base.join("c.toml"), std::slice::from_ref(&dir))
            .expect("prepared")
            .create_private_dir(&dir)
            .expect("repaired");
        assert_eq!(mode(&dir), 0o700);
    }

    #[test]
    fn force_refuses_a_configuration_symlink_without_changing_its_target() {
        let temp = tempfile::tempdir().expect("temp");
        let base = temp.path().canonicalize().expect("canonical");
        let target = base.join("target");
        let selected = base.join("config.toml");
        std::fs::write(&target, b"keep").expect("target");
        std::os::unix::fs::symlink(&target, &selected).expect("link");
        let writer = FilesystemSetupWriter::new(selected.clone(), &[]).expect("prepared");

        assert_eq!(
            writer.write_config("replace", true),
            Err(SetupError::PathEscape(selected))
        );
        assert_eq!(std::fs::read(target).expect("target"), b"keep");
    }
}
```

`crates/vpt/tests/support/mod.rs`: `vpt()` gains a session detach so the child has no controlling
terminal, whatever the test runner's stdin is:

```rust
    pub fn vpt(&self) -> Command {
        use std::os::unix::process::CommandExt;
        let mut command = Command::new(VPT);
        command
            .env_clear()
            .env("HOME", self.root.join("home"))
            .env("XDG_CONFIG_HOME", self.root.join("config"))
            .env("XDG_DATA_HOME", self.root.join("data"))
            .env("XDG_STATE_HOME", self.root.join("state"))
            .env("VPT_CONFIG", self.config_path())
            .env("PATH", self.root.join("bin"));
        // SAFETY: setsid is async-signal-safe and the forked child has no other threads.
        unsafe {
            command.pre_exec(|| if libc::setsid() == -1 { Err(std::io::Error::last_os_error()) } else { Ok(()) });
        }
        command
    }
```

`crates/vpt/tests/setup.rs`:

```rust
mod support;

use std::os::unix::fs::PermissionsExt;
use support::{Sandbox, run, stderr, stdout};

#[test]
fn setup_without_a_terminal_exits_2_and_writes_nothing() {
    let sandbox = Sandbox::new("setup-no-tty");

    let output = run(sandbox.vpt().args(["setup", "--json"]));

    assert_eq!(output.status.code(), Some(2));
    assert_eq!(stdout(&output), "");
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("error document");
    assert_eq!(document["error"]["kind"], "usage");
    assert_eq!(document["error"]["message"], "vpt setup needs a controlling terminal");
    assert!(!sandbox.config_path().exists());
    assert!(!sandbox.path().join("home/.vpt").exists());
}

#[test]
fn setup_under_a_pty_writes_the_config_home_state_and_store_leaves() {
    let sandbox = Sandbox::new("setup-pty");

    let mut command = std::process::Command::new("/usr/bin/script");
    command.args(["-q", "/dev/null", support::VPT, "setup"]);
    let vpt = sandbox.vpt();
    let envs: Vec<(String, String)> = vpt
        .get_envs()
        .filter_map(|(key, value)| Some((key.to_string_lossy().into_owned(), value?.to_string_lossy().into_owned())))
        .collect();
    command.env_clear().envs(envs).stdin(std::process::Stdio::piped()).stdout(std::process::Stdio::piped());
    let mut child = command.spawn().expect("script spawned");
    use std::io::Write;
    child.stdin.take().expect("stdin").write_all(b"\n").expect("answer");
    let output = child.wait_with_output().expect("script finished");

    assert_eq!(output.status.code(), Some(0), "{}", stdout(&output));
    let config = std::fs::read_to_string(sandbox.config_path()).expect("config written");
    assert!(config.starts_with("config_version = 1"), "{config}");
    assert!(config.contains("main = \"apple\""), "{config}");
    let mode = std::fs::metadata(sandbox.config_path()).expect("meta").permissions().mode() & 0o777;
    assert_eq!(mode, 0o600);
    let home = sandbox.path().join("home/.vpt");
    assert_eq!(std::fs::metadata(&home).expect("home").permissions().mode() & 0o777, 0o700);
    for leaf in ["audio", "transcripts", "analysis", "briefs", "engine-outputs", "drafts", "released"] {
        assert!(home.join(leaf).is_dir(), "{leaf} missing");
    }
    assert!(sandbox.path().join("state/vpt").is_dir());
}

#[test]
fn setup_refuses_an_existing_config_without_force_and_before_any_terminal() {
    let sandbox = Sandbox::new("setup-exists");
    std::fs::create_dir_all(sandbox.config_path().parent().expect("dir")).expect("config dir");
    std::fs::write(sandbox.config_path(), "config_version = 1\n").expect("existing");

    let output = run(sandbox.vpt().args(["setup"]));

    assert_eq!(output.status.code(), Some(2));
    assert!(stderr(&output).contains("exists; pass --force"), "{}", stderr(&output));
}

#[test]
fn setup_honours_an_explicit_config_path() {
    let sandbox = Sandbox::new("setup-config-flag");
    let elsewhere = sandbox.path().join("elsewhere/config.toml");
    std::fs::create_dir_all(elsewhere.parent().expect("dir")).expect("dir");
    std::fs::write(&elsewhere, "config_version = 1\n").expect("existing");

    let output = run(sandbox.vpt().args(["setup", "--config", elsewhere.to_str().expect("utf8")]));

    assert_eq!(output.status.code(), Some(2));
    assert!(stderr(&output).contains("elsewhere/config.toml exists"), "{}", stderr(&output));
}
```

The `script` process is started outside `Sandbox::vpt()` on purpose: it allocates the pseudoterminal the
interactive test attaches to, so it is the one child that keeps a terminal.

- [ ] **Step 2: Run the tests to verify they fail**

Run independently, including the second command after the first expected failure:

Run: `cargo test -p vpt-application setup`

Run: `cargo test -p vpt-adapters write`

Expected: the builds fail with `cannot find` for `Setup`, `SetupWriter`, `Prompt`,
`FilesystemSetupWriter`. Both test modules are compiled and selected; a run that selects zero tests, or
that succeeds, does not satisfy this step.

Run: `cargo test -p vpt --test setup`

Expected: `setup_without_a_terminal_exits_2_and_writes_nothing` FAILS on the message (the verb is
unimplemented and says so); the pty test FAILS on the missing config; the two refusal tests FAIL on their
stderr text.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-application/src/ports/prompt.rs`:

```rust
//! An interactive choice on the controlling terminal.

#[derive(Debug, PartialEq, Eq)]
pub enum PromptError {
    NoTerminal,
    Closed,
}

pub trait Prompt {
    fn choose(&mut self, question: &str, options: &[&str], preselected: usize) -> Result<usize, PromptError>;
}
```

`crates/vpt-application/src/setup.rs`, above its test module:

```rust
//! `vpt setup`: one prompt, one rendered file, the directories the spec names.

use crate::ports::{Prompt, PromptError};
use std::path::{Path, PathBuf};

#[derive(Debug, PartialEq, Eq)]
pub enum SetupError {
    NoTerminal,
    Exists(PathBuf),
    PathEscape(PathBuf),
    Io(String),
}

pub trait SetupWriter {
    fn config_path(&self) -> PathBuf;
    fn config_exists(&self) -> bool;
    /// Exclusive creation unless `force`; an existing file is `Exists`.
    fn write_config(&self, text: &str, force: bool) -> Result<PathBuf, SetupError>;
    fn create_private_dir(&self, path: &Path) -> Result<(), SetupError>;
}

#[derive(Debug)]
pub struct SetupOutcome {
    pub written: PathBuf,
    pub main_engine: String,
}

pub struct Setup<R: Fn(&str) -> String> {
    pub engines: Vec<String>,
    pub render: R,
    pub directories: Vec<PathBuf>,
}

impl<R: Fn(&str) -> String> Setup<R> {
    pub fn run<P: Prompt, W: SetupWriter>(&self, prompt: &mut P, writer: &W, force: bool) -> Result<SetupOutcome, SetupError> {
        if writer.config_exists() && !force {
            return Err(SetupError::Exists(writer.config_path()));
        }
        let options: Vec<&str> = self.engines.iter().map(String::as_str).collect();
        let chosen = prompt.choose("Main transcription engine", &options, 0).map_err(|error| match error {
            PromptError::NoTerminal => SetupError::NoTerminal,
            PromptError::Closed => SetupError::Io("the terminal closed before an answer".into()),
        })?;
        let main_engine = self.engines.get(chosen).cloned().unwrap_or_else(|| self.engines[0].clone());
        let written = writer.write_config(&(self.render)(&main_engine), force)?;
        for directory in &self.directories {
            writer.create_private_dir(directory)?;
        }
        Ok(SetupOutcome { written, main_engine })
    }
}
```

`crates/vpt-adapters/src/prompt.rs`:

```rust
//! The controlling terminal, opened by name so `--json` keeps stdout clean.

use std::fs::{File, OpenOptions};
use std::io::{BufRead, BufReader, Write};
use vpt_application::ports::{Prompt, PromptError};

pub struct TtyPrompt {
    tty: File,
}

impl TtyPrompt {
    pub fn open() -> Result<TtyPrompt, PromptError> {
        OpenOptions::new().read(true).write(true).open("/dev/tty").map(|tty| TtyPrompt { tty }).map_err(|_| PromptError::NoTerminal)
    }
}

impl Prompt for TtyPrompt {
    fn choose(&mut self, question: &str, options: &[&str], preselected: usize) -> Result<usize, PromptError> {
        let mut text = format!("{question}:\n");
        for (index, option) in options.iter().enumerate() {
            let marker = if index == preselected { "*" } else { " " };
            text.push_str(&format!("  {marker} {} {option}\n", index + 1));
        }
        text.push_str(&format!("choice [{}]: ", preselected + 1));
        self.tty.write_all(text.as_bytes()).map_err(|_| PromptError::Closed)?;
        let mut answer = String::new();
        let mut reader = BufReader::new(self.tty.try_clone().map_err(|_| PromptError::Closed)?);
        if reader.read_line(&mut answer).map_err(|_| PromptError::Closed)? == 0 {
            return Err(PromptError::Closed);
        }
        let answer = answer.trim();
        if answer.is_empty() {
            return Ok(preselected);
        }
        match answer.parse::<usize>() {
            Ok(number) if (1..=options.len()).contains(&number) => Ok(number - 1),
            _ => Ok(preselected),
        }
    }
}
```

A zero-length read is the terminal closing, so setup stops rather than writing the default engine after
the operator has gone.

`crates/vpt-adapters/src/config/write.rs`, above its test module:

```rust
use crate::contained::{Access, ContainedError, RootDir};
use std::ffi::OsString;
use std::fs::{File, Permissions};
use std::io::Write;
use std::os::fd::AsFd;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use vpt_application::{SetupError, SetupWriter};

struct PlannedDirectory {
    path: PathBuf,
    anchor: RootDir,
    missing: Vec<OsString>,
}

impl PlannedDirectory {
    fn capture(path: &Path) -> Result<Self, SetupError> {
        if !path.is_absolute() {
            return Err(SetupError::PathEscape(path.to_path_buf()));
        }
        let mut cursor = path.to_path_buf();
        let mut missing = Vec::new();
        loop {
            match RootDir::open(&cursor) {
                Ok(anchor) => {
                    missing.reverse();
                    return Ok(Self {
                        path: path.to_path_buf(),
                        anchor,
                        missing,
                    });
                }
                Err(ContainedError::Io {
                    kind: std::io::ErrorKind::NotFound,
                    ..
                }) => {
                    let leaf = cursor
                        .file_name()
                        .ok_or_else(|| SetupError::PathEscape(path.to_path_buf()))?
                        .to_os_string();
                    missing.push(leaf);
                    cursor = cursor
                        .parent()
                        .ok_or_else(|| SetupError::PathEscape(path.to_path_buf()))?
                        .to_path_buf();
                }
                Err(error) => return Err(contained(error)),
            }
        }
    }

    fn create(&self) -> Result<RootDir, SetupError> {
        self.anchor.revalidate().map_err(contained)?;
        let mut directory = self.anchor.try_clone().map_err(contained)?;
        for component in &self.missing {
            directory.revalidate().map_err(contained)?;
            let component = component
                .to_str()
                .ok_or_else(|| SetupError::Io("directory name is not UTF-8".into()))?;
            directory = directory.subdirectory(component).map_err(contained)?;
        }
        directory.revalidate().map_err(contained)?;
        let file = File::from(directory.as_fd().try_clone_to_owned().map_err(io)?);
        file.set_permissions(Permissions::from_mode(0o700))
            .map_err(io)?;
        Ok(directory)
    }
}

pub struct FilesystemSetupWriter {
    config_path: PathBuf,
    config_parent: PlannedDirectory,
    directories: Vec<PlannedDirectory>,
}

impl FilesystemSetupWriter {
    pub fn new(config_path: PathBuf, directories: &[PathBuf]) -> Result<Self, SetupError> {
        let parent = config_path
            .parent()
            .ok_or_else(|| SetupError::PathEscape(config_path.clone()))?;
        Ok(Self {
            config_parent: PlannedDirectory::capture(parent)?,
            config_path,
            directories: directories
                .iter()
                .map(|path| PlannedDirectory::capture(path))
                .collect::<Result<_, _>>()?,
        })
    }
}

fn io(error: std::io::Error) -> SetupError {
    SetupError::Io(error.kind().to_string())
}

fn contained(error: ContainedError) -> SetupError {
    match error {
        ContainedError::Io {
            path,
            kind: std::io::ErrorKind::AlreadyExists,
        } => SetupError::Exists(path),
        ContainedError::Io { kind, .. } => SetupError::Io(kind.to_string()),
        ContainedError::Escape { path, .. }
        | ContainedError::NotRegular(path)
        | ContainedError::NotADirectory(path) => SetupError::PathEscape(path),
    }
}

impl SetupWriter for FilesystemSetupWriter {
    fn config_path(&self) -> PathBuf {
        self.config_path.clone()
    }

    fn config_exists(&self) -> bool {
        self.config_path.symlink_metadata().is_ok()
    }

    fn write_config(&self, text: &str, force: bool) -> Result<PathBuf, SetupError> {
        let root = self.config_parent.create()?;
        root.revalidate().map_err(contained)?;
        let name = self
            .config_path
            .file_name()
            .ok_or_else(|| SetupError::PathEscape(self.config_path.clone()))?;
        let name = Path::new(name);
        let mut file = if force {
            match root.open_file(name, Access::Write) {
                Ok(file) => file,
                Err(ContainedError::Io {
                    kind: std::io::ErrorKind::NotFound,
                    ..
                }) => root.create_file(name, 0o600).map_err(contained)?,
                Err(error) => return Err(contained(error)),
            }
        } else {
            root.create_file(name, 0o600).map_err(contained)?
        };
        file.set_permissions(Permissions::from_mode(0o600))
            .map_err(io)?;
        if force {
            file.set_len(0).map_err(io)?;
        }
        file.write_all(text.as_bytes()).map_err(io)?;
        file.sync_all().map_err(io)?;
        root.revalidate().map_err(contained)?;
        root.sync().map_err(contained)?;
        Ok(self.config_path.clone())
    }

    fn create_private_dir(&self, path: &Path) -> Result<(), SetupError> {
        let directory = self
            .directories
            .iter()
            .find(|directory| directory.path == path)
            .ok_or_else(|| SetupError::PathEscape(path.to_path_buf()))?;
        directory.create().map(|_| ())
    }
}
```

`crates/vpt/src/compose.rs`:

```rust
//! The composition root: the environment, the settings and the adapters every
//! command shares. Nothing here decides policy.

use std::path::PathBuf;
use vpt_adapters::config::{config_path, default_state_dir};

pub struct Environment {
    vars: Vec<(String, String)>,
}

impl Environment {
    pub fn from_process() -> Environment {
        Environment { vars: std::env::vars().collect() }
    }

    pub fn var(&self, name: &str) -> Option<String> {
        self.vars.iter().find(|(key, _)| key == name).map(|(_, value)| value.clone())
    }

    pub fn config_path(&self) -> PathBuf {
        config_path(|name| self.var(name))
    }

    pub fn home_dir(&self) -> PathBuf {
        PathBuf::from(self.var("HOME").unwrap_or_default())
    }

    pub fn state_dir_default(&self) -> String {
        default_state_dir(|name| self.var(name))
    }
}
```

`crates/vpt/src/commands/setup.rs`:

```rust
//! `vpt setup`.

use crate::cli::output::Outcome;
use crate::compose::Environment;
use serde_json::json;
use std::path::Path;
use vpt_adapters::config::{FilesystemSetupWriter, from_table, load_text, resolve, template};
use vpt_adapters::TtyPrompt;
use vpt_application::ports::PromptError;
use vpt_application::{Setup, SetupError, SetupWriter};
use vpt_domain::layout::StoreKey;
use vpt_protocol::error::{ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

pub fn run(environment: &Environment, config: Option<&Path>, force: bool) -> Outcome {
    let selected = config
        .map(Path::to_path_buf)
        .unwrap_or_else(|| environment.config_path());
    let state_dir = environment.state_dir_default();
    let home_dir = environment.home_dir();
    let rendered_defaults = template("apple", &state_dir);
    let settings = match load_text(&rendered_defaults)
        .and_then(|table| from_table(&table, &home_dir))
    {
        Ok(settings) => settings,
        Err(error) => {
            return Outcome::Failure(ErrorDocument::new(
                ErrorKind::Config,
                format!("{error:?}"),
            ));
        }
    };
    let parent = selected
        .parent()
        .filter(|path| !path.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    let roots = match resolve(&settings, parent) {
        Ok(roots) => roots,
        Err(error) => {
            return Outcome::Failure(ErrorDocument::new(
                ErrorKind::Config,
                format!("{error:?}"),
            ));
        }
    };
    let Some(name) = selected.file_name() else {
        return Outcome::Failure(ErrorDocument::new(
            ErrorKind::Usage,
            "the configuration path needs a file name",
        ));
    };
    let mut directories = vec![roots.home.clone(), roots.state_dir.clone()];
    directories.extend(
        StoreKey::all()
            .iter()
            .map(|key| roots.stores.get(*key).to_path_buf()),
    );
    let writer = match FilesystemSetupWriter::new(
        roots.config_dir.join(name),
        &directories,
    ) {
        Ok(writer) => writer,
        Err(error) => return setup_failure(error),
    };
    if writer.config_exists() && !force {
        return setup_failure(SetupError::Exists(writer.config_path()));
    }
    let setup = Setup {
        engines: vec!["apple".into(), "whisply".into()],
        render: move |engine: &str| template(engine, &state_dir),
        directories,
    };
    let mut prompt = match TtyPrompt::open() {
        Ok(prompt) => prompt,
        Err(PromptError::NoTerminal) | Err(PromptError::Closed) => {
            return Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, "vpt setup needs a controlling terminal"));
        }
    };
    match setup.run(&mut prompt, &writer, force) {
        Ok(outcome) => Outcome::Success {
            document: document("setup", json!({"written": outcome.written, "main_engine": outcome.main_engine})),
            human: format!("wrote {} (main engine {})\n", outcome.written.display(), outcome.main_engine),
        },
        Err(error) => setup_failure(error),
    }
}

fn setup_failure(error: SetupError) -> Outcome {
    let document = match error {
        SetupError::NoTerminal => ErrorDocument::new(
            ErrorKind::Usage,
            "vpt setup needs a controlling terminal",
        ),
        SetupError::Exists(path) => ErrorDocument::new(
            ErrorKind::Usage,
            format!("{} exists; pass --force to overwrite it", path.display()),
        ),
        SetupError::PathEscape(path) => ErrorDocument::new(
            ErrorKind::Refused,
            format!("{} escapes its prepared root", path.display()),
        )
        .rule("path_escape"),
        SetupError::Io(detail) => ErrorDocument::new(ErrorKind::Store, detail),
    };
    Outcome::Failure(document)
}
```

Resolution and overlap checks run before the terminal is opened or anything is created. The writer
retains the checked ancestors for the configuration, home, state and stores. Existing configuration
without `--force` is refused before prompting. The selected path includes `--config` and `VPT_CONFIG`
included. The `ConfigError` Debug form names keys and kinds, never values, so formatting it here quotes
nothing from the file. In `crates/vpt/src/lib.rs` the dispatch arm is

```rust
        Verb::Setup { force } => commands::setup::run(&Environment::from_process(), invocation.config.as_deref(), *force),
```

with `use compose::Environment;` at the top.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test --workspace --features dev-tools`

Expected: all PASS, the pty test included.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(setup): vpt setup writes the config, the home and the store leaves"
```

______________________________________________________________________
