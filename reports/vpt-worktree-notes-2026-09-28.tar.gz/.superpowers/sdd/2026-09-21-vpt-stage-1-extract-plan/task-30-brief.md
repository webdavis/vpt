### Task 30: `vpt doctor`

Doctor never refuses at startup: every check runs, the whole list is printed either way, and any failed
check makes the exit code 3 with the array inside a `vpt.error/1` document. The stage 1 checks are
config, stores, one git-tree check per store, helper, recordings directory, symlink, one count per Apple
subdirectory, cleanup pending and source gone.

**Files:**

- Create: `crates/vpt-adapters/src/git_tree.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`
- Modify: `crates/vpt/src/cli/output.rs`
- Create: `crates/vpt/src/doctor/mod.rs`, `crates/vpt/src/doctor/checks.rs`,
  `crates/vpt/src/doctor/probes.rs`
- Modify: `crates/vpt/src/lib.rs`
- Test: `crates/vpt/tests/doctor.rs`

**Interfaces:**

- Consumes
  `settings_from(environment: &Environment, config: Option<&Path>) -> Result<Settings, Box<ErrorDocument>>`;
  `resolve(settings: &Settings, config_dir: &Path) -> Result<Roots, RootError>`;
  `planned_directory(path: &Path, key: &str) -> Result<PathBuf, RootError>`;
  `HelperClient::version(&self) -> Result<String, HelperError>`;
  `VoiceMemosStore::open(path: &Path) -> Result<VoiceMemosStore, ContainedError>`;
  `RecorderStore::candidates(&self) -> Result<Vec<Candidate>, RecorderError>`;
  `RootDir::{open(path: &Path) -> Result<RootDir, ContainedError>, open_subdirectory(&self, name: &str) -> Result<RootDir, ContainedError>, names(&self) -> Result<Vec<String>, ContainedError>}`;
  `ClonefileArchive::open_read_only(path: &Path) -> Result<ClonefileArchive, ContainedError>`;
  `Archive::staged_leftovers(&self) -> Result<Vec<PathBuf>, ArchiveError>`;
  `RuntimeLedger::read_only(path: &Path) -> Result<RuntimeLedger, Box<ErrorDocument>>`;
  `RecordingLedger::seen_all(&self) -> Result<Vec<SeenRow>, LedgerError>`;
  `Check { pub name: String, pub ok: bool, pub detail: String }`;
  `ErrorDocument::{checks(self, checks: Vec<Check>) -> Self, diagnostics(self, diagnostics: Vec<String>) -> Self}`.

- Adapter root export `enclosing_git_tree(path: &Path) -> Option<PathBuf>` returns the nearest ancestor,
  including the path itself, with a `.git` entry of any type.

- `Outcome::FailedReport { error: ErrorDocument, human: String }`;
  `emit(outcome: Outcome, json: bool) -> i32` preserves stdout write failures as exit 1.

- Command-private `doctor::run(environment: &Environment, config: Option<&Path>) -> Outcome`;
  `checks::all(environment: &Environment, config: Option<&Path>) -> Vec<Check>` is `pub(super)` inside
  private `doctor::checks`.

- `INSTALL_HINT: &str` names the two install commands from spec section 13. Every invocation emits
  exactly 18 named Stage 1 checks, including failures and explicit dependent checks that could not run.

- [ ] **Step 1: Write the failing tests**

In adapter `lib.rs`, add `mod git_tree;` and `pub use git_tree::enclosing_git_tree;` now. The file starts
with the test module below. The output tests are appended inside the existing `#[cfg(test)] mod tests` in
`cli/output.rs`. Cargo discovers `tests/doctor.rs` automatically.

`crates/vpt-adapters/src/git_tree.rs`, test section:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_nearest_ancestor_with_a_git_entry_is_found_from_a_nested_path() {
        let dir = tempfile::tempdir().expect("dir");
        std::fs::create_dir_all(dir.path().join("vault/.git")).expect("git");
        std::fs::create_dir_all(dir.path().join("vault/notes/vpt")).expect("nested");
        assert_eq!(enclosing_git_tree(&dir.path().join("vault/notes/vpt")), Some(dir.path().join("vault")));
    }

    #[test]
    fn a_git_file_counts_and_no_entry_is_none() {
        let dir = tempfile::tempdir().expect("dir");
        std::fs::create_dir_all(dir.path().join("worktree/sub")).expect("worktree");
        std::fs::write(dir.path().join("worktree/.git"), b"gitdir: elsewhere").expect("git file");
        assert_eq!(enclosing_git_tree(&dir.path().join("worktree/sub")), Some(dir.path().join("worktree")));
        assert_eq!(enclosing_git_tree(&dir.path().join("plain")), None);
    }
}
```

`crates/vpt/src/cli/output.rs`, appended test:

```rust
    #[test]
    fn a_failed_report_keeps_the_error_exit_code() {
        let outcome = Outcome::FailedReport { error: ErrorDocument::new(ErrorKind::Refused, "x").rule("doctor_checks"), human: "ok config\n".into() };
        let mut out = Vec::new();
        let mut err = Vec::new();
        assert_eq!(emit_to(outcome, true, &mut out, &mut err), 3);
        assert!(out.is_empty());
        assert_eq!(serde_json::from_slice::<serde_json::Value>(&err).expect("error")["error"]["rule"], "doctor_checks");
    }

    #[test]
    fn failed_stdout_is_a_store_error_for_both_output_modes() {
        struct Broken;
        impl Write for Broken {
            fn write(&mut self, _bytes: &[u8]) -> std::io::Result<usize> {
                Err(std::io::ErrorKind::BrokenPipe.into())
            }
            fn flush(&mut self) -> std::io::Result<()> { Ok(()) }
        }
        for json in [false, true] {
            let mut err = Vec::new();
            let outcome = Outcome::Success { document: serde_json::json!({"ok": true}), human: "ok\n".into() };
            assert_eq!(emit_to(outcome, json, &mut Broken, &mut err), 1);
            if json {
                assert_eq!(serde_json::from_slice::<serde_json::Value>(&err).expect("error")["error"]["kind"], "store");
            } else {
                assert!(String::from_utf8(err).expect("text").contains("standard output write failed"));
            }
        }
    }

```

`crates/vpt/tests/doctor.rs`:

```rust
mod support;

use support::{Sandbox, run, stderr, stdout};

fn checks(document: &serde_json::Value, key: &str) -> Vec<(String, bool, String)> {
    let list: Vec<(String, bool, String)> = document[key].as_array().expect("checks array").iter().map(|check| (
        check["name"].as_str().expect("name").to_owned(),
        check["ok"].as_bool().expect("ok"),
        check["detail"].as_str().expect("detail").to_owned(),
    )).collect();
    let names: std::collections::BTreeSet<&str> = list.iter().map(|(name, _, _)| name.as_str()).collect();
    let expected = [
        "config", "stores", "helper", "recordings_dir", "symlink", "cleanup_pending", "source_gone",
        "git_tree:audio", "git_tree:transcripts", "git_tree:analysis", "git_tree:briefs",
        "git_tree:engine_outputs", "git_tree:drafts", "git_tree:released",
        "subdirectory:Capture", "subdirectory:CaptureRecovery",
        "subdirectory:CloudRecordings_ckAssets", "subdirectory:EncryptedCloudRecordings",
    ].into_iter().collect();
    assert_eq!(names, expected);
    assert_eq!(list.len(), 18);
    list
}

fn check<'a>(list: &'a [(String, bool, String)], name: &str) -> &'a (String, bool, String) {
    list.iter().find(|(n, _, _)| n == name).unwrap_or_else(|| panic!("no check {name} in {list:?}"))
}

#[test]
fn a_healthy_setup_passes_every_check_and_prints_them_on_stdout() {
    let sandbox = Sandbox::new("doctor-ok");
    sandbox.install_fake_helper();
    sandbox.write_config("");

    let output = run(sandbox.vpt().args(["doctor", "--json"]));

    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["command"], "doctor");
    let list = checks(&document, "checks");
    assert!(list.iter().all(|(_, ok, _)| *ok), "{list:?}");
    assert!(check(&list, "helper").2.contains("1.0.0"));
    assert!(check(&list, "recordings_dir").2.contains("readable"));
    assert_eq!(check(&list, "symlink").2, "not configured");
    assert!(check(&list, "subdirectory:Capture").2.contains("absent"));
    assert_eq!(check(&list, "cleanup_pending").2, "none");
    assert_eq!(check(&list, "git_tree:audio").2, "not in a git tree");
    assert!(!sandbox.path().join("state/vpt").exists());
    assert!(!sandbox.path().join("home/.vpt/audio").exists());
}

#[test]
fn a_missing_helper_fails_with_the_two_install_commands_and_the_human_run_lists_every_check() {
    let sandbox = Sandbox::new("doctor-helper");
    sandbox.write_config("");

    let output = run(sandbox.vpt().args(["doctor", "--json"]));

    assert_eq!(output.status.code(), Some(3));
    assert!(stdout(&output).is_empty());
    let error: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    assert_eq!(error["error"]["rule"], "doctor_checks");
    let list = checks(&error["error"], "checks");
    let helper = check(&list, "helper");
    assert!(!helper.1);
    assert!(helper.2.contains("cargo install --git https://github.com/webdavis/vpt vpt"), "{}", helper.2);
    assert!(helper.2.contains("swift build -c release"), "{}", helper.2);
    let human = run(sandbox.vpt().arg("doctor"));
    assert_eq!(human.status.code(), Some(3));
    assert!(stderr(&human).contains("config") && stderr(&human).contains("FAIL helper"), "{}", stderr(&human));
}

#[test]
fn doctor_preserves_additive_helper_diagnostics_on_success_and_refusal() {
    use std::os::unix::fs::PermissionsExt;
    for (version, exit) in [("1.0.0", 0), ("2.0.0", 3)] {
        let sandbox = Sandbox::new("doctor-helper-diagnostics");
        sandbox.write_config("");
        let helper = sandbox.path().join("bin/vpt-macos");
        let reply = serde_json::json!({"schema":"vpt.helper/1", "version":version, "capabilities":[]});
        std::fs::write(&helper, format!("#!/bin/sh\nprintf '%s\\n' '{reply}'\n")).expect("helper fixture");
        std::fs::set_permissions(&helper, std::fs::Permissions::from_mode(0o755)).expect("executable");
        let output = run(sandbox.vpt().args(["doctor", "--json"]));
        assert_eq!(output.status.code(), Some(exit));
        let text = if exit == 0 { stdout(&output) } else { stderr(&output) };
        let document: serde_json::Value = serde_json::from_str(&text).expect("one document");
        let body = if exit == 0 { &document } else { &document["error"] };
        let list = checks(body, "checks");
        assert_eq!(check(&list, "helper").1, exit == 0);
        assert!(check(&list, "helper").2.contains("unknown additive helper field: capabilities"));
        assert!(!sandbox.path().join("state/vpt").exists());
    }
}

#[test]
fn without_a_config_the_config_check_fails_and_the_rest_are_reported_as_not_run() {
    let sandbox = Sandbox::new("doctor-no-config");

    let output = run(sandbox.vpt().args(["doctor", "--json"]));

    assert_eq!(output.status.code(), Some(3));
    let error: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    let list = checks(&error["error"], "checks");
    assert!(!check(&list, "config").1);
    assert!(check(&list, "config").2.contains("vpt setup"));
    assert_eq!(check(&list, "helper").2, "not run: the configuration did not load");
}

#[test]
fn a_store_inside_a_git_tree_is_reported_and_the_sensitive_two_are_named() {
    let sandbox = Sandbox::new("doctor-git");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    std::fs::create_dir_all(sandbox.path().join("home/.git")).expect("git tree");

    let output = run(sandbox.vpt().args(["doctor", "--json"]));

    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    let list = checks(&document, "checks");
    assert!(check(&list, "git_tree:audio").2.contains("confirm the ignore rules exclude audio"));
    assert!(check(&list, "git_tree:drafts").2.contains("sensitive"));
    assert!(check(&list, "git_tree:engine_outputs").2.contains("sensitive"));
    assert!(!check(&list, "git_tree:transcripts").2.contains("sensitive"));
}

#[test]
fn a_staged_file_left_behind_is_cleanup_pending_and_a_managed_link_is_verified() {
    let sandbox = Sandbox::new("doctor-cleanup");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    std::fs::create_dir_all(sandbox.path().join("home/.vpt/audio")).expect("audio");
    std::fs::write(sandbox.path().join("home/.vpt/audio/.vpt-staging-1"), b"x").expect("leftover");

    let output = run(sandbox.vpt().args(["doctor", "--json"]));

    assert_eq!(output.status.code(), Some(3));
    let error: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    let list = checks(&error["error"], "checks");
    let pending = check(&list, "cleanup_pending");
    assert!(!pending.1);
    assert!(pending.2.contains(".vpt-staging-1"), "{}", pending.2);
}

#[test]
fn a_root_failure_preserves_independent_checks_and_marks_dependencies() {
    let sandbox = Sandbox::new("doctor-bad-root");
    sandbox.install_fake_helper();
    sandbox.write_config(&format!("[stores]\naudio = {:?}\n", sandbox.path().join("absent/audio")));
    let output = run(sandbox.vpt().args(["doctor", "--json"]));
    assert_eq!(output.status.code(), Some(3));
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    let list = checks(&document["error"], "checks");
    assert!(!check(&list, "stores").1);
    assert!(check(&list, "helper").1);
    assert!(check(&list, "recordings_dir").1);
    assert!(check(&list, "git_tree:audio").1);
    assert!(check(&list, "cleanup_pending").2.starts_with("not run:"));
    assert!(!sandbox.path().join("state/vpt").exists());
}

#[test]
fn one_bad_apple_subdirectory_does_not_suppress_the_other_checks() {
    let sandbox = Sandbox::new("doctor-subdirectory");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    let source = sandbox.path().join("voice-memos/Recordings");
    std::os::unix::fs::symlink(sandbox.path(), source.join("Capture")).expect("link");
    let output = run(sandbox.vpt().args(["doctor", "--json"]));
    assert_eq!(output.status.code(), Some(3));
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    let list = checks(&document["error"], "checks");
    assert!(!check(&list, "subdirectory:Capture").1);
    assert!(check(&list, "subdirectory:CaptureRecovery").1);
    assert!(check(&list, "helper").1);
}

#[test]
fn doctor_and_ingest_dry_run_preserve_existing_state() {
    use vpt_domain::fixtures::m4a;
    let sandbox = Sandbox::new("doctor-observes");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    sandbox.add_recording("a.m4a", &m4a(1_787_690_856, 1, b"audio"));
    assert!(run(sandbox.vpt().arg("ingest")).status.success());
    let before = support::state_snapshot(&sandbox);
    for args in [vec!["doctor", "--json"], vec!["ingest", "--dry-run", "--json"]] {
        let output = run(sandbox.vpt().args(args));
        assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
        assert_eq!(support::state_snapshot(&sandbox), before);
    }
}

#[test]
fn doctor_reports_git_ancestry_through_home_links_even_when_another_root_fails() {
    for bad_root in [false, true] {
        let sandbox = Sandbox::new("doctor-resolved-git");
        sandbox.install_fake_helper();
        sandbox.write_config("");
        let repository = sandbox.path().join("repository");
        std::fs::create_dir_all(repository.join(".git")).expect("repository");
        std::fs::rename(sandbox.path().join("home/.vpt"), repository.join("vault")).expect("move home");
        std::os::unix::fs::symlink(repository.join("vault"), sandbox.path().join("home/.vpt")).expect("home link");
        if bad_root {
            sandbox.write_config(&format!("[stores]\nreleased = {:?}\n", sandbox.path().join("missing/released")));
        }
        let output = run(sandbox.vpt().args(["doctor", "--json"]));
        assert_eq!(output.status.code(), Some(if bad_root { 3 } else { 0 }), "{}", stderr(&output));
        let text = if bad_root { stderr(&output) } else { stdout(&output) };
        let document: serde_json::Value = serde_json::from_str(&text).expect("document");
        let list = checks(if bad_root { &document["error"] } else { &document }, "checks");
        for key in ["audio", "drafts", "engine_outputs"] {
            assert!(check(&list, &format!("git_tree:{key}")).2.contains(&repository.display().to_string()));
        }
        assert_eq!(check(&list, "stores").1, !bad_root);
        assert!(!sandbox.path().join("state/vpt").exists());
    }
}

```

- [ ] **Step 2: Run the tests to verify they fail**

Run each command separately: `cargo test -p vpt-adapters git_tree`,
`cargo test -p vpt --features dev-tools --lib cli::output`, and
`cargo test -p vpt --features dev-tools --test doctor`. Expected: each new module is compiled and
selected and fails on the missing implementation. Zero selected tests or a successful command does not
satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-adapters/src/git_tree.rs`:

```rust
//! Whether a path sits inside a git working tree: a walk up for a `.git` entry.

use std::path::{Path, PathBuf};

pub fn enclosing_git_tree(path: &Path) -> Option<PathBuf> {
    path.ancestors().find(|ancestor| ancestor.join(".git").symlink_metadata().is_ok()).map(Path::to_path_buf)
}
```

In Step 1 add `mod git_tree;` and `pub use git_tree::enclosing_git_tree;` to the adapters `lib.rs`. In
`crates/vpt/src/cli/output.rs` the enum and `emit` become:

```rust
pub enum Outcome {
    Success { document: serde_json::Value, human: String },
    Failure(ErrorDocument),
    FailedReport { error: ErrorDocument, human: String },
}

pub fn emit(outcome: Outcome, json: bool) -> i32 {
    emit_to(outcome, json, &mut std::io::stdout(), &mut std::io::stderr())
}

fn emit_to(outcome: Outcome, json: bool, stdout: &mut dyn Write, stderr: &mut dyn Write) -> i32 {
    match outcome {
        Outcome::Success { document, human } => {
            let text = if json { format!("{document}\n") } else { human };
            if stdout.write_all(text.as_bytes()).is_err() {
                return failure(&ErrorDocument::new(ErrorKind::Store, "standard output write failed"), json, "", stderr);
            }
            0
        }
        Outcome::Failure(error) => failure(&error, json, "", stderr),
        Outcome::FailedReport { error, human } => failure(&error, json, &human, stderr),
    }
}

fn failure(error: &ErrorDocument, json: bool, report: &str, stderr: &mut dyn Write) -> i32 {
    let diagnostics = error.diagnostics.iter().map(|line| format!("note: {line}\n")).collect::<String>();
    let text = if json { format!("{}\n", error.to_json()) } else { format!("{report}{diagnostics}vpt: {}\n", error.message) };
    let _ = stderr.write_all(text.as_bytes());
    error.exit_code()
}
```

`crates/vpt/src/doctor/mod.rs`:

```rust
//! `vpt doctor`: every check, always, then one verdict.

mod checks;
mod probes;

use crate::cli::output::Outcome;
use crate::compose::Environment;
use serde_json::json;
use std::path::Path;
use vpt_protocol::error::{Check, ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

pub const INSTALL_HINT: &str = "install with `cargo install --git https://github.com/webdavis/vpt vpt`, then \
`swift build -c release` in helper/vpt-macos and copy .build/release/vpt-macos beside vpt";

pub fn run(environment: &Environment, config: Option<&Path>) -> Outcome {
    let checks = checks::all(environment, config);
    let human = checks.iter().map(line).collect::<String>();
    let failed = checks.iter().filter(|check| !check.ok).count();
    if failed == 0 {
        return Outcome::Success { human, document: document("doctor", json!({"checks": checks})) };
    }
    let error = ErrorDocument::new(ErrorKind::Refused, format!("{failed} checks failed")).rule("doctor_checks").checks(checks);
    Outcome::FailedReport { error, human }
}

fn line(check: &Check) -> String {
    format!("{} {:<26} {}\n", if check.ok { "ok  " } else { "FAIL" }, check.name, check.detail)
}
```

`crates/vpt/src/doctor/checks.rs`:

```rust
use super::probes::{cleanup_pending, git_tree, helper, source_gone, subdirectory, symlink};
use crate::compose::{Environment, settings_from};
use std::path::Path;
use vpt_adapters::VoiceMemosStore;
use vpt_adapters::config::{planned_directory, resolve};
use vpt_application::ports::RecorderStore;
use vpt_domain::layout::StoreKey;
use vpt_protocol::error::Check;

const APPLE: [&str; 4] = ["Capture", "CaptureRecovery", "CloudRecordings_ckAssets", "EncryptedCloudRecordings"];
const NOT_RUN: &str = "not run: the configuration did not load";

pub(super) fn check(name: impl Into<String>, ok: bool, detail: impl Into<String>) -> Check {
    Check { name: name.into(), ok, detail: detail.into() }
}

fn names() -> Vec<String> {
    let mut names: Vec<String> = ["config", "stores", "helper", "recordings_dir", "symlink", "cleanup_pending", "source_gone"]
        .map(str::to_owned).into();
    names.extend(StoreKey::all().map(|key| format!("git_tree:{}", key.key_name())));
    names.extend(APPLE.map(|name| format!("subdirectory:{name}")));
    names
}

pub(super) fn all(environment: &Environment, config: Option<&Path>) -> Vec<Check> {
    let settings = match settings_from(environment, config) {
        Ok(settings) => settings,
        Err(error) => return names().into_iter().map(|name| {
            let detail = if name == "config" { error.message.clone() } else { NOT_RUN.into() };
            check(name, false, detail)
        }).collect(),
    };
    let mut checks = vec![check("config", true, format!("config_version {}", settings.config_version))];
    let selected = environment.selected_config(config);
    let config_dir = selected.parent().filter(|path| !path.as_os_str().is_empty()).unwrap_or(Path::new("."));
    let roots = resolve(&settings, config_dir);
    checks.push(match &roots {
        Ok(roots) => check("stores", true, format!("home {}", roots.home.display())),
        Err(error) => check("stores", false, format!("{error:?}")),
    });
    checks.extend(StoreKey::all().map(|key| {
        let path = match &roots {
            Ok(roots) => Ok(roots.stores.get(key).to_path_buf()),
            Err(_) => planned_directory(settings.stores.get(key), &format!("stores.{}", key.key_name())),
        };
        match path {
            Ok(path) => git_tree(key, &path),
            Err(error) => check(format!("git_tree:{}", key.key_name()), false, format!("{error:?}")),
        }
    }));
    checks.push(helper(&settings));
    let source = if settings.source.recordings_dir.is_absolute() {
        settings.source.recordings_dir.canonicalize()
            .map_err(|error| error.kind().to_string())
            .and_then(|path| VoiceMemosStore::open(&path).map_err(|error| format!("{error:?}")))
    } else {
        Err("source.recordings_dir must be absolute".into())
    };
    checks.push(match &source {
        Ok(store) => match store.candidates() {
            Ok(candidates) => check("recordings_dir", true, format!("readable, {} candidates", candidates.len())),
            Err(error) => check("recordings_dir", false, format!("{error:?}")),
        },
        Err(detail) => check("recordings_dir", false, detail),
    });
    checks.push(symlink(&settings));
    for name in APPLE {
        checks.push(match &source {
            Ok(store) => subdirectory(store.recordings_dir(), name),
            Err(_) => check(format!("subdirectory:{name}"), false, "not run: recordings_dir could not be opened"),
        });
    }
    match &roots {
        Ok(roots) => {
            checks.push(cleanup_pending(&roots.stores.audio));
            checks.push(source_gone(&roots.state_dir));
        }
        Err(_) => {
            checks.push(check("cleanup_pending", false, "not run: store roots did not resolve"));
            checks.push(source_gone(&settings.state_dir));
        }
    }
    checks
}

```

`crates/vpt/src/doctor/probes.rs`:

```rust
use super::{INSTALL_HINT, checks::check};
use crate::compose::RuntimeLedger;
use std::path::Path;
use vpt_adapters::{
    ClonefileArchive, HelperClient, HelperError, LinkState, RootDir, BUILT_AGAINST_MAJOR,
    enclosing_git_tree, inspect_symlink, verify_symlink,
};
use vpt_application::ports::{Archive, RecordingLedger};
use vpt_application::Settings;
use vpt_domain::layout::StoreKey;
use vpt_protocol::error::Check;

pub(super) fn git_tree(key: StoreKey, path: &Path) -> Check {
    let name = format!("git_tree:{}", key.key_name());
    if !path.is_absolute() { return check(name, false, "store path must be absolute"); }
    match enclosing_git_tree(path) {
        None => check(name, true, "not in a git tree"),
        Some(tree) => {
            let note = match key {
                StoreKey::Audio => "; confirm the ignore rules exclude audio",
                StoreKey::Drafts | StoreKey::EngineOutputs => "; sensitive: this store holds private JSON",
                _ => "",
            };
            check(name, true, format!("inside git tree {}{note}", tree.display()))
        }
    }
}

pub(super) fn helper(settings: &Settings) -> Check {
    let helper = HelperClient::new(settings.helper_path.clone());
    let mut result = match helper.version() {
        Ok(version) => check("helper", true, format!("vpt-macos {version} at {}", settings.helper_path.display())),
        Err(HelperError::Absent) => check("helper", false, format!("{} not found; {INSTALL_HINT}", settings.helper_path.display())),
        Err(HelperError::MajorMismatch { found }) => check("helper", false, format!("major version {found}, this build needs {BUILT_AGAINST_MAJOR}")),
        Err(error) => check("helper", false, format!("{error:?}")),
    };
    for diagnostic in helper.take_diagnostics() {
        result.detail.push_str(&format!("; {diagnostic}"));
    }
    result
}

pub(super) fn subdirectory(recordings: &Path, name: &str) -> Check {
    let result = RootDir::open(recordings).and_then(|root| root.open_subdirectory(name));
    let label = format!("subdirectory:{name}");
    match result {
        Ok(root) => match root.names() {
            Ok(names) => check(label, true, format!("{} entries", names.len())),
            Err(error) => check(label, false, format!("{error:?}")),
        },
        Err(vpt_adapters::ContainedError::Io { kind: std::io::ErrorKind::NotFound, .. }) => check(label, true, "absent"),
        Err(error) => check(label, false, format!("{error:?}")),
    }
}

pub(super) fn symlink(settings: &Settings) -> Check {
    match &settings.symlink_target {
        Some(target) => match verify_symlink(&settings.home, target) {
            Ok(()) => check("symlink", true, format!("{} -> {}", settings.home.display(), target.display())),
            Err(error) => check("symlink", false, format!("{error:?}")),
        },
        None => match inspect_symlink(&settings.home) {
            LinkState::LinkTo(target) => check("symlink", true, format!("followed, not managed: {} -> {}", settings.home.display(), target.display())),
            LinkState::Unreadable(detail) => check("symlink", false, detail),
            _ => check("symlink", true, "not configured"),
        },
    }
}

pub(super) fn cleanup_pending(audio: &Path) -> Check {
    let archive = match ClonefileArchive::open_read_only(audio) {
        Ok(archive) => archive,
        Err(error) => return check("cleanup_pending", false, format!("{error:?}")),
    };
    match archive.staged_leftovers() {
        Ok(leftovers) if leftovers.is_empty() => check("cleanup_pending", true, "none"),
        Ok(leftovers) => {
            let names: Vec<String> = leftovers.iter().map(|path| path.display().to_string()).collect();
            check("cleanup_pending", false, format!("{} staged files await the Trash: {}", names.len(), names.join(", ")))
        }
        Err(error) => check("cleanup_pending", false, format!("{error:?}")),
    }
}

pub(super) fn source_gone(state: &Path) -> Check {
    if !state.is_absolute() { return check("source_gone", false, "home.state_dir must be absolute"); }
    let rows = RuntimeLedger::read_only(state).and_then(|ledger| {
        ledger.seen_all().map_err(|error| Box::new(crate::compose::errors::ledger_error(error)))
    });
    match rows {
        Ok(rows) => check("source_gone", true, format!("{} recordings whose source is gone", rows.iter().filter(|row| row.source_gone_at.is_some()).count())),
        Err(error) => check("source_gone", false, error.message),
    }
}
```

Every configured invocation emits the same 18 check names. Root resolution failure does not suppress
helper, source, symlink, git-tree or ledger checks. Only cleanup depends on the whole store-root
validation. An absent archive and ledger are empty observations. No doctor path creates or repairs state.

Dispatch: `Verb::Doctor => doctor::run(&environment, invocation.config.as_deref()),` with `mod doctor;`
in `lib.rs`.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test --workspace --features dev-tools`

Expected: all PASS. Format before counting: `checks.rs` owns the census, `probes.rs` owns independent
adapter observations, and both remain below 200 implementation lines.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(doctor): every stage 1 check with the doctor_checks verdict"
```

______________________________________________________________________

