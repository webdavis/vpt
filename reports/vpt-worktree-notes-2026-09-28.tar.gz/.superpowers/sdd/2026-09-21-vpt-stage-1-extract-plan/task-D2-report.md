# D2: Descriptor-owned database locks and supervised fixtures

## Controller checkpoint

Independent Astra review is complete in `task-D2-review-1.md`. It found no functional lock or containment defect, but its required rubric marks the plan-mandated duplicate crate-local process cleanup as Important. Follow-up `6hc89rxCFRpJ8Fjg` awaits the operator's decision on retaining it versus expanding scope for shared test support. D2 remains unaccepted. Bounded timeout-output diagnostics are a Minor follow-up, tracked with `6hc7MMRc2QhRm75g`.

The fresh committed-HEAD `just ship` exited 0 in `task-D2-controller-ship.log`: all 225 baseline binary/leaf names retained, 245 final, 20 added and zero missing. The 99-commit secrets scan is clean. The longest complete target was the 124-test adapter target at 0.82 seconds, bounding every leaf in this run below one second. Worktree/index remained clean and HEAD unchanged. The controller read current source hashes and confirmed the lock mutation target and restored D1 file equal the values below. Independent Astra review is complete; D2 acceptance awaits the decision above.

Base: `1a00d858db6a744970599096318340af1ce7ccee`. Final HEAD:
`338dc9ca3806e69990c1b59056466e88ba6c4719`, `feat(database): coordinate descriptor-owned locks`.
Worktree: `/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract`, branch `feat/stage-1-extract`.
The commit contains the eight D2 files listed below. Normal hooks ran, with `SKIP_AI_COMMIT=1` used only
for the approved message-generator bypass. Worktree and index were clean after committing. Independent
review and the controller's fresh committed-HEAD gate remain controller work.

## Scope and interfaces

`database/locks.rs` supplies crate-private `LockKind::{Shared, Exclusive, Unlock}` and
`set_record_lock(&File, i64, i64, LockKind) -> Result<(), DatabaseError>`. Its private conflict query uses
`F_OFD_GETLK`. `DatabaseLocks` and its methods remain visible only within `database`: `new(File)` owns the
file; `lock(i32)`, `unlock(i32)` and `reserved()` implement the checked SQLite protocol; `file()` and
`level()` support D3 callbacks and file controls. Each test connection uses a separately opened D1 file
description. No duplicate descriptor or process-wide inode table coordinates locks.

Nonblocking `F_OFD_SETLK` attempts use checked ranges and a zero-initialized `libc::flock`. Contention maps
to SQLite busy, interrupted calls retry, and other failures retain an input/output error kind. Unsupported
locking fails closed. Shared acquisition releases the temporary pending-byte lock even when the shared
range is busy. Exclusive promotion retains pending after acquiring that byte. Downgrade converts the
shared range before releasing pending/reserved; full unlock affects only the owning description. Failed
operations propagate errors, and recorded levels advance only after successful transitions or acquisition
of the deliberately retained pending lock. Reserved queries include the owner's known state.

The private child harness owns the process group, stdin and both nonblocking output readers. Its single
500 ms deadline covers readiness, sending and output collection. Cleanup allows a 50 ms graceful phase,
then terminates the owned group and polls for reaping before the 900 ms cleanup deadline. Each output
capture is capped at 64 KiB. The child is this test executable selecting the exact
`database::tests::children::scenarios::database_child` leaf. A fixed scenario match selects owned fixtures;
the environment is cleared and HOME, all three XDG roots, VPT_CONFIG, PATH and current directory point
inside the synthetic temporary tree. The existing command-test ownership pattern was adapted inside the
adapters crate. No cross-crate include or new dependency was introduced.

The eight files are `database/locks.rs`, `database/mod.rs`, `database/tests/mod.rs`,
`database/tests/locks.rs`, `database/tests/children.rs`, and the latter's `capture.rs`, `process.rs` and
`scenarios.rs` children. Existing `database/tests/support.rs` supplies the private root unchanged. The
five-crate dependency graph, public interfaces, command arguments, configuration and database formats are
unchanged. D3 owners/callbacks, D4 shared memory, D5 schema/ledger work and D6 title copies remain outside D2.

## Primary sources and preflight

The local SDK's `fcntl(2)` open-file-description section confirms the independent-open and last-close
semantics and the nonblocking/query operations. Locked `libc 0.2.189` defines `F_OFD_SETLK = 90` and
`F_OFD_GETLK = 92`. Locked `libsqlite3-sys 0.37.0` SQLite source confirms the pending/reserved/shared byte
ranges, transition protocol and `unix-posix` registration using `posixIoFinder`. These excerpts are in
[source anchors](task-D2-source-anchors-01.log). The complete lock and unlock implementations were also
read before implementation. The runtime native tests confirm that `unix-posix` is registered; missing
reference locking is an explicit failure, not a passing skip.

The current pane's Neovim diagnostic reported no answering server before edits. Product edits used
`apply_patch` with scoped escalation for this existing worktree. There was no live configuration/data
access, Voice Memos scan, source/destination scan, installation, apply, third-party edit, SQLite syscall
override, broad process listing, push or remote publication.

## Test-first evidence and coverage

[RED](task-D2-red-01.log) compiled and ran all 19 initial lock/watchdog leaves. All failed against explicit
`Unsupported` stubs for the intended missing behavior; the watchdog specifically observed `Unsupported`
instead of `TimedOut`. [First GREEN](task-D2-green-01.log) passed all 19 in 0.57 seconds. The final workspace
run adds the child entry leaf, which returns immediately when no scenario marker exists.

Coverage includes independent close, two shared holders, reserved writer exclusion with concurrent
readers, new-reader exclusion by pending, failed/retried promotion, exclusive and pending downgrades,
description-local full unlock, temporary pending-lock release after failed shared acquisition, unchanged
levels on pending-byte contention, invalid levels/ranges, and repeated requests. Reserved queries are
checked both on the owner and on another description.

Four separately named FIFO (first in, first out) leaves exercise database, journal, write-ahead log (WAL)
and shared-memory refusals. Each child creates one FIFO and opens only its read end through D1. The stall
fixture ignores SIGTERM and blocks on its owned stdin, so the watchdog exercises forced group termination
and reaping independently of any database lock implementation.

Native reference scenarios create a valid rollback-mode database and close the fixture connection before
starting the reference transaction. A child-held `BEGIN EXCLUSIVE` blocks the rooted reader, which then
successfully acquires exclusive access after the child releases it. A rooted reserved writer blocks a
native child's `BEGIN IMMEDIATE`. Native and rooted participants never share one process on the same
inode. These are real SQLite transactions versus D2 record locks; full rooted SQL/WAL interoperability
remains D4 work.

## Compiled mutations and exact restoration

All 11 mutants compiled and failed their intended named behavior. Every mutant log records the changed
file's SHA-256 and source bytes before compilation. Controls compare the restored file against its
pre-mutation hash before compiling and running the same selected leaf or leaves. No mutant survived.

| Mutation | Failed behavior | Raw evidence |
| --- | --- | --- |
| `F_OFD_SETLK` to `F_SETLK` | Independent close accepts the conflicting writer instead of busy | [mutant](task-D2-mut-process-lock-01.log), [control](task-D2-control-process-lock-01.log) |
| Remove D1 existing-open `O_NONBLOCK` | All four FIFO roles return `TimedOut` | [mutant](task-D2-mut-blocking-fifo-01.log), [control](task-D2-control-blocking-fifo-01.log) |
| Pending write lock becomes shared | New reader enters during pending | [mutant](task-D2-mut-shared-pending-01.log), [control](task-D2-control-shared-pending-01.log) |
| Retained pending level becomes reserved | Failed promotion reports the wrong level | [mutant](task-D2-mut-retained-pending-01.log), [control](task-D2-control-retained-pending-01.log) |
| Downgrade unlocks the shared range | Competing writer obtains exclusive access | [mutant](task-D2-mut-downgrade-shared-01.log), [control](task-D2-control-downgrade-shared-01.log) |
| Owner reserved query returns false | Current owner loses its reserved result | [mutant](task-D2-mut-reserved-query-own-01.log), [control](task-D2-control-reserved-query-own-01.log) |
| Invert the conflict query | Other description misses the reserved owner | [mutant](task-D2-mut-reserved-query-peer-01.log), [control](task-D2-control-reserved-query-peer-01.log) |
| Full unlock affects only byte zero | Reserved lock remains after unlock | [mutant](task-D2-mut-unlock-range-01.log), [control](task-D2-control-unlock-range-01.log) |
| Shared-acquisition cleanup retains pending read lock | Failed acquisition still excludes a pending writer | [mutant](task-D2-mut-shared-cleanup-01.log), [control](task-D2-control-shared-cleanup-02.log) |
| Move reserved byte to pending plus 512 | Native transaction succeeds during rooted reserved lock | [mutant](task-D2-mut-reserved-byte-01.log), [control](task-D2-control-reserved-byte-01.log) |
| Remove range validation | Negative range fails the typed-invalid-input assertion | [mutant](task-D2-mut-range-validation-01.log), [control](task-D2-control-range-validation-01.log) |

The FIFO mutation ran only in supervised children. Its entire four-test target finished in 0.51 seconds;
all children were terminated and reaped. The restored four-role control passed in 0.03 seconds.

One restoration attempt was rejected by its hash guard: the inverse shared-cleanup patch matched the
earlier repeated pending-byte call. No incorrect control ran. The [failed control artifact](task-D2-control-shared-cleanup-01.log)
and [repair record](task-D2-restoration-repair-01.log) are retained. Restoring the complete surrounding
block recovered the original bytes, and control 02 passed. This was a mutation-fixture correction, with
no change to the green implementation.

Exact original/restored SHA-256 values:

- `database/locks.rs`: `3d88c5338e63f620cfc4dde2de76a957963a67ba7db50ae27fa0d1b39fc797e2`.
- D1 `contained/file.rs`: `b5792bcf7d0d653d136f3dc8c53443ae9ce823d9c4ca96f48d5a793ec8ff033e`.

[Final hashes](task-D2-final-hashes-01.log) records all eight committed source/test files. D1's file has no
final diff.

## Final-source and committed-HEAD gates

| Command | Result | Raw evidence |
| --- | --- | --- |
| `just ship` | exit 0; 245 leaves; 38.10 s | [ship](task-D2-ship-final-01.log) |
| `just test-rust` | exit 0; 245 leaves; 6.61 s | [tests](task-D2-test-rust-final-01.log) |
| `just lint-check` | exit 0; 1.25 s | [lint](task-D2-lint-check-final-01.log) |
| `cargo check --locked --workspace --all-targets --features dev-tools` | exit 0; 5.43 s | [check](task-D2-check-all-targets-final-01.log) |
| `cargo build --locked --release` | exit 0; 4.42 s | [release](task-D2-release-final-01.log) |
| `cargo clippy --locked -p vpt-adapters --all-targets -- -D warnings` | exit 0; 0.34 s | [focused Clippy](task-D2-adapters-clippy-final-01.log) |
| `cargo fmt --all -- --check` | exit 0 inside ship and lint | [ship](task-D2-ship-final-01.log) |
| `RUSTDOCFLAGS="-D warnings" cargo doc --locked --workspace --no-deps` | exit 0 inside ship | [ship](task-D2-ship-final-01.log) |
| Staged whitespace and complete physical-line audit | exit 0 | [size audit](task-D2-size-audit-final-01.log) |
| `gitleaks git --redact --no-banner` after commit | exit 0; 99 commits, no leaks; 5.47 s | [secrets](task-D2-committed-head-secrets-01.log) |

The [baseline](task-D2-baseline-leaves-01.log) and [final](task-D2-final-leaves-01.log) inventories retain
all 225 baseline binary/leaf names. There are [20 added names](task-D2-added-leaves-01.log) and
[zero missing names](task-D2-missing-leaves-01.log). No baseline test was renamed or removed.

The [timing record](task-D2-timings-final-01.log) uses the normal parallel workspace runner. The longest
complete target was the 124-test adapter target, 0.80 seconds during ship and 0.78 seconds during
`just test-rust`. Those complete-target durations bound every contained leaf below one second. They are
upper bounds, not invented individual measurements. The existing command deadline issue did not recur
in these runs; follow-up `6hc7MMRc2QhRm75g` remains open. Stable libtest rejected an attempted
`--report-time` diagnostic; its [tool-output transcript](task-D2-timing-diagnostic-01.log) is retained, and
no nightly-feature bypass was used.

After staging all new files, the audit measured `locks.rs` at 180 implementation/180 total lines,
`database/mod.rs` at 86/88, and the new test files at 284, 137, 63, 36 and 90 total lines. The test module
declaration file is four lines. Only the accepted inherited `config/schema.rs` (471) and
`config/load/tests.rs` (304) exceed targets. The command entry point remains three lines.

## Incremental staging ruling and remaining work

The [initial Clippy diagnostic](task-D2-incremental-clippy-01.log) identified exactly 11 unused production
items. The controller approved item-level `cfg_attr(not(test), expect(dead_code, reason = ...))` on them.
[Focused Clippy](task-D2-clippy-pre-mutation-01.log) and all final gates passed after those annotations.
The following complete inventory belongs to cleanup follow-up `6hc7x7wMwxF8R9rg`:

| Annotated item | Real consumer and removal point |
| --- | --- |
| `PENDING_BYTE` | D3 database lock callbacks |
| `RESERVED_BYTE` | D3 lock and reserved-query callbacks |
| `SHARED_FIRST` | D3 database lock callbacks |
| `SHARED_SIZE` | D3 database lock callbacks |
| `LockKind` | D3 lock callbacks; later D4 and D6 also use it |
| `set_record_lock` | D3 lock callbacks; later D4 and D6 also use it |
| `has_conflict` | D3 reserved-query callback |
| `record_lock` | D3 nonblocking lock operations |
| `DatabaseLocks` | D3 file-state ownership |
| `DatabaseLocks` concrete implementation | D3 callbacks, including `file` and `level` controls |
| `invalid` | D3 checked callback lock requests |

Remove all 11 D2 expectations in D3. D1's nine existing expectations are unchanged. The production module
compiles in normal and test builds; no module allowance, public visibility expansion, synthetic caller,
test-only production gate or dependency change was added.

D2 is implemented and committed. Review still needs to assess its unsafe lock boundary and fixture
ownership independently. D3 supplies callback wiring, lifetime and fault injection; D4 supplies full SQL
and WAL interoperability. The tests here do not claim injected syscall failure coverage or an installed
binary result. No further task was started, and progress.md/Todoist were left to the controller.
