# D6 execution brief

## Controller constraints

- Close staging-lint follow-up 6hc7x7wMwxF8R9rg only after source inspection and warning-denied gates verify all inventoried expectations are gone.
- Remove any inventoried title-policy staging expect(dead_code) annotations when the real title-copy consumers are wired. Together with D5's earlier cleanup, no database staging lint expectations may remain at acceptance. Do not invent use sites or expand visibility to silence the compiler.
- Dispatch from accepted Task 15 and the accepted contained database, locks and fixture supervisor. The 2026-09-27 dependency review confirmed that Tasks 12 and 14 supply no code prerequisite; the independent ledger query can use the existing schema-version method. D6 replaces original Task 16. Read the actual recorder/title/database interfaces and the complete original Task 16 in docs/superpowers/plans/2026-09-21-vpt-stage-1-extract-plan.md for its concrete fixture and lookup contracts. The amendment below controls ownership, leases, convenience return types and access policy. Astra implementation and independent Astra review.
- Own only the recorder port additions, existing recorder store integration, title copy/lease/query modules, focused tests and required exports listed below, plus D6 report/evidence. Main owns progress.md and Todoist. You are not alone; preserve all other work. One product writer, no subagents/new worktree, no early ingest/application work.
- Read task-D6-query-preflight.md. Controller correction: reproduce the default LIKE case-fold mismatch using the real locked-library TitleCopy fixture, then require literal case-sensitive basename matching with parameterized binary equality. This replaces only the original case-folding predicate, preserving table quoting, lookup outcomes and existing metacharacter tests. The recorded CLI experiment is not VPT runtime evidence. Todoist follow-up 6hc7cv7J4HH7JWPg remains open until review accepts the correction.
- Preserve TitleLookup::{Titled(String), Unavailable}, RecorderStore::title and refresh_titles, COPY_DIRECTORY = "title-copy", and both VoiceMemosStore title builders. TitleCopy::refresh and existing now return Result<TitleCopy, ContainedError> as the amendment requires. Do not revive the original native opener, erase typed containment with .ok(), or replace the actual store with the outdated sample struct.
- Use the owned retained descriptor for refresh, take the exclusive byte-zero lease before any chmod/truncate/copy, and drop the prior database owner before refreshing. Source opens are read-only. Refreshed private copies may write their shared memory; existing-copy observation changes nothing. Close the database before releasing the lease on every path.
- All fixtures are synthetic and owned, with actual database readers inside the independent watchdog. No live Voice Memos or destination access, broad process listings, third-party modifications, system-call overrides, denied probes, install, push, pull request, merge, apply or destructive cleanup. Verify buffer safety and use apply_patch.
- Follow clean-code-rust, sql-toolkit's relevant parameterized-query guidance and scoped security review. Preserve prior leaves, compiling behavioral RED, unique raw evidence, exact compiled mutations and byte-identical restored controls. Address survivors. Required Rust/release/staged-size/secrets gates apply; controller owns fresh committed-HEAD ship. Existing command deadlines are tracked as 6hc7MMRc2QhRm75g; preserve recurrence without retry loops or deadline increases.

## Approved D6 task

## D6: Private title-copy leases and contained title reads

**Files:** Original Task 16's recorder port additions, exports, `voice_memos/store.rs`,
`voice_memos/titles.rs` and its tests; create `voice_memos/titles/lease.rs`. Extend the existing
`database/tests/children.rs` and `database/tests/support.rs` for actual title-reader scenarios.

**Interfaces:** Keep `RecorderStore::refresh_titles(&self) -> Result<(), RecorderError>` and
`title(&self, file_name: &str) -> TitleLookup` unchanged. `TitleCopy` holds an optional
`RefCell<Database>`, discovered table and lease. Replace private `open_copy` with
`open_copy(root: RootDir, policy: AccessPolicy, lease: CopyLease) -> Result<TitleCopy, DatabaseError>`.
Change adapter convenience methods `refresh(container: &Path, state_dir: &Path)` and
`existing(state_dir: &Path)` to return `Result<TitleCopy, ContainedError>` so callers must classify
containment; ordinary copy/schema/query failures still produce an unavailable copy. Keep
`refresh_at(container: &Path, state: &RootDir) -> Result<TitleCopy, ContainedError>`.

`CopyLease::read(copy: &RootDir, timeout: Duration) -> Result<Self, DatabaseError>` opens the existing
main copy read-only. `CopyLease::refresh(copy: &RootDir, timeout: Duration)` opens or exclusively creates
it read/write, without truncating or repairing permissions before the exclusive lease is held.
`downgrade(&mut self) -> Result<(), DatabaseError>` converts the exclusive lock to shared. The lease
holds an independently opened file description for byte 0, length 1, and stays alive until after the
title database closes. It is never a duplicate of SQLite's description. D2 supplies the lock primitive.

- [ ] **Step 1: Write compiling red title and lease tests.**

```rust
#[test]
fn an_existing_title_reader_prevents_refresh_truncation() {
    let (_temp, root) = root();
    let copy = root.subdirectory(COPY_DIRECTORY).unwrap();
    std::fs::write(copy.path().join("CloudRecordings.db"), b"unchanged").unwrap();
    let before = snapshot(copy.path());
    let reader = CopyLease::read(&copy, Duration::from_millis(20)).unwrap();
    assert!(CopyLease::refresh(&copy, Duration::from_millis(20)).is_err());
    assert_eq!(snapshot(copy.path()), before);
    drop(reader);
    assert!(CopyLease::refresh(&copy, Duration::from_millis(20)).is_ok());
}
```

Preserve original Task 16's concrete title fixtures and SQL assertions, adapting calls to the typed
result. Verify a committed title that exists only in the copied WAL, unchanged source snapshots,
missing/empty titles, escaped SQL filename patterns, unexpected schema, absent source companions and copy
failure. Add separate refreshed-copy and existing-copy snapshots: the former may change private shared
memory but not copied database/WAL bytes; the latter changes nothing. Assert dry run neither opens nor
refreshes title databases.

Add a child reader holding an actual `TitleCopy`, then attempt refresh in another process. Assert busy or
bounded unavailable without truncation, close the reader, and assert refresh succeeds. While the title
lease is held, query a separate ledger successfully. The timeout must be covered by the existing
watchdog, including a mutation that removes the refresh deadline.

- [ ] **Step 2: Run red.**

```bash
cargo test --locked -p vpt-adapters voice_memos::titles -- --nocapture
```

Expected: the selected tests run and fail against the missing lease/owner behavior. Compilation errors
from changed convenience signatures must be resolved before recording red evidence.

- [ ] **Step 3: Implement the lease and refresh order.**

Use a monotonic deadline and nonblocking `set_record_lock` attempts. Retry contention only until the
supplied deadline; other failures return immediately. A bounded sleep between attempts is permitted in
production retry handling, not as test synchronization. All production callers supply five seconds. Byte
0 is outside SQLite's database locking range; the separate description keeps the lease independent of
SQLite's unlock-all operation. This lease coordinates VPT copy readers and refreshers only.

```text
refresh_titles:
  remove and drop the previous TitleCopy before acquiring a refresh lease
  revalidate source and checked private state roots
  acquire exclusive CopyLease before any destination truncate, chmod or copy
  open every source through Access::Read
  copy the three fixed files through destination descriptors
  leave a missing source companion represented by the existing empty-copy rule
  on any copy failure, keep this sweep's titles unavailable and do not reopen
  after the complete copy succeeds, open with RefreshedTitleCopy policy
  discover the title table and initialize any needed shared memory while still exclusive
  downgrade the lease to shared and retain it with the owner

existing:
  open existing private root without creating or repairing it
  acquire shared CopyLease before opening SQLite
  open with ExistingTitleCopy policy; retain lease through final close
```

The lease's main descriptor and the descriptor used for main-file copying must identify the same file.
Use the retained lease file for truncation/copy, or verify identity when a second descriptor is needed.
Do not repair its mode before the lease is acquired. Refuse unsafe entries and multiple links on every
destination acquisition. Permission repair is confined to the exclusive refresh phase.

Store the owner in `RefCell` because the existing `title(&self, ...)` port borrows immutably. Execute the
original parameterized title query inside `with_connection`, with the original table-name quoting and
LIKE escaping. Match ordinary query/schema failures to `Unavailable` only after checking the typed error.
`refresh_at` propagates containment; the store maps it to `RecorderError::Escape`. Existing-copy callers
explicitly choose their documented observation outcome rather than silently calling `.ok()` on the shared
opener. Keep application port types unchanged.

Implement `Drop` for `TitleCopy` so the database is closed/dropped before the copy lease. Field order
alone must not release a lease while a dependent connection remains. Root substitution during close
retains the same acquired descriptors and never switches to a new copy directory.

- [ ] **Step 4: Verify green and lease/error mutations.**

Run title and database tests. Mutate removal of the old owner before refresh, the exclusive lease, lease
lifetime, the existing-copy policy and typed-containment propagation individually. Each relevant leaf
must fail; restore exact bytes and controls. Test both same-process VPT readers and separate process
readers. Native source-fixture SQLite may stay open because its inode differs from the private copy's
inode; snapshot its source only after its fixture writer is quiescent.

- [ ] **Step 5: Format, review and commit.**

```bash
cargo fmt --all
cargo test --locked -p vpt-adapters voice_memos
git add crates/vpt-application/src/ports/recorder.rs crates/vpt-application/src/ports/mod.rs
git add crates/vpt-adapters/src/voice_memos crates/vpt-adapters/src/lib.rs
git add crates/vpt-adapters/src/database/tests
git commit -m "feat(titles): protect private database refresh and reads"
```
