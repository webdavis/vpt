# Task 31 execution brief

Read `task-31-brief.md` completely and
`task-D7-integration-addendum.md`. Root read both complete sources and the current ledger wrappers,
contract registration, memory state and retention value type on 2026-09-27.

## Independent repository slice

The expiry rule, typed audio-retention journal, Memory/SQLite implementations and shared contracts
depend on accepted ledger primitives, not on the doctor or ingest command. This slice may proceed
independently after root dispatch. It does not create a RuntimeLedger, command stub or CLI route.
Runtime delegation remains with command composition once that actual type exists. Task 31 stays
incomplete until the deferred delegation and combined acceptance checks pass.

## Remaining runtime delegation dispatched

Root owns the remaining delegation in `feat/retention-runtime`, based on accepted `a66dbac`.
The actual `RuntimeLedger` now exists from Task 28. Delegate pending intents to its current ledger.
The empty observational variant must refuse both mutations rather than creating transient intents.
The SQLite variant delegates while preserving `SqliteLedger::transaction`'s existing access-policy
guard, so an observational SQLite ledger still refuses both writes before database access. No new
runtime mode, command route, database opener or history interface belongs in this slice.

Five named tests precede this implementation: empty observational reads and both write refusals;
populated read-only fields, ordering and both write refusals; durable writable insertion; selected
writable completion; and preserved root-replacement refusal. Existing recording delegation leaves
remain unchanged. Root requests independent review of its own slice before combined acceptance.

## Repository implementation constraints

Keep private insert/complete helpers reusable by the forthcoming state/history transaction. The
later retention workflow must save each intent or completion and corresponding history together;
calling two separately committed public methods will not meet the approved logging contract.
Do not change Task 19's history interfaces or schema in this independent slice. Root owns that
cross-cutting integration. No log export, hook, real Trash or retention action runs here.

Before behavior implementation, write a compact coverage census and compiling behavioral tests for
all new branches: full-field persistence, ordered remaining intents, repeated/unknown completion,
safe malformed-row rejection and durable reopen, plus expiry arithmetic boundaries. Existing guards
that already pass are recorded honestly; never manufacture an initial failure. Preserve existing
test names and use the current supervised SQLite fixture, not the sample's obsolete macro layout.
One native verification batch at a time, coordinated directly with the active writers. Root owns the
combined ship, release and normal-parallel timing gates; this writer runs focused tests, meaningful
compiled mutations and static checks.

- Own the expiry function, audio-retention intent port, memory/SQLite implementations, shared contract and runtime delegation named by Task 31, plus its ignored report/evidence. Main owns progress and Todoist. Preserve other work; one product writer, no new worktree or subagents.
- Consume the strengthened owner's existing `SqliteLedger` wrappers. No bare connection export, native production opener, writable path reconstruction or broadened database visibility. Preserve typed containment and storage errors.
- The historical sample's `Corrupt(format!("... {row_value}"))` decoders conflict with the safe-error contract. Use the actual typed decoder/error conventions from D5/Task 12 and never include stored kind, recording or digest values in a returned error. Add private malformed-row regressions with canary values to prove refusal without disclosure.
- Make the shared contract genuinely verify every intent field, including recording and recorded_at, using distinct values. Its ordering test must leave at least two pending intents whose sequence can be checked after an earlier completion. Preserve both original leaf names, adding focused cases where needed. Exercise identical scenarios through memory and durable implementations, with a reopened durable ledger for persistence evidence.
- Keep exact full-width expiry arithmetic and cover zero hold, future mtime, nanoseconds and u64::MAX without sleeps. Mutation-test a boundary change and relevant serialized-field/ordering changes with exact restored passing controls.
- Use compiling behavioral RED stubs, not the historical compile-error RED example. Preserve all baseline leaves. Add no later-stage artifact model here: Stage 1 ownership is audio from RecordingLedger, and this port is its intent journal only.
- Follow clean-code-rust, buffer safety, apply_patch, normal commit hooks, focused static checks and
  the staged size census. Root owns combined ship, release, nightly timing and independent review.
  Synthetic fixtures only; no live paths, installation, publication, apply, third-party changes or
  destructive cleanup.
