### Task 28: `vpt show`, `vpt list` and `vpt storage`

Three read-only verbs over the ledger and the stores. `list --stage <stage>` narrows to the recordings
whose named stage (`transcribe`, `note`, `synthesis`) has not succeeded, which is the work waiting there;
any other stage word is a usage error.

**Files:**

- Modify: `crates/vpt-application/src/ports/stores.rs`
- Create: `crates/vpt-application/src/inventory.rs`
- Modify: `crates/vpt-application/src/ports/mod.rs`, `crates/vpt-application/src/lib.rs`
- Modify: `crates/vpt-adapters/src/stores.rs`
- Create: `crates/vpt/src/commands/show.rs`, `crates/vpt/src/commands/list.rs`,
  `crates/vpt/src/commands/storage.rs`
- Modify: `crates/vpt/src/commands/mod.rs`, `crates/vpt/src/lib.rs`, `crates/vpt/src/compose.rs`
- Create: `crates/vpt/src/compose/observations.rs`
- Test: `crates/vpt/tests/show_list_storage.rs`

**Interfaces:**

- Consumes
  `RecordingLedger::{by_id(&self, id: &RecordingId) -> Result<Option<RecordingRecord>, LedgerError>, recordings(&self) -> Result<Vec<RecordingRecord>, LedgerError>}`;
  `record_json(record: &RecordingRecord) -> serde_json::Value`;
  `settings_from(environment: &Environment, config: Option<&Path>) -> Result<Settings, Box<ErrorDocument>>`;
  `RuntimeLedger::read_only(path: &Path) -> Result<RuntimeLedger, Box<ErrorDocument>>`;
  `planned_directory(path: &Path, key: &str) -> Result<PathBuf, RootError>`;
  `resolve_stores(settings: &Settings) -> Result<StorePaths, RootError>`;
  `StoreKey::{all() -> [StoreKey; 7], key_name(self) -> &'static str}`;
  `FilesystemStores::open_read_only(paths: &[PathBuf]) -> Result<FilesystemStores, ContainedError>`.

- Adds `StoreEntry { pub path: PathBuf, pub size: u64, pub mtime: FileTime }` to the
  `vpt_application::ports` exports and extends the existing `Stores` trait with
  `fn entries(&self, root: &Path) -> Result<Vec<StoreEntry>, StoreError>`. It lists regular files at
  depth one, refuses symbolic links, and treats an absent configured root as empty. Unknown roots are
  `StoreError::Escape`.

- Exports
  `vpt_application::{StoreInventory { pub files: u64, pub bytes: u64, pub oldest: Option<FileTime>, pub newest: Option<FileTime> }, inventory(entries: &[StoreEntry]) -> Option<StoreInventory>}`.

- Produces composition
  `ledger_from(environment: &Environment, config: Option<&Path>) -> Result<RuntimeLedger, Box<ErrorDocument>>`
  and
  `storage_from(environment: &Environment, config: Option<&Path>) -> Result<(StorePaths, FilesystemStores), Box<ErrorDocument>>`.

- Command-private functions: `show::run(ledger: &dyn RecordingLedger, id: &str) -> Outcome`,
  `list::run(ledger: &dyn RecordingLedger, stage: Option<&str>) -> Outcome`,
  `storage::run(paths: &StorePaths, source: &dyn Stores) -> Outcome`.

- Acceptance support: `state_snapshot(sandbox: &Sandbox) -> Vec<(PathBuf, u32, i64, i64, Vec<u8>)>`
  recursively captures sorted state and store paths, permission bits, modification time seconds and
  nanoseconds, and file bytes.

- [ ] **Step 1: Write the failing tests**

Register `mod inventory;` and `pub use inventory::{StoreInventory, inventory};` in application `lib.rs`
now. The file starts as the test module below. The adapter tests belong in the existing private stores
test module. Add `pub(crate) mod show; pub(crate) mod list; pub(crate) mod storage;` in
`commands/mod.rs`, with initially empty command files; Cargo discovers the integration test
automatically. Create `compose/observations.rs` empty and register `mod observations;` plus
`pub(crate) use observations::{ledger_from, storage_from};` in `compose.rs` before the red run.

`crates/vpt-application/src/inventory.rs`, test section:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    fn entry(size: u64, secs: i64) -> StoreEntry {
        StoreEntry { path: PathBuf::from(format!("/s/{secs}")), size, mtime: FileTime { secs, nanos: 0 } }
    }

    #[test]
    fn an_empty_store_has_no_oldest_or_newest() {
        assert_eq!(inventory(&[]).expect("bounded inventory"), StoreInventory { files: 0, bytes: 0, oldest: None, newest: None });
    }

    #[test]
    fn files_and_bytes_are_summed_and_the_extremes_found() {
        let report = inventory(&[entry(10, 300), entry(5, 100), entry(1, 200)]).expect("bounded inventory");
        assert_eq!(report.files, 3);
        assert_eq!(report.bytes, 16);
        assert_eq!(report.oldest, Some(FileTime { secs: 100, nanos: 0 }));
        assert_eq!(report.newest, Some(FileTime { secs: 300, nanos: 0 }));
    }
    #[test]
    fn an_unrepresentable_total_is_refused() {
        assert_eq!(inventory(&[entry(u64::MAX, 100), entry(1, 200)]), None);
    }

}
```

`crates/vpt-adapters/src/stores.rs`, appended inside its existing test module:

```rust
    #[test]
    fn entries_lists_regular_files_at_depth_one_and_absent_configured_roots() {
        let dir = tempfile::tempdir().expect("dir");
        let root = dir.path().canonicalize().expect("canonical");
        std::fs::write(root.join("a.m4a"), b"aaa").expect("a");
        std::fs::create_dir(root.join("sub")).expect("sub");
        std::fs::write(root.join("sub/b.m4a"), b"b").expect("b");
        let absent = root.join("absent");
        let stores = FilesystemStores::open_read_only(&[root.clone(), absent.clone()]).expect("stores");
        let entries = stores.entries(&root).expect("entries");
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0].path, root.join("a.m4a"));
        assert_eq!(entries[0].size, 3);
        assert!(stores.entries(&absent).expect("absent").is_empty());
        assert!(!absent.exists());
    }

    #[test]
    fn entries_refuses_a_symlink_instead_of_following_it() {
        let dir = tempfile::tempdir().expect("dir");
        let root = dir.path().canonicalize().expect("canonical");
        std::fs::write(root.join("a.m4a"), b"aaa").expect("a");
        std::os::unix::fs::symlink(root.join("a.m4a"), root.join("link.m4a")).expect("link");
        let stores = FilesystemStores::open(std::slice::from_ref(&root)).expect("stores");
        assert_eq!(stores.entries(&root), Err(StoreError::Escape(root.join("link.m4a"))));
    }
```

`crates/vpt/tests/show_list_storage.rs`:

```rust
mod support;

use support::{Sandbox, run, stderr, stdout};
use vpt_domain::fixtures::m4a;

const CAPTURED: i64 = 1_787_690_856;

fn ingested(name: &str) -> (Sandbox, String) {
    let sandbox = Sandbox::new(name);
    sandbox.install_fake_helper();
    sandbox.write_config("");
    sandbox.add_recording("a.m4a", &m4a(CAPTURED, 9, b"audio"));
    let output = run(sandbox.vpt().args(["ingest", "--json"]));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    let id = document["ingested"][0]["id"].as_str().expect("id").to_owned();
    (sandbox, id)
}

#[test]
fn show_prints_the_record_and_an_unknown_id_is_exit_2() {
    let (sandbox, id) = ingested("show");

    let output = run(sandbox.vpt().args(["show", &id, "--json"]));

    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["command"], "show");
    assert_eq!(document["id"], id);
    assert_eq!(document["stages"]["transcribe"], "pending");
    let missing = run(sandbox.vpt().args(["show", "2026-08-24T144736-4f3ab19c02de", "--json"]));
    assert_eq!(missing.status.code(), Some(2));
    let error: serde_json::Value = serde_json::from_str(&stderr(&missing)).expect("json");
    assert_eq!(error["error"]["kind"], "usage");
    assert_eq!(error["error"]["ids"][0], "2026-08-24T144736-4f3ab19c02de");
    let malformed = run(sandbox.vpt().args(["show", "nonsense"]));
    assert_eq!(malformed.status.code(), Some(2));
}

#[test]
fn list_prints_every_recording_and_stage_narrows_to_outstanding_work() {
    let (sandbox, id) = ingested("list");

    let all = run(sandbox.vpt().args(["list", "--json"]));
    let document: serde_json::Value = serde_json::from_str(&stdout(&all)).expect("json");
    assert_eq!(document["recordings"][0]["id"], id);

    let waiting = run(sandbox.vpt().args(["list", "--stage", "transcribe", "--json"]));
    let document: serde_json::Value = serde_json::from_str(&stdout(&waiting)).expect("json");
    assert_eq!(document["recordings"].as_array().map(Vec::len), Some(1));
    let unknown = run(sandbox.vpt().args(["list", "--stage", "polish"]));
    assert_eq!(unknown.status.code(), Some(2));
    let human = run(sandbox.vpt().arg("list"));
    assert!(stdout(&human).contains(&id), "{}", stdout(&human));
}

#[test]
fn storage_reports_each_store_with_counts_and_bytes() {
    let (sandbox, _id) = ingested("storage");

    let output = run(sandbox.vpt().args(["storage", "--json"]));

    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["stores"]["audio"]["files"], 1);
    assert_eq!(document["stores"]["audio"]["bytes"], m4a(CAPTURED, 9, b"audio").len());
    assert!(document["stores"]["audio"]["oldest"].is_string());
    assert_eq!(document["stores"]["released"]["files"], 0);
    assert!(document["stores"]["released"]["oldest"].is_null());
    assert_eq!(document["stores"].as_object().map(|s| s.len()), Some(7));
}

#[test]
fn fresh_observations_do_not_create_state_or_stores() {
    for verb in ["list", "storage", "show"] {
        let sandbox = Sandbox::new(&format!("fresh-{verb}"));
        sandbox.write_config("");
        let mut command = sandbox.vpt();
        command.arg(verb).arg("--json");
        if verb == "show" { command.arg("2026-08-24T144736-4f3ab19c02de"); }
        let output = run(&mut command);
        assert_eq!(output.status.code(), Some(if verb == "show" { 2 } else { 0 }), "{}", stderr(&output));
        assert!(!sandbox.path().join("state/vpt").exists());
        assert!(!sandbox.path().join("home/.vpt/audio").exists());
    }
}

#[test]
fn observations_preserve_dirty_ledger_bytes_modes_and_store_contents() {
    use std::os::unix::fs::PermissionsExt;
    let (sandbox, id) = ingested("read-only-dirty");
    let target = sandbox.path().join("home/.vpt/transcripts/pending.md");
    std::fs::write(&target, b"operator prose").expect("target");
    sandbox.ledger().execute(
        "INSERT INTO dirty_publications(target, expected_previous, intended, recorded_at) VALUES (?1, NULL, ?2, 1)",
        [target.to_string_lossy().as_ref(), &"ab".repeat(32)],
    ).expect("dirty");
    let database = sandbox.path().join("state/vpt/vpt.db");
    std::fs::set_permissions(&database, std::fs::Permissions::from_mode(0o644)).expect("mode");
    let before = support::state_snapshot(&sandbox);
    for args in [vec!["show", &id, "--json"], vec!["list", "--json"], vec!["storage", "--json"]] {
        let output = run(sandbox.vpt().args(args));
        assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
        assert_eq!(support::state_snapshot(&sandbox), before);
    }
}

#[test]
fn show_and_list_need_neither_source_nor_valid_store_roots() {
    let (sandbox, id) = ingested("ledger-only-observations");
    std::fs::rename(sandbox.path().join("voice-memos"), sandbox.path().join("held-source")).expect("hide source");
    sandbox.write_config(&format!("[stores]\naudio = {:?}\n", sandbox.path().join("missing/audio")));
    for args in [vec!["show", &id, "--json"], vec!["list", "--json"]] {
        let output = run(sandbox.vpt().args(args));
        assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
        assert!(stdout(&output).contains(&id));
    }
}

#[test]
fn storage_needs_neither_source_nor_a_readable_ledger() {
    let (sandbox, _) = ingested("stores-only-observation");
    std::fs::rename(sandbox.path().join("voice-memos"), sandbox.path().join("held-source")).expect("hide source");
    std::fs::write(sandbox.path().join("state/vpt/vpt.db"), b"corrupt ledger").expect("corrupt fixture");
    let before = support::state_snapshot(&sandbox);
    let output = run(sandbox.vpt().args(["storage", "--json"]));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("result");
    assert_eq!(document["stores"]["audio"]["files"], 1);
    assert_eq!(support::state_snapshot(&sandbox), before);
}

#[test]
fn ledger_path_escapes_are_refused_by_show_and_list() {
    let (sandbox, id) = ingested("ledger-path-escape");
    let database = sandbox.path().join("state/vpt/vpt.db");
    let held = sandbox.path().join("held.db");
    std::fs::rename(&database, &held).expect("hold database");
    let before = std::fs::read(&held).expect("database bytes");
    std::os::unix::fs::symlink(&held, &database).expect("database link");
    for args in [vec!["show", &id, "--json"], vec!["list", "--json"]] {
        let output = run(sandbox.vpt().args(args));
        assert_eq!(output.status.code(), Some(3), "{}", stderr(&output));
        let error: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("error");
        assert_eq!(error["error"]["rule"], "path_escape");
    }
    assert_eq!(std::fs::read(held).expect("unchanged"), before);
}

```

Append to `crates/vpt/tests/support/mod.rs` in Step 1:

```rust
pub fn state_snapshot(sandbox: &Sandbox) -> Vec<(PathBuf, u32, i64, i64, Vec<u8>)> {
    use std::os::unix::fs::{MetadataExt, PermissionsExt};
    fn visit(path: &Path, rows: &mut Vec<(PathBuf, u32, i64, i64, Vec<u8>)>) {
        let metadata = match path.symlink_metadata() {
            Ok(metadata) => metadata,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return,
            Err(error) => panic!("snapshot: {error}"),
        };
        assert!(!metadata.file_type().is_symlink(), "snapshot fixture contains a link");
        let bytes = if metadata.is_file() { std::fs::read(path).expect("read") } else { Vec::new() };
        rows.push((path.to_path_buf(), metadata.permissions().mode() & 0o777, metadata.mtime(), metadata.mtime_nsec(), bytes));
        if metadata.is_dir() {
            for entry in std::fs::read_dir(path).expect("directory") {
                visit(&entry.expect("entry").path(), rows);
            }
        }
    }
    let mut rows = Vec::new();
    visit(&sandbox.path().join("state/vpt"), &mut rows);
    visit(&sandbox.path().join("home/.vpt"), &mut rows);
    rows.sort();
    rows
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run separately: `cargo test -p vpt-application inventory`, `cargo test -p vpt-adapters stores`, and
`cargo test -p vpt --features dev-tools --test show_list_storage`.

Expected: compile errors for `inventory` and `entries`; the three command tests FAIL with exit 2 "verb
not implemented yet". The new modules must compile and be selected; zero selected tests or a successful
command does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-application/src/ports/stores.rs` retains all existing `StoreError` and `Stores` members. Add
`use vpt_domain::time::FileTime;`, this declaration above `Stores`, and its method:

```rust
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StoreEntry {
    pub path: PathBuf,
    pub size: u64,
    pub mtime: FileTime,
}
```

```rust
    fn entries(&self, root: &Path) -> Result<Vec<StoreEntry>, StoreError>;
```

The existing fake `impl Stores` blocks in publication tests gain the following method in Step 1:

```rust
    fn entries(&self, _root: &Path) -> Result<Vec<StoreEntry>, StoreError> {
        Ok(Vec::new())
    }
```

Import `StoreEntry` with `StoreError` in those private test modules.

`crates/vpt-application/src/inventory.rs`:

```rust
//! `vpt storage`: counts, bytes and the mtime extremes of one store.

use crate::ports::StoreEntry;
use vpt_domain::time::FileTime;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct StoreInventory {
    pub files: u64,
    pub bytes: u64,
    pub oldest: Option<FileTime>,
    pub newest: Option<FileTime>,
}

pub fn inventory(entries: &[StoreEntry]) -> Option<StoreInventory> {
    let key = |time: &FileTime| (time.secs, time.nanos);
    Some(StoreInventory {
        files: u64::try_from(entries.len()).ok()?,
        bytes: entries.iter().try_fold(0_u64, |total, entry| total.checked_add(entry.size))?,
        oldest: entries.iter().map(|entry| entry.mtime).min_by_key(key),
        newest: entries.iter().map(|entry| entry.mtime).max_by_key(key),
    })
}
```

`ports/mod.rs` adds `StoreEntry` to its existing `pub use stores::{StoreError, Stores};`. Register
`mod inventory;` and `pub use inventory::{StoreInventory, inventory};` in application `lib.rs` during
Step 1, before the red run. Extend the existing adapter `impl Stores`:

```rust
    fn entries(&self, path: &Path) -> Result<Vec<StoreEntry>, StoreError> {
        if !self.configured.iter().any(|configured| configured == path) {
            return Err(StoreError::Escape(path.to_path_buf()));
        }
        let Some(root) = self.roots.iter().find(|root| root.path() == path) else {
            return Ok(Vec::new());
        };
        let mut entries = Vec::new();
        for name in root.names().map_err(|error| store_error(path, error))? {
            let stat = root.stat(Path::new(&name)).map_err(|error| store_error(path, error))?;
            if stat.kind == Kind::Link {
                return Err(StoreError::Escape(path.join(name)));
            }
            if stat.kind != Kind::File {
                continue;
            }
            entries.push(StoreEntry {
                path: root.leaf(Path::new(&name)).map_err(|error| store_error(path, error))?,
                size: stat.size,
                mtime: FileTime { secs: stat.mtime_secs, nanos: stat.mtime_nanos },
            });
        }
        Ok(entries)
    }
```

Add `Kind` to the adapter's contained imports, `StoreEntry` to its port imports and
`use vpt_domain::time::FileTime;`. The retained root supplies every stat and leaf operation.

`crates/vpt/src/commands/show.rs`:

```rust
//! `vpt show <id>`.

use crate::cli::output::Outcome;
use crate::documents::record_json;
use vpt_application::ports::RecordingLedger;
use vpt_domain::identity::RecordingId;
use vpt_protocol::error::{ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

pub fn run(ledger: &dyn RecordingLedger, id: &str) -> Outcome {
    let Ok(identity) = RecordingId::parse(id) else {
        return Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, format!("{id} is not a recording id")));
    };
    match ledger.by_id(&identity) {
        Ok(Some(record)) => {
            let json = record_json(&record);
            Outcome::Success { human: format!("{}\n", serde_json::to_string_pretty(&json).unwrap_or_default()), document: document("show", json) }
        }
        Ok(None) => Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, format!("no recording {id}")).ids(vec![id.to_owned()])),
        Err(error) => Outcome::Failure(crate::compose::errors::ledger_error(error)),
    }
}
```

`crates/vpt/src/commands/list.rs`:

```rust
//! `vpt list [--stage <stage>]`.

use crate::cli::output::Outcome;
use crate::documents::record_json;
use serde_json::json;
use vpt_application::ports::{RecordingLedger, RecordingRecord, StageState};
use vpt_protocol::error::{ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

pub fn run(ledger: &dyn RecordingLedger, stage: Option<&str>) -> Outcome {
    let outstanding: fn(&RecordingRecord) -> StageState = match stage {
        None => |_| StageState::Pending,
        Some("transcribe") => |record| record.stages.transcribe,
        Some("note") => |record| record.stages.note,
        Some("synthesis") => |record| record.stages.synthesis,
        Some(other) => return Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, format!("{other} is not a stage"))),
    };
    let records = match ledger.recordings() {
        Ok(records) => records,
        Err(error) => return Outcome::Failure(crate::compose::errors::ledger_error(error)),
    };
    let selected: Vec<&RecordingRecord> = records.iter().filter(|record| outstanding(record) != StageState::Succeeded).collect();
    let human = selected.iter().map(|record| format!("{}  {}\n", record.id, record.title.as_deref().unwrap_or("(untitled)"))).collect::<String>();
    Outcome::Success {
        human: if human.is_empty() { "no recordings\n".into() } else { human },
        document: document("list", json!({"recordings": selected.iter().map(|record| record_json(record)).collect::<Vec<_>>()})),
    }
}
```

With no `--stage`, every record's selector answers `Pending`, so every record is listed.

`crates/vpt/src/commands/storage.rs`:

```rust
//! `vpt storage`.

use crate::cli::output::Outcome;
use serde_json::{Map, Value, json};
use vpt_application::inventory;
use vpt_application::ports::Stores;
use vpt_domain::layout::StoreKey;
use vpt_domain::time::{FileTime, UtcInstant};
use vpt_protocol::error::{ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

fn stamp(time: Option<FileTime>) -> Value {
    time.map_or(Value::Null, |t| Value::String(UtcInstant { secs: t.secs }.rfc3339()))
}

pub fn run(paths: &vpt_application::StorePaths, source: &dyn Stores) -> Outcome {
    let mut stores = Map::new();
    let mut human = String::new();
    for key in StoreKey::all() {
        let root = paths.get(key);
        let entries = match source.entries(root) {
            Ok(entries) => entries,
            Err(error) => return Outcome::Failure(crate::compose::errors::store_error(error)),
        };
        let Some(report) = inventory(&entries) else {
            return Outcome::Failure(ErrorDocument::new(
                ErrorKind::Store, format!("{} exceeds the supported inventory total", root.display()),
            ));
        };
        human.push_str(&format!("{:<15} {:>6} files {:>12} bytes  {}\n", key.key_name(), report.files, report.bytes, root.display()));
        stores.insert(
            key.key_name().to_owned(),
            json!({"files": report.files, "bytes": report.bytes, "oldest": stamp(report.oldest), "newest": stamp(report.newest), "path": root}),
        );
    }
    Outcome::Success { human, document: document("storage", json!({"stores": stores})) }
}
```

Add `mod observations;` and `pub(crate) use observations::{ledger_from, storage_from};` to `compose.rs`.
The empty observations file and declarations are registered in Step 1, before the red run.

`crates/vpt/src/compose/observations.rs`:

```rust
use super::{Environment, RuntimeLedger, settings_from};
use super::errors::{contained_error, root_error};
use std::path::Path;
use vpt_adapters::FilesystemStores;
use vpt_adapters::config::{planned_directory, resolve_stores};
use vpt_application::StorePaths;
use vpt_domain::layout::StoreKey;
use vpt_protocol::error::ErrorDocument;

pub(crate) fn ledger_from(environment: &Environment, config: Option<&Path>) -> Result<RuntimeLedger, Box<ErrorDocument>> {
    let settings = settings_from(environment, config)?;
    let state = planned_directory(&settings.state_dir, "home.state_dir").map_err(|error| root_error(&error))?;
    RuntimeLedger::read_only(&state)
}

pub(crate) fn storage_from(environment: &Environment, config: Option<&Path>) -> Result<(StorePaths, FilesystemStores), Box<ErrorDocument>> {
    let settings = settings_from(environment, config)?;
    let paths = resolve_stores(&settings).map_err(|error| root_error(&error))?;
    let configured = StoreKey::all().map(|key| paths.get(key).to_path_buf());
    let stores = FilesystemStores::open_read_only(&configured).map_err(contained_error)?;
    Ok((paths, stores))
}
```

The dispatch arms in `crates/vpt/src/lib.rs`:

```rust
        Verb::Show { id } => match compose::ledger_from(&environment, invocation.config.as_deref()) {
            Ok(ledger) => commands::show::run(&ledger, id),
            Err(error) => Outcome::Failure(*error),
        },
        Verb::List { stage } => match compose::ledger_from(&environment, invocation.config.as_deref()) {
            Ok(ledger) => commands::list::run(&ledger, stage.as_deref()),
            Err(error) => Outcome::Failure(*error),
        },
        Verb::Storage => match compose::storage_from(&environment, invocation.config.as_deref()) {
            Ok((paths, stores)) => commands::storage::run(&paths, &stores),
            Err(error) => Outcome::Failure(*error),
        },
```

Retain the Task 27 ingest dispatch unchanged. These observations create only their named capability; show
and list do not resolve or open stores or Voice Memos, and storage never opens the ledger.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test --workspace --features dev-tools`

Expected: all PASS.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(cli): vpt show, vpt list and vpt storage"
```

______________________________________________________________________

