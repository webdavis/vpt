# D1 execution brief

## Controller execution constraints

- Staging-lint removal follow-up: 6hc7x7wMwxF8R9rg. Keep it open through the last real consumer and include the annotation inventory in the task report.
- Incremental lint ruling, based on task-D1-incremental-clippy-01.log: allow narrow expect(dead_code, reason = ...) annotations only on concrete D1 items or impls genuinely awaiting approved consumers. Use cfg_attr(not(test), ...) when tests already use them. No crate/module-wide allowance, broad allow, test-only production-module gate, visibility expansion or synthetic keepalive references. Fix unused imports and stub fields normally; use real error-payload assertions when they are part of D1 behavior. Inventory each expectation and its consuming task in the report. Remove owner/file expectations as D3-D5 consume them; only explicitly named title-policy variants may wait for D6. No staging expectations may remain at Stage 1 acceptance.
- Removal-sync ruling: RootDir::unlink_file performs checked unlink only. DatabaseFiles::remove(role, sync) synchronizes the retained directory exactly when sync is true and propagates failure; false does not add a sync. New creation still synchronizes. This resolves the original step's broad removal wording against its explicit bool API, D3's requested-directory-sync mapping, and pinned libsqlite3-sys-0.37.0/sqlite3/sqlite3.c:46030-46069. D3 owns still-pending injected directory-sync error/route verification. No native opener or swallowed error is copied from SQLite.
- Dispatch only after original Tasks 7 through 10 are complete and reviewed. This is preparation, not authorization to begin D1 now. Record the actual clean base at dispatch.
- Read the approved database-containment design and the amendment plan's Global Constraints, Review Focus and Source Anchors before implementation. D1 replaces only the first part of original Task 11.
- Scope is the checked file boundary and four access policies below. Registration, callbacks, locks, connections, schema and title-copy integration belong to later tasks. Add no dependency, daemon or configuration key.
- Adapt the file map to current Task 5a structure: checked file operations live in contained/file.rs, with existing contained tests split by behavior. Preserve those modules rather than recreating a monolithic contained.rs. Keep new implementation children private and exports crate-private as specified.
- Current-code preflight at Task 9 HEAD: RootDir::open_file already uses descriptor-relative no-follow/nonblocking opens and checks the opened file type, but not its link count. RootDir::create_file is write-only. Reuse the safe pieces and add only D1's specified read-write creation and unlink methods; perform link checks before permission repair.
- RootDir::leaf and c_name deliberately accept the checked root's joined absolute path. DatabaseFiles::new has the narrower bare-leaf contract in this task and must independently refuse every absolute database name. Do not relax the database allowlist by forwarding directly to the broader helper.
- RootDir::revalidate currently reports a missing pathname as Io(NotFound) and a symlink/type failure as NotADirectory; only an identity mismatch becomes Escape. D1 must satisfy its approved typed containment rule for missing/replaced/link paths while keeping ordinary permission/device failures distinct. Trace actual callers before changing a shared helper. These are source observations, not newly reproduced runtime failures.
- The controller's focused caller trace found production revalidation in contained/directory.rs::names, config/write.rs::write_config, and config/write/directory.rs::PlannedDirectory. The setup converter maps Escape/NotRegular/NotADirectory to PathEscape, but generic Io to an ordinary setup error. Keep those callers and their accepted behavior in view if the shared revalidation classifier changes; no caller changes are authorized merely by this observation.
- This is high-risk storage work: use Astra implementation and independent Astra review under the approved model-routing strategy. One product writer; preserve others' work. Main owns progress.md and Todoist.
- Every fixture and replacement directory must be owned by the test. Never repeat the denied SQLite system-call-override experiment or broad process listing. No third-party modification, live data, installation, publication, apply or destructive cleanup.
- Use compiling behavioral RED, exact compiled mutations and byte-identical restored controls. Preserve all baseline leaf names. Run final-source workspace gates, release build, staged-file size audit and committed-history secrets scan; retain raw logs in task-D1-report.md and linked evidence. The controller owns the fresh post-commit gate.
- Add only the specified missing descriptor operations. Existing safe helpers take precedence over copied samples. Do not use pathname fallbacks or expose private implementation types just to silence warnings. Surface any incremental private-code wiring issue for a scoped ruling.
- Use apply_patch, verify buffer safety, and keep each test below one second. No subagents or new worktree.

## Approved task text
## D1: Checked database files and access policies

**Files:** Modify `contained.rs`, `contained/tests.rs` and adapters `lib.rs`; create `database/mod.rs`,
`database/files.rs`, `database/tests/mod.rs`, `database/tests/files.rs` and `database/tests/support.rs`.

**Interfaces:** Consume original Task 5a's `RootDir`, `Access`, `ContainedError`, `Kind`, `leaf`,
`open_file`, `stat`, `try_clone`, `revalidate` and `sync`. Add only these checked-root methods:

```rust
pub(crate) fn create_read_write_file(
    &self, leaf: &Path, mode: u32,
) -> Result<File, ContainedError>;
pub(crate) fn unlink_file(&self, leaf: &Path) -> Result<(), ContainedError>;
```

Create the following private adapter types. `FileRole` and `DatabaseFiles` remain inside `database`; the
policy and error are visible to sibling adapters through curated crate-private exports.

```rust
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum AccessPolicy {
    WritableLedger,
    ObservationalLedger,
    RefreshedTitleCopy,
    ExistingTitleCopy,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum FileRole { Database, Journal, Wal, SharedMemory }

#[derive(Debug)]
pub(crate) enum DatabaseError {
    Contained(ContainedError),
    Sqlite(rusqlite::Error),
    Io { operation: &'static str, kind: std::io::ErrorKind },
}

struct DatabaseFiles {
    root: RootDir,
    leaf: std::ffi::CString,
    policy: AccessPolicy,
}
```

Define
`DatabaseFiles::new(root: RootDir, leaf: &Path, policy: AccessPolicy) -> Result<Self, DatabaseError>`,
`open(&self, role: FileRole, create: bool) -> Result<File, DatabaseError>`,
`remove(&self, role: FileRole, sync: bool) -> Result<(), DatabaseError>` and
`revalidate(&self) -> Result<(), DatabaseError>`. `DatabaseError` implements `From<ContainedError>`,
`From<rusqlite::Error>` and a private `is_containment(&self) -> bool`. Unsafe file kinds, hard links and
root substitution are containment refusals. Plain permission, space and device failures remain
input/output errors.

- [ ] **Step 1: Add compiling red tests and the smallest signatures they require.**

Use explicit `Unsupported` errors as temporary red stubs, never panics or successful dummy values. Add
the owned fixture below to `database/tests/support.rs`; extend it only when later tests need a helper.
Each test child imports the named production types from its parent, `std::path::Path`,
`std::time::Duration`, and `super::support::root` when used. Keep these imports explicit in the files.

```rust
pub(super) fn root() -> (tempfile::TempDir, crate::RootDir) {
    use std::os::unix::fs::DirBuilderExt;
    let temp = tempfile::tempdir().expect("owned temp");
    let path = temp.path().canonicalize().expect("canonical temp").join("state");
    std::fs::DirBuilder::new().mode(0o700).create(&path).expect("state");
    let root = crate::RootDir::open(&path).expect("checked root");
    (temp, root)
}
```

Add these tests in `database/tests/files.rs`, importing the parent types and `support::root`:

```rust
#[test]
fn lazy_open_stays_with_the_acquired_directory() {
    use std::io::Write;
    let (temp, root) = root();
    let original = root.path().to_path_buf();
    let saved = temp.path().join("saved");
    let files = DatabaseFiles::new(root, Path::new("vpt.db"), AccessPolicy::WritableLedger)
        .expect("files");
    files.revalidate().expect("valid before replacement");
    std::fs::rename(&original, &saved).expect("retain original inode");
    std::fs::create_dir(&original).expect("replacement");
    files.open(FileRole::Journal, true).expect("held root open")
        .write_all(b"owned").expect("write");
    assert_eq!(std::fs::read(saved.join("vpt.db-journal")).unwrap(), b"owned");
    assert!(!original.join("vpt.db-journal").exists());
    assert!(files.revalidate().unwrap_err().is_containment());
    files.remove(FileRole::Journal, true).expect("contained cleanup");
    assert!(!saved.join("vpt.db-journal").exists());
    assert!(std::fs::read_dir(original).unwrap().next().is_none());
}

#[test]
fn observation_neither_creates_nor_repairs() {
    use std::os::unix::fs::{MetadataExt, PermissionsExt};
    let (_temp, root) = root();
    let path = root.path().join("vpt.db");
    std::fs::write(&path, b"fixture").unwrap();
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o640)).unwrap();
    let files = DatabaseFiles::new(root, Path::new("vpt.db"), AccessPolicy::ObservationalLedger)
        .unwrap();
    assert!(files.open(FileRole::Database, false).is_ok());
    assert!(files.open(FileRole::Wal, true).is_err());
    assert_eq!(std::fs::metadata(path).unwrap().mode() & 0o777, 0o640);
}
```

Add table-driven leaves for each role with a symbolic link, directory and multiply linked regular file in
its place. The outside target's bytes and metadata must remain unchanged. Add rejected leaf values
`../vpt.db`, an absolute path, `vpt.db/child`, an empty name and an embedded NUL. Cover a root ancestor
replaced after acquisition, not only the final directory. D2 adds first-in, first-out (FIFO) special-file
cases under its child watchdog and mutation-tests the nonblocking guard. Task 5a's existing type checks
remain active throughout.

- [ ] **Step 2: Run the selected tests red.**

```bash
cargo test --locked -p vpt-adapters database::tests::files -- --nocapture
```

Expected: the new leaves run and fail at their specific successful-open or containment assertions.
Compilation failure does not count.

- [ ] **Step 3: Implement the descriptor operations and policy table.**

`create_read_write_file` validates a single leaf, calls `openat` with
`O_RDWR | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC | O_NONBLOCK`, verifies the descriptor is a regular
file with link count one, then uses descriptor permission repair. Never use `O_TRUNC` while opening an
unchecked file. `unlink_file` checks the named entry without following links, refuses non-regular or
multiply linked entries, and calls `unlinkat` relative to the retained descriptor. It never accepts a
directory. File creation/removal is followed by `RootDir::sync`; propagate failure.

Apply this policy at every callback, not only the initial database open:

```rust
impl AccessPolicy {
    fn writable(self, role: FileRole) -> bool {
        match self {
            Self::WritableLedger => true,
            Self::RefreshedTitleCopy => role == FileRole::SharedMemory,
            Self::ObservationalLedger | Self::ExistingTitleCopy => false,
        }
    }
}
```

`create` is permission to create only when the policy permits it. A read-only policy may satisfy SQLite's
writable WAL probe with an existing read-only descriptor and must report that actual mode; it must never
create or repair the file. An existing writable open repairs to `0600` only after the type and link
checks. Preserve `O_EXCL` creation races: an `AlreadyExists` result permits a fresh checked open, never
an unchecked fallback. Build companions by appending exactly `-journal`, `-wal` or `-shm` to the
validated database leaf. All physical operations consume those names relative to the root.

Revalidation detects changed device/inode, links, or a now-missing acquired pathname as
`ContainedError::Escape`. Initial acquisition of an absent state directory remains the caller's
empty-state case. Low-level callbacks continue using retained authority during error cleanup even after
revalidation has refused a new query.

- [ ] **Step 4: Verify green and mutation controls.**

Run the red command again. Mutate the descriptor-relative open to a pathname open, remove the link-count
guard, and enable observation's creation/permission repair one at a time. Each corresponding leaf must
fail; restore exact original bytes and rerun the control. Check both replacement-directory and ancestor
cases. Record created file modes and unchanged outside snapshots.

- [ ] **Step 5: Format, review and commit this deliverable.**

```bash
cargo fmt --all
cargo clippy --locked -p vpt-adapters --all-targets -- -D warnings
git add crates/vpt-adapters/src/contained.rs crates/vpt-adapters/src/contained/tests.rs
git add crates/vpt-adapters/src/lib.rs crates/vpt-adapters/src/database
git commit -m "feat(database): contain database file access"
```
