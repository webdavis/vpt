# Command watchdog independent review

Verdict: Needs fixes, acceptance evidence only. No blocking source defect found. The final gate output is verified, but the original compiling RED and mutation/control output is unavailable for independent review. This does not establish that those runs did not happen. It prevents this review from confirming their reported chronology and exact restorations.

Base: `c84df8aba6f1154e77b11f9aa7f107d9b39f0889`. Reviewed all four tracked diffs against that base and both new files, `harness/deadline.rs` and `support/diagnostic.rs`, under `crates/vpt/tests/`. All six source hashes and physical line counts match `command-deadline-execution-report.md`. No product writes, builds, tests, mutations or commits were performed in this review lane.

## Finding 1: original RED and mutation evidence is unavailable

`command-watchdog-evidence-provenance.md:10` explicitly distinguishes the unavailable original raw output from its transcribed observations and chunk identifiers. The five initial REDs and ten mutant/control pairs therefore cannot be independently checked for compilation success, the intended assertion failure, exact restoration, or historical order. The source-hash table in `command-deadline-execution-report.md:29` provides reported hashes without the original command results that establish those transitions.

The final passing suite does not establish these historical claims. Supply the original output if it can be recovered. Otherwise the controller must explicitly resolve the acceptance-evidence gap before an unconditional approval. Any new mutation run would be fresh evidence and must not be represented as recovery of the original test-first chronology. No retry or retrospective run is requested by this review.

## Source review

- `support/mod.rs:114` rejects an expired collector before the driver or pipe polling. The independent check at line 142 precedes acceptance of completed child and pipe observations. The late-entry and during-poll regressions target these different branches.
- `support/mod.rs:106` retains the existing `ProcessGroup` cleanup owner before capture setup, driver execution or assertions. `drop(group)` precedes diagnostic rendering. The existing 500 ms operation, 50 ms termination grace and 900 ms absolute cleanup budgets are unchanged. New shell fixtures are direct children in owned groups. The terminal helper still uses the existing exec path in the owned session, without adding a nested supervisor.
- The short-child regressions reap their child before inducing the intended late observation (`harness/deadline.rs:64`). The live stdin-blocked cases retain an exact-process cleanup backstop. Their passing path checks group disappearance and an already-reaped direct child (`harness/deadline.rs:89`). No new product process-lifecycle behavior or cleanup-owner implementation was introduced.
- `support/diagnostic.rs:25` records unavailable observations as `none`; the caller supplies actual observed spawn return where available. Phase durations and between-poll gaps have separate measurements. Child exit and actual pipe end-of-file observations are retained once. The stream-presence guards at `support/mod.rs:125` and line 132 prevent an absent pipe from being reported as an observed end of file.
- `support/diagnostic.rs:104` limits each prefix to 64 source bytes before escaping. Full capture behavior is unchanged. Terminal diagnostics apply the same bound to the three owned streams at `setup/terminal.rs:107`. The strict classifier at `setup.rs:188` checks the leading collector label; an unrelated missing-prompt panic cannot satisfy it merely by occurring or containing child text.
- Environment clearing, temporary homes and configuration paths remain in effect. The changed files are test-only, remain below 300 physical lines, and do not touch database code, live destinations or the future notification design.

## Verified final evidence

Read the exported `command-watchdog-final-ship.tool-output.log` and `command-watchdog-final-nightly.tool-output.log`. Their lengths and hashes match the provenance record: 30,717 and 34,155 bytes respectively. Both contain 325 passing named leaves. A binary-qualified name comparison against the accepted 318-name D4 inventory found zero missing names, zero stable/nightly mismatches and exactly seven additions, four harness and three setup leaves.

The stable output reaches formatting, Clippy, workspace tests, documentation, history secret scanning and the file-size gate. The nightly output's maximum measured leaf is 0.574 s, `database::tests::locks::child_watchdog_reaps_a_stalled_lock_test`. The separate all-target check, release build, working-tree secret scan and diff-check exit claims remain transcript-only, as the provenance record states. This review did not rerun them.

## Timing and evidence limits

`command-watchdog-harness-green-failure.log` preserves the real `runner_captures_output_and_exit_status` failure with `spawn_return=501.1675ms`, before any polling phase was observed. The record localizes the elapsed interval to the parent's observation of spawn return. It cannot distinguish operating-system spawn work from parent descheduling. Later passing gates do not resolve that cause or prove the failure cannot recur.

That failure alone does not block this scoped ordering and diagnostic correction: rejecting it is consistent with the retained operation deadline. The fixture still cannot preempt a blocked spawn, a long polling step, an operating-system wait or a descheduled test thread. A cleanup-owner panic can precede the new record. The controller retains final acceptance and committed-HEAD verification; this review grants no waiver for the missing historical evidence.
