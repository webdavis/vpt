# Task 12 adapter preflight

Read-only lookup by /root/vpt_task12_adapter_lookup_luna, gpt-6-luna medium. Original Task 12 occupies Stage 1 plan lines 7242-8288. This is an interface lookup, not implementation or test evidence. The controller subsequently read the full original task and prepared task-12-execution-brief.md, but dispatch still waits for completed D5 code.

No Task 12 sample opens, owns, stores or returns a native rusqlite Connection. Its fixture open_ledger calls SqliteLedger::open at lines 7641-7645. The contract consumes SqliteLedger::read and transaction at line 7262 and describes their method API at lines 7795-7815.

- RecordingLedger::seen, seen_all, by_digest, by_id and recordings call self.read at lines 7978-8014. PublicationJournal::pending_publications does so at lines 8086-8112.
- RecordingLedger::record_seen, commit, set_source_path and set_audio_trashed call self.transaction at lines 7996-8045. PublicationJournal::clear_publication does so at lines 8114-8120.
- Borrowed SQL helpers are upsert_seen at lines 7914-7943, insert_recording at 7945-7968, one_record at 7970-7976, and journal::upsert_publication at 8065-8080. Each takes a borrowed Connection and does not manage its lifetime.
- D5 preserves the read and transaction signatures and implements their common lifecycle boundary with Database::with_connection, immediate Transaction::new_unchecked and finish error precedence. That common wrapper is the integration point, not a duplicated open/close sequence in each Task 12 repository method.
- No signature mismatch was found. A borrowed Transaction can supply the Connection reference to those helpers. Preserve the application ledger contract and borrowed helper signatures unless implementation reveals a concrete compiler constraint.

D5 does not implement these repositories early. Read the full Task 12 text and actual completed D5 implementation before dispatching Task 12.
