### Task 10: The sweep gates

## Controller execution constraints

- Implement only the pure sweep decisions using the actual completed time API. Keep dataless precedence even for a previously ingested unchanged candidate, and include nanosecond-only mtime changes in coverage.
- Use compiling behavioral RED, exact boundary assertions and representative mutation/control pairs. Mutate the actual rest comparison, not the stale final-task mutation wording. No filesystem or wall-clock access in these decisions.
- Verify the macOS SF_DATALESS constant against installed headers or official source before asserting its value, and record the evidence.
- Run current full gates, timings, staged-file size audit and committed-HEAD gitleaks. Preserve earlier leaves and record raw evidence in task-10-report.md.
- No unsolicited docstrings, broad lint suppression, subagents, new worktree, unrelated edits, push, pull request, installation, live resources or destructive cleanup.


**Files:**

- Create: `crates/vpt-domain/src/sweep.rs`
- Modify: `crates/vpt-domain/src/lib.rs`

**Interfaces:**

- Consumes: `time::{FileTime, UtcInstant}`.

- Produces: `vpt_domain::sweep::{DeferralReason, CandidateFacts, SeenFacts, SweepLimits, PreOpen,`
  `pre_open, size_gate, rest_gate, SF_DATALESS}`;
  `CandidateFacts { pub size: u64, pub mtime: FileTime, pub flags: u32 }` (the source's whole `st_flags`
  word; `SF_DATALESS` is `0x4000_0000`, the bit macOS sets on a file whose bytes are still in iCloud);
  `SeenFacts { pub size: u64, pub mtime: FileTime, pub ingested: bool, pub deferred_size: Option<u64> }`;
  `SweepLimits { pub max_audio_bytes: u64, pub quiet_period_secs: u64 }`;
  `DeferralReason::{Dataless, AudioTooLarge, InvalidContainer, NotAtRest, ChangedDuringRead}` with
  `fn as_str(self) -> &'static str` and `fn parse(text: &str) -> Option<DeferralReason>`;
  `PreOpen::{Dataless, Unchanged, Open}`;
  `pre_open(candidate: &CandidateFacts, seen: Option<&SeenFacts>) -> PreOpen`;
  `size_gate(size: u64, limits: &SweepLimits) -> Result<(), DeferralReason>`;
  `rest_gate(mtime: FileTime, size: u64, now: UtcInstant, seen: Option<&SeenFacts>,`
  `limits: &SweepLimits) -> Result<(), DeferralReason>`.

- [ ] **Step 1: Write the failing tests**

`crates/vpt-domain/src/lib.rs` gains `pub mod sweep;`. `crates/vpt-domain/src/sweep.rs` starts as its
test module alone:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    const LIMITS: SweepLimits = SweepLimits { max_audio_bytes: 2_147_483_648, quiet_period_secs: 30 };
    const UF_HIDDEN: u32 = 0x0000_8000;

    fn candidate(size: u64, secs: i64, flags: u32) -> CandidateFacts {
        CandidateFacts { size, mtime: FileTime { secs, nanos: 0 }, flags }
    }

    #[test]
    fn a_dataless_entry_is_never_opened_whatever_else_is_set() {
        assert_eq!(pre_open(&candidate(10, 0, SF_DATALESS), None), PreOpen::Dataless);
        assert_eq!(pre_open(&candidate(10, 0, SF_DATALESS | UF_HIDDEN), None), PreOpen::Dataless);
        assert_eq!(pre_open(&candidate(10, 0, UF_HIDDEN), None), PreOpen::Open);
    }

    #[test]
    fn an_unchanged_ingested_triple_is_skipped_and_a_changed_one_is_opened() {
        let seen = SeenFacts { size: 10, mtime: FileTime { secs: 5, nanos: 0 }, ingested: true, deferred_size: None };
        assert_eq!(pre_open(&candidate(10, 5, 0), Some(&seen)), PreOpen::Unchanged);
        assert_eq!(pre_open(&candidate(11, 5, 0), Some(&seen)), PreOpen::Open);
        assert_eq!(pre_open(&candidate(10, 6, 0), Some(&seen)), PreOpen::Open);
        let deferred = SeenFacts { ingested: false, ..seen };
        assert_eq!(pre_open(&candidate(10, 5, 0), Some(&deferred)), PreOpen::Open);
    }

    #[test]
    fn the_size_gate_defers_one_byte_over_the_limit_and_accepts_the_limit() {
        assert_eq!(size_gate(2_147_483_648, &LIMITS), Ok(()));
        assert_eq!(size_gate(2_147_483_649, &LIMITS), Err(DeferralReason::AudioTooLarge));
    }

    #[test]
    fn the_rest_gate_needs_the_whole_quiet_period_to_the_nanosecond() {
        let now = UtcInstant { secs: 1_000 };
        assert_eq!(rest_gate(FileTime { secs: 971, nanos: 0 }, 10, now, None, &LIMITS), Err(DeferralReason::NotAtRest));
        assert_eq!(rest_gate(FileTime { secs: 970, nanos: 1 }, 10, now, None, &LIMITS), Err(DeferralReason::NotAtRest));
        assert_eq!(rest_gate(FileTime { secs: 970, nanos: 0 }, 10, now, None, &LIMITS), Ok(()));
        let unbounded = SweepLimits { max_audio_bytes: 1, quiet_period_secs: u64::MAX };
        assert_eq!(rest_gate(FileTime { secs: 0, nanos: 0 }, 10, now, None, &unbounded), Err(DeferralReason::NotAtRest));
    }

    #[test]
    fn a_size_that_moved_since_the_last_deferral_is_not_at_rest() {
        let now = UtcInstant { secs: 1_000 };
        let seen = SeenFacts { size: 9, mtime: FileTime { secs: 1, nanos: 0 }, ingested: false, deferred_size: Some(9) };
        assert_eq!(rest_gate(FileTime { secs: 1, nanos: 0 }, 10, now, Some(&seen), &LIMITS), Err(DeferralReason::NotAtRest));
        assert_eq!(rest_gate(FileTime { secs: 1, nanos: 0 }, 9, now, Some(&seen), &LIMITS), Ok(()));
    }

    #[test]
    fn reasons_round_trip_through_their_names() {
        for reason in [
            DeferralReason::Dataless,
            DeferralReason::AudioTooLarge,
            DeferralReason::InvalidContainer,
            DeferralReason::NotAtRest,
            DeferralReason::ChangedDuringRead,
        ] {
            assert_eq!(DeferralReason::parse(reason.as_str()), Some(reason));
        }
        assert_eq!(DeferralReason::parse("busy"), None);
    }
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-domain sweep`

Expected: the build fails with `cannot find` for `pre_open`, `size_gate`, `rest_gate`, `CandidateFacts`,
`SeenFacts`, `SweepLimits`, `PreOpen`, `DeferralReason` and `SF_DATALESS`.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-domain/src/sweep.rs`, above its test module:

```rust
//! The sweep gates of spec section 5.2, cheapest first, as pure decisions.

use crate::time::{FileTime, UtcInstant};

/// The `st_flags` bit macOS sets on a file whose bytes are still in iCloud.
pub const SF_DATALESS: u32 = 0x4000_0000;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DeferralReason {
    Dataless,
    AudioTooLarge,
    InvalidContainer,
    NotAtRest,
    ChangedDuringRead,
}

impl DeferralReason {
    pub fn as_str(self) -> &'static str {
        match self {
            DeferralReason::Dataless => "dataless",
            DeferralReason::AudioTooLarge => "audio_too_large",
            DeferralReason::InvalidContainer => "invalid_container",
            DeferralReason::NotAtRest => "not_at_rest",
            DeferralReason::ChangedDuringRead => "changed_during_read",
        }
    }

    pub fn parse(text: &str) -> Option<DeferralReason> {
        [
            DeferralReason::Dataless,
            DeferralReason::AudioTooLarge,
            DeferralReason::InvalidContainer,
            DeferralReason::NotAtRest,
            DeferralReason::ChangedDuringRead,
        ]
        .into_iter()
        .find(|reason| reason.as_str() == text)
    }
}

pub struct CandidateFacts {
    pub size: u64,
    pub mtime: FileTime,
    pub flags: u32,
}

impl CandidateFacts {
    pub fn dataless(&self) -> bool {
        self.flags & SF_DATALESS != 0
    }
}

pub struct SeenFacts {
    pub size: u64,
    pub mtime: FileTime,
    pub ingested: bool,
    pub deferred_size: Option<u64>,
}

pub struct SweepLimits {
    pub max_audio_bytes: u64,
    pub quiet_period_secs: u64,
}

#[derive(Debug, PartialEq, Eq)]
pub enum PreOpen {
    Dataless,
    Unchanged,
    Open,
}

pub fn pre_open(candidate: &CandidateFacts, seen: Option<&SeenFacts>) -> PreOpen {
    if candidate.dataless() {
        return PreOpen::Dataless;
    }
    match seen {
        Some(seen) if seen.ingested && seen.size == candidate.size && seen.mtime == candidate.mtime => PreOpen::Unchanged,
        _ => PreOpen::Open,
    }
}

pub fn size_gate(size: u64, limits: &SweepLimits) -> Result<(), DeferralReason> {
    if size > limits.max_audio_bytes { Err(DeferralReason::AudioTooLarge) } else { Ok(()) }
}

pub fn rest_gate(
    mtime: FileTime,
    size: u64,
    now: UtcInstant,
    seen: Option<&SeenFacts>,
    limits: &SweepLimits,
) -> Result<(), DeferralReason> {
    if mtime.age_secs(now) < i64::try_from(limits.quiet_period_secs).unwrap_or(i64::MAX) {
        return Err(DeferralReason::NotAtRest);
    }
    if let Some(deferred) = seen.and_then(|seen| seen.deferred_size)
        && deferred != size
    {
        return Err(DeferralReason::NotAtRest);
    }
    Ok(())
}
```

`FileTime::age_secs` counts the nanoseconds (Task 7), so a file touched 29.999999999 seconds ago is not
at rest under a 30 second quiet period.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-domain sweep`

Expected: 6 tests PASS. Run `cargo clippy -p vpt-domain --all-targets -- -D warnings` and expect no
warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates/vpt-domain
SKIP_AI_COMMIT=1 git commit -m "feat(domain): the sweep gates and deferral reasons"
```

______________________________________________________________________


