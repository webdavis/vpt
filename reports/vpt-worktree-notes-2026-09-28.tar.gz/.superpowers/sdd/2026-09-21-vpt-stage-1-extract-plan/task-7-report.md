# Task 7: time and digest values

Controller acceptance: final commit 8c017586fec61c29cd1dd9c04d9de1463babcc15 passed independent scoped review in task-7-review-2.md. Fresh committed-HEAD just ship exited 0, with 171 passing leaves and a clean 94-commit secrets scan (task-7-fix1-controller-ship.log). Restored hashes and clean worktree/index were verified before Task 8 began. The historical intermittent command-test deadline issue remains open as Todoist 6hc7MMRc2QhRm75g; these passing gates do not establish its cause or resolution.

BASE `c60a01c9c165df7df7fcb6eb492e11921cb1035d`; HEAD `8c01758` (`feat(domain): add time and digest values`, amended after review). The commit changes only `crates/vpt-domain/src/{lib,time,digest}.rs`. The values use standard-library arithmetic and parsing. Time conversion uses `i128` intermediates; `Civil::is_valid` checks Gregorian and clock bounds independently of `Civil::instant`, which refuses only an instant outside `i64`.

The first compiled `cargo test -p vpt-domain --lib` RED run failed eight new behavioral tests and passed the malformed-input test with the deliberate `None` stub. Its verbatim output and tool locator are [preserved from the execution transcript](task-7-transcript-evidence.md#compiled-test-first-red). After implementation, the same suite passed 25/25. Ten exact source mutants were checked against the named leaf; each final mutant compiled and failed, and each restored control passed. The paired raw logs use the listed stem with `-mutant.log` and `-control.log`, except the first two controls use `-restored-control.log` after rustfmt restored their indentation. All paths below are relative to this directory.

| Mutant and control log stem | Break caught |
| --- | --- |
| `task-7-digest-hex` | empty digest encoding |
| `task-7-digest-invalid` | malformed input accepted |
| `task-7-time-negative-floor` | truncation on a negative instant |
| `task-7-time-offset-sign` | negative offset printed positive |
| `task-7-time-negative-year` | truncation in inverse calendar era |
| `task-7-time-calendar-leap` | 1900 accepted as a leap year |
| `task-7-time-offset-inverse` | offset added on inverse conversion |
| `task-7-time-checked-range` | out-of-range instant accepted |
| `task-7-time-age-floor` | fractional negative age truncated |
| `task-7-time-age-saturation` | positive saturation one second short |

At the original commit, restored SHA-256 values were `time.rs` `350608e712b17d9dda7a975e90bda4014bb0cd4c43eb98e894a04d1cc0e331dd` and `digest.rs` `191f694a3bf8314c04ea71e355fbe228a78eb0afd93b75d48990c8ddb9299c20`. The original [age-divisor mutant](task-7-transcript-evidence.md#surviving-age-divisor-mutant) changed `.div_euclid(NANOS_PER_SECOND)` to `.div_euclid(NANOS_PER_SECOND - 1)`; the named test still passed. The later truncating-division mutant above caught a different flooring error. The generated [named-leaf list](task-7-final-leaves.log) has 171 leaves against 162 at BASE, with [nine additions](task-7-added-leaves.log) and [zero missing](task-7-missing-leaves.log). The domain suite completed in 0.00 s in the original ship run, and the new leaves completed within its one-second limit.

Gate output is preserved in the linked raw logs:

| Command | Result and elapsed time |
| --- | --- |
| [`just ship`](task-7-ship.log) | failed in 24.60 s: `setup_refuses_existing_config_before_the_terminal` exceeded its 500 ms deadline at 662 ms |
| [focused setup test](task-7-setup-timeout-recheck.log) | passed in 0.29 s (3.77 s including compilation) |
| [`just ship` retry](task-7-ship-retry.log) | passed in 23.41 s, including 171 tests, documentation, formatting, Clippy and history secrets scan |
| [`cargo check --locked --workspace --all-targets --features dev-tools`](task-7-check.log) | passed in 9.28 s |
| [`just test-rust`](task-7-test-rust.log) | failed in 14.42 s on repeated 500 ms deadlines: three `setup` tests and two `usage` tests; all 25 domain tests passed |
| [`just lint-check`](task-7-lint-check.log) | passed in 1.28 s |
| [`cargo build --locked --release`](task-7-release.log) | passed in 24.35 s |
| [`cargo clippy -p vpt-domain --all-targets -- -D warnings`](task-7-clippy.log) | passed |
| [committed-HEAD `gitleaks git --no-banner`](task-7-committed-head-secrets.log) | passed, 94 commits scanned, no leaks |

The [staged Rust size audit](task-7-size-audit.log) counted `time.rs` at 146 implementation and 292 total lines, `digest.rs` at 28 and 57. `git diff --cached --check` passed before commit. The ship size gate still warns about inherited `schema.rs` (471 implementation lines) and `config/load/tests.rs` (304 total lines); neither belongs to this slice. The repeated CLI deadlines remain unresolved and make `just test-rust` red despite the passing ship retry. The controller owns any later diagnosis and a fresh committed-HEAD ship.

Calendar conversion follows Howard Hinnant's [days-from-civil and civil-from-days algorithms](https://howardhinnant.github.io/date_algorithms.html), whose negative-year era arithmetic and public-domain grant the controller checked on 2026-09-22. This source check supports attribution, while the local tests and mutation controls provide runtime evidence.

## Review fix 1

[Sol review 1](task-7-review-1.md) found that the original divisor mutant was valid and survived. The age test now asserts `FileTime { secs: 0, nanos: 1 }.age_secs(UtcInstant { secs: 1 }) == 0`; production code is unchanged. The exact original mutation compiled and [failed at that assertion](task-7-fix1-exact-survivor-mutant.log), returning `1` instead of `0`. The [restored control](task-7-fix1-exact-survivor-control.log) passed, with `time.rs` SHA-256 `b6a783c18f253c04ef660dbe206fe51a5a7c027e234e426b0e6b78c3bbcb9866` before and after mutation. The [initial control](task-7-fix1-initial-control.log) also passed. `digest.rs` remains `191f694a3bf8314c04ea71e355fbe228a78eb0afd93b75d48990c8ddb9299c20`.

Final-source gates: [`just ship`](task-7-fix1-ship.log) passed in 16.41 s; [`cargo check --locked --workspace --all-targets --features dev-tools`](task-7-fix1-check.log) passed in 2.29 s; [`just test-rust`](task-7-fix1-test-rust.log) passed in 2.71 s; [`just lint-check`](task-7-fix1-lint-check.log) passed in 0.69 s; [`cargo build --locked --release`](task-7-fix1-release.log) passed in 3.00 s. The [size audit](task-7-fix1-size-audit.log) counts `time.rs` at 146 implementation and 296 total lines. The [named-leaf comparison](task-7-fix1-final-leaves.log) remains 171 leaves with [zero missing](task-7-fix1-missing-leaves.log). `git diff --cached --check` passed before the amend. The [amend log](task-7-fix1-amend.log) records HEAD `8c01758`; the [committed-HEAD secrets scan](task-7-fix1-committed-head-secrets.log) found no leaks in 94 commits. The controller owns the fresh ship on amended HEAD.
