F1 ADDRESSED. crates/vpt/src/lib.rs:35 handles stderr writes without panicking and returns 1 on failure. All three diagnostic paths call it at lines 10, 24 and 28.

Regression coverage: crates/vpt/tests/usage.rs:17 and :28, crates/vpt/tests/version.rs:43. The red and mutation runs reproduce exit 101; task-1-fix-1-green.log:7, :8 and :17 confirm the regressions pass. Existing acceptance cases remain green.

New fix-introduced breakage: none. Out-of-scope observations: none.

Fix round 1: all findings addressed, no new Critical or Important breakage. Reviewer /root/vpt_build_review_1 approved the scoped fix.
