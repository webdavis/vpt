### Spec Compliance

Compliant. The prior Minor is closed: container/tests.rs:19 pins fractional flooring; container/tests.rs:134 verifies valid creation and duration fields above 32 bits.

### Strengths

- Both tests exercise public parser results.
- Raw evidence confirms three compiled mutants fail the intended assertions. All restored controls pass with the original parser hash.
- The diff adds only 24 test lines. The test file remains below the 300-line target at 261 lines.

### Critical / Important / Minor

None. No new issue in 6eaf984..17ea73a.

### Assessment

Approved. The two tests directly cover the identified gap without changing production behavior.

Fresh postcommit verification remains controller-owned. No suites rerun or outside-diff code inspected.
