# Task 13 execution brief

## Parallel scheduling amendment, 2026-09-26

The operator requested independent implementation lanes. The controller reread the complete original
Task 13, spec section 4.4, and the accepted `contained.rs`, `contained/file.rs` and
`contained/directory.rs` at `c84df8a`. Task 13 consumes only `Access`, `ContainedError` and `RootDir`,
all already accepted. It does not consume a ledger trait, migration, database owner or Task 12 row type.
Its former D5/Task 12 wait was ordering, not an API dependency, and is withdrawn for an isolated lane.
The public lock contract and all verification requirements below remain unchanged. Integration must
preserve both lanes' curated exports and pass the combined suite. The controller creates the lane and
coordinates process-test, mutation and timing windows; the implementer does not create worktrees.

Read the entire approved Task 13 in
`docs/superpowers/plans/2026-09-21-vpt-stage-1-extract-plan.md`, from `### Task 13:` through the next
task heading (currently lines 8289-8455), and the actual current checked-root APIs before writing.
Its separate application write-lock role does not replace SQLite's D2 record locks.

## Ownership and verification

- Own `crates/vpt-adapters/src/lock.rs`, its focused test children and curated exports, plus the ignored Task 13 report and raw evidence. Main owns progress and Todoist. Preserve all other work; one product writer, no new worktree or subagents.
- Controller safety ruling: potentially blocking calls run inside the accepted D4 direct-root child supervisor. Minimal test-only visibility/exports in `database/mod.rs`, `database/tests/mod.rs` and `database/tests/children.rs`, plus one `lock_` scenario route, are authorized. Keep its 500 millisecond operation and 900 millisecond cleanup deadlines unchanged; peers share one starting Instant and remain direct children of the root test. Do not change supervisor behavior or add another runner. Root reconciles these test-only overlaps with D5 during integration.
- The private immediate `try_lock(RawFd)` syscall/classification seam may test its non-contention error with literal `-1` in a supervised child. That value is not a live descriptor. Never close or corrupt an owned descriptor to manufacture the error. Add its compiling RED before implementing the branch.
- Use the actual retained-root no-follow/nonblocking/exclusive-open helpers. Do not copy obsolete path openers, expand shared helper semantics, add dependencies or expose database internals. Verify `flock` constants and error behavior from local primary sources.
- Use compiling behavioral RED stubs, never missing imports as RED. Test busy acquisition at zero and bounded waits, release on owner drop, close-on-exec, private creation and refused unsafe entries. Keep all waits bounded in owned fixtures. Mutation-test the actual lock and timeout branches with exact restored passing controls. Preserve every baseline leaf.
- Follow clean-code-rust, approved model routing and normal local commit hooks. All fixtures are owned and synthetic; no live paths, installation, publication, apply, third-party edits or destructive cleanup. Check editor buffers and use apply_patch. Stage owned files before size audit, run required final-source Rust/release gates, and leave the fresh committed-HEAD ship to the controller.

## Duration boundary correction

Tracked with Task 14's digest boundary in Todoist `6hc85XHXH5QRq5mg`; close only after both owning tasks pass independent review.

A read-only Luna lookup found no write-lock wait key in the current configuration. The planned production composition uses a fixed five-second wait (`Runtime::load`, around lines 16637-16731); `load_with_wait` is a test seam. Accepted configuration durations do not flow into this lock. Do not add a configuration ceiling or claim a configuration defect.

The public `WriteLock::acquire(..., wait: Duration)` nevertheless accepts any Duration, while the sample computes `Instant::now() + wait` before its first lock attempt. That addition has no overflow handling. This is a source-level concern, not a reproduced VPT bug. Add a compiling behavioral regression that acquires an uncontended owned lock with `Duration::MAX` and returns promptly without panicking. Use the smallest overflow-safe elapsed/remaining calculation for bounded polling; do not reject a successful uncontended acquisition or introduce a new public error/configuration field. Never exercise a centuries-long contended wait. Catch reintroduced unchecked deadline addition with that focused mutation.

Lookup evidence: `/root/vpt_task13_wait_lookup_luna` traced the current schema, `config/validate.rs:70`, `vpt-domain/src/duration.rs:9`, `config/settings.rs:147`, planned acquire at line 8387 and runtime call sites. Existing command cleanup's fixed 50 ms addition is not a reusable arbitrary-duration solution.
