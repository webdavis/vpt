# Task 22 execution brief

Read task-22-brief.md completely after Task 21 is accepted. Use the actual typed ledger and archive
interfaces. This is preparation, not dispatch.

- Own orphan recovery and source-disappearance handling with their focused tests. You are not alone;
  preserve others' work. One product writer, no subagents. Main owns the ledger and task tracker.
- Establish compiling behavioral RED for each new recovery or disappearance branch before code.
- Recover using the archive filename's identity and whole-file digest, valid container and persisted
  capture instant. Infer the stored offset from that filename, never the current machine zone. Cover
  positive and negative offsets, the strict less-than-one-day boundary and checked extreme arithmetic.
- Keep unrecognized names, invalid containers, mismatched hash suffixes and incompatible timestamps
  untouched with the specified diagnostics. Skip existing rows without resetting accepted state.
- Require successful sync_existing, including retained-root validation, before committing recovery.
  A sync or commit failure cannot report a new durable recovery. Preserve earlier completed work.
- Mark only previously ingested, newly absent sources on a full mutating sweep. Preserve an existing
  disappearance timestamp; never mark unrelated paths absent during --once or write during dry run.
- Preserve the approved ordering: title refresh and orphan recovery precede candidates on mutating
  sweeps; disappearance follows a successful full sweep. Task 23 owns the empty-store abort behavior.
- Reuse the accepted observational snapshot helper where state immutability is asserted. Keep source
  fixture writers quiescent; no real Voice Memos data or source mutations in product code.
- Preserve every accepted leaf, typed errors and size limits. Add compiled focused mutations and
  exact restored controls. No sample docstrings, broad lint suppressions or generic recovery layer.
- Report chronology, logs, hashes, timing/size audit and normal-hook commits in task-22-report.md.
  Main owns independent review and final ship. No live data, real Trash, notifications, installation,
  publishing or destructive evidence cleanup.
