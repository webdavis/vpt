# Task 21 execution brief

Read task-21-brief.md completely after Task 20 is accepted. Reconcile its samples with the actual
ledger, archive and cleanup interfaces. This is preparation, not dispatch.

- Own duplicate and collision handling and its focused fixtures. You are not alone; preserve others'
  work. One product writer, no subagents. Main owns the ledger and task tracker.
- Capture compiling, reachable behavioral RED before each new branch. The fault guards already
  covered by Task 19 are regression evidence, not new test-first evidence for this task.
- Look up the whole digest before deriving an identity in the current zone. Known bytes keep their
  identity, move their source path, refresh seen state, and discard only this run's owned staging.
- Use the accepted `RunHistory::commit_step` boundary. A known-digest source-path update belongs in
  `WorkDelta::source_updates`, with its seen row in `commit.seen` and its Completed work fact in the
  same step. Do not copy the sample's separate `set_source_path` and `record_seen` writes. Preserve
  the existing recording's capture fields, title, stages and audio Trash marker.
- Commit and export that duplicate step before discarding owned staging. A required-history failure,
  known-committed failure or sink Stop preserves staging and prevents further work. Keep any confirmed
  receipt and completed identities supplied by the accepted helpers; an export warning alone follows
  the approved Continue policy. Pin rollback, post-commit and sink-stop paths before implementation.
- On an existing target, require whole-digest and container agreement, then successful file and
  directory durability through sync_existing before committing missing rows. Carry Task 18's retained
  root revalidation. A collision replaces nothing and reports exactly one failure event.
- Recover the missing recording and seen row with their work history atomically. Reuse any already
  committed archive intent's explicit ID when recording its observed result. A known-digest shortcut
  creates no archive publication intent. Report recovery only after confirmed persistence, retaining
  that confirmation if a later export fails. Required-history failures never trigger staged cleanup.
- Route collisions through the existing failure finisher so a successful failure-history write emits
  one IngestFailed event and one failed run ending before cleanup. A refused failure-history write or
  sink Stop preserves the staged clone. Do not notify directly or duplicate the caller's failure event.
- Preserve a placed-but-unsynced archive for recovery. Failed ledger reads, updates and commits must
  follow the existing staging-ownership contract, using typed safe errors rather than database text.
- The lost-ledger fixture owns only synthetic temporary data. Explicitly close all database owners
  before simulating loss; never unlink an open database or any source-store entry in product code.
- Reuse existing fault probes and both clone kinds. Add only missing behavior checks, including a
  failed sync_existing that cannot commit recovery and invalid cleanup paths never sent to Trash.
- Reconcile the historical nine sample cases against accepted Task 19 and Task 20 leaves by name;
  do not duplicate their existing copy, disk-full, sync or cleanup controls. Task 20's typed staged
  deferrals supersede the sample's temporary invalid-container refusal. Keep the public dry-run
  refusal until Task 23 and consume the finished private deferral seam where needed.
- Keep all prior leaves and add focused compiled mutations with byte-identical restored controls.
  No broad lint allowances, sample docstrings, generic fault framework or speculative API changes.
- Report exact chronology, logs, mutation hashes, timing/size audit and normal-hook commits in
  task-21-report.md. Main performs independent review and final ship. No live data, real Trash,
  notifications, installation, publishing or destructive evidence cleanup.
