# Task 15 execution brief

Read the entire approved Task 15 in `docs/superpowers/plans/2026-09-21-vpt-stage-1-extract-plan.md`, from `### Task 15:` through the next task heading. The controller reread it fully on 2026-09-26, together with the current retained-root, file, directory, container and port implementations and installed `clonefile(2)` manual. D6, not the superseded native Task 16 sample, adds the title integration afterward.

## Parallel scheduling amendment

Task 15 consumes only accepted root, container and time APIs. It does not consume Task 12 or Task 14.
The former serial wait is withdrawn for an isolated VPT-local lane under the operator's parallel-work
request. Root creates the worktree and reconciles the two curated export files at integration. Native
descriptor cloning and destination-identity checks use Astra implementation and independent review.
All verification windows remain root-coordinated. No source recordings are opened outside owned tests.

## Ownership and constraints

- Own the recorder application port, private `voice_memos` store adapter, their focused tests and curated exports, plus ignored Task 15 report/evidence. Main owns progress/Todoist. Preserve others' work; one product writer, no new worktree or subagents.
- Source access stays read-only by descriptor. Candidate listing is depth one, lowercase `.m4a`, with the complete flags word; never traverse the four Apple subdirectories as candidates. Subdirectory counts use the existing no-follow child-root helpers.
- Cloning uses the already-open source descriptor and a separately acquired destination directory whose identity must equal the supplied expected identity. All clone names pass the actual checked-root name boundary. Only EXDEV permits the existing bounded byte-copy fallback. Preserve Exists and NoSpace classifications, exclusive destination ownership, and existing bytes on a collision. Verify the installed platform clone interface before using it.
- Do not add title/database behavior, archive staging, source scanning outside fixtures, a new copy abstraction, or new dependency. Task 17 owns final archive staging privacy and cleanup; the controller read that task's use of descriptor chmod, digest and ownership checks, so do not implement it early.
- Use compiling behavioral RED, not missing imports. Retain all baseline leaves and test the complete approved behavior set, including replaced destination identity and no-follow subdirectory counts, with exact compiled mutations and restored passing controls. Source snapshots exclude only access time. Keep each test below one second; owned synthetic fixtures only.
- Prove the complete nonzero flags word, rather than only absence of a dataless bit, using an owned safe fixture or the narrow actual stat conversion. Pin descriptor-based cloning after the source pathname changes, checked destination names, collision preservation, and each error/fallback class. Do not mount volumes, exhaust disks, invalidate live descriptors or weaken containment to force errors. Propose any small private error-injection seam before implementing it; do not add a general copy framework.
- Follow clean-code-rust and normal local commit hooks. No live recordings/databases, installation, push, pull request, merge, apply, third-party edits or destructive cleanup. Verify buffers and use apply_patch. Stage owned new files before size audit; run required final-source gates/release. Main owns the fresh committed-HEAD ship and independent review.
