### Task 3: The configuration key table, the setup template and the loader

One authoritative definition of every key (name, kind, default, comment, secret) drives the rendered
template, the unknown-key refusal and the validator. The loader parses the operator's file, refuses an
unknown key, an unknown table or a missing `config_version`, and merges the file over the rendered
defaults, so every key the application reads is present. A parse failure is reported by a fixed sentence,
never by the parser's own message, because that message can quote the rejected line.

## Controller execution constraints

- Read the plan's Global Constraints and the top of progress.md, not the large audit appendix. Use the approved spec's configuration table as authority for every key, type and default.
- Preserve all prior tests and protocol behavior. This task owns the configuration schema, rendering and loading files, plus their adapter exports. Do not implement Task 4 value rules or Task 5 settings early.
- Start with compiling stubs and observe behavioral RED, then GREEN. Missing-name compiler failures do not establish test coverage. Keep parse-error tests canary-based so raw configuration and secret values cannot leak.
- Keep fields in one authoritative key table. No separate copy of defaults or supported-key lists. Follow the requested file-size limits after rustfmt; avoid unsolicited docstrings and prose copied from the plan.
- Run the complete current suite and clean-code Rust gates, and record named leaf tests, mutation controls, timing and the exact staged-file size audit in the report. No subagents, push, pull request, merge, installation or live destinations.
- Preserve durable raw RED, GREEN, mutation and gate output beside the report in this ignored evidence directory. Keep the report compact: a leaf-name delta, command/exit table, mutation table with source-byte proof and log paths, and size output. A baseline inventory file plus an empty removed-name set can establish unchanged leaves without reprinting them all.
- Capture a complete final green run, and scan the committed HEAD with gitleaks after the normal-hook commit so the new source is included. A history scan before commit does not scan the uncommitted new source. Do not change source after final gates without rerunning the affected checks.

**Files:**

- Create: `crates/vpt-adapters/src/config/mod.rs`, `crates/vpt-adapters/src/config/schema.rs`,
  `crates/vpt-adapters/src/config/schema/types.rs`, `crates/vpt-adapters/src/config/schema/dynamic.rs`,
  `crates/vpt-adapters/src/config/render.rs`, `crates/vpt-adapters/src/config/load.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`

**Interfaces:**

- Consumes: nothing.

- Produces, re-exported from `vpt_adapters::config` (the files below `config/` are private modules):
  `Kind::{Bool, PositiveInt, NonNegativeInt, PositiveInt64, Ratio, RatioAboveZero, Duration,`
  `Enum(&'static [&'static str]), Text, Secret, TextList, Argv}` with
  `Kind::expected(self) -> &'static str` (the type name a wrong-type refusal reports);
  `KeySpec { pub path: &'static str, pub kind: Kind, pub default: &'static str,`
  `pub comment: &'static str }`; `KEYS: &[KeySpec]`; `STORE_KEYS: &[&str]`;
  `DynamicTable { pub prefix: &'static str, pub leaves: &'static [(&'static str, Kind)] }`;
  `DYNAMIC_TABLES: &[DynamicTable]`; `spec_for(path: &str) -> Option<Kind>`;
  `template(main_engine: &str, state_dir: &str) -> String`; `CONFIG_VERSION: i64`;
  `ConfigError::{Missing(String), Unreadable { path: String, detail: String }, Unparseable(String),`
  `MissingVersion, UnsupportedVersion(i64), UnknownKey(String), WrongType { key: String,`
  `expected: String },` `OutOfRange { key: String, rule: String }}`;
  `load_text(text: &str) -> Result<toml::Table, ConfigError>`;
  `load_file(path: &Path) -> Result<toml::Table, ConfigError>`;
  `get<'a>(table: &'a toml::Table, path: &str) -> Option<&'a toml::Value>`.

- [ ] **Step 1: Write the failing tests**

Declare every module first so the test modules are compiled and selected by the red run.
`crates/vpt-adapters/src/lib.rs`:

```rust
//! Concrete adapters: filesystem, SQLite, processes and configuration.

pub mod config;
```

`crates/vpt-adapters/src/config/mod.rs`:

```rust
//! Configuration: one key table, the template rendered from it, the loader
//! that refuses what the table does not name, and the validator.

mod load;
mod render;
mod schema;

pub use load::{CONFIG_VERSION, ConfigError, get, load_file, load_text};
pub use render::template;
pub use schema::{DYNAMIC_TABLES, DynamicTable, KEYS, KeySpec, Kind, STORE_KEYS, spec_for};
```

`crates/vpt-adapters/src/config/schema.rs` starts as its doc line, `//! The configuration key table.`,
and `crates/vpt-adapters/src/config/load.rs` starts as its test module alone:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::{KEYS, template};

    #[test]
    fn the_rendered_template_loads_and_every_key_of_the_table_is_present() {
        let table = load_text(&template("apple", "~/.local/state/vpt")).expect("template loads");
        for key in KEYS {
            assert!(get(&table, key.path).is_some(), "{} missing after load", key.path);
        }
        assert_eq!(get(&table, "engines.main").and_then(|v| v.as_str()), Some("apple"));
    }

    #[test]
    fn an_operator_value_wins_over_the_default() {
        let table = load_text("config_version = 1\n[source]\nquiet_period_secs = 90\n").expect("loads");
        assert_eq!(get(&table, "source.quiet_period_secs").and_then(|v| v.as_integer()), Some(90));
        assert_eq!(get(&table, "source.deferral_page_threshold").and_then(|v| v.as_integer()), Some(4));
    }

    #[test]
    fn an_unknown_key_is_refused_by_its_full_path() {
        let error = load_text("config_version = 1\n[source]\nquiet_period = 90\n").unwrap_err();
        assert_eq!(error, ConfigError::UnknownKey("source.quiet_period".into()));
    }

    #[test]
    fn an_unknown_table_is_refused_even_when_empty() {
        assert_eq!(load_text("config_version = 1\n[unknown]\n").unwrap_err(), ConfigError::UnknownKey("unknown".into()));
        assert_eq!(load_text("config_version = 1\n[source.extra]\n").unwrap_err(), ConfigError::UnknownKey("source.extra".into()));
    }

    #[test]
    fn a_table_where_a_scalar_belongs_is_a_wrong_type() {
        let error = load_text("config_version = 1\n[source]\nquiet_period_secs = {}\n").unwrap_err();
        assert_eq!(error, ConfigError::WrongType { key: "source.quiet_period_secs".into(), expected: "integer".into() });
    }

    #[test]
    fn a_missing_config_version_is_refused() {
        assert_eq!(load_text("[source]\nread_titles = false\n").unwrap_err(), ConfigError::MissingVersion);
    }

    #[test]
    fn a_future_config_version_is_refused_with_its_value() {
        assert_eq!(load_text("config_version = 2\n").unwrap_err(), ConfigError::UnsupportedVersion(2));
    }

    #[test]
    fn an_engine_table_and_a_language_pair_are_dynamic_keys() {
        let text = "config_version = 1\n[engines.cloudy]\nkind = \"command\"\ncommand = [\"x\"]\n\
                    family = \"whisper\"\nlocal = false\n[engines.by_language.de-DE]\nmain = \"cloudy\"\n\
                    [retention.hold]\naudio = \"90d\"\n";
        let table = load_text(text).expect("dynamic keys load");
        assert_eq!(get(&table, "engines.cloudy.family").and_then(|v| v.as_str()), Some("whisper"));
        assert_eq!(get(&table, "engines.by_language.de-DE.main").and_then(|v| v.as_str()), Some("cloudy"));
    }

    #[test]
    fn a_dynamic_table_still_refuses_a_leaf_it_does_not_know() {
        let error = load_text("config_version = 1\n[engines.cloudy]\nkind = \"command\"\nspeed = 3\n").unwrap_err();
        assert_eq!(error, ConfigError::UnknownKey("engines.cloudy.speed".into()));
    }

    #[test]
    fn a_hold_for_an_unknown_store_is_refused() {
        let error = load_text("config_version = 1\n[retention.hold]\nvideos = \"1d\"\n").unwrap_err();
        assert_eq!(error, ConfigError::UnknownKey("retention.hold.videos".into()));
    }

    #[test]
    fn unparseable_toml_is_refused_without_quoting_the_text() {
        let text = "config_version = 1\n[context.google]\nclient_secret = \"canary-7Q9x-secret\n";
        let error = load_text(text).unwrap_err();
        assert_eq!(error, ConfigError::Unparseable("invalid TOML syntax in configuration".into()));
        assert!(!format!("{error:?}").contains("canary"));
    }

    #[test]
    fn a_state_path_with_a_quote_and_a_backslash_round_trips_through_the_template() {
        let table = load_text(&template("apple", "/tmp/say \"hi\"\\now")).expect("loads");
        assert_eq!(get(&table, "home.state_dir").and_then(|v| v.as_str()), Some("/tmp/say \"hi\"\\now"));
    }
}
```

`crates/vpt-adapters/src/config/render.rs`, likewise the test module alone:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_template_starts_with_the_version_and_names_the_chosen_engine() {
        let text = template("whisply", "/state/vpt");
        assert!(text.starts_with("config_version = 1"), "{text}");
        assert!(text.contains("\nmain = \"whisply\""), "{text}");
        assert!(text.contains("state_dir = \"/state/vpt\""), "{text}");
    }

    #[test]
    fn every_key_line_carries_a_comment() {
        for line in template("apple", "~/.local/state/vpt").lines() {
            if line.contains(" = ") {
                assert!(line.contains(" # "), "uncommented key line: {line}");
            }
        }
    }

    #[test]
    fn a_secret_key_is_marked_in_its_comment() {
        let text = template("apple", "~/.local/state/vpt");
        assert!(text.contains("client_secret = \"\" # OAuth client secret (secret)"), "{text}");
    }
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters config`

Expected: the build of the two test modules fails with `cannot find` for `KEYS`, `template`, `load_text`,
`get` and `ConfigError`. The modules are compiled and selected; a run that selects zero tests, or that
succeeds, does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-adapters/src/config/schema/types.rs`:

```rust
//! The kinds a key can have, and the shape of one key's definition.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    Bool,
    /// A timeout, a threshold or a length: a positive 32-bit integer.
    PositiveInt,
    /// A count, a gap or a lookback: a non-negative 32-bit integer.
    NonNegativeInt,
    /// `source.max_audio_bytes` alone: a positive 64-bit integer.
    PositiveInt64,
    /// A finite number in `[0, 1]`.
    Ratio,
    /// A finite number in `(0, 1]`.
    RatioAboveZero,
    /// `0` or a positive decimal integer with one of `s`, `m`, `h`, `d`.
    Duration,
    Enum(&'static [&'static str]),
    Text,
    Secret,
    TextList,
    Argv,
}

impl Kind {
    /// The type name a wrong-type refusal reports.
    pub fn expected(self) -> &'static str {
        match self {
            Kind::Bool => "boolean",
            Kind::PositiveInt | Kind::NonNegativeInt | Kind::PositiveInt64 => "integer",
            Kind::Ratio | Kind::RatioAboveZero => "number",
            Kind::Duration => "duration",
            Kind::Enum(_) | Kind::Text | Kind::Secret => "string",
            Kind::TextList | Kind::Argv => "list of strings",
        }
    }
}

pub struct KeySpec {
    pub path: &'static str,
    pub kind: Kind,
    pub default: &'static str,
    pub comment: &'static str,
}

pub const STORE_KEYS: &[&str] =
    &["audio", "transcripts", "analysis", "briefs", "engine_outputs", "drafts", "released"];

pub(super) const fn key(path: &'static str, kind: Kind, default: &'static str, comment: &'static str) -> KeySpec {
    KeySpec { path, kind, default, comment }
}
```

`crates/vpt-adapters/src/config/schema/dynamic.rs`:

```rust
//! The tables whose middle segment the operator names, and the lookup that
//! answers what kind a dotted path has.

use super::{KEYS, Kind};

/// `engines.<name>.*` and `engines.by_language.<lang>.*`. The leaf must be one of `leaves`.
pub struct DynamicTable {
    pub prefix: &'static str,
    pub leaves: &'static [(&'static str, Kind)],
}

pub const DYNAMIC_TABLES: &[DynamicTable] = &[
    DynamicTable { prefix: "engines.by_language.", leaves: &[("main", Kind::Text), ("checker", Kind::Text)] },
    DynamicTable {
        prefix: "engines.",
        leaves: &[
            ("kind", Kind::Enum(&["apple", "whisply", "command"])),
            ("command", Kind::Argv),
            ("family", Kind::Text),
            ("local", Kind::Bool),
            ("device", Kind::Text),
            ("model", Kind::Text),
        ],
    },
];

pub fn spec_for(path: &str) -> Option<Kind> {
    if let Some(known) = KEYS.iter().find(|key| key.path == path) {
        return Some(known.kind);
    }
    for table in DYNAMIC_TABLES {
        if let Some(rest) = path.strip_prefix(table.prefix) {
            let mut parts = rest.splitn(2, '.');
            let (Some(name), Some(leaf)) = (parts.next(), parts.next()) else { continue };
            if name.is_empty() || leaf.contains('.') {
                continue;
            }
            if let Some((_, kind)) = table.leaves.iter().find(|(known, _)| *known == leaf) {
                return Some(*kind);
            }
        }
    }
    None
}

/// Whether a table at `path` is one the schema declares: a prefix of a static
/// key, a dynamic table's parent, or a dynamic table itself.
pub fn table_is_declared(path: &str) -> bool {
    let as_prefix = format!("{path}.");
    KEYS.iter().any(|key| key.path.starts_with(&as_prefix))
        || DYNAMIC_TABLES.iter().any(|table| {
            table.prefix.starts_with(&as_prefix)
                || path.strip_prefix(table.prefix).is_some_and(|name| !name.is_empty() && !name.contains('.'))
        })
}
```

`crates/vpt-adapters/src/config/schema.rs`:

```rust
//! The one authoritative definition of every configuration key. The renderer,
//! the loader, the validator and the settings reader all read this table.

mod dynamic;
mod types;

pub use dynamic::{DYNAMIC_TABLES, DynamicTable, spec_for, table_is_declared};
pub use types::{KeySpec, Kind, STORE_KEYS};
use types::key;

/// Every key of spec section 10, in the order the template renders them.
pub const KEYS: &[KeySpec] = &[
    key("config_version", Kind::PositiveInt, "1", "the configuration schema version"),
    key("home.path", Kind::Text, "\"~/.vpt\"", "the home; every store defaults under it"),
    key("home.state_dir", Kind::Text, "\"~/.local/state/vpt\"", "the ledger's directory"),
    key("home.symlink_target", Kind::Text, "\"\"", "when set, ~/.vpt is a managed symlink to this directory"),
    key("helper.path", Kind::Text, "\"vpt-macos\"", "the macOS helper, resolved on PATH when relative"),
    key("stores.audio", Kind::Text, "\"<home>/audio\"", "archive clones"),
    key("stores.transcripts", Kind::Text, "\"<home>/transcripts\"", "transcript notes"),
    key("stores.analysis", Kind::Text, "\"<home>/analysis\"", "synthesis notes"),
    key("stores.briefs", Kind::Text, "\"<home>/briefs\"", "briefs"),
    key("stores.engine_outputs", Kind::Text, "\"<home>/engine-outputs\"", "raw engine documents"),
    key("stores.drafts", Kind::Text, "\"<home>/drafts\"", "private redaction reports"),
    key("stores.released", Kind::Text, "\"<home>/released\"", "the shared folder"),
    key(
        "source.recordings_dir",
        Kind::Text,
        "\"~/Library/Group Containers/group.com.apple.VoiceMemos.shared/Recordings\"",
        "Apple's store, read read-only",
    ),
    key("source.read_titles", Kind::Bool, "true", "read titles from a private copy of the database"),
    key("source.quiet_period_secs", Kind::PositiveInt, "30", "seconds a file must be unchanged before it is at rest"),
    key("source.deferral_page_threshold", Kind::PositiveInt, "4", "consecutive deferrals of one recording before one event"),
    key("source.max_audio_bytes", Kind::PositiveInt64, "2147483648", "a larger source file defers before any content is read"),
    key("recording.language", Kind::Text, "\"en-US\"", "the language engines are asked for"),
    key("engines.main", Kind::Text, "\"apple\"", "the transcript of record"),
    key("engines.checker", Kind::Text, "\"\"", "the second slot; empty runs one engine"),
    key("engines.checker_runs", Kind::Enum(&["always", "on_failure"]), "\"always\"", "always or on_failure"),
    key("engines.allow_same_family", Kind::Bool, "false", "let two engines of one family run"),
    key("engines.timeout_secs", Kind::PositiveInt, "1800", "per-engine wall-clock deadline"),
    key("engines.apple.kind", Kind::Enum(&["apple"]), "\"apple\"", "the Apple Speech adapter through the helper"),
    key("engines.whisply.kind", Kind::Enum(&["whisply"]), "\"whisply\"", "the whisply adapter"),
    key("engines.whisply.command", Kind::Argv, "[\"whisply\"]", "how whisply is invoked"),
    key("engines.whisply.device", Kind::Text, "\"mlx\"", "mlx reports no confidence, cpu does"),
    key("engines.whisply.model", Kind::Text, "\"large-v3-turbo\"", "the model name"),
    key("reconcile.confidence_floor", Kind::Ratio, "0.35", "word confidence below this is flagged"),
    key("reconcile.max_divergence_ratio", Kind::RatioAboveZero, "0.35", "past this edit-distance ratio, one divergent flag"),
    key("reconcile.known_terms_path", Kind::Text, "\"~/.config/vpt/known-terms.txt\"", "the confirmed-terms list"),
    key("readability.enabled", Kind::Bool, "false", "the readability pass over the note body"),
    key("note.profile", Kind::Enum(&["portable", "obsidian"]), "\"portable\"", "portable or obsidian"),
    key("note.link_style", Kind::Enum(&["markdown", "wiki"]), "\"markdown\"", "markdown or wiki"),
    key("note.slug_max_chars", Kind::PositiveInt, "60", "slug length cap"),
    key("note.obsidian.hub_transcripts", Kind::Text, "\"transcripts\"", "folder note name for hub"),
    key("note.obsidian.hub_analysis", Kind::Text, "\"analysis\"", "folder note name for hub"),
    key("note.obsidian.hub_briefs", Kind::Text, "\"briefs\"", "folder note name for hub"),
    key("note.obsidian.vault_root", Kind::Text, "\"\"", "the vault's root directory, required by the obsidian profile"),
    key("tags.new_tags", Kind::Enum(&["write", "hold"]), "\"hold\"", "write (automatic) or hold (suggested until confirmed)"),
    key("tags.known_tags_path", Kind::Text, "\"~/.config/vpt/known-tags.txt\"", "the confirmed-tags list"),
    key("tags.max_per_note", Kind::NonNegativeInt, "5", "confirmed tags per note"),
    key("tags.max_suggested", Kind::NonNegativeInt, "10", "held tags per note"),
    key("relations.session_gap_minutes", Kind::NonNegativeInt, "60", "continues window"),
    key("relations.max_suggested", Kind::NonNegativeInt, "5", "agent-proposed related links kept per note"),
    key("synthesis.command", Kind::Argv, "[]", "the agent command; empty disables synthesis only"),
    key("synthesis.timeout_secs", Kind::PositiveInt, "600", "the command's deadline"),
    key("synthesis.grounding_window_secs", Kind::PositiveInt, "15", "verify-note's tolerance around a cited span"),
    key("brief.lookback_days", Kind::NonNegativeInt, "180", "how far back selection reaches"),
    key("brief.max_notes", Kind::NonNegativeInt, "12", "selection cap"),
    key("brief.max_spans_per_note", Kind::NonNegativeInt, "5", "quoted spans per selected note"),
    key("brief.trigger.enabled", Kind::Bool, "false", "the calendar trigger behind --upcoming"),
    key("brief.trigger.lead_time", Kind::Duration, "\"24h\"", "how far ahead --upcoming looks"),
    key("context.type", Kind::Enum(&["none", "dam", "google"]), "\"none\"", "none, dam or google"),
    key("context.calendars", Kind::TextList, "[]", "dam path prefixes or Google calendar ids; empty refuses"),
    key("context.projects", Kind::TextList, "[]", "dam task path prefixes; empty refuses"),
    key("context.dam.command", Kind::Argv, "[\"dam\"]", "how dam is invoked"),
    key("context.google.client_id", Kind::Secret, "\"\"", "OAuth client id"),
    key("context.google.client_secret", Kind::Secret, "\"\"", "OAuth client secret"),
    key("context.google.refresh_token", Kind::Secret, "\"\"", "a refresh token bearing only the read-only events scope"),
    key("share.automatic", Kind::Bool, "false", "redact every recording's notes during vpt run"),
    key(
        "share.source_line",
        Kind::Text,
        "\"redacted extract, not a verbatim record\"",
        "the one frontmatter line telling a recipient what they hold",
    ),
    key("share.include_date", Kind::Bool, "false", "put the capture date in the released frontmatter"),
    key("share.keep_timecodes", Kind::Bool, "false", "keep [mm:ss] references in released text"),
    key("share.deny_sections", Kind::TextList, "[]", "sections dropped from the content region before redaction"),
    key(
        "share.redact.classes",
        Kind::TextList,
        "[\"email\", \"url\", \"phone\", \"number\", \"money\"]",
        "pattern classes; terms and note names are always masked",
    ),
    key("share.redact.mask", Kind::Text, "\"[{class} {n}]\"", "rendered in place of a removed value"),
    key("share.redact.flagged_spans", Kind::Enum(&["omit", "mark"]), "\"omit\"", "omit or mark"),
    key("handoff.allow_private", Kind::Bool, "false", "let transcripts, analysis notes and briefs be handed off"),
    key("notify.mode", Kind::Enum(&["desktop", "command", "off"]), "\"desktop\"", "desktop, command or off"),
    key(
        "notify.command",
        Kind::Argv,
        "[]",
        "argv with {event}, {state}, {id}, {detail}, {count}, {path} tokens; receives vpt's JSON on stdin",
    ),
    key("notify.aggregate_after", Kind::PositiveInt, "3", "recordings needing review in one run before one aggregate event"),
    key("retention.enabled", Kind::Bool, "false", "the opt-in retention run"),
    key("retention.include_audio", Kind::Bool, "false", "let the audio store expire"),
    key("retention.hold.audio", Kind::Duration, "0", "files older than this move to the Trash; 0 never"),
    key("retention.hold.transcripts", Kind::Duration, "0", "as above"),
    key("retention.hold.analysis", Kind::Duration, "0", "as above"),
    key("retention.hold.briefs", Kind::Duration, "0", "as above"),
    key("retention.hold.engine_outputs", Kind::Duration, "0", "as above"),
    key("retention.hold.drafts", Kind::Duration, "0", "as above"),
    key("retention.hold.released", Kind::Duration, "0", "as above"),
];
```

The four counts `tags.max_per_note`, `tags.max_suggested`, `brief.max_notes` and
`brief.max_spans_per_note` are `NonNegativeInt`: spec section 10 makes a count non-negative, so zero is a
valid value for each. `config/schema.rs` formats to about 470 lines with rustfmt; the two child modules
keep it under the 500-line cap.

`crates/vpt-adapters/src/config/render.rs`, above its test module:

```rust
//! The file `vpt setup` writes: every key at its default, one comment each.

use super::schema::{KEYS, Kind};

pub fn template(main_engine: &str, state_dir: &str) -> String {
    let mut text = String::new();
    let mut current_table = String::new();
    for key in KEYS {
        let (table, leaf) = split_table(key.path);
        if table != current_table {
            if !table.is_empty() {
                text.push_str(&format!("\n[{table}]\n"));
            }
            current_table = table.to_owned();
        }
        let value = match key.path {
            "engines.main" => quoted(main_engine),
            "home.state_dir" => quoted(state_dir),
            _ => key.default.to_owned(),
        };
        let secret = if key.kind == Kind::Secret { " (secret)" } else { "" };
        text.push_str(&format!("{leaf} = {value} # {}{secret}\n", key.comment));
    }
    text
}

/// A TOML basic string. JSON string escaping is a subset of TOML's, except
/// that TOML refuses a raw DEL character, which JSON leaves unescaped.
fn quoted(value: &str) -> String {
    serde_json::to_string(value).expect("strings serialize").replace('\u{7f}', "\\u007f")
}

fn split_table(path: &str) -> (&str, &str) {
    match path.rfind('.') {
        Some(index) => (&path[..index], &path[index + 1..]),
        None => ("", path),
    }
}
```

`config_version` sits in the empty table, which renders no header, so the text starts with
`config_version = 1`.

`crates/vpt-adapters/src/config/load.rs`, above its test module:

```rust
//! Read the operator's file, refuse what the key table does not name, and merge
//! it over the rendered defaults so every key is present afterwards.

use super::render::template;
use super::schema::{STORE_KEYS, spec_for, table_is_declared};
use std::path::Path;
use toml::{Table, Value};

pub const CONFIG_VERSION: i64 = 1;
const UNPARSEABLE: &str = "invalid TOML syntax in configuration";

#[derive(Debug, PartialEq, Eq)]
pub enum ConfigError {
    Missing(String),
    Unreadable { path: String, detail: String },
    Unparseable(String),
    MissingVersion,
    UnsupportedVersion(i64),
    UnknownKey(String),
    WrongType { key: String, expected: String },
    OutOfRange { key: String, rule: String },
}

pub fn load_file(path: &Path) -> Result<Table, ConfigError> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return Err(ConfigError::Missing(path.display().to_string()));
        }
        Err(error) => {
            return Err(ConfigError::Unreadable { path: path.display().to_string(), detail: error.kind().to_string() });
        }
    };
    load_text(&text)
}

pub fn load_text(text: &str) -> Result<Table, ConfigError> {
    let operator: Table = text.parse().map_err(|_: toml::de::Error| ConfigError::Unparseable(UNPARSEABLE.into()))?;
    match operator.get("config_version") {
        None => return Err(ConfigError::MissingVersion),
        Some(Value::Integer(CONFIG_VERSION)) => {}
        Some(Value::Integer(other)) => return Err(ConfigError::UnsupportedVersion(*other)),
        Some(_) => return Err(ConfigError::WrongType { key: "config_version".into(), expected: "integer".into() }),
    }
    refuse_unknown_keys(&operator, "")?;
    let mut merged: Table = template("apple", "~/.local/state/vpt")
        .parse()
        .map_err(|_: toml::de::Error| ConfigError::Unparseable(UNPARSEABLE.into()))?;
    merge_into(&mut merged, operator);
    Ok(merged)
}

fn refuse_unknown_keys(table: &Table, prefix: &str) -> Result<(), ConfigError> {
    for (name, value) in table {
        let path = if prefix.is_empty() { name.clone() } else { format!("{prefix}.{name}") };
        match value {
            Value::Table(inner) => {
                if let Some(kind) = spec_for(&path) {
                    return Err(ConfigError::WrongType { key: path, expected: kind.expected().into() });
                }
                if !table_is_declared(&path) {
                    return Err(ConfigError::UnknownKey(path));
                }
                refuse_unknown_keys(inner, &path)?;
            }
            _ => {
                if let Some(store) = path.strip_prefix("retention.hold.") {
                    if !STORE_KEYS.contains(&store) {
                        return Err(ConfigError::UnknownKey(path));
                    }
                } else if spec_for(&path).is_none() {
                    return Err(ConfigError::UnknownKey(path));
                }
            }
        }
    }
    Ok(())
}

fn merge_into(base: &mut Table, over: Table) {
    for (name, value) in over {
        match (base.get_mut(&name), value) {
            (Some(Value::Table(existing)), Value::Table(incoming)) => merge_into(existing, incoming),
            (_, incoming) => {
                base.insert(name, incoming);
            }
        }
    }
}

/// Read a leaf by its dotted path.
pub fn get<'a>(table: &'a Table, path: &str) -> Option<&'a Value> {
    let mut segments = path.split('.');
    let first = segments.next()?;
    let mut current = table.get(first)?;
    for segment in segments {
        current = current.as_table()?.get(segment)?;
    }
    Some(current)
}
```

The unparseable message is the same fixed sentence on both parse sites, and `Unreadable` carries the
error kind rather than the operating system's text, so no refusal quotes the configuration.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters config`

Expected: 15 tests PASS.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates/vpt-adapters
SKIP_AI_COMMIT=1 git commit -m "feat(config): the key table, the setup template and the loader"
```

______________________________________________________________________
