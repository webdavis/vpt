### Task 2: The output contract, result and error envelopes

## Controller execution constraints

- Read the plan's Global Constraints and the top of progress.md, not its large preflight appendix. The sample is implementation guidance; the spec, user rules and clean-code standards govern correctness.
- Preserve Task 1's parser regressions, unique sandbox, null stdin, controlled environment and bounded process-group runner. Do not paste sample replacements over those changes.
- Preserve the closed-peer stdout regression. Its exact diagnostic wording can change to the planned Store error, but failure must still return 1. Add JSON-mode coverage asserting one Store error document on stderr, empty stdout and exit 1 for the same failure.
- Preserve Task 1's review fix for stderr failure: every diagnostic write is fallible and an unwritable stderr returns 1, never a panic or the original usage/refusal code. This supersedes the sample emit branch that ignores stderr write failures. Cover both human and JSON failure output, including simultaneous broken stdout/stderr.
- Red runs must compile and fail assertions for the intended missing behavior. Use compiling stubs where the new protocol API does not exist yet, not unresolved-name compiler errors.
- Do not silently replace a serialization error with JSON null. These document fields are concrete strings, booleans and lists; construct their values directly or use an infallible conversion. Keep the implementation small.
- Human refusal output derives the rule token from ErrorDocument.rule and includes it before the bare message. JSON keeps its separate rule field and unprefixed message. Cover the normal bare-message input, not a caller that manually duplicates the rule inside message. See progress.md for the spec ruling.
- Parser help is specific to a parse failure. Do not append USAGE to every ErrorKind::Usage; ordinary command-level input errors retain the planned vpt: message line. Keep fallible writes shared and test this distinction.
- Run the complete current test set, fmt/Clippy and the exact staged-file size audit. Record all selected leaf tests and mutation controls in the task report. No source, index or history changes belonging to another task.
- Follow the existing worktree and scoped commit workflow. No subagents, push, pull request, merge, installation or real user destinations.

**Files:**

- Create: `crates/vpt-protocol/src/result.rs`, `crates/vpt-protocol/src/error.rs`
- Modify: `crates/vpt-protocol/src/lib.rs`
- Create: `crates/vpt/src/cli/output.rs`
- Modify: `crates/vpt/src/cli/mod.rs`, `crates/vpt/src/lib.rs`
- Test: `crates/vpt/tests/usage.rs` (gains one test)

**Interfaces:**

- Consumes: `cli::args::{parse, UsageError, USAGE}` (Task 1).

- Produces:
  `vpt_protocol::result::document(command: &str, body: serde_json::Value) -> serde_json::Value`;
  `vpt_protocol::error::ErrorKind::{Refused, Usage, Config, Engine, Helper, Command, Store, Ledger}` with
  `ErrorKind::exit_code(self) -> i32`; `Check { pub name: String, pub ok: bool, pub detail: String }`
  (serde `Serialize`);
  `ErrorDocument { pub kind: ErrorKind, pub rule: Option<String>, pub message: String,`
  `pub ids: Vec<String>, pub completed: Vec<String>, pub checks: Option<Vec<Check>>,`
  `pub diagnostics: Vec<String> }` with
  `ErrorDocument::new(kind: ErrorKind, message: impl Into<String>) -> ErrorDocument`, the builder methods
  `rule(self, rule: &str) -> Self`, `ids(self, ids: Vec<String>) -> Self`,
  `completed(self, completed: Vec<String>) -> Self`, `checks(self, checks: Vec<Check>) -> Self`,
  `diagnostics(self, diagnostics: Vec<String>) -> Self`, and `exit_code(&self) -> i32`,
  `to_json(&self) -> serde_json::Value`;
  `cli::output::Outcome::{Success { document: serde_json::Value, human: String },`
  `Failure(ErrorDocument)}` and `emit(outcome: Outcome, json: bool) -> i32`, which writes stdout or
  stderr and returns the exit code (a stdout that cannot be written is a `Store` failure, exit 1).

- [ ] **Step 1: Write the failing tests**

`crates/vpt-protocol/src/lib.rs` declares both modules before the red run, so the test modules are
compiled and selected:

```rust
//! The versioned JSON documents vpt reads and writes across a process boundary.

pub mod error;
pub mod result;
```

`crates/vpt-protocol/src/error.rs` starts as its test module alone (Step 3 adds the code above it):

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_refusal_carries_its_rule_and_exits_3() {
        let document = ErrorDocument::new(ErrorKind::Refused, "engines apple and whisply both report family whisper")
            .rule("same_family");

        let json = document.to_json();

        assert_eq!(json["schema"], "vpt.error/1");
        assert_eq!(json["error"]["kind"], "refused");
        assert_eq!(json["error"]["rule"], "same_family");
        assert_eq!(json["error"]["ids"], serde_json::json!([]));
        assert_eq!(json["error"]["completed"], serde_json::json!([]));
        assert!(json["error"].get("checks").is_none());
        assert_eq!(ErrorKind::Refused.exit_code(), 3);
    }

    #[test]
    fn every_kind_maps_to_the_spec_exit_code() {
        assert_eq!(ErrorKind::Usage.exit_code(), 2);
        assert_eq!(ErrorKind::Config.exit_code(), 2);
        for kind in [ErrorKind::Engine, ErrorKind::Helper, ErrorKind::Command, ErrorKind::Store, ErrorKind::Ledger] {
            assert_eq!(kind.exit_code(), 1);
        }
    }

    #[test]
    fn a_non_refusal_has_a_null_rule() {
        let json = ErrorDocument::new(ErrorKind::Ledger, "database locked").to_json();
        assert!(json["error"]["rule"].is_null());
    }

    #[test]
    fn checks_appear_only_when_given() {
        let json = ErrorDocument::new(ErrorKind::Refused, "2 checks failed")
            .rule("doctor_checks")
            .checks(vec![Check { name: "helper".into(), ok: false, detail: "absent".into() }])
            .to_json();
        assert_eq!(json["error"]["checks"][0]["name"], "helper");
        assert_eq!(json["error"]["checks"][0]["ok"], false);
    }

    #[test]
    fn diagnostics_are_retained_inside_the_one_error_document_when_present() {
        let plain = ErrorDocument::new(ErrorKind::Store, "read failed").to_json();
        assert!(plain["error"].get("diagnostics").is_none());
        let reported = ErrorDocument::new(ErrorKind::Store, "read failed")
            .diagnostics(vec!["desktop notifications disabled: helper absent".into()])
            .to_json();
        assert_eq!(reported["error"]["diagnostics"], serde_json::json!([
            "desktop notifications disabled: helper absent"
        ]));
        assert_eq!(reported["error"]["kind"], "store");
    }
}
```

`crates/vpt-protocol/src/result.rs`, likewise the test module alone:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_result_document_leads_with_schema_and_command() {
        let json = document("storage", serde_json::json!({"stores": {}}));
        let text = json.to_string();
        assert!(text.starts_with(r#"{"schema":"vpt.result/1","command":"storage","#), "{text}");
    }
}
```

Append to `crates/vpt/tests/usage.rs`. The existing human-output test of Task 1 remains a regression
test; this is the new red acceptance test:

```rust
#[test]
fn an_unknown_verb_under_json_is_an_error_document_on_stderr() {
    let sandbox = Sandbox::new("usage-json");

    let output = run(sandbox.vpt().args(["--json", "transcode"]));

    assert_eq!(output.status.code(), Some(2));
    assert_eq!(stdout(&output), "");
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json on stderr");
    assert_eq!(document["schema"], "vpt.error/1");
    assert_eq!(document["error"]["kind"], "usage");
    assert_eq!(document["error"]["message"], "unknown verb transcode");
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-protocol`

Expected: the build of the two test modules fails with `cannot find` for `ErrorDocument`, `ErrorKind`,
`Check` and `document`. The modules are compiled and selected; a run that selects zero tests, or that
succeeds, does not satisfy this step.

Run: `cargo test -p vpt --test usage`

Expected: `an_unknown_verb_under_json_is_an_error_document_on_stderr` FAILS: stderr holds usage text, not
JSON. The regression test of Task 1 still passes.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-protocol/src/error.rs` (above the test section):

```rust
//! `vpt.error/1`: the one document a failing command writes to stderr.

use serde::Serialize;
use serde_json::Value;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ErrorKind {
    Refused,
    Usage,
    Config,
    Engine,
    Helper,
    Command,
    Store,
    Ledger,
}

impl ErrorKind {
    pub fn exit_code(self) -> i32 {
        match self {
            ErrorKind::Refused => 3,
            ErrorKind::Usage | ErrorKind::Config => 2,
            ErrorKind::Engine | ErrorKind::Helper | ErrorKind::Command | ErrorKind::Store | ErrorKind::Ledger => 1,
        }
    }

    fn name(self) -> &'static str {
        match self {
            ErrorKind::Refused => "refused",
            ErrorKind::Usage => "usage",
            ErrorKind::Config => "config",
            ErrorKind::Engine => "engine",
            ErrorKind::Helper => "helper",
            ErrorKind::Command => "command",
            ErrorKind::Store => "store",
            ErrorKind::Ledger => "ledger",
        }
    }
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct Check {
    pub name: String,
    pub ok: bool,
    pub detail: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ErrorDocument {
    pub kind: ErrorKind,
    pub rule: Option<String>,
    pub message: String,
    pub ids: Vec<String>,
    pub completed: Vec<String>,
    pub checks: Option<Vec<Check>>,
    pub diagnostics: Vec<String>,
}

impl ErrorDocument {
    pub fn new(kind: ErrorKind, message: impl Into<String>) -> Self {
        ErrorDocument { kind, rule: None, message: message.into(), ids: vec![], completed: vec![], checks: None, diagnostics: vec![] }
    }

    pub fn rule(mut self, rule: &str) -> Self {
        self.rule = Some(rule.to_owned());
        self
    }

    pub fn ids(mut self, ids: Vec<String>) -> Self {
        self.ids = ids;
        self
    }

    pub fn completed(mut self, completed: Vec<String>) -> Self {
        self.completed = completed;
        self
    }

    pub fn checks(mut self, checks: Vec<Check>) -> Self {
        self.checks = Some(checks);
        self
    }

    pub fn diagnostics(mut self, diagnostics: Vec<String>) -> Self {
        self.diagnostics = diagnostics;
        self
    }

    pub fn exit_code(&self) -> i32 {
        self.kind.exit_code()
    }

    pub fn to_json(&self) -> Value {
        let mut error = serde_json::Map::new();
        error.insert("kind".into(), Value::String(self.kind.name().into()));
        error.insert("rule".into(), self.rule.clone().map_or(Value::Null, Value::String));
        error.insert("message".into(), Value::String(self.message.clone()));
        error.insert("ids".into(), serde_json::to_value(&self.ids).unwrap_or(Value::Null));
        error.insert("completed".into(), serde_json::to_value(&self.completed).unwrap_or(Value::Null));
        if let Some(checks) = &self.checks {
            error.insert("checks".into(), serde_json::to_value(checks).unwrap_or(Value::Null));
        }
        if !self.diagnostics.is_empty() {
            error.insert("diagnostics".into(), serde_json::to_value(&self.diagnostics).unwrap_or(Value::Null));
        }
        let mut document = serde_json::Map::new();
        document.insert("schema".into(), Value::String("vpt.error/1".into()));
        document.insert("error".into(), Value::Object(error));
        Value::Object(document)
    }
}
```

`crates/vpt-protocol/src/result.rs`:

```rust
//! `vpt.result/1`: the envelope of a result with no schema of its own.

use serde_json::{Map, Value};

pub fn document(command: &str, body: Value) -> Value {
    let mut ordered = Map::new();
    ordered.insert("schema".into(), Value::String("vpt.result/1".into()));
    ordered.insert("command".into(), Value::String(command.to_owned()));
    if let Value::Object(fields) = body {
        for (key, value) in fields {
            ordered.insert(key, value);
        }
    }
    Value::Object(ordered)
}
```

Because key order matters for the assertion, add `preserve_order` to the `serde_json` dependency of
`vpt-protocol`, `vpt-adapters` and `vpt`:

```toml
serde_json = { version = "1.0.151", features = ["preserve_order"] }
```

`crates/vpt/src/cli/output.rs`:

```rust
//! Output is withheld until the final status is known: one document on stdout
//! on success, one `vpt.error/1` on stderr on failure, and nothing else.

use std::io::Write;
use vpt_protocol::error::{ErrorDocument, ErrorKind};

pub enum Outcome {
    Success { document: serde_json::Value, human: String },
    Failure(ErrorDocument),
}

pub fn emit(outcome: Outcome, json: bool) -> i32 {
    match outcome {
        Outcome::Success { document, human } => {
            let text = if json { format!("{document}\n") } else { human };
            if std::io::stdout().write_all(text.as_bytes()).is_err() {
                return emit(Outcome::Failure(ErrorDocument::new(ErrorKind::Store, "standard output write failed")), json);
            }
            0
        }
        Outcome::Failure(error) => {
            let text = if json {
                format!("{}\n", error.to_json())
            } else {
                let mut text = format!("vpt: {}\n", error.message);
                for diagnostic in &error.diagnostics {
                    text.push_str(&format!("vpt: {diagnostic}\n"));
                }
                text
            };
            let _ = std::io::stderr().write_all(text.as_bytes());
            error.exit_code()
        }
    }
}
```

`crates/vpt/src/cli/mod.rs`:

```rust
pub(crate) mod args;
pub(crate) mod output;
```

`crates/vpt/src/lib.rs` (replace `run` and `dispatch`):

```rust
//! The command crate: parse, dispatch, emit, exit. No policy lives here.

mod cli;
mod commands;

use cli::args::{Invocation, USAGE, Verb, parse};
use cli::output::{Outcome, emit};
use std::io::Write;
use vpt_protocol::error::{ErrorDocument, ErrorKind};

pub fn run() -> ! {
    let args: Vec<std::ffi::OsString> = std::env::args_os().collect();
    let json = args.iter().any(|word| word == "--json");
    let code = match parse(args) {
        Ok(invocation) => dispatch(&invocation),
        Err(error) => {
            let code = emit(Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, error.0)), json);
            if !json {
                let _ = std::io::stderr().write_all(USAGE.as_bytes());
            }
            code
        }
    };
    std::process::exit(code);
}

fn dispatch(invocation: &Invocation) -> i32 {
    let outcome = match &invocation.verb {
        Verb::Version => Outcome::Success {
            document: commands::version::document(None),
            human: commands::version::human(None),
        },
        _ => Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, "verb not implemented yet")),
    };
    emit(outcome, invocation.json)
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-protocol -p vpt`

Expected: all tests in `error.rs`, `result.rs`, `args.rs`, `version.rs` and `usage.rs` PASS.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates Cargo.lock
SKIP_AI_COMMIT=1 git commit -m "feat: result and error envelopes with the exit code contract"
```

______________________________________________________________________
