# D2 independent review

Reviewer: `/root/vpt_review_d2_astra`, independent `gpt-6-astra` at `xhigh`.
Base: `1a00d858db6a744970599096318340af1ce7ccee`.
Head: `338dc9ca3806e69990c1b59056466e88ba6c4719`.

### Spec compliance

D2 meets its functional requirements. No lock-protocol or fixture-containment defect found. Code quality needs a decision on the plan-mandated duplication below.

### Strengths and checks

- `database/locks.rs:45` validates ranges, initializes `flock`, uses nonblocking descriptor-owned operations, retries interrupted calls, maps contention to busy, and propagates other errors.
- `database/locks.rs:107` implements temporary pending acquisition, retained pending after failed promotion, downgrade ordering, and description-local unlock. Reserved queries include the current owner.
- `database/tests/children.rs:22` clears the child environment, supplies owned paths and working directory, selects one exact test entry point, and bounds pipe operations and collection. Output buffers have explicit limits.
- `database/tests/children/scenarios.rs:69` closes the native fixture connection before contention. Native and rooted participants remain in separate processes; missing `unix-posix` fails explicitly.
- The 11 staging expectations match the controller's exact allowance and have D3 removal consumers in `task-D2-report.md:158`. No blanket suppression or production visibility expansion was added.
- Evidence confirms 19 compiling RED failures, 11 caught compiled mutations, passing restored controls, and all 225 baseline names retained with 20 additions. The FIFO mutation failed all four supervised cases in 0.51 seconds. The failed restoration stopped at its hash guard before executing a control; corrected restoration passed.
- `task-D2-controller-ship.log:220` records the longest complete target at 0.82 seconds. Only the two disclosed inherited size warnings remain.
- Outside-diff check, platform/native compatibility risk: inspected local SDK `fcntl(2)`, pinned `libc::flock` and constants, and pinned SQLite lock/unlock implementations. Their ownership, nonblocking and byte-range contracts support this implementation.
- Outside-diff check, supervision consistency risk: inspected the existing command-test support files once. The new harness preserves their ownership pattern, exposing the duplication finding below.
- Read the complete changed-source package once. No cut-off function required another source read. No suites rerun or files changed.

### Critical

None.

### Important

**Plan-mandated duplication:** `crates/vpt-adapters/src/database/tests/children/process.rs:15` duplicates the cleanup logic in `crates/vpt/tests/support/process.rs:15`: graceful termination, deadline polling, forced group termination, and reaping.

This creates two owners of the same process-lifecycle policy. A future correction must reach both. No functional or safety failure from that duplication was demonstrated.

The required task-reviewer-prompt.md rubric explicitly classifies "verbatim duplication of a logic block" as Important even when plan-mandated. D2 also requires crate-local fixtures, forbids cross-crate includes, and authorizes no shared support dependency. I found no compliant consolidation within this task. Consolidation requires a plan/scope change; accepting this deliberate duplication requires an explicit adjudication of the conflicting constraints.

### Minor

`crates/vpt-adapters/src/database/tests/children.rs:72`: timeout returns a bare `TimedOut`, discarding captured stdout/stderr when the guard drops. Retaining bounded captured output in that error would make intermittent failures easier to diagnose without reruns. This does not weaken the watchdog.

### Assessment

Task quality: **Needs fixes under the required review rubric**, solely for the plan-mandated duplication decision. The reviewed lock behavior and containment tests are suitable for D2; later callback, fault-injection and shared-memory work remains outside this verdict.

## Controller disposition

The controller verified the duplicate against the existing command fixture. Follow-up `6hc89rxCFRpJ8Fjg` awaits the operator's choice: retain the small deliberate crate-local duplication, recommended within the approved scope, or authorize shared test-support consolidation. No exception has been silently granted and no source refactor started. D2 remains unaccepted; D3 is not dispatched. The Minor timeout-output diagnostic belongs with existing timing follow-up `6hc7MMRc2QhRm75g`.

## Operator decision, 2026-09-23

The operator approved keeping the duplicate. D2 is accepted at unchanged commit `338dc9ca3806e69990c1b59056466e88ba6c4719`, with this explicit exception to the review rubric. The original finding remains above. No functional lock or containment defect was found. Future process-cleanup changes must reach both crate-local fixtures. The Minor timeout-output finding remains open under `6hc7MMRc2QhRm75g`.
