### Task 27: `vpt ingest` at the command line: composition, the lock, repair before work

**Files:**

- Create: `crates/vpt-adapters/src/clock.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`
- Modify: `crates/vpt/src/compose.rs`, `crates/vpt/Cargo.toml`
- Create: `crates/vpt/src/compose/clock.rs`, `crates/vpt/src/compose/errors.rs`,
  `crates/vpt/src/compose/ledger.rs`, `crates/vpt/src/compose/runtime.rs`,
  `crates/vpt/src/compose/tests.rs`
- Create: `crates/vpt/src/commands/ingest.rs`, `crates/vpt/src/documents/mod.rs`,
  `crates/vpt/src/documents/record.rs`
- Modify: `crates/vpt/src/lib.rs`, `crates/vpt/src/commands/mod.rs`
- Test: `crates/vpt/tests/ingest.rs`; `crates/vpt/tests/support/mod.rs` gains `write_config` and
  `add_recording`

**Interfaces:**

- Consumes adapter capabilities:
  `resolve(settings: &Settings, config_dir: &Path) -> Result<Roots, RootError>`;
  `Roots::{create_state_dir(&self) -> Result<(), RootError>, create_leaves(&self) -> Result<(), RootError>}`;
  `RootDir::open(path: &Path) -> Result<RootDir, ContainedError>`;
  `WriteLock::acquire(state: &RootDir, wait: Duration) -> Result<WriteLock, LockError>`;
  `SqliteLedger::{open(state: &RootDir) -> Result<SqliteLedger, OpenError>, open_read_only(state: &Path) -> Result<Option<SqliteLedger>, OpenError>}`;
  `VoiceMemosStore::{open(path: &Path) -> Result<VoiceMemosStore, ContainedError>, with_titles_root(self, state: &RootDir, refresh: bool) -> VoiceMemosStore}`;
  `ClonefileArchive::open_read_only(path: &Path) -> Result<ClonefileArchive, ContainedError>`;
  `FilesystemStores::open_read_only(paths: &[PathBuf]) -> Result<FilesystemStores, ContainedError>`;
  `HelperClient::{new(path: PathBuf) -> HelperClient, take_diagnostics(&self) -> Vec<String>}`.

- Consumes `ConfigError::PathEscape(String)` and `LedgerError::PathEscape(PathBuf)`; produces
  `compose::errors::{config_error(error: &ConfigError, path: &Path) -> ErrorDocument, ledger_error(error: LedgerError) -> ErrorDocument}`
  with exit 3 `path_escape` preserved.

- Consumes application capabilities:
  `repair_publications<J: PublicationJournal, S: Stores>(journal: &J, stores: &S, render: impl Fn(&Path) -> Option<Vec<u8>>) -> Result<RepairReport, RepairError>`;
  `Ingest::run(&self, mode: &Mode) -> Result<IngestReport, Box<IngestError>>`;
  `Mode { pub dry_run: bool, pub once: Option<PathBuf> }`;
  `Notifier::{deliver(&self, notification: &Notification) -> DeliveryOutcome, take_diagnostics(&self) -> Vec<String>}`.

- Produces crate-private composition: `AccessMode::{ReadOnly, Mutating}`;
  `Operation::{Ingest, Retention}`;
  `Runtime::load(environment: &Environment, config: Option<&Path>, access: AccessMode, operation: Operation) -> Result<Runtime, Box<ErrorDocument>>`;
  `Runtime::mutating(&self) -> Result<RepairReport, Box<ErrorDocument>>`;
  `Runtime::trash(&self) -> &dyn Trash`; `Runtime::diagnostics(&self) -> Vec<String>`;
  `WRITE_LOCK_WAIT: Duration = Duration::from_secs(5)`. Runtime fields:
  `settings: Settings, roots: Roots, ledger: RuntimeLedger, recorder: Option<VoiceMemosStore>, archive: ClonefileArchive, stores: FilesystemStores, clock: RuntimeClock, helper: HelperClient, notifier: Box<dyn Notifier>`,
  all `pub(crate)`; `_lock: Option<WriteLock>` is private and retained for the runtime lifetime. Only
  `Operation::Ingest` opens the recorder. Writable composition passes one opened state `RootDir` to the
  lock, ledger, and title builder; neither ledger nor title setup reopens its path.
  `RuntimeLedger::{Sqlite(SqliteLedger), Empty(MemoryLedger)}` implements `RecordingLedger` and
  `PublicationJournal`;
  `RuntimeLedger::read_only(path: &Path) -> Result<RuntimeLedger, Box<ErrorDocument>>`.
  `RuntimeClock::from_environment(environment: &Environment) -> Result<RuntimeClock, Box<ErrorDocument>>`
  implements `Clock`; only `dev-tools` reads `VPT_TEST_NOW_SECS`.

- Produces adapter root export `SystemClock`, implementing
  `Clock::{now(&self) -> UtcInstant, offset_at(&self, at: UtcInstant) -> UtcOffset}`.

- Produces command-private `documents::record_json(record: &RecordingRecord) -> serde_json::Value`;
  `commands::ingest::run(runtime: &Runtime, dry_run: bool, once: Option<PathBuf>) -> Outcome`.

- Test support adds `FIXED_NOW_SECS: i64 = 1_787_690_916`,
  `Sandbox::{write_config(&self, extra: &str), add_recording(&self, name: &str, bytes: &[u8]) -> PathBuf, ledger(&self) -> rusqlite::Connection}`.
  Every `Sandbox::vpt()` sets `VPT_TEST_NOW_SECS` to that constant, and recording mtime is
  `FIXED_NOW_SECS - 60`. Task 32's `set_mtime` subtracts its age from the same constant.

- [ ] **Step 1: Write the failing tests**

Add `tempfile = "3.27.0"` under the existing `[dev-dependencies]` in `crates/vpt/Cargo.toml`. Add
`pub(crate) mod ingest;` to `commands/mod.rs` and create `commands/ingest.rs` empty. Integration files
under `tests/` are auto-discovered by Cargo. The compose unit registration and test source below are part
of this step, before either red command.

`crates/vpt/tests/ingest.rs`:

```rust
mod support;

use support::{Sandbox, run, stderr, stdout};
use vpt_domain::fixtures::m4a;

const CAPTURED: i64 = 1_787_690_856;

#[test]
fn ingest_archives_a_recording_and_prints_the_result_document() {
    let sandbox = Sandbox::new("ingest-json");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    sandbox.add_recording("a.m4a", &m4a(CAPTURED, 12, b"audio"));

    let output = run(sandbox.vpt().args(["ingest", "--json"]));

    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["schema"], "vpt.result/1");
    assert_eq!(document["command"], "ingest");
    assert_eq!(document["ingested"].as_array().map(Vec::len), Some(1));
    assert_eq!(document["ingested"][0]["duration_secs"], 12);
    assert_eq!(document["deferred"], serde_json::json!([]));
    assert_eq!(document["skipped"], 0);
    let id = document["ingested"][0]["id"].as_str().expect("id");
    assert!(sandbox.path().join(format!("home/.vpt/audio/{id}.m4a")).exists());
    assert!(sandbox.path().join("state/vpt/write.lock").exists());
}

#[test]
fn a_second_ingest_skips_and_the_human_output_says_so() {
    let sandbox = Sandbox::new("ingest-again");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    sandbox.add_recording("a.m4a", &m4a(CAPTURED, 1, b"audio"));
    run(sandbox.vpt().arg("ingest"));

    let output = run(sandbox.vpt().arg("ingest"));

    assert_eq!(output.status.code(), Some(0));
    assert!(stdout(&output).contains("skipped 1"), "{}", stdout(&output));
}

#[test]
fn a_missing_config_is_a_config_error_that_names_setup() {
    let sandbox = Sandbox::new("ingest-no-config");

    let output = run(sandbox.vpt().args(["ingest", "--json"]));

    assert_eq!(output.status.code(), Some(2));
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    assert_eq!(document["error"]["kind"], "config");
    assert!(document["error"]["message"].as_str().expect("message").contains("vpt setup"));
}

#[test]
fn a_missing_audio_store_parent_is_refused_at_startup_with_the_key_named() {
    let sandbox = Sandbox::new("ingest-bad-store");
    sandbox.install_fake_helper();
    sandbox.write_config(&format!("[stores]\naudio = \"{}\"\n", sandbox.path().join("nowhere/audio").display()));

    let output = run(sandbox.vpt().args(["ingest", "--json"]));

    assert_eq!(output.status.code(), Some(2));
    assert!(stderr(&output).contains("stores.audio"), "{}", stderr(&output));
}

#[test]
fn a_completed_publication_left_dirty_is_repaired_before_the_sweep() {
    let sandbox = Sandbox::new("ingest-repair-done");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    run(sandbox.vpt().arg("ingest"));
    let target = sandbox.path().join("home/.vpt/transcripts/a.md");
    std::fs::write(&target, b"published").expect("target");
    let mut file = std::fs::File::open(&target).expect("target open");
    let digest = vpt_adapters::digest_open(&mut file).expect("digest").hex();
    sandbox
        .ledger()
        .execute(
            "INSERT INTO dirty_publications (target, expected_previous, intended, recorded_at) VALUES (?1, NULL, ?2, 1)",
            [target.to_string_lossy().as_ref(), digest.as_str()],
        )
        .expect("seed");

    let output = run(sandbox.vpt().arg("ingest"));

    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let pending: i64 = sandbox.ledger().query_row("SELECT COUNT(*) FROM dirty_publications", [], |r| r.get(0)).expect("count");
    assert_eq!(pending, 0);
}

#[test]
fn a_modified_target_refuses_every_mutating_command_with_target_modified() {
    let sandbox = Sandbox::new("ingest-repair-modified");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    run(sandbox.vpt().arg("ingest"));
    let target = sandbox.path().join("home/.vpt/transcripts/a.md");
    std::fs::write(&target, b"someone else's prose").expect("target");
    sandbox
        .ledger()
        .execute(
            "INSERT INTO dirty_publications (target, expected_previous, intended, recorded_at) VALUES (?1, ?2, ?3, 1)",
            [target.to_string_lossy().as_ref(), &"ab".repeat(32), &"cd".repeat(32)],
        )
        .expect("seed");
    sandbox.add_recording("a.m4a", &m4a(CAPTURED, 1, b"audio"));

    let output = run(sandbox.vpt().args(["ingest", "--json"]));

    assert_eq!(output.status.code(), Some(3));
    let document: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("json");
    assert_eq!(document["error"]["rule"], "target_modified");
    assert!(std::fs::read_dir(sandbox.path().join("home/.vpt/audio")).expect("audio").next().is_none(), "nothing was ingested");
}

#[test]
fn dry_run_creates_no_state_directory_and_no_title_copy() {
    let sandbox = Sandbox::new("ingest-dry");
    sandbox.install_fake_helper();
    sandbox.write_config("");
    sandbox.add_recording("a.m4a", &m4a(CAPTURED, 1, b"audio"));

    let output = run(sandbox.vpt().args(["ingest", "--dry-run", "--json"]));

    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    assert_eq!(document["would_ingest"].as_array().map(Vec::len), Some(1));
    assert!(!sandbox.path().join("state/vpt").exists());
    assert!(!sandbox.path().join("state/vpt/title-copy").exists());
    assert!(std::fs::read_dir(sandbox.path().join("home/.vpt/audio")).map(|mut d| d.next().is_none()).unwrap_or(true));
}

#[test]
fn dry_run_once_only_proposes_the_selected_file() {
    let sandbox = Sandbox::new("ingest-dry-once");
    sandbox.write_config("");
    let selected = sandbox.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    sandbox.add_recording("b.m4a", &m4a(CAPTURED, 1, b"b"));
    let output = run(sandbox.vpt().args(["ingest", "--dry-run", "--once"])
        .arg(&selected).arg("--json"));
    assert_eq!(output.status.code(), Some(0), "{}", stderr(&output));
    let document: serde_json::Value = serde_json::from_str(&stdout(&output)).expect("json");
    let proposed = document["would_ingest"].as_array().expect("proposals");
    assert_eq!(proposed.len(), 1);
    assert_eq!(proposed[0]["path"], selected.to_string_lossy().as_ref());
    assert!(!sandbox.path().join("state/vpt").exists());
}

#[test]
fn dry_run_root_and_source_failures_never_send_a_notification() {
    for bad_root in [false, true] {
        let sandbox = Sandbox::new(if bad_root { "dry-invalid-root" } else { "dry-unreadable-source" });
        sandbox.install_fake_helper();
        let extra = format!("[stores]\naudio = {:?}\n", sandbox.path().join("missing/audio"));
        sandbox.write_config(if bad_root { &extra } else { "" });
        let config = std::fs::read_to_string(sandbox.config_path()).expect("config").replace(
            "mode = \"off\"", "mode = \"desktop\"",
        );
        std::fs::write(sandbox.config_path(), config).expect("desktop");
        use std::os::unix::fs::PermissionsExt;
        let source = sandbox.path().join("voice-memos/Recordings");
        if !bad_root {
            std::fs::set_permissions(&source, std::fs::Permissions::from_mode(0o000)).expect("unreadable");
        }
        let output = run(sandbox.vpt().args(["ingest", "--dry-run", "--json"])
            .env("VPT_FAKE_LOG", sandbox.fake_log()));
        if !bad_root {
            std::fs::set_permissions(&source, std::fs::Permissions::from_mode(0o700)).expect("restore fixture");
        }
        assert!(!output.status.success());
        assert!(!sandbox.fake_log().exists());
        assert!(!sandbox.path().join("state/vpt").exists());
    }
}

#[test]
fn unreadable_source_startup_reports_one_ingest_failure_and_dry_run_reports_none() {
    use std::os::unix::fs::PermissionsExt;
    for (ancestor, dry_run) in [(false, false), (true, false), (false, true), (true, true)] {
        let sandbox = Sandbox::new("source-startup-failure");
        sandbox.install_fake_helper();
        sandbox.write_config("");
        let helper = sandbox.path().join("bin/vpt-macos");
        let config = std::fs::read_to_string(sandbox.config_path()).expect("config").replace(
            "mode = \"off\"",
            &format!("mode = \"command\"\ncommand = [{helper:?}, \"command-sink\", \"{{event}}\"]"),
        );
        std::fs::write(sandbox.config_path(), config).expect("command notifier");
        let denied = sandbox.path().join(if ancestor { "voice-memos" } else { "voice-memos/Recordings" });
        std::fs::set_permissions(&denied, std::fs::Permissions::from_mode(0o000)).expect("deny source");
        let mut command = sandbox.vpt();
        command.args(["ingest", "--json"]);
        if dry_run { command.arg("--dry-run"); }
        let output = run(&mut command);
        std::fs::set_permissions(&denied, std::fs::Permissions::from_mode(0o700)).expect("restore fixture");
        assert_eq!(output.status.code(), Some(1), "{}", stderr(&output));
        assert!(stdout(&output).is_empty());
        let error: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("one error");
        assert_eq!(error["error"]["kind"], "store");
        let log = std::fs::read_to_string(sandbox.fake_log()).unwrap_or_default();
        if dry_run {
            assert!(log.is_empty(), "{log}");
        } else {
            let lines: Vec<_> = log.lines().collect();
            assert_eq!(lines.len(), 1, "{log}");
            assert!(lines[0].starts_with("command-sink\tingest_failed\t"), "{log}");
        }
        assert!(!sandbox.path().join("state/vpt").exists());
    }
}

#[test]
fn a_configuration_leaf_link_is_a_path_escape_at_the_command_boundary() {
    let sandbox = Sandbox::new("config-leaf-link");
    sandbox.write_config("");
    let selected = sandbox.config_path();
    let held = selected.with_file_name("held.toml");
    std::fs::rename(&selected, &held).expect("hold config");
    let before = std::fs::read(&held).expect("bytes");
    std::os::unix::fs::symlink(&held, &selected).expect("config link");
    let output = run(sandbox.vpt().args(["ingest", "--json"]));
    assert_eq!(output.status.code(), Some(3), "{}", stderr(&output));
    let error: serde_json::Value = serde_json::from_str(&stderr(&output)).expect("error");
    assert_eq!(error["error"]["rule"], "path_escape");
    assert_eq!(std::fs::read(held).expect("unchanged"), before);
    assert!(!sandbox.path().join("state/vpt").exists());
}

```

Support additions in `crates/vpt/tests/support/mod.rs`:

```rust
pub const FIXED_NOW_SECS: i64 = 1_787_690_916;

impl Sandbox {
    pub fn write_config(&self, extra: &str) {
        let config = format!(
            "config_version = 1\n[home]\npath = \"{home}\"\nstate_dir = \"{state}\"\n[helper]\npath = \"{helper}\"\n\
             [source]\nrecordings_dir = \"{recordings}\"\n[notify]\nmode = \"off\"\n{extra}",
            home = self.root.join("home/.vpt").display(),
            state = self.root.join("state/vpt").display(),
            helper = self.root.join("bin/vpt-macos").display(),
            recordings = self.root.join("voice-memos/Recordings").display(),
        );
        std::fs::create_dir_all(self.config_path().parent().expect("dir")).expect("config dir");
        std::fs::write(self.config_path(), config).expect("config");
        std::fs::create_dir_all(self.root.join("home/.vpt")).expect("home");
    }

    pub fn add_recording(&self, name: &str, bytes: &[u8]) -> PathBuf {
        let path = self.root.join("voice-memos/Recordings").join(name);
        std::fs::write(&path, bytes).expect("recording");
        let file = std::fs::File::options().write(true).open(&path).expect("open");
        let instant = std::time::UNIX_EPOCH + std::time::Duration::from_secs(u64::try_from(FIXED_NOW_SECS - 60).expect("fixture epoch"));
        file.set_times(std::fs::FileTimes::new().set_modified(instant)).expect("mtime");
        path
    }

    pub fn ledger(&self) -> rusqlite::Connection {
        let connection = rusqlite::Connection::open(self.root.join("state/vpt/vpt.db")).expect("ledger");
        let mut enabled: std::ffi::c_int = 1;
        // SAFETY: the connection and integer outlive this synchronous call.
        let result = unsafe {
            rusqlite::ffi::sqlite3_file_control(
                connection.handle(), c"main".as_ptr(), rusqlite::ffi::SQLITE_FCNTL_PERSIST_WAL,
                (&mut enabled as *mut std::ffi::c_int).cast(),
            )
        };
        assert_eq!(result, rusqlite::ffi::SQLITE_OK, "preserve fixture sidecars");
        connection
    }
}
```

Add this environment entry to the existing `Sandbox::vpt()` chain in Step 1:

```rust
            .env("VPT_TEST_NOW_SECS", FIXED_NOW_SECS.to_string())
```

Register `mod clock;` with its `SystemClock` re-export in the adapter root before the red run. Create
`compose/clock.rs`, `compose/errors.rs`, `compose/ledger.rs` and `compose/runtime.rs` empty, add their
private `mod` declarations in `compose.rs`, and add `#[cfg(test)] mod tests;` at the end of `compose.rs`.
The source modules start with the tests and imports below; their missing production symbols make this a
compiled red.

`crates/vpt/src/compose/tests.rs`:

```rust
use super::*;
use std::os::unix::fs::PermissionsExt;
use vpt_adapters::{LockError, RootDir};
use vpt_application::ports::Clock;

fn configured() -> (tempfile::TempDir, Environment) {
    let temp = tempfile::tempdir().expect("temp");
    let root = temp.path().canonicalize().expect("canonical");
    for directory in ["config", "state", "voice-memos/Recordings", "home"] {
        std::fs::create_dir_all(root.join(directory)).expect("directory");
    }
    let config = root.join("config/config.toml");
    std::fs::write(&config, format!(
        "config_version = 1\n[home]\npath = {:?}\nstate_dir = {:?}\n[source]\nrecordings_dir = {:?}\n[notify]\nmode = \"off\"\n",
        root.join("home/vpt"), root.join("state/vpt"), root.join("voice-memos/Recordings"),
    )).expect("config");
    let environment = Environment { vars: vec![
        ("HOME".into(), root.join("home").display().to_string()),
        ("VPT_CONFIG".into(), config.display().to_string()),
        ("VPT_TEST_NOW_SECS".into(), "1787690916".into()),
    ] };
    (temp, environment)
}

#[test]
fn read_only_composition_creates_no_state_or_store_leaf() {
    let (_temp, environment) = configured();
    let runtime = Runtime::load(&environment, None, AccessMode::ReadOnly, Operation::Ingest).expect("read only");
    assert!(!runtime.roots.state_dir.exists());
    assert!(!runtime.roots.home.exists());
    assert!(runtime._lock.is_none());
}

#[test]
fn lock_contention_precedes_database_open_mode_changes_and_store_creation() {
    let (_temp, environment) = configured();
    let settings = settings_from(&environment, None).expect("settings");
    std::fs::create_dir(&settings.state_dir).expect("state");
    let state = RootDir::open(&settings.state_dir).expect("state root");
    let _held = WriteLock::acquire(&state, Duration::ZERO).expect("held");
    let database = settings.state_dir.join("vpt.db");
    std::fs::write(&database, b"not yet opened").expect("database");
    std::fs::set_permissions(&database, std::fs::Permissions::from_mode(0o644)).expect("mode");
    let outcome = Runtime::load_with_wait(&environment, None, AccessMode::Mutating, Operation::Ingest, Duration::ZERO);
    assert_eq!(outcome.err().expect("locked").exit_code(), 1);
    assert_eq!(std::fs::read(&database).expect("same bytes"), b"not yet opened");
    assert_eq!(std::fs::metadata(&database).expect("metadata").permissions().mode() & 0o777, 0o644);
    assert!(!settings.home.exists());
}

#[test]
fn mutating_composition_retains_the_lock_until_runtime_is_dropped() {
    let (_temp, environment) = configured();
    let runtime = Runtime::load(&environment, None, AccessMode::Mutating, Operation::Ingest).expect("mutable");
    let state = RootDir::open(&runtime.roots.state_dir).expect("state");
    assert!(matches!(WriteLock::acquire(&state, Duration::ZERO), Err(LockError::Busy)));
    drop(runtime);
    assert!(WriteLock::acquire(&state, Duration::ZERO).is_ok());
}

#[cfg(feature = "dev-tools")]
#[test]
fn dev_tools_clock_is_fixed_and_utc() {
    let (_temp, environment) = configured();
    let clock = RuntimeClock::from_environment(&environment).expect("clock");
    assert_eq!(clock.now().secs, 1_787_690_916);
    assert_eq!(clock.offset_at(clock.now()).secs, 0);
}

#[cfg(not(feature = "dev-tools"))]
#[test]
fn production_clock_does_not_read_the_test_environment_value() {
    let environment = Environment { vars: vec![("VPT_TEST_NOW_SECS".into(), "invalid".into())] };
    assert!(RuntimeClock::from_environment(&environment).is_ok());
}

#[test]
fn configuration_and_ledger_path_escapes_keep_the_refusal_rule() {
    use vpt_adapters::config::ConfigError;
    use vpt_application::ports::LedgerError;
    for error in [
        errors::config_error(&ConfigError::PathEscape("/config/config.toml".into()), Path::new("/config/config.toml")),
        errors::ledger_error(LedgerError::PathEscape(PathBuf::from("/state/vpt.db"))),
    ] {
        assert_eq!(error.exit_code(), 3);
        assert_eq!(error.rule.as_deref(), Some("path_escape"));
    }
}

#[test]
fn retention_composition_does_not_open_the_recording_source() {
    let (_temp, environment) = configured();
    let settings = settings_from(&environment, None).expect("settings");
    std::fs::rename(&settings.source.recordings_dir, settings.source.recordings_dir.with_file_name("held")).expect("hide source");
    let runtime = Runtime::load(&environment, None, AccessMode::ReadOnly, Operation::Retention).expect("retention");
    assert!(runtime.recorder.is_none());
    assert!(!runtime.roots.state_dir.exists());
}

#[test]
fn locked_runtime_refuses_replacement_state_for_ledger_and_title_refresh() {
    use vpt_application::ports::{LedgerError, RecorderError, RecorderStore, RecordingLedger};
    let (_temp, environment) = configured();
    let runtime = Runtime::load(&environment, None, AccessMode::Mutating, Operation::Ingest).expect("runtime");
    let state = &runtime.roots.state_dir;
    let held = state.with_file_name("held-state");
    std::fs::rename(state, &held).expect("hold original state");
    std::fs::create_dir(state).expect("replacement state");
    assert!(matches!(runtime.ledger.recordings(), Err(LedgerError::PathEscape(path)) if path == *state));
    let recorder = runtime.recorder.as_ref().expect("source");
    assert!(matches!(recorder.refresh_titles(), Err(RecorderError::Escape(path)) if path == *state));
    assert!(std::fs::read_dir(state).expect("replacement").next().is_none());
    let original = RootDir::open(&held).expect("original state");
    assert!(matches!(WriteLock::acquire(&original, Duration::ZERO), Err(LockError::Busy)));
}

```

- [ ] **Step 2: Run the tests to verify they fail**

Run separately: `cargo test -p vpt --features dev-tools --lib compose` and
`cargo test -p vpt --features dev-tools --test ingest`.

Expected: the compiled compose tests fail on missing implementation, and ingest fails with exit 2 and
"verb not implemented yet". Zero selected tests or a successful command does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-adapters/src/clock.rs`:

```rust
//! The system clock, and the local offset at an instant through `localtime_r`.

use vpt_application::ports::Clock;
use vpt_domain::time::{UtcInstant, UtcOffset};

pub struct SystemClock;

impl Clock for SystemClock {
    fn now(&self) -> UtcInstant {
        let secs = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(0);
        UtcInstant { secs }
    }

    fn offset_at(&self, at: UtcInstant) -> UtcOffset {
        let time: libc::time_t = at.secs as libc::time_t;
        let mut civil: libc::tm = unsafe { std::mem::zeroed() };
        // SAFETY: `time` and `civil` are valid for the call; localtime_r writes only into `civil`.
        let filled = unsafe { libc::localtime_r(&time, &mut civil) };
        if filled.is_null() {
            return UtcOffset { secs: 0 };
        }
        UtcOffset { secs: civil.tm_gmtoff as i32 }
    }
}
```

`crates/vpt/src/compose.rs` (full replacement):

```rust
mod clock;
pub(crate) mod errors;
mod ledger;
mod runtime;

pub(crate) use clock::RuntimeClock;
use errors::config_error;
pub(crate) use ledger::RuntimeLedger;

use std::path::{Path, PathBuf};
use std::time::Duration;
use vpt_adapters::{
    ClonefileArchive, CommandNotifier, DesktopNotifier, FilesystemStores, HelperClient,
    OffNotifier, Roots, VoiceMemosStore, WriteLock,
};
use vpt_adapters::config::{config_path, default_state_dir, from_table, load_file};
use vpt_application::ports::Notifier;
use vpt_application::{NotifyMode, Settings};
use vpt_protocol::error::ErrorDocument;

pub(crate) const WRITE_LOCK_WAIT: Duration = Duration::from_secs(5);

pub(crate) struct Environment {
    vars: Vec<(String, String)>,
}

impl Environment {
    pub(crate) fn from_process() -> Self {
        Self { vars: std::env::vars().collect() }
    }

    pub(crate) fn var(&self, name: &str) -> Option<String> {
        self.vars.iter().find(|(key, _)| key == name).map(|(_, value)| value.clone())
    }

    pub(crate) fn config_path(&self) -> PathBuf {
        config_path(|name| self.var(name))
    }

    pub(crate) fn selected_config(&self, config: Option<&Path>) -> PathBuf {
        config.map(Path::to_path_buf).unwrap_or_else(|| self.config_path())
    }

    pub(crate) fn home_dir(&self) -> PathBuf {
        PathBuf::from(self.var("HOME").unwrap_or_default())
    }

    pub(crate) fn state_dir_default(&self) -> String {
        default_state_dir(|name| self.var(name))
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum AccessMode {
    ReadOnly,
    Mutating,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Operation {
    Ingest,
    Retention,
}

pub(crate) struct Runtime {
    pub(crate) settings: Settings,
    pub(crate) roots: Roots,
    pub(crate) ledger: RuntimeLedger,
    pub(crate) recorder: Option<VoiceMemosStore>,
    pub(crate) archive: ClonefileArchive,
    pub(crate) stores: FilesystemStores,
    pub(crate) clock: RuntimeClock,
    pub(crate) helper: HelperClient,
    pub(crate) notifier: Box<dyn Notifier>,
    _lock: Option<WriteLock>,
}

pub(crate) fn settings_from(environment: &Environment, config: Option<&Path>) -> Result<Settings, Box<ErrorDocument>> {
    let path = environment.selected_config(config);
    let table = load_file(&path).map_err(|error| config_error(&error, &path))?;
    from_table(&table, &environment.home_dir()).map_err(|error| Box::new(config_error(&error, &path)))
}

pub(crate) fn notifier_for(settings: &Settings) -> Box<dyn Notifier> {
    let desktop = DesktopNotifier::new(HelperClient::new(settings.helper_path.clone()));
    match &settings.notify.mode {
        NotifyMode::Desktop => Box::new(desktop),
        NotifyMode::Command(argv) => Box::new(CommandNotifier::new(argv.clone(), desktop)),
        NotifyMode::Off => Box::new(OffNotifier),
    }
}


#[cfg(test)]
mod tests;

```

`crates/vpt/src/compose/runtime.rs`:

```rust
use super::{AccessMode, Environment, Operation, Runtime, RuntimeClock, RuntimeLedger, WRITE_LOCK_WAIT, notifier_for, settings_from};
use super::errors::{contained_error, open_error, repair_error, root_error};
use std::path::Path;
use std::time::Duration;
use vpt_adapters::{ClonefileArchive, FilesystemStores, HelperClient, LockError, RootDir, RootError, SqliteLedger, VoiceMemosStore, WriteLock};
use vpt_adapters::config::resolve;
use vpt_application::ports::{Clock, Trash};
use vpt_application::{RepairReport, repair_publications};
use vpt_domain::notification::{EventKind, Notification};
use vpt_protocol::error::{ErrorDocument, ErrorKind};

impl Runtime {
    pub(crate) fn load(environment: &Environment, config: Option<&Path>, access: AccessMode, operation: Operation) -> Result<Self, Box<ErrorDocument>> {
        Self::load_with_wait(environment, config, access, operation, WRITE_LOCK_WAIT)
    }

    pub(super) fn load_with_wait(environment: &Environment, config: Option<&Path>, access: AccessMode, operation: Operation, wait: Duration) -> Result<Self, Box<ErrorDocument>> {
        let settings = settings_from(environment, config)?;
        let notifier = notifier_for(&settings);
        let clock = RuntimeClock::from_environment(environment)?;
        let config_path = environment.selected_config(config);
        let config_dir = config_path.parent().filter(|path| !path.as_os_str().is_empty()).unwrap_or(Path::new("."));
        let roots = resolve(&settings, config_dir).map_err(|error| {
            let source_io = matches!(&error, RootError::Io { key, .. } if key == "source.recordings_dir");
            let ingest_failure = operation == Operation::Ingest && source_io;
            let mut document = if ingest_failure {
                ErrorDocument::new(ErrorKind::Store, format!("{error:?}"))
            } else {
                root_error(&error)
            };
            if access == AccessMode::Mutating {
                let _ = notifier.deliver(&Notification::failed(
                    if ingest_failure { EventKind::IngestFailed } else { EventKind::ConfigRefused },
                    document.message.clone(), clock.now(),
                ));
                document = document.diagnostics(notifier.take_diagnostics());
            }
            document
        })?;
        let mut recorder = if operation == Operation::Retention {
            None
        } else {
            Some(VoiceMemosStore::open(&roots.recordings_dir).map_err(contained_error).map_err(|mut document| {
                if access == AccessMode::Mutating {
                    let _ = notifier.deliver(&Notification::failed(
                        EventKind::IngestFailed, document.message.clone(), clock.now(),
                    ));
                    document = document.diagnostics(notifier.take_diagnostics());
                }
                document
            })?)
        };
        let (lock, ledger, state) = if access == AccessMode::Mutating {
            roots.create_state_dir().map_err(|error| root_error(&error))?;
            let state = RootDir::open(&roots.state_dir).map_err(contained_error)?;
            let lock = WriteLock::acquire(&state, wait).map_err(|error| match error {
                LockError::Busy => ErrorDocument::new(ErrorKind::Ledger, "another vpt command holds the write lock"),
                LockError::Contained(error) => contained_error(error),
                LockError::Io(detail) => ErrorDocument::new(ErrorKind::Ledger, detail),
            })?;
            let ledger = SqliteLedger::open(&state).map_err(open_error)?;
            (Some(lock), RuntimeLedger::Sqlite(ledger), Some(state))
        } else {
            (None, RuntimeLedger::read_only(&roots.state_dir)?, None)
        };
        if lock.is_some() {
            roots.create_leaves().map_err(|error| root_error(&error))?;
        }
        if settings.source.read_titles {
            recorder = match (recorder, state.as_ref()) {
                (Some(store), Some(state)) => Some(store.with_titles_root(state, true)),
                (recorder, _) => recorder,
            };
        }
        let paths = vpt_domain::layout::StoreKey::all().map(|key| roots.stores.get(key).to_path_buf());
        let archive = ClonefileArchive::open_read_only(&roots.stores.audio).map_err(contained_error)?;
        let stores = FilesystemStores::open_read_only(&paths).map_err(contained_error)?;
        Ok(Self {
            helper: HelperClient::new(settings.helper_path.clone()),
            settings, roots, ledger, recorder, archive, stores, clock, notifier, _lock: lock,
        })
    }

    pub(crate) fn mutating(&self) -> Result<RepairReport, Box<ErrorDocument>> {
        if self._lock.is_none() {
            return Err(Box::new(ErrorDocument::new(ErrorKind::Ledger, "mutating startup requires the write lock")));
        }
        repair_publications(&self.ledger, &self.stores, |_| None).map_err(|error| Box::new(repair_error(error)))
    }

    pub(crate) fn trash(&self) -> &dyn Trash {
        &self.helper
    }

    pub(crate) fn diagnostics(&self) -> Vec<String> {
        let mut diagnostics = self.notifier.take_diagnostics();
        diagnostics.extend(self.helper.take_diagnostics());
        diagnostics
    }
}

```

`crates/vpt/src/compose/errors.rs`:

```rust
use std::path::Path;
use vpt_adapters::{ContainedError, OpenError, RootError};
use vpt_adapters::config::ConfigError;
use vpt_application::RepairError;
use vpt_application::ports::{LedgerError, StoreError};
use vpt_protocol::error::{ErrorDocument, ErrorKind};

pub(crate) fn config_error(error: &ConfigError, path: &Path) -> ErrorDocument {
    let message = match error {
        ConfigError::PathEscape(path) => return ErrorDocument::new(
            ErrorKind::Refused, format!("{path} escapes the configuration root"),
        ).rule("path_escape"),
        ConfigError::Missing(_) => format!("no configuration at {}; run `vpt setup`", path.display()),
        ConfigError::Unreadable { detail, .. } => format!("configuration unreadable: {detail}"),
        ConfigError::Unparseable(_) => "configuration does not parse".into(),
        ConfigError::MissingVersion => "config_version is missing".into(),
        ConfigError::UnsupportedVersion(found) => format!("config_version {found} is not supported (this build reads 1)"),
        ConfigError::UnknownKey(key) => format!("unknown key {key}"),
        ConfigError::WrongType { key, expected } => format!("{key} must be a {expected}"),
        ConfigError::OutOfRange { key, rule } => format!("{key} must be {rule}"),
    };
    ErrorDocument::new(ErrorKind::Config, message)
}

pub(crate) fn root_error(error: &RootError) -> ErrorDocument {
    let message = match error {
        RootError::NotAbsolute { key } => format!("{key} must be absolute after expansion"),
        RootError::ParentMissing { key } => format!("{key}: the parent directory does not exist"),
        RootError::NotADirectory { key } => format!("{key}: not a directory"),
        RootError::PathEscape { key } => return ErrorDocument::new(ErrorKind::Refused, format!("{key}: path escapes its resolved root")).rule("path_escape"),
        RootError::Overlap { first, second } => format!("{first} overlaps {second}"),
        RootError::Io { key, detail } => format!("{key}: {detail}"),
    };
    ErrorDocument::new(ErrorKind::Config, message)
}

pub(crate) fn contained_error(error: ContainedError) -> ErrorDocument {
    match error {
        ContainedError::Io { path, kind } => ErrorDocument::new(ErrorKind::Store, format!("{kind} at {}", path.display())),
        error => ErrorDocument::new(ErrorKind::Refused, format!("{error:?}")).rule("path_escape"),
    }
}

pub(crate) fn open_error(error: OpenError) -> ErrorDocument {
    match error {
        OpenError::Contained(error) => contained_error(error),
        OpenError::Ledger(error) => ledger_error(error),
    }
}

pub(crate) fn ledger_error(error: LedgerError) -> ErrorDocument {
    match error {
        LedgerError::PathEscape(path) => ErrorDocument::new(
            ErrorKind::Refused, format!("{} escapes the retained state root", path.display()),
        ).rule("path_escape"),
        error => ErrorDocument::new(ErrorKind::Ledger, format!("{error:?}")),
    }
}

pub(crate) fn store_error(error: StoreError) -> ErrorDocument {
    match error {
        StoreError::Escape(path) => ErrorDocument::new(ErrorKind::Refused, format!("{} escapes its root", path.display())).rule("path_escape"),
        StoreError::Io(detail) => ErrorDocument::new(ErrorKind::Store, detail),
    }
}

pub(crate) fn repair_error(error: RepairError) -> ErrorDocument {
    match error {
        RepairError::TargetModified(path) | RepairError::Render(path) | RepairError::RenderedDigestMismatch(path) =>
            ErrorDocument::new(ErrorKind::Refused, format!("{} cannot be repaired safely", path.display())).rule("target_modified"),
        RepairError::Sync { cause, .. } | RepairError::Stores(cause) => store_error(cause),
        RepairError::Ledger(error) => ledger_error(error),
    }
}
```

`crates/vpt/src/compose/clock.rs`:

```rust
use super::Environment;
use vpt_adapters::SystemClock;
use vpt_application::ports::Clock;
use vpt_domain::time::{UtcInstant, UtcOffset};
use vpt_protocol::error::ErrorDocument;
#[cfg(feature = "dev-tools")]
use vpt_protocol::error::ErrorKind;

pub(crate) struct RuntimeClock {
    #[cfg(feature = "dev-tools")]
    fixed: Option<UtcInstant>,
}

impl RuntimeClock {
    pub(crate) fn from_environment(environment: &Environment) -> Result<Self, Box<ErrorDocument>> {
        #[cfg(feature = "dev-tools")]
        {
            let fixed = environment.var("VPT_TEST_NOW_SECS").map(|value| {
                value.parse::<i64>().map(|secs| UtcInstant { secs })
                    .map_err(|_| Box::new(ErrorDocument::new(ErrorKind::Config, "invalid test clock")))
            }).transpose()?;
            Ok(Self { fixed })
        }
        #[cfg(not(feature = "dev-tools"))]
        {
            let _ = environment;
            Ok(Self {})
        }
    }
}

impl Clock for RuntimeClock {
    fn now(&self) -> UtcInstant {
        #[cfg(feature = "dev-tools")]
        if let Some(fixed) = self.fixed {
            return fixed;
        }
        SystemClock.now()
    }

    fn offset_at(&self, at: UtcInstant) -> UtcOffset {
        #[cfg(feature = "dev-tools")]
        if self.fixed.is_some() {
            return UtcOffset { secs: 0 };
        }
        SystemClock.offset_at(at)
    }
}
```

The default build never reads the test variable. The fixed build uses UTC, so timestamps and retention
age assertions are independent of the host timezone.

`crates/vpt/src/compose/ledger.rs`:

```rust
use std::path::Path;
use vpt_adapters::{MemoryLedger, SqliteLedger};
use vpt_application::ports::{
    DirtyPublication, LedgerCommit, LedgerError, PublicationJournal, RecordingLedger,
    RecordingRecord, SeenRow,
};
use vpt_domain::{digest::Sha256Digest, identity::RecordingId, time::UtcInstant};
use vpt_protocol::error::ErrorDocument;

pub(crate) enum RuntimeLedger {
    Sqlite(SqliteLedger),
    Empty(MemoryLedger),
}

impl RuntimeLedger {
    pub(crate) fn read_only(path: &Path) -> Result<Self, Box<ErrorDocument>> {
        Ok(match SqliteLedger::open_read_only(path).map_err(super::errors::open_error)? {
            Some(ledger) => Self::Sqlite(ledger),
            None => Self::Empty(MemoryLedger::new()),
        })
    }

    fn recordings_port(&self) -> &dyn RecordingLedger {
        match self { Self::Sqlite(ledger) => ledger, Self::Empty(ledger) => ledger }
    }

    fn publications_port(&self) -> &dyn PublicationJournal {
        match self { Self::Sqlite(ledger) => ledger, Self::Empty(ledger) => ledger }
    }
}

impl RecordingLedger for RuntimeLedger {
    fn seen(&self, path: &Path) -> Result<Option<SeenRow>, LedgerError> { self.recordings_port().seen(path) }
    fn seen_all(&self) -> Result<Vec<SeenRow>, LedgerError> { self.recordings_port().seen_all() }
    fn record_seen(&self, row: &SeenRow) -> Result<(), LedgerError> { self.recordings_port().record_seen(row) }
    fn by_digest(&self, digest: &Sha256Digest) -> Result<Option<RecordingRecord>, LedgerError> { self.recordings_port().by_digest(digest) }
    fn by_id(&self, id: &RecordingId) -> Result<Option<RecordingRecord>, LedgerError> { self.recordings_port().by_id(id) }
    fn recordings(&self) -> Result<Vec<RecordingRecord>, LedgerError> { self.recordings_port().recordings() }
    fn commit(&self, batch: &LedgerCommit) -> Result<(), LedgerError> { self.recordings_port().commit(batch) }
    fn set_source_path(&self, id: &RecordingId, path: &Path) -> Result<(), LedgerError> { self.recordings_port().set_source_path(id, path) }
    fn set_audio_trashed(&self, id: &RecordingId, at: UtcInstant) -> Result<(), LedgerError> { self.recordings_port().set_audio_trashed(id, at) }
}

impl PublicationJournal for RuntimeLedger {
    fn pending_publications(&self) -> Result<Vec<DirtyPublication>, LedgerError> { self.publications_port().pending_publications() }
    fn clear_publication(&self, target: &Path) -> Result<(), LedgerError> { self.publications_port().clear_publication(target) }
}
```

`crates/vpt/src/documents/mod.rs`: `mod record; pub(crate) use record::record_json;`.
`crates/vpt/src/documents/record.rs`:

```rust
//! A recording's record as `vpt show` and `vpt list` print it.

use serde_json::{Value, json};
use vpt_application::ports::RecordingRecord;

pub fn record_json(record: &RecordingRecord) -> Value {
    json!({
        "id": record.id.as_str(),
        "source_path": record.source_path,
        "digest": record.digest.hex(),
        "captured_at": record.captured_at.rfc3339_with(record.captured_offset),
        "captured_at_utc": record.captured_at.rfc3339(),
        "duration_secs": record.duration_secs,
        "title": record.title,
        "title_source": record.title_source.as_str(),
        "ingested_at": record.ingested_at.rfc3339(),
        "audio_path": record.audio_path,
        "stages": {
            "transcribe": record.stages.transcribe.as_str(),
            "note": record.stages.note.as_str(),
            "synthesis": record.stages.synthesis.as_str(),
        },
        "audio_trashed_at": record.audio_trashed_at.map(|at| at.rfc3339()),
    })
}
```

`crates/vpt/src/commands/ingest.rs`:

```rust
//! `vpt ingest`.

use crate::cli::output::Outcome;
use crate::compose::Runtime;
use crate::documents::record_json;
use serde_json::json;
use std::path::PathBuf;
use vpt_application::{Ingest, IngestError, IngestFailure, IngestReport, Mode};
use vpt_protocol::error::{ErrorDocument, ErrorKind};
use vpt_protocol::result::document;

pub fn run(runtime: &Runtime, dry_run: bool, once: Option<PathBuf>) -> Outcome {
    let Some(recorder) = runtime.recorder.as_ref() else {
        return Outcome::Failure(ErrorDocument::new(ErrorKind::Config, "ingest composition has no recording source"));
    };
    if !dry_run {
        if let Err(error) = runtime.mutating() {
            return Outcome::Failure((*error).diagnostics(runtime.diagnostics()));
        }
    }
    let ingest = Ingest {
        recorder,
        archive: &runtime.archive,
        ledger: &runtime.ledger,
        clock: &runtime.clock,
        trash: runtime.trash(),
        notifier: runtime.notifier.as_ref(),
        settings: &runtime.settings.source,
    };
    let mode = Mode { dry_run, once };
    match ingest.run(&mode) {
        Ok(mut report) => {
            report.log.extend(runtime.diagnostics());
            Outcome::Success { human: human(&report), document: document("ingest", body(&report)) }
        }
        Err(mut error) => {
            error.log.extend(runtime.diagnostics());
            Outcome::Failure(failure(*error))
        }
    }
}

fn body(report: &IngestReport) -> serde_json::Value {
    json!({
        "ingested": report.ingested.iter().map(record_json).collect::<Vec<_>>(),
        "already_ingested": report.already_ingested.iter().map(|id| id.as_str()).collect::<Vec<_>>(),
        "recovered": report.recovered.iter().map(|id| id.as_str()).collect::<Vec<_>>(),
        "deferred": report.deferred.iter().map(|d| json!({"path": d.path, "reason": d.reason.as_str()})).collect::<Vec<_>>(),
        "skipped": report.skipped,
        "would_ingest": report.would_ingest.iter().map(|w| json!({"path": w.path, "title": w.title, "title_source": w.title_source.as_str()})).collect::<Vec<_>>(),
        "log": report.log,
    })
}

fn human(report: &IngestReport) -> String {
    let mut lines = Vec::new();
    for record in &report.ingested {
        lines.push(format!("ingested {}", record.id));
    }
    for would in &report.would_ingest {
        lines.push(format!("would ingest {}", would.path.display()));
    }
    for deferred in &report.deferred {
        lines.push(format!("deferred {} ({})", deferred.path.display(), deferred.reason.as_str()));
    }
    for line in &report.log {
        lines.push(format!("note: {line}"));
    }
    lines.push(format!(
        "ingested {}, already ingested {}, deferred {}, skipped {}",
        report.ingested.len(),
        report.already_ingested.len(),
        report.deferred.len(),
        report.skipped
    ));
    lines.join("\n") + "\n"
}

fn failure(error: IngestError) -> ErrorDocument {
    let completed: Vec<String> = error.completed.iter().map(|id| id.as_str().to_owned()).collect();
    let message = error.failure.message();
    let document = match error.failure {
        IngestFailure::ArchiveCollision { .. } => ErrorDocument::new(ErrorKind::Refused, message).rule("archive_collision"),
        IngestFailure::PathEscape(_) => ErrorDocument::new(ErrorKind::Refused, message).rule("path_escape"),
        IngestFailure::HelperVersion { .. } => ErrorDocument::new(ErrorKind::Refused, message).rule("helper_version"),
        IngestFailure::Ledger(error) => crate::compose::errors::ledger_error(error),
        _ => ErrorDocument::new(ErrorKind::Store, message),
    };
    document.completed(completed).diagnostics(error.log)
}
```

In `crates/vpt/src/lib.rs`, `dispatch` gains:

```rust
        Verb::Ingest { dry_run, once } => {
            let access = if *dry_run { AccessMode::ReadOnly } else { AccessMode::Mutating };
            match Runtime::load(&environment, invocation.config.as_deref(), access, Operation::Ingest) {
                Ok(runtime) => commands::ingest::run(&runtime, *dry_run, once.clone()),
                Err(error) => Outcome::Failure(*error),
            }
        }
```

with `let environment = Environment::from_process();` at the top of `dispatch`, `mod documents;`, and the
imports `use compose::{AccessMode, Environment, Operation, Runtime};`. `commands/mod.rs` lists `ingest`,
`setup`, `version`. Add `mod clock;` and `pub use clock::SystemClock;` to the adapters `lib.rs` in Step
1\.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test --workspace --features dev-tools` and
`cargo test -p vpt --lib compose --no-default-features`.

Expected: all PASS. Also run `cargo clippy --workspace --all-targets --features dev-tools -- -D warnings`
and expect no warnings; `main.rs` stays at three lines and `lib.rs` under 150.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(cli): vpt ingest with the write lock and repair before work"
```

______________________________________________________________________

