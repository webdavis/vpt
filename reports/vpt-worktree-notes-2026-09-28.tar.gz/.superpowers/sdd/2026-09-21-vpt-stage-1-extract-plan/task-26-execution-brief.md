# Task 26 execution brief

Preparation only. Dispatch after the prerequisites below are accepted. The 2026-09-26 report and alert amendment and design spec sections 8.7 and 9 govern this task. The original Task 26 sample and `task-26-brief.md` describe withdrawn notification modes, desktop delivery, token substitution and fallback; none of their code blocks or test commands is an executable recipe. One product writer owns the task; main owns the ledger, review and final ship.

## Dispatch gates and accepted interfaces

- On 2026-09-27 root dispatches export, recovery, protocol encoding and optional hooks in
  `feat/event-export`, from accepted `4e7413b`. The writer implements the frozen interfaces below
  test-first and owns only this adapter slice. The application sink replacement and protocol's
  `vpt-domain` path dependency are approved. Add only this slice's necessary shared module exports;
  root reviews their preservation during integration. Root owns final combined gates, while Task 28
  completes its current native window. The command producers and result envelopes remain later work.
- On 2026-09-27 root dispatches the independent private-state/private-log filesystem slice in
  `feat/private-event-log`, from accepted `1720508`. This slice can proceed before Task 19 because
  it owns only narrow contained filesystem capabilities and their tests. The writer proposes exact
  append/receipt and incomplete-tail handling before implementing those choices. Export, history
  acknowledgement, hooks and protocol serialization remain behind accepted history/event interfaces.
  Root owns shared adapter/protocol exports. Only focused writer checks run; root owns combined
  ship/release/timing. All writers coordinate one native batch while source work proceeds in parallel.
- Task 19 must supply accepted domain events, durable history and recovery contracts. Its
  `run-history` source has the types listed below, but acceptance still precedes exporter
  implementation. Task 26 owns the frozen receipt-based `EventSink` adjustment and its recording
  fake. Do not copy the withdrawn `Notification` and `Notifier` sample.
- Task 24's accepted `spawn::run_with_env` takes argv, standard-input bytes, a duration, an output
  limit and environment overrides. It returns `Outcome` with typed exited/signaled/deadline/
  interrupted status or `SpawnError::{NotFound, Io}`. Use its process ownership and cleanup with
  a five-second hook deadline and `OUTPUT_LIMIT` (65,536 bytes). Do not add another process runner
  or timeout mechanism.
- The report and alert config slice must be accepted in this lane before runtime wiring. It defines independent `Settings.report_command` and `Settings.alert_command` argument lists, both empty by default, and `Settings.alert_aggregate_after`, default `3` with a positive 32-bit bound. Do not restore `NotifyMode` or legacy keys.
- Task 25's helper client is for version and Trash in Stage 1. It is not a hook prerequisite or delivery fallback. Its old notification request, reply and fake-helper branches are withdrawn.
- Task 26 owns the `vpt.event/1` outgoing document and the logging and command-hook adapter over the accepted `EventSink`. Task 27 owns command composition and end-to-end output checks; Task 32 owns the retention producer and its report hook integration. Verify those later tasks against this contract without claiming their behavior is already present.

## Logging destination and failure policy

The operator chose a private `events.jsonl` file inside VPT's state directory on 2026-09-26. Log emitted events and hook failures there, including when both commands are empty. Resolve the path through the validated, retained state root; never follow a redirected path or make an existing shared folder private by changing its permissions. Keep event records independent of command output. Section 9 still requires one JSON result on stdout after success or one JSON error on stderr after failure.

The operator approved preserving the underlying operation's result and exit status when a log write
fails, with a bounded, content-free warning inside that operation's existing JSON document. This
applies to successful and failed operations; a completed operation must not become a reported failure
solely because logging failed. Do not emit a second JSON document or recursively log the warning.
Reconcile the warning with the accepted event port and command result interfaces before dispatch.
Do not silently discard a log error, add rotation, another transport, a config key or a notification
fallback. Default logging is not implemented yet.

Spec section 8.7.1 adds recovery-aware history. The database owns saved run and event facts; the
private JSON Lines file exports those facts. Before implementation, review the narrow application
repository, migration, transaction coupling and versioned log-record shape with Task 19. Preserve
occurrence time separately from recovery time, stable run/event identifiers and ordering sequence.
Save export progress only after a complete record is synced. A crash between append and database
acknowledgement may replay the same identifier; do not claim exactly-once append. Incomplete final
lines must remain distinguishable from complete records. Attempt export after each history commit,
before continuing work or invoking its original hook. Export and hook execution happen outside the
transaction. A log-only failure preserves the work result, carries the already approved warning,
and still permits the original configured hook. Unsafe shared state or failed required state/history
commits stop new work through their typed failures while reporting completed work.

Task 27 performs recovery under the existing write lock before new mutating work. Restore pending
records and write a recovery summary using only saved facts and reconciliation evidence. Mark
unresolved outcomes and unavailable history explicitly. Record observed failure and restoration
times without inventing the repair time, cause or operator action. A recovery attempt itself may
be interrupted and must resume. Do not replay work or hooks, or invoke a hook for the recovery
summary. If neither store retains evidence, the original command reports that failure immediately;
later recovery cannot reconstruct or reliably detect that attempt. Summaries describe only retained
facts and detectable gaps. A failure before safe state exists uses the existing command output only.
Neither dry runs nor observational commands create history or repair exports.

The adapter's lost-evidence test covers the boundary it owns: a required history read failure
stops recovery without inventing a receipt or summary, and a fresh empty history cannot reconstruct
an earlier attempt. Task 27 owns the immediate command error and completed-work envelope;
Task 32 owns detectable gaps between retention intents and matching history. This adapter test
does not establish those command or reconciliation contracts and requires no log-body parser.

`RootDir::open_file` checks regular-file type but does not establish private ownership, permissions
or a single link. Use the reviewed private-log capability described below. Its descriptor-relative
operations revalidate the root and privacy checks before writing event bytes. Preserve the owned
fixture coverage for replaced roots and log symlinks, nonregular files, hard links and nonprivate
modes. Existing unsafe paths must remain unchanged in permissions and contents.

The independent filesystem slice uses fixed-leaf `EventLog` acquisition, observational inspection
and complete-line append. Inspection returns the retained file identity and complete/physical ends,
not durability evidence. Before append, a partial suffix is removed only through the verified owned
descriptor and its repair is synced; complete lines remain untouched. Each successful append syncs
the file and retained directory before final identity validation. This covers interrupted creation
followed by reopening. Failures retain confirmed repair and partial-write effects, including the
validated pre-effect identity, without exposing the discarded bytes. A receipt alone is not a
database acknowledgement. Existing unsafe modes remain unchanged; only newly exclusive-created
files may have their mode established explicitly. These choices passed focused test-first and
independent security review in filesystem commit `c0b5bbaf3b45a98df5bbf6c39438a921f9137bac`.
Export orchestration and hooks remain unimplemented.

Any persistent-log choice must preserve the existing no-write observation and dry-run contracts.
Section 5.2 explicitly excludes durable events from ingest dry runs. Pin that boundary in the assembled
command tests rather than weakening observational snapshots to accommodate a log file. Configuration
refusal before a safe sink exists also needs a content-free diagnostic in the existing command error
document; never follow an unvalidated config path just to record an event.

## Frozen exporter interfaces and composition

Root froze this interface on 2026-09-27. It belongs to `vpt-application` and replaces the
record-at-a-time placeholder when Task 26 implementation starts. `BTreeSet` makes warnings
deterministic and bounds them to the five closed variants. Ledger errors remain internal typed
causes; their strings and paths must not enter a warning or hook document.

```rust
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum SinkWarning {
    ExportUnavailable,
    ExportProgressUnconfirmed,
    ExportFailureEvidenceUnconfirmed,
    ExportBookkeepingPostCommitFailure,
    HookFailed,
}

pub enum SinkError {
    UnsafeState,
    RequiredHistory(LedgerError),
}

pub struct SinkStop {
    pub reason: SinkError,
    pub committed: Option<HistoryReceipt>,
    pub warnings: BTreeSet<SinkWarning>,
}

pub enum SinkOutcome {
    Continue { warnings: BTreeSet<SinkWarning> },
    Stop(Box<SinkStop>),
}

pub trait EventSink {
    fn after_commit(&mut self, committed: &HistoryReceipt) -> SinkOutcome;
    fn recover(&mut self, view: &RecoveryView) -> SinkOutcome;
}
```

`HistoryReceipt` retains `run`, ordered `records` and `completed`. The caller retains its original
receipt and operation result. A stop retains any known receipt from a required history save that
committed before reporting failure; it must not imply that completed work rolled back.

Use one concrete `LoggedEvents<'a, H: RunHistory, N: FnMut() -> UtcInstant>` adapter. It borrows the
validated state `RootDir`, history repository and report/alert argv slices, and owns its clock.
Construction performs no filesystem or process operation. Keep export, recovery and hook helpers
private. The public dependencies are the consumer-owned history port, accepted filesystem boundary,
protocol encoders and existing process runner. Tests may inject faults at narrow private operations;
no new public filesystem, delivery or subprocess abstraction is needed.

Live delivery reads authoritative history, validates the log and handles a safe export restart,
then drains pending records in saved order. Only confirmed append receipts permit acknowledgement.
After the export attempt, invoke original hooks only for `HistoryFact::Event` records in the supplied
newly committed receipt. An export-only failure still permits those original hooks. A hook failure
saves `HistoryFact::HookFailed { event, failure }` with an empty `WorkDelta`; export that fact without
invoking another hook. A failed required save stops subsequent work.

If the original export attempt stops with an unexported or unacknowledged prefix, save any original
hook failure in history and leave it pending behind that prefix. Do not retry the prefix inline to
export the new `HookFailed` fact. The next normal export or recovery attempt preserves saved order
without replaying the hook. A fully drained export can export the newly saved hook-failure fact
immediately. Test both a refused log leaf and an unconfirmed acknowledgement followed by a failed
original hook; each must make only one attempt at the blocked prefix.

Recovery runs under Task 27's existing write lock after reconciliation facts are saved. It resumes
saved progress and summaries, exports pending facts and saves any new summary in history before
exporting it. It has no work-retry or hook-delivery capability. Export and hooks remain outside
database transactions.

`LoggedEvents::new(state, history, report_command, alert_command, clock)` borrows the first four
arguments and remains inert. Recovery owns a `RunKind::Recover` run only when saved unsummarized
failures or interrupted work require a summary. Resume saved recovery progress or an already-saved
summary before creating another run or summary. Its own recovery bookkeeping is not new interrupted
business work. A repeated recovery with unchanged summarized evidence only resumes pending export.
Task 27 still owns the application lock and work reconciliation before calling `recover`.

Save recovery progress before draining the recorded backlog. Root approved a narrow
`RunHistory::begin_recovery(at, evidence)` operation on 2026-09-27. Within the existing history
transaction it captures the baseline, then saves RunStarted and RecoveryProgress together.
An unconfirmed write supplies no invented start receipt; a committed-with-failure result keeps
its combined receipt. Export both initial facts before committing the summary. A blocked prefix
stays pending without an inline retry. An unfinished, summary-free, work-free Recover run with
only its saved start can resume by saving its baseline before draining.

Use `RecoveryProgress { evidence, baseline }`, with a typed `RecoveryBaseline` containing
`generation: Option<u64>`, `pending_from: Option<EventId>` and `through: Option<EventId>`.
Capture the initial cursor generation, first pending identifier and final preexisting identifier.
The baseline remains fixed through resumed attempts. The exported progress fact exposes these
fields, so its stable run identity also identifies the summary's counting scope. Reuse the
existing fact storage, with no new table or generic checkpoint framework.

For generic `commit_step`, the first Progress must equal its fresh pre-step snapshot; a later
Progress must retain the same run's first baseline. Validate before applying any work delta.
Atomic begin captures its baseline before inserting RunStarted and validates both saved facts
inside the existing transaction. A start-only interrupted run's fresh snapshot includes its
already-saved start. Do not weaken these guards for fixtures with invented empty baselines.

Detectable missing retention history has its own safe fact:
`HistoryFact::MissingRetentionHistory { intent_id: u64 }`, with a positive identifier and wire
tag `missing_retention_history`. Task 32 records the current observation for its known pending
journal row, then stops; it invents no original event, run or occurrence time. Recovery derives
`missing_history` from distinct observed intent identifiers in the evidence used for that
summary. Repeated sightings of one row count once. RecoveryProgress is a saved summary snapshot,
not a new observation to add to that count. A Recover run carrying this fact is affected evidence.
Use the existing fact storage and no new table or port. The separate history-gaps writer owns
the shared type, validation and codecs; Task 26 owns reduction and Task 32 the producer.

`recovered_records` counts distinct confirmed records inside that fixed backlog. When generation
is unchanged, count acknowledged identifiers from `pending_from` through `through`. After a safe
generation advance, count all acknowledged preexisting identifiers through `through`. Initial
cursor creation from None to generation zero is not a restart. Records beyond `through` can
contribute work outcomes to the summary but do not enlarge this backlog count. Physical appends
whose acknowledgements were lost are not a knowable total.

Pin partial-drain interruption, all-acknowledged replacement or truncation, new records beyond
the frontier, and initial cursor creation before implementing this correction. Shared Memory and
SQLite contracts cover atomic initial facts and the captured baseline. Validate frontier identity,
ordering, empty-history combinations and generation consistency through the existing closed
failure paths. Preserve separate work/effect counts and advance the failure watermark only when
the summary commits.

Recovery work and external-effect counts are separate evidence categories. Replace the unshipped
ambiguous `completed`, `failed` and `unresolved` evidence fields with `completed_work`, `failed_work`,
`unknown_work`, `completed_effects`, `failed_effects` and `unresolved_effects`. The work fields count
saved `WorkStep` facts by record identity. Effect fields count distinct intents, classified by their
latest saved observation in sequence order; absent or unknown observations remain unresolved.
Never sum or take a maximum across these categories to infer unique operations. A completed effect
cannot erase an unrelated unknown work fact. This change covers the domain shape, private codec,
protocol encoding and fixtures, with compiling regression evidence before implementation; it adds
no table, schema, compatibility fallback or work/effect association model.

Unchanged summarized evidence creates no new summary. A later saved reconciliation fact on a
previously summarized business run must still be considered, using saved record sequence rather
than occurrence time. Pin an atomic `EffectObserved` and `WorkStep` completion pair at the same
occurrence time: the new summary shows one completed work fact and one completed effect, without
replaying work or hooks. Independent work/effect evidence and observation-order tests pin the
separate categories before recovery implementation.

Keep the run identity that actually owns each saved work fact. Reconciliation may save an
`EffectObserved` and `WorkStep` on a separate `RunKind::Recover` run, as Task 32 does. Such a run
contains business work and belongs in `affected_runs` alongside the original intent's run.
Resolve the observation through its explicit intent identifier. Count its WorkStep under its own
run, without inferring a work/effect association from adjacency, equal timestamps or recording IDs.
Exclude summary-only recovery bookkeeping from new-work detection; do not exclude all Recover
runs. The cross-run regression uses later sequence numbers with the original occurrence time and
requires both affected run identities, separate work/effect counts and a no-op repeat.

Task 20's typed deferral prerequisite adds `WorkOutcome::Deferred`. After that prerequisite is
accepted, extend this evidence with a separate `deferred_work` count, test-first. A deferred fact
does not increment completed, failed or unknown work, or any effect category. Preserve the original
six-counter packet as evidence for its own source; do not rewrite its chronology.

Inspect an existing acknowledged log even when no record is pending, so a safe replacement or
truncation can trigger replay. An unsafe leaf in that all-acknowledged state produces the closed
export warning and preserves every acknowledgement and cursor. It creates no failure fact:
`note_export_failure` requires a pending record, and inspection does not make a prior confirmed
append unsuccessful. A later genuinely pending record can save its export refusal normally.

The error mapping is fixed:

| Boundary | Outcome |
| --- | --- |
| Unsafe private state or history containment failure | `Stop`, preserving known receipts and warnings |
| Failed required history read/save | `Stop(RequiredHistory(...))`; retain a committed receipt when present |
| Refused log leaf, append failure or export encoding refusal | `Continue` with `ExportUnavailable`; preserve the original hook and work result |
| Unconfirmed export acknowledgement or restart bookkeeping | `Continue` with `ExportProgressUnconfirmed` |
| Unconfirmed optional export-failure evidence save | `Continue` with `ExportFailureEvidenceUnconfirmed` |
| Optional export bookkeeping committed with a later non-containment failure | `Continue` with `ExportBookkeepingPostCommitFailure` |
| Hook failure, including hook encoding refusal | `HookFailed` warning and required typed history save; stop if that save fails |

Containment errors take precedence in every row. Do not retry delivery inline or log a warning
recursively. Optional bookkeeping failure does not erase a confirmed append or imply work rollback.

After any failed optional history operation, validate the same retained state `RootDir` with
`validate_private_state` before an original hook or `Continue`. This applies to acknowledgement,
restart and failure-evidence saves, including both unconfirmed and committed-with-failure results
and every error class. Any failed validation stops with `UnsafeState`, preserving known receipts
and warnings. A definite `LedgerError::PathEscape` stops immediately even if later validation would
succeed. Successful validation permits only the existing warning and original hook; it neither
confirms an unconfirmed write nor retries it. Required history failures still stop unconditionally.

This boundary uses the existing typed errors. Ordinary contained input/output failures also include
directory-sync failures, so they cannot all mean unsafe state. Test optional failures with a valid
private root, a replaced root, a changed mode and a narrow injected validation error. Cover an
earlier definite escape despite a currently valid root, and preserve committed receipts on both
safe and unsafe post-commit paths. The corresponding unsafe-state leaf must reach compiling RED
before this rule is implemented.

## Frozen history and filesystem handoff

Task 19 supplies these contracts before dispatch:

- `HistoryWrite<T>::Committed(T)`, `CommittedWithFailure { receipt, error }` and
  `Unconfirmed(error)` distinguish known commits from unconfirmed writes. `commit_step` saves work
  changes and facts atomically; export acknowledgement and failure evidence are separate operations.
- `EventId`, `RunId` and `ExportFailureId` are opaque namespaced identifiers with checked numeric
  sequences. Use their accessors and `render()`; do not generate another identifier during replay.
- `HookFailureClass` is closed: `Spawn`, `Io`, `Encoding`, `Exited(i32)`, `Signaled(i32)`,
  `DeadlineExceeded` and `Interrupted`. The referenced event must be a saved event fact.
- `SavedExportFailure { id, failure }` retains the durable failure sequence.
  `ExportFailureClass` is `LeafRefused`, `Io`, `Encoding` or `UnsafeState`.
- `ExportFailure.last_confirmed` is the latest acknowledged append position, not the observed
  baseline of a restarted export. It is `None` after restart until replay acknowledgement succeeds.
  `observed_file: Option<ObservedLogFile>` separately records `device`, `inode`,
  `complete_end_offset` and `physical_end_offset` from a validated `LogInspection`.
- `ExportCursor { generation, position }` guards `acknowledge_export` and `restart_export`.
  A safe changed identity or shortened complete prefix can restart against the expected cursor.
  A stale token cannot erase replay progress; another genuine truncation uses a fresh generation.
  Unsafe or unvalidated files never reset acknowledgement state.
- `RecoverySummary { evidence, window: Option<FailureWindow> }` advances the failure watermark
  atomically with its saved fact. `Some(FailureWindow { after, through })` must start at the current
  `RecoveryView.summarized_through` and end at an existing later saved failure. `None` supports
  work-only recovery without advancing that watermark. Count later failures by saved ID, including
  another outage while replaying the same event at the same observed timestamp.
- `RecoveryEvidence.first_failure_observed_at: Option<UtcInstant>` is `None` for work-only recovery.
  Its optional restoration time records an observation, never an inferred repair time. Summaries
  use saved failures, work facts and reconciliation evidence; they cannot reconstruct an attempt
  absent from both stores.

`LogInspection` supplies observational identity and complete/physical ends. Map it to
`ObservedLogFile`, never an append acknowledgement. `AppendReceipt` supplies the confirmed
`ExportPosition { device, inode, end_offset }` after file and directory sync and final validation.
`append_line` returns `Result<AppendReceipt, Box<AppendFailure>>`. Failure effects retain the
pre-effect inspection, optional tail repair, written-byte count and sync stage. Map those effects
conservatively to `PartialAppend`; a failed final identity check cannot set
`identity_revalidated=true`. A repaired suffix or partial write remains failure evidence even when
the later append, sync or validation fails.

## Frozen outgoing protocol

The protocol crate owns two encoders and a closed error:

```rust
pub enum EventEncodeError {
    NonUtf8Path,
    TimestampOutOfRange,
}

pub fn encode_hook(event: &Event) -> Result<Vec<u8>, EventEncodeError>;
pub fn encode_history(
    record: &HistoryRecord,
    appended_at: UtcInstant,
) -> Result<String, EventEncodeError>;
```

`encode_hook` emits the approved `vpt.event/1` document. `encode_history` emits one compact
`vpt.log/1` document with `schema`, `event_id`, `run_id`, `sequence`, `occurred_at`, `appended_at`
and `fact`. The caller supplies the current append-attempt time; the saved occurrence time and
identifiers survive recovery unchanged. `EventLog::append_line` adds the line feed. JSON escaping
keeps each document on one physical line. The log encoder covers every closed history fact and
safe detail variant without exposing the SQLite codec as a public wire format.

Every serialized path requires exact UTF-8 conversion. Every serialized timestamp, including
nested event and recovery times, requires UTC civil year `0..=9999` before rendering.
`UtcInstant::rfc3339()` uses minimum-width year formatting and accepts the whole `i64` second range;
leave that legacy method unchanged. The outgoing boundary enforces the four-digit year required
by [RFC 3339 section 5.6](https://www.rfc-editor.org/rfc/rfc3339#section-5.6).
Use neither lossy paths nor clamped timestamps. Both encoder refusals map to the corresponding
closed history `Encoding` class, never `Io`. Refusal produces no partial document, append
acknowledgement or hook spawn.

Root owns shared application/adapter/protocol exports. The writer owns the receipt-based sink
adjustment, concrete adapter, protocol encoders and focused tests after history acceptance. Task 27
owns command assembly and result-envelope changes. No schema or transaction redesign belongs in
this adapter slice.

## Named exporter and recovery test census

Prepare these named leaves before the corresponding behavior. A name may cover a table of closed
variants, but each branch needs an observable assertion. Keep the accepted filesystem 41-leaf suite
intact; these are additional exporter and composition proofs.

1. `hook_document_preserves_typed_event_metadata`
2. `all_event_kinds_choose_the_approved_channel`
3. `literal_argv_and_single_json_stdin_reach_only_the_selected_hook`
4. `empty_hook_configuration_still_exports_each_saved_record`
5. `confirmed_history_precedes_export_and_original_hook`
6. `log_only_failure_preserves_work_and_runs_original_hook_once`
7. `unsafe_state_or_required_history_failure_stops_new_work`
8. `hook_status_failures_save_only_typed_content_free_facts`
9. `hook_failure_fact_exports_without_recursive_hook`
10. `failed_append_preserves_observed_file_and_partial_effects_without_ack`
11. `replay_preserves_ids_sequence_and_occurrence_times_without_hooks`
12. `partial_tail_and_append_before_ack_resume_with_recognizable_duplicates`
13. `validated_replacement_or_truncation_restarts_export_generation`
14. `unsafe_log_never_resets_acknowledgements`
15. `saved_summary_watermark_prevents_recounting_prior_failures`
16. `new_replay_outage_of_same_event_and_timestamp_remains_unsummarized`
17. `interrupted_summary_commit_append_and_ack_resume_one_saved_summary`
18. `work_only_recovery_summary_leaves_failure_watermark_unchanged`
19. `unresolved_effects_are_reported_without_operation_retry`
20. `both_store_failure_reports_only_retained_evidence`
21. `non_utf8_paths_return_typed_encoding_refusals_without_lossy_output`
22. `utc_wire_year_bounds_apply_to_occurrence_append_and_recovery_times`
23. `encoding_failures_preserve_work_and_save_only_closed_failure_classes`

The UTC boundary leaf must include years 0000 and 9999, one second outside each boundary and
`i64::MIN`/`i64::MAX`. Pin optional timestamps and every history fact's path/time-bearing branch.
The failure leaves must cover required committed-with-failure receipts, unconfirmed required saves,
optional evidence-save failure and post-commit bookkeeping failure without discarding known work.
Use real private-log operations and an owned fake subprocess for the commit/export/hook ordering
and recovery no-replay proofs; a recording fake alone does not establish assembly. Keep subprocess
cleanup, test deadlines and normal parallelism unchanged. Tasks 27 and 32 retain the command-level
dry-run, no-write, aggregation and single-result-document coverage described below.

## Behavior to implement after the gates resolve

- Log each emitted event independently of hook configuration. Map `brief_written` and `retention` to `report`; map `review_needed`, `transcribe_failed`, `ingest_failed`, `deferred` and `config_refused` to `alert`. Keep the accepted event state and producer-specific privacy rules. Preserve review aggregation through `alert.aggregate_after` without moving its producer policy into the adapter.
- Encode one `vpt.event/1` JSON document per configured hook invocation, with `schema`, `channel`, `event`, `state`, `recording`, `detail`, `counts`, `paths` and `occurred_at`. Use the accepted domain values and UTC formatting. The hook receives the document on standard input. The configured argv passes directly with its original argument boundaries and literal contents, including brace text and shell metacharacters.
- An empty command invokes no hook. For a nonempty command, invoke only the event's channel, with the five-second deadline and the accepted runner's process ownership and cleanup. Capture and bound child output without copying it into VPT's logs, stdout, stderr or JSON result. Hooks do not depend on the macOS helper.
- A nonzero exit, spawn failure, signal, interruption or timeout produces a bounded, content-free diagnostic in the chosen log. Do not retry inline, invoke the other channel or use desktop delivery. Hook failure leaves the underlying operation's result and exit status unchanged. A failed log write produces the approved warning in the existing command JSON document, without recursion or changing the operation's result.
- Observation and dry-run producers spawn no hooks. Task 26 can pin its adapter behavior with controlled fakes; Tasks 27 and 32 must pin the assembled command paths and the one-document JSON envelope. No test reads live configuration or reaches a real destination.

## Test-first execution cases

Write compiling, reachable behavioral RED tests against the accepted interfaces. Each test must fail at its intended assertion, not from a missing symbol or zero selected tests. Use the Task 24 sandbox environment and fake command for every spawned process.

1. A report event and an alert event each produce the documented JSON shape, including the `channel`, exact event/state mapping, counts, path, optional recording and UTC time. Adapter tests keep child-output and secret canaries out of diagnostics. Producer and composition tests keep source-content canaries out of the event and its log.
2. With both commands empty, each emitted event reaches the chosen log and no child is spawned. With only one command configured, only events for that channel spawn it; events for the other channel still log. With both configured, each event selects exactly one command.
3. The fake command captures exact argv boundaries and literal values, including a space-containing argument, brace text, Unicode and shell metacharacters. Its standard input parses as one `vpt.event/1` document; no event value is interpolated into argv and no shell runs.
4. Exercise exited zero, nonzero, spawn refusal, signaled, interrupted and deadline outcomes. Assert one bounded diagnostic for each failure, no cross-channel call, no raw child output and an unchanged underlying work result. A hanging fake and descendant exercise the runner's deadline and cleanup under a test watchdog.
5. Observation and dry-run command tests, when their producers are composed, assert zero hook spawns. The review-needed producer tests cover `alert.aggregate_after` at the accepted boundary and one step on either side. Task 27 and Task 32 assert diagnostic visibility and one-document CLI JSON behavior on success and failure.
6. A refused or failed log write preserves both successful and failed operation results and their exit
   status, adds a content-free warning to the same JSON document, and neither retries logging nor
   emits a second document. Refusal leaves the unsafe file and its permissions unchanged. Include
   synthetic private-content canaries in the underlying I/O failure and keep them out of the warning.
7. A log outage with writable history, followed by restoration, recovers the original event facts,
   identifiers and occurrence times and emits a truthful summary. Include completed, failed and
   unresolved work; assert zero operation retries and zero hook replay. Repeated recovery after an
   acknowledgement failure retains the same event identity and never claims a new operation.
8. Interrupt before append, within a final line, after sync but before acknowledgement, and while
   writing the recovery summary. Resume without losing pending history or accepting a partial line
   as a full record. Simulate both stores failing and require an immediate command diagnostic, with
   later summaries restricted to surviving evidence and detectable gaps.
9. Shared in-memory/SQLite history contracts prove state/history transaction atomicity, stable
   identity and ordering, persistence across reopening, and content-free failure mapping. Command
   tests pin human warning visibility and the unchanged one-document machine-output contract.
   Verify per-event commit/export/hook ordering, required-history failure stopping new work, and
   original-hook delivery after export-only failure without any hook replay during recovery.

Mutation-check the exact guards that these tests claim to protect: suppress logging for an empty hook, swap report and alert routing, omit the JSON channel, interpolate brace text into argv, spawn an empty hook, copy child output into diagnostics, ignore a failed hook status, or preserve a child after its deadline. For each mutant, assert changed source bytes, run the named test to a bounded failure, restore the exact source and rerun a same-depth green control. The command-composition tests must also catch a constant or disconnected `EventSink` at the composition root. Preserve the existing leaf-name set except for explicitly mapped contract replacements.

Report the accepted prerequisite signatures, operator logging decision, RED and GREEN chronology, exact mutant/control evidence, source hashes, timing and file-size audit. Main owns final quality gates and publication. This brief authorizes no source changes or tests during preparation.
