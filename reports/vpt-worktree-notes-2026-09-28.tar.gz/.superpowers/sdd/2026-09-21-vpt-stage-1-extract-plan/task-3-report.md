# Task 3 report

Implemented and committed; controller review pending.

- Commit: `ae53d8c5b1762f2c2112dc22ac937e11f114160d`
- Review base: `0a08d7bc405167de7e3682e00c515ceaea2b2dd1`
- Branch: `feat/stage-1-extract`
- New behavior: configuration schema, template rendering, file/text loading and dotted lookup.
- Final result: 55 passing leaves, no failed or ignored leaves. Working tree and index are clean.

The original 31-leaf baseline exposed `json_usage_with_broken_stderr_exits_one` returning 2 instead of 1. Work paused; the controller's separate fixture repair added one regression and committed the review base above. Task 3 changes only eight files under `crates/vpt-adapters/src`. The command crate, parser, emitter, sandbox, protocol, manifests and lockfile have an empty diff against that base.

## Behavior and boundaries

One static key table supplies names, kinds, defaults, comments and secret classification. Dynamic definitions cover engine and language tables. The default merge calls the same renderer without overrides, so it contains no second copy of the main-engine or state-directory defaults. Unknown keys and tables, dotted literal segments impersonating nested paths, scalar/table replacements and reserved language-table confusion are refused before merging.

Parse failures use a fixed sentence. File failures expose their path and error kind. Canary assertions discard a successful raw table before reporting an unexpected success, and check diagnostic secrecy before comparing its detailed shape. The loader still returns the required raw table; value bounds and typed secret/settings wrappers remain Tasks 4 and 5.

The crate graph is unchanged: domain <- application <- adapters <- command, with the independent protocol crate consumed outward. Configuration implementation modules are private. No new ports, database state, generated deployment artifact, live destination, installation, apply, push or pull request is involved. Neovim tools were unavailable and its diagnostic could not identify a caller pane; edits were limited to new configuration files and the previously empty adapter export file.

## Named test delta

All inventory files are beside this report:

| File | Leaves |
| --- | ---: |
| `task-3-original-baseline-leaves.txt` | 31 |
| `task-3-baseline-leaves.txt` | 32 after the separate fixture repair |
| `task-3-added-leaves.txt` | 23 |
| `task-3-removed-leaves.txt` | 0 |
| `task-3-final-leaves.txt` | 55 |

The added inventory contains each full leaf name. Baseline names are unchanged. The refined RED compiled and failed all 23 leaves behaviorally. The earlier stub run selected 22 leaves with 20 failures and two vacuous passes; both were corrected before implementation.

Under final workspace concurrency, configuration's complete 23-leaf suite took 0.00-0.01 seconds. Command/protocol units took 0.00 seconds; usage/version suites took at most 0.02 seconds; the unchanged bounded harness suite took 0.51 seconds. Every leaf is below one second. New tests use finite in-process inputs and owned regular-file fixtures, with no spawned child, socket, channel or live configuration access.

## Commands and raw logs

Every log path below is relative to this report's directory. Pipelines used `pipefail`; final grouped gates also used `set -euo pipefail`.

| Command or run | Exit | Log |
| --- | ---: | --- |
| Original full workspace baseline | 101, prior fixture failure | `task-3-baseline.log` |
| `cargo test --offline --locked -p vpt-adapters config`, initial/refined RED | 101 / 101 | `task-3-red.log`, `task-3-red-refined.log` |
| First implementation attempt | compilation failed on re-export visibility | `task-3-first-green.log` |
| Configuration GREEN | 0 | `task-3-config-green.log` |
| First full workspace GREEN | 0 | `task-3-workspace-green.log` |
| Initial `just lint-check` | 101, test `err().expect()` lint | `task-3-lint-check.log` |
| Corrected `just lint-check` | 0 | `task-3-lint-check-final.log` |
| `CARGO_NET_OFFLINE=true just test-rust` | 0 | `task-3-final-gates.log` |
| `CARGO_NET_OFFLINE=true just lint-check` | 0 | `task-3-final-gates.log` |
| `CARGO_NET_OFFLINE=true just ship` | 0 | `task-3-final-gates.log` |
| `cargo check --offline --locked --workspace --all-targets --features dev-tools` | 0 | `task-3-final-gates.log` |
| `cargo build --offline --locked --release -p vpt` | 0 | `task-3-final-gates.log` |
| Staged whitespace check and unstaged diff check | 0 / 0 | `task-3-final-gates.log` |
| `SKIP_AI_COMMIT=1 git -c core.fsmonitor=false commit -m "feat(config): add key schema, template and loader"` | 0, normal hooks | `task-3-commit.log` |
| `cargo test --offline --locked --workspace --no-fail-fast --features dev-tools` at committed HEAD | 0 | `task-3-post-commit.log` |
| `gitleaks git --no-banner --no-color --redact --log-opts=HEAD` | 0, 86 commits, no leaks | `task-3-post-commit.log` |

The final gate log includes rustfmt check, Clippy with warnings denied, full workspace tests, rustdoc with warnings denied, gitleaks and the tracked-file size gate. The release build took 0.91 seconds. The post-commit log identifies the exact HEAD and ends with successful diff/status checks. No source changed after final gates.

## Mutation verification

Each row ran `cargo test --offline --locked -p vpt-adapters --lib <full-leaf> -- --exact`. Every mutant selected one named leaf and failed with exit 101; its restored control selected the same leaf and passed with exit 0. Complete before/after strings, full commands and results are in `task-3-mutations.json`.

Before every run, the complete on-disk file was compared with the intended mutated bytes. Restoration was compared byte for byte with the original. Each `task-3-<id>-mutant.log` and `task-3-<id>-control.log` records the file hash and changed source line. Those log names use the IDs below.

| ID | File below config | Selected leaf suffix | Mutant / control |
| --- | --- | --- | --- |
| version-missing | `load.rs` | `load::a_missing_config_version_is_refused` | 101 / 0 |
| version-future | `load.rs` | `load::a_future_config_version_is_refused_with_its_value` | 101 / 0 |
| version-type | `load.rs` | `load::a_noninteger_version_never_leaks_its_secret_value` | 101 / 0 |
| unknown-leaf | `load.rs` | `load::an_unknown_key_is_refused_by_its_full_path` | 101 / 0 |
| unknown-table | `load.rs` | `load::an_unknown_table_is_refused_even_when_empty` | 101 / 0 |
| quoted-segment | `load.rs` | `load::dotted_literal_segments_cannot_impersonate_schema_paths` | 101 / 0 |
| scalar-table | `load.rs` | `load::scalar_replacement_of_a_declared_table_is_refused` | 101 / 0 |
| parse-canary | `load.rs` | `load::unparseable_toml_is_refused_without_quoting_the_text` | 101 / 0 |
| merge-override | `load.rs` | `load::an_operator_value_wins_over_the_default` | 101 / 0 |
| load-composition | `load.rs` | `load::the_rendered_template_loads_and_every_key_of_the_table_is_present` | 101 / 0 |
| dynamic-leaf | `schema/dynamic.rs` | `load::an_engine_table_and_a_language_pair_are_dynamic_keys` | 101 / 0 |
| reserved-prefix | `schema/dynamic.rs` | `load::language_table_cannot_be_used_as_an_engine` | 101 / 0 |
| secret-marker | `render.rs` | `render::a_secret_key_is_marked_in_its_comment` | 101 / 0 |
| comment | `render.rs` | `render::every_key_line_carries_a_comment` | 101 / 0 |
| escape-del | `render.rs` | `render::all_control_characters_and_unicode_round_trip_as_values` | 101 / 0 |
| chosen-engine | `render.rs` | `render::the_template_starts_with_the_version_and_names_the_chosen_engine` | 101 / 0 |
| file-content | `load.rs` | `load::file_loading_reads_only_the_selected_fixture_and_classifies_failures` | 101 / 0 |
| file-missing | `load.rs` | `load::file_loading_reads_only_the_selected_fixture_and_classifies_failures` | 101 / 0 |
| kind-error | `schema/types.rs` | `load::table_values_report_the_declared_leaf_kind` | 101 / 0 |
| get-traversal | `load.rs` | `load::an_operator_value_wins_over_the_default` | 101 / 0 |

After the assertion cleanup, the parser privacy mutation was repeated against the final tests: `task-3-parse-canary-final-mutant.log` and `task-3-parse-canary-final-control.log`, exits 101/0. The mutant changed the operator parse error to `error.to_string()`; the test printed only "configuration contents leaked". Its raw canary value is absent from that log. Source hashes are `675870d29cad49b4c03674241344052ef0ef479fff79e77e6916f135f660c2e7` mutated and `82fa8b669d506756dd4d4062dac2636d25712007cb9f9bf14d608814d48b0a7c` restored.

## Exact staged-file size audit

All eight owned files were staged first. The skill's command was run with only the established read-only fsmonitor override:

```bash
git -c core.fsmonitor=false ls-files 'crates/*.rs' | while IFS= read -r f; do
  awk -v F="$f" '
    /^[[:space:]]*#\[cfg\(test\)\]/ && !seen { seen = 1 }
    !seen { impl++ }
    { total++ }
    END {
      if (F ~ /(^|\/)tests(\.rs|\/)/) impl = 0
      printf "%5d impl %5d total  %s\n", impl, total, F
    }' "$f"
done | sort -k3,3rn
```

Output is also preserved in `task-3-file-size.log`:

```text
  471 impl   471 total  crates/vpt-adapters/src/config/schema.rs
    0 impl   304 total  crates/vpt-adapters/src/config/load/tests.rs
  135 impl   280 total  crates/vpt/src/cli/args.rs
  128 impl   225 total  crates/vpt-protocol/src/error.rs
    0 impl   136 total  crates/vpt/tests/support/mod.rs
  120 impl   122 total  crates/vpt-adapters/src/config/load.rs
   55 impl    92 total  crates/vpt/src/cli/output.rs
   44 impl    89 total  crates/vpt-adapters/src/config/render.rs
    0 impl    81 total  crates/vpt/tests/version.rs
    0 impl    73 total  crates/vpt/tests/harness.rs
   59 impl    59 total  crates/vpt-adapters/src/config/schema/types.rs
    0 impl    58 total  crates/vpt/tests/usage.rs
   57 impl    57 total  crates/vpt-adapters/src/config/schema/dynamic.rs
   33 impl    33 total  crates/vpt/src/lib.rs
   12 impl    27 total  crates/vpt-protocol/src/result.rs
   17 impl    17 total  crates/vpt/src/commands/version.rs
    7 impl     7 total  crates/vpt-adapters/src/config/mod.rs
    4 impl     4 total  crates/vpt/src/bin/vpt-fake-engine.rs
    3 impl     3 total  crates/vpt/src/main.rs
    2 impl     2 total  crates/vpt-protocol/src/lib.rs
    2 impl     2 total  crates/vpt/src/cli/mod.rs
    1 impl     1 total  crates/vpt-adapters/src/lib.rs
    1 impl     1 total  crates/vpt-application/src/lib.rs
    1 impl     1 total  crates/vpt-domain/src/lib.rs
    1 impl     1 total  crates/vpt/src/commands/mod.rs
```

The 471-line schema exceeds the decomposition threshold. It is one declarative table, with its type definitions and dynamic lookup already separated; retaining the table keeps the required authoritative key list readable and contiguous. It contains no policy branches or compressed macros. The private 304-line test file slightly exceeds the 300-line target and remains below the 400-line decomposition threshold; its cases cover the loader's one public boundary. Every file stays below the hard 500-line limit. No lint suppression or size waiver was added.

No known Task 3 behavior defect remains. Controller review is pending; later validation/settings/database work has not started.
