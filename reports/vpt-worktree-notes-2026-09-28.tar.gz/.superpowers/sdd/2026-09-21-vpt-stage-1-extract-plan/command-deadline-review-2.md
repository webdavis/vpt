# Command watchdog evidence re-review

Verdict: Needs fixes, procedural compliance pending controller adjudication. No blocking source defect found, and final gates are verified. The recovered original tool records resolve Finding 1 in `command-deadline-review-1.md`, but establish a separate source-first change: the absent-pipe diagnostic guards preceded their behavioral test. This review grants no test-first waiver and requests no rerun or cosmetic rewrite to manufacture historical compliance. The controller owns that process decision, acceptance and committed-HEAD verification.

## Recovered source

Controller disposition, 2026-09-26: the operator explicitly approved the narrow process exception for
the absent-pipe diagnostic guards. This resolves the procedural acceptance gate without changing the
historical chronology or treating the later test as prior RED evidence. No source fix or repeat review
is required by the findings. Root committed the six reviewed files as
`b48c3dcb87c5474edc0b848ec572d3a3d6514830`. Its fresh full gate passes all 331 leaves after integration
with the independently accepted config slice, with the exact expected union of leaf names and a clean
105-commit secrets scan. See `command-watchdog-controller-ship-01.log`. The tracked worktree is clean.

Read the task-specific command, patch and result records in `/Users/stephen/.codex/sessions/2026/09/26/rollout-2026-09-26T17-52-09-01a0e022-2774-7bb2-bad6-91e3b276eab9.jsonl`. The identifiers below are the original result chunks and JSON record `ordinal` values, not reconstructed output. This review copied no session context into the repository and ran no tests or builds.

## Compiling initial REDs

The test additions are in patch records 209 and 252. Each named result below reaches the test executable and fails its intended assertion. These results precede the collector implementation at record 275 and the terminal diagnostics and strict classifier at record 305.

| Regression | Original result | Observed failure |
| --- | --- | --- |
| Late completion | `5ef391`, record 219 | Completed output returned at 501.025416 ms. |
| Command diagnostic | `a63c8a`, record 226 | Bare timeout panic lacks the required record. |
| Exit before prompt | `b4a15c`, record 233 | Missing-prompt panic lacks status and captured output. |
| Timeout classification | `4c20b5`, record 240 | Early version exit is classified as timeout. |
| Terminal byte diagnostic | `0e276d`, record 262 | Raw unbounded terminal prefix lacks the required byte-count fields. |

The terminal commands request scoped terminal access and run the exact named leaves. These are assertion failures after compilation, not permission or compilation failures. The initial RED interval is 2026-09-27 00:05:29 through 00:06:52 UTC; the implementation patches follow at 00:07:55 and 00:08:49 UTC.

## Exact mutations and restored controls

Read the mutation patches, commands, hash results, failing test output, restoration patches and passing controls for every row. Each mutant compiled and exited 101 at the intended assertion. Each restored named control exited 0. The original changed and restored hashes match the execution report's table.

| Mutation | Failed result / record | Restored control / record |
| --- | --- | --- |
| Remove pre-poll guard | `b168d7` / 499 | `2cb07c` / 512 |
| Accept completion before post-poll deadline | `ca0648` / 525 | `7109cc` / 538 |
| Command preview of 65 source bytes | `3e21db` / 551 | `e01849` / 564 |
| Raw command control bytes | `caf367` / 577 | `b02bbf` / 590 |
| Omit command driver phase | `79b8b5` / 605 | `0f72b5` / 618 |
| Omit terminal status | `3a3347` / 633 | `f18b56` / 646 |
| Terminal preview of 65 source bytes | `51a1c9` / 659 | `f27315` / 672 |
| Raw terminal control bytes | `752aa1` / 685 | `8c5dcf` / 698 |
| Route answer-timeout test to version exit | `579f3d` / 718 | `8b7a38` / 731 |
| Timestamp absent stdout as end of file | `57147a` / 987 | `b7d51f` / 1000 |

The ordering mutations restore `support/mod.rs` to `14b8fbbeb565951807e11eda31dfcf68ddb21d52b561fe32153f70d58fa3cc0a`. Later stream-presence guards change it to the final `4d4d4471267478e42deccaf9d14023eeb856a8d9620c832447c466307cc906fc`, which is also the absent-pipe control's restored hash. The timeout-classification mutation restores the then-current `setup.rs` hash `9f5f2cc01298d1c4707c3485ad5c60921bc784813c6bbc782d97646e9cc38471`; record 1072 subsequently strengthens the negative regression's expected missing-prompt outcome. These historical hashes are not presented as the final hashes.

The two additional boundary leaves have a different chronology from the five initial REDs. The during-poll leaf was added at record 461 after the ordering fix. The absent-pipe guard was added at record 947, its leaf at 963, and the removed-guard mutation then failed at 987. They establish later mutation sensitivity, not two additional pre-implementation REDs. The original five test-first claims are verified.

The absent-pipe guard is an unwaived behavior-first deviation. The initial diagnostic test at record 209 creates both stdout and stderr pipes. It checks that `stdout_eof=` and `stderr_eof=` field names occur, but does not assert that an absent pipe has `eof=none`. It therefore did not already cover the guard's observable contract. Record 947 adds both stream-presence guards before a test exercises that state. The subsequent compiling mutation proves that the later test catches the error; it cannot make the earlier implementation test-first. Source correctness and final passing gates do not settle this procedural question.

## Final state and limits

Original final-gate commands at records 1104 and 1111 use normal test parallelism and scoped terminal permission. The timing run uses the installed VPT-local nightly, `--locked --offline`, and `RUSTUP_AUTO_INSTALL=0`. Review 1 already verified their exported output: 325 passing names in each run, all 318 baseline names retained, seven additions, and a maximum measured leaf of 0.574 s.

The original all-target check `f9eaf2`, working-tree secret scan `91090b`, release build `880275` and diff check `e5a2c5` also show exit 0. Record 1143 contains the final six-file source hashes and line counts. A fresh read-only hash check during this review matches all six, including both new files. No product source was changed in this review lane.

The preserved 501.1675 ms spawn-return failure remains real and unattributed. Later passing runs do not establish its cause or eliminate recurrence. It does not independently block this scoped ordering and diagnostic correction. Blocking spawn, polling work, operating-system waits and thread descheduling remain outside the fixture's preemption capability; cleanup-owner panics can still precede the diagnostic.

The provenance document's earlier statement that the raw records were unavailable describes the first review's evidence state. This recovered-record audit supersedes that limitation. The controller should record the recovery alongside that provenance when recording acceptance.
