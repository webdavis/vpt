# D4 execution brief

## Controller constraints

- Test-first checkpoint: before implementing each new behavior group, name its covering leaf and retain a compiling failure for that behavior. Unsupported stubs may make the tests compile; they must not implement other untested behavior in advance. Send the first RED inventory to the controller before implementing that group, and retain the same mapping for later groups. Passing coverage added afterward and retrospective mutants do not substitute for test-first chronology. The D3 review found this exact process violation; no exception to future test-first work is granted.
- D3 independently accepted at clean 3d5b18ed5701b505c68f0ad89fe3e160026ec1be; all 270 baseline leaves pass. The operator-approved historical test-first exception is limited to D3. owner.rs provides the planned Database API and test-only fail_next/short_write_next/consumed. FileState in io.rs owns registration pointer, DatabaseLocks, role, writable and persistent_wal; the four shared-memory methods are currently None. registration/dispatch.rs initializes FileState after checked acquisition. State::run in state.rs owns callback panic containment and the connection-local latch. Reuse these boundaries; do not rebuild the owner or callback framework.
- DatabaseFiles owns the one FaultState. create(role) performs exclusive retained-directory creation and sync before success; open(role, create) falls back on AlreadyExists only. sync() checks the connection-local directory-sync fault before the real retained-root sync. xDelete preserves its requested synchronization. Add the mapping fault to this same slot, with the actual consumed flag, rather than a separate global injector.
- The controller read existing tests/support.rs: snapshot already returns a sorted Vec<Snapshot>, includes every entry and directory, bytes, full mode, device/inode/link count/size, mtime/ctime/nanoseconds/flags, plus uid/gid, and excludes atime. Reuse this interface rather than adding the plan sample's second BTreeMap helper. Strengthen descriptor-safe acquisition as required, preserve all callers and fields, and compare only while writers are quiescent. This controller ruling is recorded in progress.md.
- D3's independently reproduced fixture failure shows that a concurrent fork can temporarily retain an open-file-description lock after the parent closes it, even with close-on-exec. Strict post-close lock-release assertions now create their descriptors inside the existing post-exec supervised child. Apply the same fixture discipline where this task asserts last-close release; do not serialize the suite, retry, increase deadlines or alter production lock behavior. The exact controlled reproducer and repair are in task-D3-report.md.
- Seven D3 item-level staging expectations remain for real D5/D6 consumers, as inventoried in task-D3-report.md and follow-up 6hc7x7wMwxF8R9rg. No earlier D1/D2 expectations remain. Remove an expectation if D4 genuinely consumes the item in production; preserve exact diagnostics and ask for a scoped ruling if a new private staging issue appears. Never widen visibility or create an artificial caller.
- Dispatch only after D3 is independently accepted. Read its actual owner/callback/fault APIs and the approved containment design. Shared mappings and native concurrency are high-risk: Astra implementation and independent Astra review.
- Own only the database shared-memory implementation, required callback/lock/fault changes and focused tests listed below, plus D4 report/evidence. Main owns progress.md and Todoist. You are not alone; preserve others' work. One product writer, no subagents/new worktree, no early D5-D7 implementation.
- Verify the locked SQLite shared-memory protocol and native reference implementation from local primary sources. Retain the read-only-uninitialized descriptor and its usable slot locks; protocol read-only outcomes must not poison the connection latch. Preserve explicit close and mapping ownership.
- Use only synthetic owned databases and the already-green independent watchdog. Supervised children must have isolated environment and an owned working directory. Establish SQL milestones by handshake, never elapsed sleep. Prove injected faults are consumed; snapshot every observational path with writers quiescent.
- Do not modify third-party code or SQLite's system-call table, retry denied probes, use broad process listings, or access live source/destination/database paths. Parent/root replacement is tested at VPT's own boundary only. Contain deliberate bad-pointer or hang mutations in supervised children with core dumps disabled where required.
- Preserve all prior leaves; compiling behavioral RED, meaningful exact compiled mutants, byte-identical restored controls and unique raw logs per attempt. Address survivors. Required Rust/release/staged-size/secrets gates apply; controller owns fresh committed-HEAD ship.
- Existing command-test deadline overruns are tracked as 6hc7MMRc2QhRm75g. Preserve recurrence without retry loops or deadline increases. No install, push, pull request, merge, apply or destructive cleanup. Verify buffer safety and use apply_patch.

## Approved D4 task

## D4: Shared memory, WAL concurrency and recovery

**Files:** Create `database/shared_memory.rs`, `database/tests/wal.rs` and `database/tests/failures.rs`;
modify `database/io.rs`, `database/registration.rs`, `database/locks.rs`, `database/faults.rs`,
`database/tests/children.rs` and test support.

**Interfaces:** A private `SharedMemory` owns its independently opened companion file, initialization
lock, mappings, retained directory authority and held slot locks.
`SharedMemory::open(files: &DatabaseFiles) -> Result<Self, DatabaseError>` acquires these through D1's
policy. Its `map(region: i32, size: i32, extend: bool) -> Result<MappedRegion, DatabaseError>` returns
one of these explicit outcomes:

```rust
enum Initialization { Acquired, ReadOnlyUninitialized }
enum MappedRegion {
    Missing,
    ReadOnlyUninitialized,
    ReadOnly(std::ptr::NonNull<std::ffi::c_void>),
    Writable(std::ptr::NonNull<std::ffi::c_void>),
}
```

`Initialization` is retained with the shared-memory file. A read-only uninitialized file is a successful
open of that state, not an error that drops the descriptor.
`lock(offset: i32, count: i32, flags: i32) -> Result<(), DatabaseError>` checks SQLite's shared-memory
flags; `barrier()` supplies the required memory ordering;
`unmap(delete: bool) -> Result<(), DatabaseError>` releases mappings and locks, then applies policy and
persistence rules to any deletion. `io.rs` translates `Missing` to null/success, `ReadOnlyUninitialized`
to null/`SQLITE_READONLY_CANTINIT`, `ReadOnly` to the address/`SQLITE_READONLY`, and `Writable` to the
address/success. These protocol outcomes do not poison the error latch.

- [ ] **Step 1: Write compiling red snapshot tests.**

```rust
#[test]
fn a_reader_keeps_its_snapshot_while_a_writer_commits() {
    let (_temp, root) = root();
    let mut writer = Database::open(root.try_clone().unwrap(), Path::new("vpt.db"),
        AccessPolicy::WritableLedger, Duration::from_millis(20)).unwrap();
    writer.with_connection::<_, DatabaseError>(|c| {
        c.execute_batch("PRAGMA journal_mode=WAL; CREATE TABLE item(value INTEGER);
            INSERT INTO item VALUES (1);")?;
        Ok(())
    }).unwrap();
    let mut reader = Database::open(root, Path::new("vpt.db"),
        AccessPolicy::ObservationalLedger, Duration::from_millis(20)).unwrap();
    reader.with_connection::<_, DatabaseError>(|c| {
        c.execute_batch("BEGIN")?;
        let first: i64 = c.query_row("SELECT sum(value) FROM item", [], |r| r.get(0))?;
        assert_eq!(first, 1);
        writer.with_connection::<_, DatabaseError>(|w| {
            w.execute("INSERT INTO item VALUES (2)", [])?;
            Ok(())
        })?;
        let pinned: i64 = c.query_row("SELECT sum(value) FROM item", [], |r| r.get(0))?;
        assert_eq!(pinned, 1);
        c.execute_batch("COMMIT")?;
        let latest: i64 = c.query_row("SELECT sum(value) FROM item", [], |r| r.get(0))?;
        assert_eq!(latest, 3);
        Ok(())
    }).unwrap();
    reader.try_close().unwrap();
    writer.try_close().unwrap();
}
```

Extend test support with `snapshot(root: &Path) -> BTreeMap<OsString, FileSnapshot>`. `FileSnapshot`
derives `Debug, PartialEq, Eq` and records bytes, entry kind, device/inode, mode, link count, size,
mtime/nanoseconds, ctime/nanoseconds and flags. Include directory metadata and entries; exclude atime.
Use descriptor-safe reads of the synthetic tree, with writers quiescent around each comparison. Run a
readonly query and close between snapshots after the last writer has closed, with the writer still alive,
with missing companions, and with recovery required. Each gets its own leaf.

Extend D3's connection-local faults with `Fault::Map`, returning `EIO` before a mapping. Keep all
injection at VPT's own operation boundary; do not change SQLite or its system-call table.

- [ ] **Step 2: Run WAL tests red.**

```bash
cargo test --locked -p vpt-adapters database::tests::wal -- --nocapture
cargo test --locked -p vpt-adapters database::tests::failures -- --nocapture
```

Expected: WAL operations fail with the unimplemented shared-memory methods, not a compile error. All
contention/crash scenarios use the already-green process watchdog.

- [ ] **Step 3: Implement shared-memory initialization, mapping and locks.**

```rust
const SHM_LOCK_BASE: i64 = 120;
const SHM_LOCK_COUNT: i32 = 8;
const SHM_LIFETIME_BYTE: i64 = 128;
const SHM_REGION_BYTES: usize = 32 * 1024;
```

Use descriptor-owned locks on these native-compatible bytes. Slots 0, 1 and 2 coordinate writer,
checkpoint and recovery; slots 3 through 7 protect readers. Shared locks cover one slot; exclusive locks
may cover a checked contiguous range. Reject invalid flag combinations, ranges and upgrades that SQLite's
contract does not allow. The shared-memory descriptor must be separate from the database descriptor and
remain open for the mappings' lifetime.

Initialization follows the pinned native protocol:

1. Inspect byte 128 for a conflicting exclusive holder. That holder means busy.
1. With an existing shared lifetime holder, acquire a shared lifetime lock and use its initialized file.
1. With no lifetime holder and writable shared memory, acquire exclusive byte 128, invalidate stale
   shared memory by truncating to the pinned implementation's three-byte initialization length, then
   downgrade to shared. Recheck after a raced acquisition; do not truncate under another holder.
1. With no lifetime holder and read-only shared memory, retain the descriptor without a lifetime lock as
   `ReadOnlyUninitialized`. Mapping reports `SQLITE_READONLY_CANTINIT`, allowing SQLite's heap-index
   recovery. Later mapping calls retry initialization and transition to `Acquired` only after a
   successful shared lifetime lock. Slot locking remains available through the retained descriptor
   without requiring that transition. Never create a fake initialized state or repair the file.

Map regions with checked arithmetic and host page alignment. Provision a writable region before mapping
so reads cannot fault beyond the file. Use `PROT_READ` for observational policies and add `PROT_WRITE`
only where the policy permits. A missing region with `extend=false` returns null and success. Once a
connection reports read-only shared memory, keep that mode until unmap. Honor the requested region size;
reject unsupported sizes rather than silently mapping a different layout. Implement the cross-process
synchronization barrier with the platform memory fence required by SQLite, then release locks and
mappings in reverse acquisition order on every error path.

Persistent WAL preserves companion entries on close; it does not prohibit writable checkpointing or
truncation. SQLite owns transaction, reader-mark and checkpoint decisions. The adapter enforces access
policy on every write/truncate/map/delete so an observational connection cannot perform recovery that
requires writes.

- [ ] **Step 4: Add native interoperability, crash and durability assertions.**

Use child scenarios `native_writer`, `native_reader`, `rooted_uncommitted` and `rooted_committed` in
`tests/children.rs`. They select one synthetic database, announce a completed SQL milestone through the
pipe, then wait for a command. Test both native-to-rooted and rooted-to-native reads, WAL snapshots and
writer contention. Terminate the two rooted crash scenarios only after their milestone; writable reopen
must respectively exclude the uncommitted row and retain the committed row. No sleep determines when the
transaction is ready.

For write, partial-write and file-sync faults, record rows before the transaction, inject at the named
operation, attempt a two-row transaction, assert failure, close and reopen writable, then assert that no
partial pair exists. Trigger directory-sync failure on a newly created rollback journal, truncate failure
during journal finalization, and map failure during the first WAL read. Assert the fault was consumed in
every case; a dormant fault is not evidence. A failed commit may be absent or fully present according to
SQLite's documented commit point; it must never be reported successful after the injected failure. Check
database integrity and successful subsequent transactions. Test interrupted rollback-journal recovery as
well as WAL.

Add individual shared-memory leaves for lifetime initialization racing another opener, read-only
initialization refusal, missing region without extension, multi-region mapping, map failure cleanup, slot
contention and connection-close lock retention. Test busy waits with a 20 ms implementation timeout and
the independent 500 ms watchdog.

Pin the uninitialized read-only path with committed frames still in the WAL after its last writer closes:
retain slot-lock functionality, read through SQLite's heap index, and leave the snapshot unchanged.
Mutate dropping that retained state to prove the case matters. Mutate the read-only checkpoint-on-close
setting and require the normal successful-close test to catch the unwanted probe.

- [ ] **Step 5: Verify green, mutations and independent review.**

Mutate one shared-memory lock offset, enable write protection on an observational map, suppress a sync
failure, remove persistent companions, and release another connection's lock. The matching leaves must
fail. Repeat the busy-bound hang control through a real WAL transaction. Restore exact bytes and run each
control. Request independent review of byte ranges, initialization, mapped-memory lifetime and close
cleanup before continuing to D5.

```bash
cargo fmt --all
cargo test --locked -p vpt-adapters database
cargo clippy --locked -p vpt-adapters --all-targets -- -D warnings
git add crates/vpt-adapters/src/database
git commit -m "feat(database): support contained concurrent WAL access"
```
