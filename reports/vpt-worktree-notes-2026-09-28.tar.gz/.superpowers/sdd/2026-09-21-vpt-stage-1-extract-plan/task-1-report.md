# Task 1 implementation report

Status: DONE, pending controller review.
Commit: `43cc9c01f9a2968925c4aae4dbb21ae1ff6144d7`.

## Scope and interfaces

Implemented the first buildable Stage 1 slice on `feat/stage-1-extract`, from
`9ad7c3e1980c7fc0c40c47803dcad21e8649f3ee`. This is new behavior, developed test first.
Baseline had no implementation or tests, so the baseline leaf-test set is empty.

The workspace contains the five required crates. Dependencies are inward:
`vpt-application` uses `vpt-domain`; `vpt-adapters` uses application, domain and protocol;
`vpt` composes all four. Domain has no dependencies; protocol has no workspace dependencies.
The only public command-crate export is `vpt::run() -> !`. Internal parser, version and test-support
interfaces match the task brief. The fake engine remains behind `dev-tools`.

`--version` emits one human line or one `vpt.result/1` document. Unknown arguments return 2 with
usage on stderr. A stdout write failure returns 1. The parser handles all planned Stage 1 forms.
Other verbs retain the task's explicit unimplemented response; helper discovery, configuration
loading and structured error documents belong to later tasks. README claims only this implemented
slice and labels both installation steps as planned. No later-stage capability is claimed.

No old entry points, persistent state, filesystem protocols, generated files, oversized files or
external consumers were migrated. The controller's preflight found no external VPT consumers.
No file outside this worktree changed. The approved specification, plan and earlier reports remain
untouched. No package installation, apply, live destination, push or pull request was performed.

## Controller rulings and implementation choices

- `tempfile::TempDir` owns a unique sandbox. No deterministic scratch removal remains.
- Every VPT command clears its environment and sets private HOME, all required XDG roots,
  VPT_CONFIG and PATH. Its stdin defaults to null; stdout and stderr default to pipes and caller
  overrides remain intact.
- The acceptance runner owns a new process group, drains output concurrently, polls a 500 ms
  deadline, terminates the group, force-kills survivors after up to 50 ms, reaps its child, and joins
  its reader threads. Commands over 200 ms warn; commands over one second fail.
- A real shell plus a 30-second sleep descendant proves deadline cleanup. Both recorded process IDs
  must be absent before the regression passes. The suite completes this test in about 0.51 s.
- A closed-peer UnixStream tests stdout failure. The earlier read-only descriptor fixture returned
  status 0 even with the error branch present and was removed. Local Rust source was unavailable, so
  no claim about its internal EBADF handling is made. Only the closed-peer red/green is evidence
  for the final branch.
- Value flags are validated against original adjacent tokens before removing any global flags.
  This covers `--config`, `--once` and `--stage` consistently.
- Non-UTF-8 arguments are explicitly refused with a usage error. This is the smaller permitted
  choice, and prevents silently substituting path bytes.
- `just test-rust` aliases `test`; `just lint-check` depends on `fmt` and `clippy`.
- No lint suppression or unsolicited module docstring was added. README received the humanizer pass.

## Leaf-test inventory

All are new, permanent tests. All pass in the final full workspace run; none was removed or renamed.

| Test | Final result |
| --- | --- |
| `cli::args::tests::json_and_config_are_global_flags_in_any_position` | PASS |
| `cli::args::tests::an_unknown_verb_is_a_usage_error_naming_it` | PASS |
| `cli::args::tests::a_trailing_unknown_argument_is_refused` | PASS |
| `cli::args::tests::a_value_flag_without_a_value_is_refused` | PASS |
| `cli::args::tests::every_stage_one_verb_decodes_its_arguments` | PASS |
| `cli::args::tests::missing_positionals_subcommands_and_flag_values_are_refused` | PASS |
| `cli::args::tests::global_flags_cannot_fill_missing_value_slots` | PASS |
| `cli::args::tests::non_utf8_paths_are_refused_without_substitution` | PASS |
| `version_reports_the_crate_version_and_no_helper_when_the_path_is_empty` | PASS |
| `version_without_json_prints_one_human_line` | PASS |
| `a_stdout_write_failure_exits_one` | PASS |
| `an_unknown_verb_prints_usage_to_stderr_and_exits_2` | PASS |
| `watchdog_terminates_the_hanging_group_and_reaps_its_child` | PASS |
| `runner_captures_output_and_exit_status` | PASS |

The eight unit tests finish together in 0.00 s, the two harness tests in 0.51 s, usage in 0.01 s,
and the three version tests in 0.02 s in the last workspace run. Thus each test is below one second.

## Red and green evidence

All logs are in this report's directory. Commands ran from the worktree root. Pipelines used
`set -o pipefail`; exit codes below are command exits, including expected failures.

| Command | Exit | Evidence |
| --- | --- | --- |
| `cargo test --offline -p vpt --test version --test usage` | 101 | `task-1-red-acceptance.log`: usage missing; cargo stopped before version |
| `cargo test --offline -p vpt --test version --test usage --no-fail-fast` | 101 | `task-1-red-acceptance-all.log`: all three specified acceptance tests fail for missing output/dispatch |
| `cargo test --offline -p vpt --lib` | 101 | `task-1-red-unit.log`: four assertions fail against compiling parser stub |
| `cargo test --offline -p vpt --lib --test harness --no-fail-fast` | 101 | `task-1-red-harness-and-parser.log`: six parser tests and two harness tests fail against stubs |
| `cargo test --offline -p vpt --test version a_stdout_write_failure_exits_one -- --exact` | 101 | `task-1-red-write-error.log`: runner stub failure, excluded as write-error evidence |
| `cargo test --offline -p vpt --no-fail-fast` | 101 | `task-1-first-implementation.log`: config adjacency and stdout error regressions fail; other tests pass |
| `cargo test --offline --locked --workspace --no-fail-fast --features dev-tools` | 101 | `task-1-first-green.log`: despite the filename, this run failed on the inconclusive read-only descriptor fixture |
| `cargo test --offline -p vpt --test version a_stdout_write_failure_exits_one -- --exact` | 101 | `task-1-red-broken-pipe.log`: closed peer with error ignored yields 0, expected 1 |
| `cargo test --offline --locked --workspace --no-fail-fast --features dev-tools` | 0 | `task-1-green-control.log`: first full green, twelve tests at that point |
| `cargo test --offline --locked -p vpt --lib --no-fail-fast` | 101 | `task-1-red-parser-boundaries.log`: original adjacency and non-UTF-8 tests fail on successful malformed parses |
| `cargo test --offline --locked -p vpt --lib` | 0 | `task-1-green-parser-boundaries.log`: all eight parser tests pass |

## Mutation verification

Each mutation was applied with `apply_patch`; `rg -n` displayed its actual bytes before the run.
All mutations were restored with `apply_patch` before final gates. The green controls are the full
workspace control above, the parser boundary control, and the final full ship/alias runs below.

| Source mutation | Command and result | Named failure evidence |
| --- | --- | --- |
| Add an endless 30-second sleep loop at the start of `vpt::run` | `cargo test --offline --locked -p vpt --test version --test usage --no-fail-fast`, exit 101 | All four selected acceptance tests fail with `command exceeded 500 ms deadline`, about 501 to 502 ms each; `task-1-mutation-hanging-composition.log` |
| Consume `--json` but force its parsed value to false | `cargo test --offline --locked -p vpt --lib`, exit 101 | `json_and_config_are_global_flags_in_any_position` and `every_stage_one_verb_decodes_its_arguments` fail their json assertions |
| Disable the original-adjacency guard | Same parser run | `global_flags_cannot_fill_missing_value_slots` receives a successful malformed ingest instead of a usage error |
| Restore lossy argument conversion | Same parser run | `non_utf8_paths_are_refused_without_substitution` receives a substituted config path instead of refusal |
| Ignore leftover arguments | Same parser run | `a_trailing_unknown_argument_is_refused` receives a successful doctor invocation; all four parser mutations are in `task-1-mutation-parser.log` |
| Change version schema to `vpt.result/99` | `cargo test --offline --locked -p vpt --test version`, exit 101 | `version_reports_the_crate_version_and_no_helper_when_the_path_is_empty` fails exact schema assertion |
| Print `helper present` when absent | Same version run | `version_without_json_prints_one_human_line` fails exact human output assertion |
| Return 0 after a write error | Same version run | `a_stdout_write_failure_exits_one` fails 0 versus 1; all three output mutations are in `task-1-mutation-version-and-write.log` |

## Final gates

| Command | Exit | Evidence |
| --- | --- | --- |
| `cargo fmt --all` | 0 | Formatting completed before staging |
| `CARGO_NET_OFFLINE=true just ship` | 0 | `task-1-ship.log`: format, all-target Clippy with denied warnings, full workspace tests, docs with denied warnings, gitleaks and file-size |
| `CARGO_NET_OFFLINE=true just lint-check test-rust` | 0 | `task-1-required-alias-gates.log`: all fourteen named tests pass |
| `cargo check --offline --locked --workspace --all-targets --features dev-tools` | 0 | All five crates checked |
| `cargo build --offline --locked` | 0 | The documented normal build succeeds |
| `actionlint .github/workflows/ci.yml` | 0 | Workflow validated |
| `just --show file-size \| sed '1d;s/^    //' \| shellcheck -s bash -` | 0 | File-size shell recipe validated; real recipe ran in ship |
| `git -c core.fsmonitor=false diff --cached --check` | 0 | No staged whitespace errors |
| `git -c core.fsmonitor=false diff --check` | 0 | No unstaged whitespace errors |

No test or lint failure remains. The expected 500 ms watchdog case emits the support module's slow
command warning when test output is displayed. It is below the one-second ceiling.

## File-size audit

The skill's exact physical-line algorithm ran after staging all task-owned Rust sources. The only
command spelling adaptation is the required `-c core.fsmonitor=false` git option:

```bash
git -c core.fsmonitor=false ls-files 'crates/*.rs' | while IFS= read -r f; do
  awk -v F="$f" '
    /^[[:space:]]*#\[cfg\(test\)\]/ && !seen { seen = 1 }
    !seen { impl++ }
    { total++ }
    END {
      if (F ~ /(^|\/)tests(\.rs|\/)/) impl = 0
      printf "%5d impl %5d total  %s\n", impl, total, F
    }' "$f"
done | sort -k3,3rn
```

Exit 0. Full output: `task-1-file-size.log`.

```text
  135 impl   280 total  crates/vpt/src/cli/args.rs
    0 impl   125 total  crates/vpt/tests/support/mod.rs
    0 impl    58 total  crates/vpt/tests/harness.rs
    0 impl    40 total  crates/vpt/tests/version.rs
   37 impl    37 total  crates/vpt/src/lib.rs
   19 impl    19 total  crates/vpt/src/commands/version.rs
    0 impl    14 total  crates/vpt/tests/usage.rs
    4 impl     4 total  crates/vpt/src/bin/vpt-fake-engine.rs
    3 impl     3 total  crates/vpt/src/main.rs
    1 impl     1 total  crates/vpt-adapters/src/lib.rs
    1 impl     1 total  crates/vpt-application/src/lib.rs
    1 impl     1 total  crates/vpt-domain/src/lib.rs
    1 impl     1 total  crates/vpt-protocol/src/lib.rs
    1 impl     1 total  crates/vpt/src/cli/mod.rs
    1 impl     1 total  crates/vpt/src/commands/mod.rs
```

No file exceeds a review threshold. The empty role crates are explicitly required by Task 1.

## Self-review and handoff

Read the staged parser, dispatcher, test support, watchdog, README, justfile and workflow diffs.
Checked manifests, module visibility, no broad suppressions, feature-gated test binary and clean
whitespace. The architecture introduces no ports or state before their planned tasks. User-facing
version output is black-box tested through the composition root, including a real hang mutation.
Staging contains only the 26 Task 1 files. No independent reviewer or subagent was launched.

No unresolved Task 1 concern. The controller owns independent review and subsequent tasks. No live
operator verification is needed for this version-only slice.

Commit command: `SKIP_AI_COMMIT=1 git -c core.fsmonitor=false commit -m 'feat: scaffold workspace and vpt version command'`, exit 0. Normal hooks were enabled. Post-commit status was clean, and the commit contains the 26 task-owned files with no attribution trailer.

Post-commit `gitleaks git --no-banner` exited 0 and scanned all 83 commits, including this task's
commit, with no leaks. Evidence: `task-1-post-commit-secrets.log`.

## Fix round 1: fallible diagnostics

Fix base: `43cc9c01f9a2968925c4aae4dbb21ae1ff6144d7`.
Addresses review finding F1 in `task-1-review-1.md` and the controller's diagnostic-write ruling.

All three diagnostics in `src/lib.rs` now use one fallible `diagnostic` function. Successful writes
preserve the requested status. A failed stderr write returns 1. The stdout failure path also uses
this function, so simultaneous stdout/stderr failure returns 1 without panicking. Only this source
file and the two existing acceptance test files changed.

The original fourteen tests remain unchanged and passing. These three permanent regression tests
were added with closed-peer sockets inside the existing bounded sandbox:

- `unknown_input_with_broken_stderr_exits_one`
- `unimplemented_verb_with_broken_stderr_exits_one`
- `version_with_both_output_streams_broken_exits_one`

| Check | Command | Exit and evidence |
| --- | --- | --- |
| RED, before source edits | `cargo test --offline --locked -p vpt --test usage --test version --no-fail-fast` | 101; all three new cases got 101 instead of 1; the four existing cases passed; `task-1-fix-1-red.log` |
| GREEN | Same acceptance command | 0; all seven cases pass; `task-1-fix-1-green.log` |
| Mutation | `cargo test --offline --locked -p vpt --test usage --test version --no-fail-fast broken` | 101; exactly the three new cases selected and failed 101 versus 1; `task-1-fix-1-mutation.log` |
| Full ship | `CARGO_NET_OFFLINE=true just ship` | 0; 17 tests pass, format, all-target Clippy and docs deny warnings, secrets and size checks pass; `task-1-fix-1-ship.log` |
| Required aliases | `CARGO_NET_OFFLINE=true just lint-check test-rust` | 0; full suite passes again; `task-1-fix-1-alias-gates.log` |
| All-target check | `cargo check --offline --locked --workspace --all-targets --features dev-tools` | 0 |
| Normal build | `cargo build --offline --locked` | 0 |
| Workflow | `actionlint .github/workflows/ci.yml` | 0 |
| Shell recipe | `just --show file-size \| sed '1d;s/^    //' \| shellcheck -s bash -` | 0 |
| Diff whitespace | `git -c core.fsmonitor=false diff --cached --check` | 0 |

The mutation replaced the diagnostic function's handled write with
`write_all(text.as_bytes()).expect("mutated diagnostic write")`. `rg -n -A 3 '^fn diagnostic'`
displayed that exact edit on disk before the run. It was restored before the final gates.
All new acceptance cases finish within their 0.01-second suite totals; the watchdog suite remains
0.51 seconds. No failing check remains.

The same exact file-size command documented above ran after staging these three files, exit 0.
Full evidence: `task-1-fix-1-file-size.log`. Changed file measurements:

```text
   41 impl    41 total  crates/vpt/src/lib.rs
    0 impl    36 total  crates/vpt/tests/usage.rs
    0 impl    53 total  crates/vpt/tests/version.rs
```

All other file measurements are unchanged. Self-review checked the complete three-file staged diff,
the shared diagnostic routing, preservation of existing output text, and the source-only scope.
No controller evidence or earlier report content was changed. No unresolved fix-round concern.

Amended commit: `b5f818d3f1a3fa97d6bc40fc68861266216fb6c9`. Before amending, an exact HEAD
comparison confirmed the fix base above was still current. `SKIP_AI_COMMIT=1 git -c
core.fsmonitor=false commit --amend --no-edit` exited 0 with normal hooks enabled. The worktree is
clean. Post-amend `gitleaks git --no-banner` exited 0 with no leaks across 83 commits; evidence is
`task-1-fix-1-post-amend-secrets.log`.
