# Command watchdog evidence provenance

## Controller recovery, 2026-09-26

The original tool records were recovered from
`/Users/stephen/.codex/sessions/2026/09/26/rollout-2026-09-26T17-52-09-01a0e022-2774-7bb2-bad6-91e3b276eab9.jsonl`.
Its session metadata identifies the implementing agent and this controller as its parent. Independent
review 2 verifies the five initial compiling REDs, all ten compiled mutations and exact restored
controls, final gates and source hashes. The export limitation below describes the earlier handoff,
not the currently available evidence. Review 2 separately records that the absent-pipe diagnostic fix
preceded its regression test; that sequence is not labeled test-first. The operator explicitly selected
"Accept this narrow exception" on 2026-09-26. It applies only to the absent-pipe diagnostic guards;
future behavior remains test-first. Root may commit the reviewed source and run the fresh
committed-HEAD gate. The original chronology and the unexplained spawn-return failure remain recorded.

## Initial export

The two `.tool-output.log` files are byte-for-byte exports of the `output` fields retained by the original command tool results. Each original result ended with a newline, and the exported byte counts match the retained string lengths. No test was rerun for this handoff. Both commands ran against the six source hashes listed in `command-deadline-execution-report.md`; those hashes were rechecked before export.

| Evidence file | Original tool result | Command | Exit | Bytes | SHA-256 |
| --- | --- | --- | ---: | ---: | --- |
| `command-watchdog-final-ship.tool-output.log` | `accepted_ship_result`, chunk `83f17d` | `just ship` | 0 | 30,717 | `c9ac10f60527b52fe85f2ea9744b06cdee67ed5da50a8266cf306a3797bbab8a` |
| `command-watchdog-final-nightly.tool-output.log` | `accepted_nightly_result`, chunk `c17ee8` | `env RUSTUP_HOME=/Users/stephen/.herdr/worktrees/vpt/feat-stage-1-extract/.superpowers/toolchains/rustup RUSTUP_AUTO_INSTALL=0 cargo +nightly test --locked --offline --workspace --no-fail-fast --features dev-tools -- -Z unstable-options --report-time` | 0 | 34,155 | `35c601b6ece9bab31e7dddc0e7b02ab97994ed61b7df5ea407f6d643c7642594` |

The initial RED and mutation outputs were displayed in the original agent tool transcript but were not retained in tool-result storage or a raw disk log. The tables below are pointers to those original results, not reconstructed raw output. Their observations and source hashes in `command-deadline-execution-report.md` are transcriptions, not substitutes for a raw log. There is no available transcript-retrieval tool. Rerunning the tests would create new evidence, not recover the original output.

| Initial compiling RED leaf | Original tool chunk | Exit |
| --- | --- | ---: |
| `late_completion_observed_after_deadline_is_rejected` | `5ef391` | 101 |
| `watchdog_timeout_reports_bounded_capture_and_phase` | `a63c8a` | 101 |
| `setup_terminal_exit_before_prompt_reports_status_and_output` | `b4a15c` | 101 |
| `setup_terminal_timeout_assertion_rejects_pre_prompt_exit` | `4c20b5` | 101 |
| `setup_terminal_missing_prompt_escapes_and_bounds_captured_bytes` | `0e276d` | 101 |

| Source mutation, as described in execution report | Mutant failure chunk | Restored control chunk |
| --- | --- | --- |
| Remove pre-poll deadline guard | `b168d7` | `2cb07c` |
| Accept completion before post-poll deadline | `ca0648` | `7109cc` |
| Preview 65 command source bytes | `3e21db` | `e01849` |
| Emit raw command control bytes | `caf367` | `b02bbf` |
| Omit command driver phase | `79b8b5` | `0f72b5` |
| Omit terminal child status | `3a3347` | `f18b56` |
| Preview 65 terminal source bytes | `51a1c9` | `f27315` |
| Emit raw terminal control bytes | `752aa1` | `8c5dcf` |
| Route answer-timeout leaf to early version exit | `579f3d` | `8b7a38` |
| Timestamp absent stdout pipe as EOF | `57147a` | `b7d51f` |

The existing `command-watchdog-harness-green-failure.log` is a copied full transcript of the naturally failed harness GREEN attempt. Other final checks have transcript-only exit results: all-target check `f9eaf2`, release build `880275`, worktree secret scan `91090b`, and `git diff --check` `e5a2c5`, all exit 0. The final `just ship` raw output includes its constituent formatting, lint, test, documentation, history secret-scan and file-size gates.
