### Task 23: Dry run, `--once`, and the aborts

**Files:**

- Modify: `crates/vpt-application/src/ingest/mod.rs`, `crates/vpt-application/src/ingest/candidate.rs`,
  `crates/vpt-application/src/ports/recorder.rs`, `crates/vpt-adapters/src/voice_memos/store.rs`,
  `crates/vpt-adapters/tests/support/fakes.rs`
- Test: `crates/vpt-adapters/tests/ingest_modes.rs`

**Interfaces:**

- Produces on `RecorderStore`:
  `fn digest(&self, handle: &Self::Handle) -> Result<Sha256Digest, RecorderError>`; dry-run hashes the
  validated source descriptor, rechecks its metadata, and looks up its current digest. Extend
  `ports/recorder.rs`, `voice_memos/store.rs` and the existing `ProbeStore` forwarding implementation.

- Consumes: `Mode { dry_run, once }` from Task 19, `RecordingLedger::{seen_all, by_digest}`.

- Produces: `Ingest::would_ingest(&self, candidate: &Candidate, digest: &Sha256Digest,`
  `report: &mut IngestReport) -> Result<(), IngestFailure>` (private); the empty-store abort; the dry
  run's rule set: every gate runs, nothing is staged, recorded, refreshed or notified, a known
  recording's title comes from the ledger through `by_digest` and a ledger failure there fails the run.

- [ ] **Step 1: Write the failing tests**

`crates/vpt-adapters/tests/ingest_modes.rs`:

```rust
mod support;

use std::os::macos::fs::MetadataExt;
use support::{CAPTURED, Fixture, Parts, clock, digest_of};
use vpt_application::ports::{Archive, RecordingLedger, TitleOrigin};
use vpt_application::{IngestFailure, Mode};
use vpt_domain::fixtures::m4a;
use vpt_domain::identity::RecordingId;
use vpt_domain::notification::EventKind;
use vpt_domain::time::UtcInstant;

const DRY: Mode = Mode { dry_run: true, once: None };

fn copy_snapshot(fixture: &Fixture) -> Vec<(String, Vec<u8>, i64, i64, u32)> {
    let dir = fixture.state.join("title-copy");
    let mut entries: Vec<_> = std::fs::read_dir(&dir)
        .expect("copy dir")
        .map(|entry| {
            let entry = entry.expect("entry");
            let metadata = entry.metadata().expect("metadata");
            let bytes = std::fs::read(entry.path()).expect("bytes");
            (entry.file_name().to_string_lossy().into_owned(), bytes, metadata.st_mtime(), metadata.st_mtime_nsec(), metadata.st_mode())
        })
        .collect();
    entries.sort();
    entries
}

#[test]
fn a_dry_run_runs_every_gate_and_writes_nothing_durable() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    let whole = m4a(CAPTURED, 1, b"payload");
    fixture.add_recording("broken.m4a", &whole[..whole.len() - 12]);
    let orphan = m4a(CAPTURED, 2, b"orphan");
    let orphan_id = RecordingId::derive(UtcInstant { secs: CAPTURED }, clock().offset, &digest_of(&orphan)).expect("id");
    std::fs::write(fixture.audio.join(format!("{orphan_id}.m4a")), &orphan).expect("orphan");
    let mut parts = fixture.parts();
    parts.store = fixture.titled_store(false);

    let report = parts.ingest().run(&DRY).expect("dry run");

    assert_eq!(report.would_ingest.len(), 1);
    assert_eq!(report.would_ingest[0].path, fixture.recordings.join("a.m4a"));
    assert_eq!(report.would_ingest[0].title_source, TitleOrigin::Unavailable);
    assert_eq!(report.deferred.len(), 1);
    assert!(report.recovered.is_empty(), "a dry run recovers nothing");
    assert_eq!(parts.archive.archived().expect("archived").len(), 1, "the orphan is untouched");
    assert!(parts.archive.staged_leftovers().expect("leftovers").is_empty());
    assert!(parts.ledger.seen_all().expect("seen").is_empty(), "a dry run records no deferral");
    assert!(parts.ledger.recordings().expect("list").is_empty());
    assert!(parts.events().is_empty());
    assert!(!fixture.state.join("title-copy").exists());
}

#[test]
fn a_dry_run_does_not_apply_the_previous_recording_title_to_edited_bytes() {
    let fixture = Fixture::new();
    let source = fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    fixture.add_title("a.m4a", "Alpha");
    let mut parts = fixture.parts();
    parts.store = fixture.titled_store(true);
    parts.ingest().run(&Mode::default()).expect("a real sweep records the title");
    fixture.add_title("b.m4a", "Beta, never copied");
    std::fs::write(&source, m4a(CAPTURED + 30, 1, b"edited")).expect("edit");
    fixture.set_mtime(&source, clock().now.secs - 60);
    let before = copy_snapshot(&fixture);
    let dry = Parts { store: fixture.titled_store(false), ..fixture.parts() };

    let report = dry.ingest().run(&DRY).expect("dry run");

    assert_eq!(report.would_ingest.len(), 1);
    assert_eq!(report.would_ingest[0].title, None);
    assert_eq!(report.would_ingest[0].title_source, TitleOrigin::Unavailable);
    assert_eq!(copy_snapshot(&fixture), before);
    assert_eq!(dry.ledger.recordings().expect("list").len(), 1);
    assert!(dry.events().is_empty());
}

#[test]
fn a_dry_run_on_an_unreadable_source_fails_without_an_event() {
    let fixture = Fixture::new();
    let parts = fixture.parts();
    std::fs::remove_dir_all(&fixture.recordings).expect("test setup only");

    let error = parts.ingest().run(&DRY).unwrap_err();

    assert!(matches!(error.failure, IngestFailure::StoreUnreadable(_)), "{error:?}");
    assert!(parts.events().is_empty());
}

#[test]
fn once_runs_the_gates_and_touches_nothing_else() {
    let fixture = Fixture::new();
    let whole = m4a(CAPTURED, 1, b"payload");
    let broken = fixture.add_recording("broken.m4a", &whole[..whole.len() - 12]);
    fixture.add_recording("other.m4a", &m4a(CAPTURED + 1, 1, b"other"));
    let parts = fixture.parts();

    let report = parts.ingest().run(&Mode { dry_run: false, once: Some(broken.clone()) }).expect("once");

    assert_eq!(report.deferred.len(), 1);
    assert!(report.ingested.is_empty());
    assert_eq!(parts.ledger.seen_all().expect("seen").len(), 1);
    let dry_once = parts.ingest().run(&Mode { dry_run: true, once: Some(fixture.recordings.join("other.m4a")) }).expect("dry once");
    assert_eq!(dry_once.would_ingest.len(), 1);
    assert!(parts.ledger.recordings().expect("list").is_empty());
}

#[test]
fn an_unreadable_recordings_directory_aborts_with_one_event() {
    let fixture = Fixture::new();
    let parts = fixture.parts();
    std::fs::remove_dir_all(&fixture.recordings).expect("test setup only");

    let error = parts.ingest().run(&Mode::default()).unwrap_err();

    assert!(matches!(error.failure, IngestFailure::StoreUnreadable(_)));
    assert_eq!(parts.events(), vec![EventKind::IngestFailed]);
}

#[test]
fn an_empty_store_that_held_recordings_before_is_the_silent_failure_and_aborts() {
    let fixture = Fixture::new();
    let a = fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"a"));
    let parts = fixture.parts();
    parts.ingest().run(&Mode::default()).expect("first");
    std::fs::remove_file(&a).expect("test setup only");

    let error = parts.ingest().run(&Mode::default()).unwrap_err();

    assert_eq!(error.failure, IngestFailure::EmptyStore);
    assert!(error.completed.is_empty());
    assert_eq!(parts.ledger.seen(&a).expect("seen").and_then(|row| row.source_gone_at), Some(clock().now));
    assert_eq!(parts.events(), vec![EventKind::IngestFailed]);
}

#[test]
fn a_fresh_empty_store_is_not_a_failure() {
    let fixture = Fixture::new();
    let parts = fixture.parts();
    assert!(parts.ingest().run(&Mode::default()).is_ok());
    assert!(parts.events().is_empty());
}

#[test]
fn a_failure_after_an_ingestion_lists_the_completed_identities() {
    let fixture = Fixture::new();
    let a = m4a(CAPTURED, 1, b"a");
    let b = m4a(CAPTURED + 5, 1, b"b");
    fixture.add_recording("a.m4a", &a);
    fixture.add_recording("b.m4a", &b);
    let b_id = RecordingId::derive(UtcInstant { secs: CAPTURED + 5 }, clock().offset, &digest_of(&b)).expect("id");
    std::fs::write(fixture.audio.join(format!("{b_id}.m4a")), b"tampered").expect("collision setup");
    let parts = fixture.parts();

    let error = parts.ingest().run(&Mode::default()).unwrap_err();

    assert!(matches!(error.failure, IngestFailure::ArchiveCollision { .. }), "{error:?}");
    let a_id = RecordingId::derive(UtcInstant { secs: CAPTURED }, clock().offset, &digest_of(&a)).expect("id");
    assert_eq!(error.completed, vec![a_id]);
}

#[test]
fn a_recovery_before_a_failing_candidate_stays_in_completed() {
    let fixture = Fixture::new();
    let orphan = m4a(CAPTURED, 2, b"orphan");
    let orphan_id = RecordingId::derive(UtcInstant { secs: CAPTURED }, clock().offset, &digest_of(&orphan)).expect("id");
    std::fs::write(fixture.audio.join(format!("{orphan_id}.m4a")), &orphan).expect("orphan");
    let b = m4a(CAPTURED + 5, 1, b"b");
    fixture.add_recording("b.m4a", &b);
    let b_id = RecordingId::derive(UtcInstant { secs: CAPTURED + 5 }, clock().offset, &digest_of(&b)).expect("id");
    std::fs::write(fixture.audio.join(format!("{b_id}.m4a")), b"tampered").expect("collision setup");
    let parts = fixture.parts();

    let error = parts.ingest().run(&Mode::default()).unwrap_err();

    assert!(matches!(error.failure, IngestFailure::ArchiveCollision { .. }), "{error:?}");
    assert_eq!(error.completed, vec![orphan_id.clone()]);
    assert!(parts.ledger.by_id(&orphan_id).expect("read").is_some());
}
#[test]
fn dry_run_finds_the_stored_title_for_known_bytes_at_a_new_path() {
    let fixture = Fixture::new();
    let source = fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"audio"));
    fixture.add_title("a.m4a", "Alpha");
    let mut parts = fixture.parts();
    parts.store = fixture.titled_store(true);
    parts.ingest().run(&Mode::default()).expect("first");
    let renamed = fixture.recordings.join("renamed.m4a");
    std::fs::rename(source, &renamed).expect("rename");
    let before = copy_snapshot(&fixture);
    let dry = Parts { store: fixture.titled_store(false), ..fixture.parts() };
    let report = dry.ingest().run(&DRY).expect("dry");
    assert_eq!(report.would_ingest.len(), 1);
    assert_eq!(report.would_ingest[0].path, renamed);
    assert_eq!(report.would_ingest[0].title.as_deref(), Some("Alpha"));
    assert_eq!(report.would_ingest[0].title_source, TitleOrigin::VoiceMemos);
    assert_eq!(copy_snapshot(&fixture), before);
    assert!(dry.events().is_empty());
}

#[test]
fn dry_run_defers_a_descriptor_that_changes_while_hashing() {
    let fixture = Fixture::new();
    fixture.add_recording("a.m4a", &m4a(CAPTURED, 1, b"audio"));
    let parts = fixture.parts();
    let probe = support::fakes::ProbeStore::new(&parts.store);
    probe.grow_after_open.set(true);
    let report = vpt_application::Ingest {
        recorder: &probe, archive: &parts.archive, ledger: &parts.ledger, clock: &parts.clock,
        trash: &parts.trash, notifier: &parts.notifier, settings: &parts.settings,
    }.run(&DRY).expect("dry");
    assert!(report.would_ingest.is_empty());
    assert_eq!(report.deferred[0].reason, vpt_domain::sweep::DeferralReason::ChangedDuringRead);
    assert!(parts.ledger.seen_all().expect("seen").is_empty());
    assert!(parts.archive.staged_leftovers().expect("staging").is_empty());
    assert!(parts.events().is_empty());
}

```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters --test ingest_modes`

Expected: the unreadable dry-run event test is an existing regression guard; the new once, empty-store
and current-digest dry-run cases establish this task's red result. Run every command independently so one
expected failure cannot skip the next command.

- [ ] **Step 3: Write the minimal implementation**

In `crates/vpt-application/src/ingest/mod.rs`, `sweep` becomes:

```rust
    fn sweep(&self, mode: &Mode, report: &mut IngestReport) -> Result<(), IngestFailure> {
        if !mode.dry_run {
            self.recorder.refresh_titles().map_err(candidate::recorder_failure)?;
        }
        if !mode.dry_run {
            self.recover_orphans(report)?;
        }
        let candidates = match &mode.once {
            Some(path) => vec![self.recorder.candidate(path).map_err(candidate::recorder_failure)?],
            None => self.recorder.candidates().map_err(candidate::recorder_failure)?,
        };
        let full_sweep = mode.once.is_none();
        if full_sweep && candidates.is_empty() && !self.ledger.seen_all().map_err(IngestFailure::Ledger)?.is_empty() {
            if !mode.dry_run {
                self.mark_gone(&candidates, report)?;
            }
            return Err(IngestFailure::EmptyStore);
        }
        for candidate in &candidates {
            self.process(candidate, mode, report)?;
        }
        if full_sweep && !mode.dry_run {
            self.mark_gone(&candidates, report)?;
        }
        Ok(())
    }
```

Add `use vpt_domain::digest::Sha256Digest;` to `ports/recorder.rs`, `voice_memos/store.rs`, and
`ingest/candidate.rs`. The Task 21 fake already imports it. Add this method to `RecorderStore`:

```rust
fn digest(&self, handle: &Self::Handle) -> Result<Sha256Digest, RecorderError>;
```

In `impl RecorderStore for VoiceMemosStore`:

```rust
fn digest(&self, handle: &File) -> Result<Sha256Digest, RecorderError> {
    let mut file = handle.try_clone().map_err(|error| RecorderError::Io(error.kind().to_string()))?;
    std::io::Seek::rewind(&mut file).map_err(|error| RecorderError::Io(error.kind().to_string()))?;
    crate::digest_open(&mut file).map_err(|error| RecorderError::Io(error.kind().to_string()))
}
```

In `impl RecorderStore for ProbeStore<'_>`:

```rust
fn digest(&self, handle: &File) -> Result<Sha256Digest, RecorderError> {
    self.inner.digest(handle)
}
```

In `crates/vpt-application/src/ingest/candidate.rs`, `process` gains the dry-run exit between the rest
gate and staging:

```rust
        if let Err(reason) = rest_gate(metadata.mtime, metadata.size, now, seen_facts.as_ref(), &limits) {
            return self.defer(candidate, seen, reason, now, mode, report);
        }
        if mode.dry_run {
            let digest = self.recorder.digest(&handle).map_err(recorder_failure)?;
            let after = self.recorder.metadata(&handle).map_err(recorder_failure)?;
            if after != metadata {
                return self.defer(candidate, seen, DeferralReason::ChangedDuringRead, now, mode, report);
            }
            return self.would_ingest(candidate, &digest, report);
        }
        self.stage_and_publish(candidate, &handle, &metadata, seen, now, mode, report)
```

and the `impl` block gains:

```rust
    /// Titles belong to the current content digest, regardless of its source path.
    pub(super) fn would_ingest(&self, candidate: &Candidate, digest: &Sha256Digest, report: &mut IngestReport) -> Result<(), IngestFailure> {
        let known = self.ledger.by_digest(digest).map_err(IngestFailure::Ledger)?;
        report.would_ingest.push(super::WouldIngest {
            path: candidate.path.clone(),
            title: known.as_ref().and_then(|record| record.title.clone()),
            title_source: known.map_or(TitleOrigin::Unavailable, |record| record.title_source),
        });
        Ok(())
    }
```

with `TitleOrigin` added to the `crate::ports` import of `candidate.rs`. `defer` and `unchanged` already
honour `mode.dry_run` (Tasks 19 and 20), `run` already withholds the failure event on a dry run (Task
19). The composition root (Task 27) attaches no title-copy capability during a dry run; titles come only
from the existing ledger by the current digest, leaving the private copy untouched.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters`

Expected: all PASS, every earlier ingest test included. Run
`cargo clippy --workspace --all-targets --features dev-tools -- -D warnings` and expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(ingest): dry run, --once and the abort conditions"
```

______________________________________________________________________

