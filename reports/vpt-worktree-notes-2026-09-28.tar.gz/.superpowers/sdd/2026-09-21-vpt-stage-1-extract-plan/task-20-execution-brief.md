# Task 20 execution brief

Read task-20-brief.md completely after Task 19 is accepted. It is the approved gates and deferral task;
use the completed Task 19 interfaces and these corrections. The typed deferral-history prerequisite
below is dispatched independently; actual ingest gate implementation still waits for Task 19.

## Typed deferral prerequisite

Root verified these missing representations against the current source on 2026-09-27. A saved
deferral needs its own outcome: `WorkOutcome::Deferred`. The seen-row update and that work fact
commit together through `RunHistory::commit_step`; a threshold event joins that same transaction.
No empty-fact exception, direct split `record_seen` write, new schema, or generic transaction port.

Replace the unshipped unit `EventDetail::Deferred` with
`Deferred { reason: DeferralReason, count: u32 }`, and add `EventPathKey::Source`. Reuse the existing
five-value `DeferralReason` parser. The private event codec preserves both fields and rejects
missing, invalid or overflowing values without echoing content. Hook detail uses the approved
`deferred <count> times: <reason>` wording and `paths.source`; do not add arbitrary detail strings.
Unknown outcome and source-path tags remain refusals. No compatibility fallback for old unshipped
payloads. Pin the exact new wire outcome and event metadata with compiling RED before behavior.

The exporter lane owns recovery aggregation. It will add the separate `deferred_work` counter
after this prerequisite lands, with its own failing witness. Deferrals must never inflate completed,
failed or unknown work, or any effect counter. The six-counter prerequisite evidence remains valid
for its earlier source and must not be rewritten. Coordinate the `run.rs`, private fact codec and
`event/history.rs` overlap by exact hunk; preserve exporter recovery fields and retention encoding.

Keep Task 19's public dry-run refusal until Task 23 implements the full preview. Task 20 may test a
private no-write gate evaluator directly when it becomes a real dependency of normal candidate
processing; do not add an unused public preview entrypoint or claim full dry-run coverage.

## Ingest gate implementation

- Own only candidate gates, staged gate outcomes and their focused integration probes. You are not
  alone; preserve others' work. One product writer, no subagents. Main owns the ledger and task tracker.
- Retain compiling behavioral RED before implementing each new gate or outcome. Previously green
  coverage is evidence for unchanged behavior, not a new behavior's test-first history.
- Preserve the gate order: dataless before open, size before reads, source wholeness before staging,
  quiet period and prior deferred-size stability before cloning. A changed source after staging and an
  invalid staged container become the specified deferrals, with only owned staging cleaned up.
- Cover saturating deferral count, exact threshold crossing and no repeat notification above the
  threshold. Delivery follows a successful persisted seen-row update; a failed ledger write sends no
  deferred event. Pin the event's class/path/count metadata and absence of private source text.
- Cover this task's dry-run deferral branch with no seen-row write, staging, title refresh, cleanup or
  event at the shared private gate seam. Full ingest dry run is Task 23; the public refusal stays
  pinned until that task replaces it with complete observational behavior.
- Preserve first_seen, update last_seen, retain the observed flags and deferred size, clear source-gone
  state on observation, and reset deferral state only on successful ingestion. An unchanged ingested
  entry remains a liveness refresh rather than a new clone.
- Use the actual recorder handle and clone capability. Probe only owned synthetic inputs; do not add
  a global injector or filesystem framework. Both clone kinds remain valid. Missing helpers retain
  private staging with a bounded diagnostic; incompatible helper major stays a typed refusal.
- Add focused compiled mutations for pre-open/read ordering, threshold boundaries, saturation and
  staging ownership. Retain exact restored controls and all accepted leaves. Follow the existing
  Rust size and lint rules without copying the sample's broad dead-code allowance.
- Preserve Task 19's history-before-cleanup ordering for staged deferrals: commit and export the
  seen-row update and Deferred work fact before attempting owned-stage Trash. An unconfirmed or
  post-commit history failure, or a sink Stop, preserves staging and stops further work. Pin these
  paths before implementing them. The historical sample's discard-before-defer order is superseded.
- The approved deferral behavior replaces Task 19's temporary dataless refusal and invalid-container
  failure behavior. Record explicit old-to-new leaf mappings where expectations change; preserve
  the original evidence. Remove obsolete unshipped refusal variants once no caller needs them.
- Report chronology, exact commands/logs, mutation hashes, leaf/timing/size checks, self-review and
  normal-hook commits in task-20-report.md. Main owns independent review and final ship. No live
  source, real Trash, notification, installation, publishing or destructive cleanup.
