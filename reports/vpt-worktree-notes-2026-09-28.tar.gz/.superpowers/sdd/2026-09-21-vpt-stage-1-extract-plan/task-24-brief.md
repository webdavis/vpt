### Task 24: Bounded process execution and the fake engine

Every command vpt spawns runs from its argv directly, in its own process group, with stdin, stdout and
stderr handled concurrently under one deadline; at the deadline or on interruption the group is
terminated, force-killed after the grace period and reaped. The private executor takes its cancellation,
clock, waiting and grace as controls: production hands it the process-wide interrupt flag, the monotonic
clock, a real sleep and the one-second grace; each test hands it its own, so no test touches the
production flag or asserts elapsed wall time. A readiness marker gates each virtual deadline or
interrupt. Group-cleanup tests use zero grace; the grace-specific test advances a private clock through
one second without sleeping. Every test child has a cleared environment and temporary HOME,
XDG_STATE_HOME and VPT_CONFIG. The 750 ms watchdog only bounds a broken fixture and fails the test if
used. The fake engine is the child every later integration test spawns.

**Files:**

- Create: `crates/vpt-adapters/src/spawn.rs`, `crates/vpt-adapters/src/spawn/tests.rs`,
  `crates/vpt-adapters/src/spawn/tests/support.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`
- Create: `crates/vpt/src/bin/vpt-fake-engine.rs` (replacing the stand-in)

**Interfaces:**

- Consumes: nothing.

- Produces, through curated root reexports from the private adapters module `spawn`:
  `run(argv: &[String], stdin: &[u8], deadline: Duration, output_limit: usize) ->`
  `Result<Outcome, SpawnError>`,
  `run_with_env(argv: &[String], stdin: &[u8], deadline: Duration, output_limit: usize,`
  `env: &[(&str, &str)]) -> Result<Outcome, SpawnError>`,
  `Outcome { pub status: Status, pub stdout: Vec<u8>, pub stderr: Vec<u8>, pub group: libc::pid_t }`,
  `Status::{Exited(i32), Signaled(i32), DeadlineExceeded, Interrupted}`,
  `SpawnError::{NotFound(String), Io(String)}`, `install_interrupt_handlers()`,
  `OUTPUT_LIMIT: usize = 65_536`, `GRACE: Duration = 1 s`; privately,
  `Controls<I, K, W> { interrupted: I, now: K, wait: W, grace: Duration }` and
  `execute(command: Command, stdin, deadline, output_limit, controls)` and `interrupted() -> bool`. The
  direct child's status is provisional until the stdin writer and both drains finish. A deadline or
  interruption before that point overrides the recorded exit status. Termination reaps the leader while
  checking the whole group: only group disappearance ends grace early. Remaining members receive KILL
  after grace, and the direct child is reaped on every return path, including a wait error.

- The fake engine `vpt-fake-engine`: `--version` prints
  `{"schema":"vpt.helper/1","version":"<VPT_FAKE_VERSION or 1.0.0>"}`; `notify --title <t> --body <b>`
  appends `notify\t<t>\t<b>\n` to `$VPT_FAKE_LOG` when set and prints `{"posted":true}`; `trash <path>`
  renames the path into `$VPT_FAKE_TRASH` and prints `{"trashed":"<path>"}`; `command-sink [args...]`
  reads stdin to the end, appends `command-sink\t<args joined by space>\t<stdin>\n` to `$VPT_FAKE_LOG`
  and exits with `$VPT_FAKE_EXIT` (default 0); with `VPT_FAKE_HANG=1` every subcommand sleeps for 60
  seconds before answering.

- [ ] **Step 1: Write the failing tests**

`crates/vpt-adapters/src/lib.rs` gains these curated reexports; `spawn` remains private:

```rust
mod spawn;
pub use spawn::{
    GRACE, OUTPUT_LIMIT, Outcome, SpawnError, Status, install_interrupt_handlers, run, run_with_env,
};
```

Create `crates/vpt-adapters/src/spawn.rs` with this registration before running red:

```rust
#[cfg(test)]
mod tests;
```

`crates/vpt-adapters/src/spawn/tests.rs`:

```rust
mod support;
use super::*;
use std::cell::Cell;
use support::{OwnedGroup, command, controls, group_is_gone, pending, wait_for_leader};

#[test]
fn the_exit_code_and_both_streams_are_returned() {
    let temp = tempfile::tempdir().expect("temp");
    let child = command(
        temp.path(),
        "/bin/sh",
        &["-c", "printf out; printf err >&2; exit 3"],
    );
    let outcome = execute(
        child,
        b"",
        Duration::from_millis(750),
        OUTPUT_LIMIT,
        controls(),
    )
    .expect("ran");
    assert_eq!(outcome.status, Status::Exited(3));
    assert_eq!(outcome.stdout, b"out");
    assert_eq!(outcome.stderr, b"err");
    assert!(group_is_gone(outcome.group));
}

#[test]
fn stdin_is_written_and_a_missing_executable_is_not_found() {
    let temp = tempfile::tempdir().expect("temp");
    let child = command(temp.path(), "/bin/cat", &[]);
    let outcome = execute(
        child,
        b"hello",
        Duration::from_millis(750),
        OUTPUT_LIMIT,
        controls(),
    )
    .expect("ran");
    assert_eq!(outcome.stdout, b"hello");
    let missing = temp.path().join("missing-program");
    let child = command(temp.path(), missing.to_str().expect("path"), &[]);
    assert!(matches!(
        execute(child, b"", Duration::ZERO, OUTPUT_LIMIT, controls()),
        Err(SpawnError::NotFound(_))
    ));
}

#[test]
fn output_is_bounded_while_the_child_is_still_drained_to_completion() {
    let temp = tempfile::tempdir().expect("temp");
    let child = command(
        temp.path(),
        "/bin/sh",
        &["-c", "/usr/bin/yes | /usr/bin/head -c 200000"],
    );
    let outcome = execute(child, b"", Duration::from_millis(750), 1_000, controls()).expect("ran");
    assert_eq!(outcome.stdout.len(), 1_000);
    assert_eq!(outcome.status, Status::Exited(0));
}

#[test]
fn the_deadline_terminates_the_whole_process_group_and_reaps_it() {
    assert_eq!(pending(false, false).status, Status::DeadlineExceeded);
}

#[test]
fn an_interrupt_terminates_the_child_and_reports_interrupted() {
    assert_eq!(pending(false, true).status, Status::Interrupted);
}

#[test]
fn a_descendant_holding_stdout_does_not_outlive_the_deadline() {
    let outcome = pending(true, false);
    assert_eq!(outcome.status, Status::DeadlineExceeded);
    assert_eq!(outcome.stdout, b"{}");
}

#[test]
fn interruption_overrides_an_exited_leader_while_a_descendant_holds_stdout() {
    assert_eq!(pending(true, true).status, Status::Interrupted);
}

#[test]
fn a_descendant_that_closed_every_stream_lets_the_run_finish_with_the_child() {
    let temp = tempfile::tempdir().expect("temp");
    let child = command(
        temp.path(),
        "/bin/sh",
        &[
            "-c",
            "(exec >/dev/null 2>&1 </dev/null; exec /bin/sleep 30) & printf done",
        ],
    );
    let outcome = execute(
        child,
        b"",
        Duration::from_millis(750),
        OUTPUT_LIMIT,
        controls(),
    )
    .expect("ran");
    assert_eq!(outcome.status, Status::Exited(0));
    assert_eq!(outcome.stdout, b"done");
    assert!(group_is_gone(outcome.group));
}

#[test]
fn a_surviving_descendant_receives_the_full_grace_after_the_leader_exits() {
    let temp = tempfile::tempdir().expect("temp");
    let mut builder = command(
        temp.path(),
        "/bin/sh",
        &["-c", "trap '' TERM; /bin/sleep 30 &"],
    );
    let mut child = OwnedGroup(
        builder
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .process_group(0)
            .spawn()
            .expect("fixture group"),
    );
    wait_for_leader(&mut child.0);
    let group = child.0.id() as libc::pid_t;
    let start = Instant::now();
    let elapsed = Cell::new(Duration::ZERO);
    let controls = Controls {
        interrupted: || false,
        now: || start + elapsed.get(),
        wait: |duration| {
            elapsed.set(elapsed.get() + duration);
            std::thread::yield_now();
        },
        grace: GRACE,
    };
    terminate(group, &mut child.0, &controls);
    assert_eq!(elapsed.get(), GRACE);
    assert!(group_is_gone(group));
}

#[test]
fn test_children_receive_only_the_fixture_environment() {
    let temp = tempfile::tempdir().expect("temp");
    let child = command(temp.path(), "/usr/bin/env", &[]);
    let outcome = execute(
        child,
        b"",
        Duration::from_millis(750),
        OUTPUT_LIMIT,
        controls(),
    )
    .expect("ran");
    let text = String::from_utf8(outcome.stdout).expect("environment");
    let mut names: Vec<_> = text
        .lines()
        .map(|line| line.split_once('=').expect("entry").0)
        .collect();
    names.sort_unstable();
    assert_eq!(
        names,
        [
            "HOME",
            "PATH",
            "VPT_CONFIG",
            "XDG_CONFIG_HOME",
            "XDG_DATA_HOME",
            "XDG_STATE_HOME"
        ]
    );
    assert!(text.contains(&format!("HOME={}\n", temp.path().display())));
}
```

`crates/vpt-adapters/src/spawn/tests/support.rs`:

```rust
use super::super::*;
use std::cell::Cell;
use std::path::{Path, PathBuf};
use std::sync::{Arc, atomic::AtomicBool, mpsc};

const WATCHDOG: Duration = Duration::from_millis(750);

pub(super) fn command(temp: &Path, program: &str, arguments: &[&str]) -> Command {
    let mut command = Command::new(program);
    command
        .args(arguments)
        .env_clear()
        .current_dir(temp)
        .env("HOME", temp)
        .env("XDG_CONFIG_HOME", temp.join("config"))
        .env("XDG_DATA_HOME", temp.join("data"))
        .env("XDG_STATE_HOME", temp.join("state"))
        .env("VPT_CONFIG", temp.join("config.toml"))
        .env("PATH", "/usr/bin:/bin");
    command
}

pub(super) fn controls() -> Controls<impl Fn() -> bool, impl Fn() -> Instant, impl Fn(Duration)> {
    Controls {
        interrupted: || false,
        now: Instant::now,
        wait: |_| std::thread::yield_now(),
        grace: Duration::ZERO,
    }
}

pub(super) fn group_is_gone(group: libc::pid_t) -> bool {
    let until = Instant::now() + WATCHDOG;
    loop {
        // SAFETY: signal zero checks existence without delivering a signal.
        if unsafe { libc::killpg(group, 0) } == -1
            && std::io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH)
        {
            return true;
        }
        if Instant::now() >= until {
            return false;
        }
        std::thread::yield_now();
    }
}

pub(super) struct Watchdog {
    stop: Option<mpsc::Sender<()>>,
    worker: Option<std::thread::JoinHandle<()>>,
    pub fired: Arc<AtomicBool>,
}

impl Watchdog {
    pub fn start(group_file: PathBuf) -> Self {
        let (stop, receiver) = mpsc::channel();
        let fired = Arc::new(AtomicBool::new(false));
        let flag = fired.clone();
        let worker = std::thread::spawn(move || {
            if receiver.recv_timeout(WATCHDOG) == Err(mpsc::RecvTimeoutError::Timeout) {
                flag.store(true, Ordering::SeqCst);
                if let Some(group) = std::fs::read_to_string(group_file)
                    .ok()
                    .and_then(|text| text.parse::<libc::pid_t>().ok())
                    .filter(|group| *group > 1)
                {
                    // SAFETY: the fixture writes its own newly created process group.
                    unsafe {
                        libc::killpg(group, libc::SIGKILL);
                    }
                }
            }
        });
        Self {
            stop: Some(stop),
            worker: Some(worker),
            fired,
        }
    }
}

impl Drop for Watchdog {
    fn drop(&mut self) {
        if let Some(stop) = self.stop.take() {
            let _ = stop.send(());
        }
        if let Some(worker) = self.worker.take() {
            worker.join().expect("watchdog");
        }
    }
}

pub(super) fn pending(leader_exits: bool, interrupt: bool) -> Outcome {
    let temp = tempfile::tempdir().expect("temp");
    let ready = temp.path().join("ready");
    let group_file = temp.path().join("group");
    let script = if leader_exits {
        "printf '%s' \"$$\" > \"$VPT_TEST_GROUP\"; parent=$$; \
        (while kill -0 \"$parent\" 2>/dev/null; do :; done; \
        printf ready > \"$VPT_TEST_READY\"; exec /bin/sleep 30) & printf '{}'; exit 0"
    } else {
        "printf '%s' \"$$\" > \"$VPT_TEST_GROUP\"; /bin/sleep 30 & \
        printf ready > \"$VPT_TEST_READY\"; wait"
    };
    let mut child = command(temp.path(), "/bin/sh", &["-c", script]);
    child
        .env("VPT_TEST_READY", &ready)
        .env("VPT_TEST_GROUP", &group_file);
    let start = Instant::now();
    let elapsed = Cell::new(Duration::ZERO);
    let cancelled = Cell::new(false);
    let watchdog = Watchdog::start(group_file);
    let controls = Controls {
        interrupted: || cancelled.get(),
        now: || start + elapsed.get(),
        wait: |_| {
            if ready.exists() {
                if interrupt {
                    cancelled.set(true);
                } else {
                    elapsed.set(Duration::from_secs(1));
                }
            }
            if watchdog.fired.load(Ordering::SeqCst) {
                elapsed.set(Duration::from_secs(1));
            }
            std::thread::yield_now();
        },
        grace: Duration::ZERO,
    };
    let outcome = execute(child, b"", Duration::from_secs(1), OUTPUT_LIMIT, controls).expect("ran");
    assert!(
        !watchdog.fired.load(Ordering::SeqCst),
        "process fixture exceeded its watchdog: group={} ready={} status={:?}",
        outcome.group,
        ready.exists(),
        outcome.status
    );
    assert!(ready.exists(), "fixture readiness was not observed");
    assert!(
        group_is_gone(outcome.group),
        "fixture group survived cleanup"
    );
    outcome
}

pub(super) struct OwnedGroup(pub Child);

impl Drop for OwnedGroup {
    fn drop(&mut self) {
        let group = self.0.id() as libc::pid_t;
        // SAFETY: this guard owns the fixture's process group.
        unsafe {
            libc::killpg(group, libc::SIGKILL);
        }
        let _ = self.0.wait();
    }
}

pub(super) fn wait_for_leader(child: &mut Child) {
    let until = Instant::now() + WATCHDOG;
    loop {
        if child.try_wait().expect("leader status").is_some() {
            return;
        }
        assert!(Instant::now() < until, "fixture leader did not exit");
        std::thread::yield_now();
    }
}
```

The shell fixtures are confined to the tests. Descendants use `exec` after publishing readiness, so
termination cannot race another fork of a pipe-holding child. The group-existence assertion polls to
allow asynchronous reaping; it never equates any arbitrary signal error with group disappearance.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters spawn`

Expected: the build fails with `cannot find` for `execute`, `Controls`, `Outcome`, `Status`,
`SpawnError`, `OUTPUT_LIMIT` and the imported process types. Confirm the private child test module is
registered before accepting this compile failure.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-adapters/src/spawn.rs`, above its test module:

```rust
//! Bounded process execution: argv, own process group, one deadline for
//! writing, draining and waiting, group termination, reaping.

use std::io::{Read, Write};
use std::os::unix::process::{CommandExt, ExitStatusExt};
use std::process::{Child, Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

pub const OUTPUT_LIMIT: usize = 65_536;
pub const GRACE: Duration = Duration::from_secs(1);
const TICK: Duration = Duration::from_millis(20);

static INTERRUPTED: AtomicBool = AtomicBool::new(false);

#[derive(Debug, PartialEq, Eq)]
pub enum Status {
    Exited(i32),
    Signaled(i32),
    DeadlineExceeded,
    Interrupted,
}

#[derive(Debug)]
pub struct Outcome {
    pub status: Status,
    pub stdout: Vec<u8>,
    pub stderr: Vec<u8>,
    pub group: libc::pid_t,
}

#[derive(Debug, PartialEq, Eq)]
pub enum SpawnError {
    NotFound(String),
    Io(String),
}

/// What the executor consults: cancellation, the clock, how it waits, and
/// how long a terminated group gets before it is killed.
struct Controls<I, K, W> {
    interrupted: I,
    now: K,
    wait: W,
    grace: Duration,
}

extern "C" fn on_signal(_signal: libc::c_int) {
    INTERRUPTED.store(true, Ordering::SeqCst);
}

/// Called once at startup by the command crate.
pub fn install_interrupt_handlers() {
    for signal in [libc::SIGINT, libc::SIGTERM, libc::SIGHUP] {
        // SAFETY: the handler only stores into an atomic, which is async-signal-safe.
        unsafe {
            libc::signal(
                signal,
                on_signal as extern "C" fn(libc::c_int) as libc::sighandler_t,
            );
        }
    }
}

fn interrupted() -> bool {
    INTERRUPTED.load(Ordering::SeqCst)
}

pub fn run(
    argv: &[String],
    stdin: &[u8],
    deadline: Duration,
    output_limit: usize,
) -> Result<Outcome, SpawnError> {
    run_with_env(argv, stdin, deadline, output_limit, &[])
}

/// `run` with extra environment for the child; tests use it to steer the fake engine.
pub fn run_with_env(
    argv: &[String],
    stdin: &[u8],
    deadline: Duration,
    output_limit: usize,
    env: &[(&str, &str)],
) -> Result<Outcome, SpawnError> {
    let controls = Controls {
        interrupted,
        now: Instant::now,
        wait: std::thread::sleep,
        grace: GRACE,
    };
    let (program, arguments) = argv
        .split_first()
        .ok_or_else(|| SpawnError::Io("empty argv".into()))?;
    let mut command = Command::new(program);
    command.args(arguments).envs(env.iter().copied());
    execute(command, stdin, deadline, output_limit, controls)
}

fn execute<I, K, W>(
    mut command: Command,
    stdin: &[u8],
    deadline: Duration,
    output_limit: usize,
    controls: Controls<I, K, W>,
) -> Result<Outcome, SpawnError>
where
    I: Fn() -> bool,
    K: Fn() -> Instant,
    W: Fn(Duration),
{
    let program = command.get_program().to_string_lossy().into_owned();
    let mut child = command
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .process_group(0)
        .spawn()
        .map_err(|error| match error.kind() {
            std::io::ErrorKind::NotFound => SpawnError::NotFound(program),
            _ => SpawnError::Io(error.kind().to_string()),
        })?;
    let group = child.id() as libc::pid_t;
    let input = stdin.to_vec();
    let mut stdin_pipe = child.stdin.take();
    let writer = std::thread::spawn(move || {
        if let Some(mut pipe) = stdin_pipe.take() {
            let _ = pipe.write_all(&input);
        }
    });
    let stdout_pipe = child.stdout.take();
    let stderr_pipe = child.stderr.take();
    let out = std::thread::spawn(move || drain(stdout_pipe, output_limit));
    let err = std::thread::spawn(move || drain(stderr_pipe, output_limit));
    let started = (controls.now)();
    let mut status = None;
    let result = loop {
        if status.is_none() {
            match child.try_wait() {
                Ok(Some(exit)) => status = Some(status_of(exit)),
                Ok(None) => {}
                Err(error) => break Err(SpawnError::Io(error.kind().to_string())),
            }
        }
        let drained = writer.is_finished() && out.is_finished() && err.is_finished();
        if let (Some(_), true) = (&status, drained) {
            break Ok(());
        }
        if (controls.interrupted)() {
            status = Some(Status::Interrupted);
            break Ok(());
        }
        if (controls.now)().duration_since(started) >= deadline {
            status = Some(Status::DeadlineExceeded);
            break Ok(());
        }
        (controls.wait)(TICK);
    };
    terminate(group, &mut child, &controls);
    let _ = writer.join();
    let stdout = out.join().unwrap_or_default();
    let stderr = err.join().unwrap_or_default();
    result.map(|()| Outcome {
        status: status.unwrap_or(Status::Exited(-1)),
        stdout,
        stderr,
        group,
    })
}

fn status_of(exit: std::process::ExitStatus) -> Status {
    match (exit.code(), exit.signal()) {
        (Some(code), _) => Status::Exited(code),
        (None, Some(signal)) => Status::Signaled(signal),
        (None, None) => Status::Exited(-1),
    }
}

fn drain(pipe: Option<impl Read>, limit: usize) -> Vec<u8> {
    let Some(mut pipe) = pipe else {
        return Vec::new();
    };
    let mut kept = Vec::new();
    let mut buffer = [0u8; 8_192];
    while let Ok(read) = pipe.read(&mut buffer) {
        if read == 0 {
            break;
        }
        let room = limit.saturating_sub(kept.len());
        kept.extend_from_slice(&buffer[..read.min(room)]);
    }
    kept
}

/// TERM to whatever is left of the group, the grace period, KILL, then reap
/// the direct child. Harmless on a group that has already gone.
fn terminate<I, K, W>(group: libc::pid_t, child: &mut Child, controls: &Controls<I, K, W>)
where
    K: Fn() -> Instant,
    W: Fn(Duration),
{
    // SAFETY: `group` is the child's own process group, created by process_group(0).
    unsafe {
        libc::killpg(group, libc::SIGTERM);
    }
    let started = (controls.now)();
    while (controls.now)().duration_since(started) < controls.grace {
        let _ = child.try_wait();
        // SAFETY: signal zero checks the owned process group's existence.
        if unsafe { libc::killpg(group, 0) } == -1
            && std::io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH)
        {
            break;
        }
        (controls.wait)(TICK);
    }
    // SAFETY: as above; a group that already exited makes killpg fail harmlessly.
    unsafe {
        libc::killpg(group, libc::SIGKILL);
    }
    let _ = child.wait();
}

```

The recorded exit status remains provisional while any pipe worker is unfinished. Interruption and the
deadline override that status; a complete child result keeps its own exit or signal. Every exit cleans
the owned process group. Reaping the leader does not end a surviving descendant's grace.

`crates/vpt/src/bin/vpt-fake-engine.rs`:

```rust
//! The fake helper and fake command the tests spawn. Behind `dev-tools`.

use std::io::{Read, Write};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if std::env::var("VPT_FAKE_HANG").as_deref() == Ok("1") {
        std::thread::sleep(std::time::Duration::from_secs(60));
    }
    let code = match args.first().map(String::as_str) {
        Some("--version") => version(),
        Some("notify") => notify(&args[1..]),
        Some("trash") => trash(args.get(1).map(String::as_str)),
        Some("command-sink") => command_sink(&args[1..]),
        _ => {
            eprintln!("vpt-fake-engine: unknown subcommand");
            2
        }
    };
    std::process::exit(code);
}

fn log(line: &str) {
    if let Ok(path) = std::env::var("VPT_FAKE_LOG")
        && let Ok(mut file) = std::fs::OpenOptions::new().append(true).create(true).open(path) {
        let _ = writeln!(file, "{line}");
    }
}

fn version() -> i32 {
    let version = std::env::var("VPT_FAKE_VERSION").unwrap_or_else(|_| "1.0.0".into());
    println!("{{\"schema\":\"vpt.helper/1\",\"version\":\"{version}\"}}");
    0
}

fn notify(args: &[String]) -> i32 {
    let value = |flag: &str| args.iter().position(|a| a == flag).and_then(|i| args.get(i + 1)).cloned().unwrap_or_default();
    log(&format!("notify\t{}\t{}", value("--title"), value("--body")));
    println!("{{\"posted\":true}}");
    0
}

fn trash(path: Option<&str>) -> i32 {
    let Some(path) = path else { return 2 };
    let Ok(dir) = std::env::var("VPT_FAKE_TRASH") else {
        eprintln!("VPT_FAKE_TRASH unset");
        return 1;
    };
    let name = std::path::Path::new(path).file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
    if std::fs::rename(path, std::path::Path::new(&dir).join(name)).is_err() {
        return 1;
    }
    log(&format!("trash\t{path}"));
    println!("{{\"trashed\":{}}}", serde_json::Value::String(path.to_owned()));
    0
}

fn command_sink(args: &[String]) -> i32 {
    let mut stdin = String::new();
    let _ = std::io::stdin().read_to_string(&mut stdin);
    log(&format!("command-sink\t{}\t{}", args.join(" "), stdin.replace('\n', "\\n")));
    std::env::var("VPT_FAKE_EXIT").ok().and_then(|v| v.parse().ok()).unwrap_or(0)
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters spawn && cargo build -p vpt --features dev-tools`

Expected: 10 tests PASS; the fake engine builds. Run `cargo fmt --all`, then `cargo fmt --all -- --check`
and `cargo clippy -p vpt-adapters --all-targets -- -D warnings`.

Run `cargo +nightly test -p vpt-adapters spawn -- -Z unstable-options --report-time` and record each test
below one second. Restore each of these mutants after its named test fails: retain `Exited(0)` on
deadline, retain it on interruption, break grace when only the leader exits, or signal only the child pid
instead of its process group. Rerun the unmutated stable suite after all four.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(adapters): bounded process execution and the fake engine"
```

______________________________________________________________________

