# Task 27 execution brief

Preparation only. Dispatch after Tasks 1-26, including D1-D6 and the approved replacements, have passed their independent task reviews. Read `task-27-brief.md` completely, then `task-D7-integration-addendum.md`. The controller read both complete sources. Reconcile this brief with the actual completed prerequisite interfaces before dispatch.

## Ownership

- Use Task 19's accepted Event/EventSink and Task 26's private `events.jsonl` plus optional command
  hooks. Do not construct a desktop notifier or helper-backed notification fallback. Read-only and
  dry-run composition must neither open a writable event log nor invoke a report or alert command.
- Consume the approved recovery contract in spec section 8.7.1. Under the existing write lock,
  reconcile unfinished work and resume history export before new mutating work. Keep original
  occurrence times and event identifiers, summarize only recorded or reconciled facts, and expose
  detectable history gaps. An entirely unsaved attempt cannot be reliably detected later; its
  original command reports the failure immediately. Log repair never repeats work or hooks. A
  log-only failure preserves the operation result and exit status with a warning in the existing
  JSON document or human output.
  Failed required state or run-history commits stop new work and report completed work through the
  existing failure path. Pin these as assembled command contracts; the current schema and output
  adapter do not yet implement them.
- Own Task 27's ingest command, operation-specific runtime composition, typed error conversion and command fixtures, plus its ignored report and raw evidence. Main owns progress and Todoist. Preserve other work; one product writer, no new worktree or subagents.
- Consume the existing use case, checked roots, application write lock, strengthened `SqliteLedger` and typed title-copy adapter. Do not recreate adapter logic at the command boundary. Use the actual D5/D6 result types rather than the older bare-connection and infallible title-builder examples in the historical plan.
- Own safe human messages and command error documents derived from typed `IngestFailure`.
  The historical application `message()` method is withdrawn; test the renderer at this boundary.
- Read-only composition takes no application write lock and opens no title database. Mutating startup checks state, acquires the existing write lock, opens the strengthened ledger and repairs pending publications and retention intents before new work. Only ingest opens the recorder. Keep retention's recorder-free path.
- Preserve existing `vpt.result/1` and `vpt.error/1` documents, stream selection, IDs, completed IDs and command exit codes. A definitive containment error maps to exit 3 `path_escape`; ordinary storage, private-directory and synchronization failures retain their typed exit-1 path. Doctor's separate aggregate contract is not implemented here.

## D7 fixture and acceptance integration

- Native `Sandbox::ledger()` fixture writes must set `SQLITE_FCNTL_PERSIST_WAL` with the addendum's checked helper before returning. Close fixture writers before snapshots. Native and rooted connections never overlap on the same inode in one process. A native fixture may overlap the separate VPT subprocess only in an explicit bounded concurrency test.
- Keep every path, HOME, XDG directory and child working directory in an owned synthetic tree. No real source, user database, helper notification or destination. Fixed-clock controls stay behind `dev-tools`; production never reads test fault variables.
- Ingest dry run creates and repairs nothing, does not refresh or open the title database, and sends no notification. An unreadable source on a real ingest emits one safe `ingest_failed` event; the dry run emits none.
- Feed actual typed ledger/storage failures through the shared converter and emitter. Assert the complete JSON error envelope and empty stdout, not a human-text substring. D3/D4 fault controls remain private adapter-test helpers, never environment variables in the command binary.
- The Stage 1 startup renderer may still report no renderable bytes for an unpublished derived artifact. Stage 2 owns that producer and its exact-byte recovery data. Preserve Stage 1's already-intended-digest repair and modified-target refusal tests; do not invent Stage 2 artifact storage here.

## Verification

- Use compiling behavioral RED, then GREEN, exact compiled mutations and restored passing controls. A missing type or import is not RED. Preserve every prior named leaf.
- Read the D7 mutation requirements and cover this task's shared containment conversion and dry-run routing. Every mutating test has an independent watchdog and cleanup bounded within the one-second leaf requirement.
- Deadline follow-up `6hc7MMRc2QhRm75g` remains separately owned. Preserve any recurrence and its evidence; no blind retries or deadline increases.
- Follow clean-code-rust, buffer safety, apply_patch, normal commit hooks, staged source-size checks and the required final-source Rust/release gates. The controller runs the fresh committed-HEAD ship. No installation, publication, apply, third-party patch or destructive cleanup.
