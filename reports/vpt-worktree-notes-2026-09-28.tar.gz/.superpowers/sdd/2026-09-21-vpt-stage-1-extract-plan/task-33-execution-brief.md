# Task 33 execution brief

## Current Swift standards, 2026-09-27

The operator requires current Swift standards. Root verified the installed Swift 6.4 compiler and
the official Swift 6.4 release, API design guidelines, concurrency guidance and Apple testing
guidance. Keep Swift 6 language mode and compiler-enforced concurrency safety. Use precise isolation
where shared state requires it; synchronous file operations need no invented asynchronous layer.
Do not suppress concurrency diagnostics or add Swift 5 compatibility workarounds.

Use the narrowest access level, including `package` for collaboration between this package's
targets. Prefer value types, explicit errors and meaningful capability protocols. Preserve the
existing macOS 15 deployment floor and the required file-size and architecture checks.

Apple recommends Swift Testing for new direct unit and integration tests. Use it for new tests;
preserve the ten existing XCTest leaf contracts and their test-first evidence. Any later migration
must map names and prove unchanged behavior. Keep fixture isolation, subject factories and leak
checks in the chosen framework. Do not mix frameworks' assertions in a single test. This choice
updates the skill's XCTest examples for the operator's current request; shared skills stay untouched.

Sources checked by root:

- https://www.swift.org/blog/swift-6.4-released/
- https://www.swift.org/documentation/api-design-guidelines/
- https://www.swift.org/migration/documentation/swift-6-concurrency-migration-guide/dataracesafety/
- https://developer.apple.com/documentation/xcode/adding-tests-to-your-xcode-project

## Parallel scheduling amendment, 2026-09-26

Root reread the complete task, helper specification, current justfile and continuous-integration
workflow. The helper consumes no Rust implementation. Its version and Trash document shapes are
specified independently, and the required Swift, SwiftFormat, SwiftLint and just executables are
present. Task 32 acceptance is not a prerequisite for an isolated lane. Root creates the lane and
controls verification windows; the writer must verify current tool flags and environment isolation
before its first build. This readiness ruling permits RED preparation, not execution of live Trash
or the existing Rust process suite while the shared test-helper safety correction remains open.

Preparation only. Read Task 33 completely in `docs/superpowers/plans/2026-09-21-vpt-stage-1-extract-plan.md` and `task-33-preflight.md`, subject to the report/alert amendment. The controller reread the full task and both clean-code language standards on 2026-09-26. Before dispatch, verify the actual helper document contract and current build recipes. The original Task 32 ordering is not proof of a code dependency: Task 33 consumes no Rust interface, but any parallel dispatch requires a separate lane and controller readiness check.

- Own the Swift helper package, its tests, the planned build/continuous-integration wiring and ignored task evidence. Main owns progress and Todoist. Preserve other work; one product writer, no new worktree or subagents.
- Follow clean-code, clean-code-swift and the Rust standard for any changed Rust integration. Use Foundation, the approved package/target boundaries and the macOS 15 floor. Stage 1 implements only version and Trash operations; transcription belongs to Stage 2. Omit Notify.swift, notification types, AppleScript, poster construction and notification arguments or documents.
- Keep Trash behind the approved injectable protocol. Automated tests use moves inside an owned temporary directory. Never run a system Trash or speech operation. The original notification smoke recipe is withdrawn; do not add or run it. Real-destination checks are outside this dispatch.
- Isolate all helper binary runs, including release `--version`, with owned temporary home, configuration and state roots. Isolate Swift test execution as well. Preserve production environment semantics. Do not install tooling or change shared caches/configuration to work around an environmental blocker.
- Capture compiled, operation-specific behavioral REDs against minimal scaffolding before implementation. Missing symbols, malformed packages and absent targets are not behavioral evidence. Apply the same evidence standard to the Swift helper as to the Rust tool.
- Pin exact version and Trash documents, usage and error exit codes, and empty success/error streams where required. Exercise malformed arguments and refusal of the unsupported notify command. Add a Trash-path JSON (JavaScript Object Notation) fixture containing quotes, backslashes and a newline, and decode it to verify the exact original path.
- Use Foundation JSON serialization. Inspect the sample generic encoder's success-shaped fallback before copying it: serialization failure must not be reported as a successful helper document. Keep any needed unshipped interface adjustment narrow and record its callers and evidence. Do not add a speculative serialization framework.
- Verify installed Swift command options through local help before using them. Run formatter checks on Sources, Tests and Package.swift, SwiftLint, explicit target-dependency import checks, the full Swift test suite and the release build. Record named test outcomes and durations. Keep Swift production files at most 200 lines and tests at most 700.
- The tracked-file size recipe cannot see new untracked files. Stage only this task's explicit paths before its final census, or measure those paths separately until staged. Include Package.swift in the audit. Preserve existing Rust size thresholds and any reviewed cohesive warnings.
- Use compiled, behavior-specific mutations for helper dispatch, error exits, JSON path preservation and escaping, with exact restoration and passing controls. Keep live framework adapters out of mutations. Reconcile the Stage 1 mutation matrix with the actual accepted leaf names; reuse unchanged valid evidence and explain gaps instead of rerunning every prior task by default.
- Run the final-source `just ship`, required normal-parallel nightly Rust timing and release checks. Preserve all accepted leaf names. Stop and diagnose any failure under the existing watchdog follow-up; no retries to obtain a green, serialized timing, deadline extensions or dropped assertions.
- Check the already planned README installation instructions without running installation. Follow buffer safety, apply_patch and normal commit hooks. Main owns independent review and the fresh committed-HEAD gate. No publication, live destination, dotfiles edit, apply, third-party source change or destructive cleanup.
