### Task 7: Time and digest value types

## Controller execution constraints

- Scope is the pure domain time and digest values in this task. Use the actual current exports without overwriting earlier modules. No clocks, filesystem access, SQLite work or dependencies on sibling workspaces.
- Start with compiling behavioral RED, not the sample's unresolved-name failure. Preserve every existing leaf. Cover negative instants, offset signs, nanosecond flooring, saturation and checked civil conversion, plus malformed full-length digest input and UTF-8 safety.
- The interface separates Civil::is_valid from Civil::instant, whose documented refusal is an out-of-range instant. Preserve that contract rather than inventing a new date-input policy here. Later input adapters must validate before conversion.
- Follow clean-code-rust with cohesive private modules only where the actual size warrants a split. Omit unsolicited docstrings and negative-rationale comments from samples. Verify any external algorithm attribution from its primary source.
- Source preflight: the controller verified Howard Hinnant's https://howardhinnant.github.io/date_algorithms.html on 2026-09-22. Its days_from_civil and civil_from_days sections match the plan's era arithmetic; the explanation uses floored or Euclidean division for negative years. Calendar validation is separate, and the Summary donates the formulas to the public domain. Keep attribution concise and record this source in the report. This source check is not runtime correctness evidence.
- Capture exact compiled behavioral mutations and byte-identical restored controls, full workspace gates, timings, staged-file size audit, release build and committed-HEAD secrets scan in task-7-report.md. Keep the report concise with links to raw logs.
- You own time.rs, digest.rs, focused tests and required domain exports, plus your report/evidence. You are not alone in the codebase; preserve others' work. Main owns progress.md and Todoist.
- No subagents, new worktree, unrelated edits, live data/state, installation, push, pull request, merge, destructive cleanup, third-party modification or bypassing a denied safeguard. Verify buffer safety and use apply_patch for authored edits.

**Files:**

- Create: `crates/vpt-domain/src/time.rs`, `crates/vpt-domain/src/digest.rs`
- Modify: `crates/vpt-domain/src/lib.rs`

**Interfaces:**

- Consumes: nothing.

- Produces: `vpt_domain::time::{UtcInstant { pub secs: i64 }, UtcOffset { pub secs: i32 },`
  `FileTime { pub secs: i64, pub nanos: u32 }, Civil { pub year: i64, pub month: u32, pub day: u32,`
  `pub hour: u32, pub minute: u32, pub second: u32 }}` with `UtcInstant::rfc3339(self) -> String`,
  `UtcInstant::rfc3339_with(self, offset: UtcOffset) -> String`,
  `UtcInstant::civil(self, offset: UtcOffset) -> Civil`, `UtcOffset::label(self) -> String`,
  `Civil::instant(self, offset: UtcOffset) -> Option<UtcInstant>` (None when the instant leaves `i64`),
  `Civil::is_valid(self) -> bool` (Gregorian month, day and leap-year rules and the hour, minute and
  second bounds), `FileTime::age_secs(self, now: UtcInstant) -> i64` (whole seconds, nanoseconds counted,
  saturating at the `i64` bounds); `vpt_domain::digest::Sha256Digest(pub [u8; 32])` with
  `hex(&self) -> String`, `hash12(&self) -> String`, `hash8(&self) -> String`,
  `from_hex(text: &str) -> Option<Sha256Digest>`. Civil arithmetic uses `i128` intermediates, so every
  `i64` instant plus any offset converts.

- [ ] **Step 1: Write the failing tests**

Declare the modules first: `crates/vpt-domain/src/lib.rs` gains `pub mod digest;` and `pub mod time;`
beside `duration`, `layout` and `retention`. Each new file starts as its test module alone.

`crates/vpt-domain/src/time.rs`:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_epoch_renders_as_utc_midnight() {
        assert_eq!(UtcInstant { secs: 0 }.rfc3339(), "1970-01-01T00:00:00Z");
    }

    #[test]
    fn an_offset_shifts_the_civil_time_and_is_printed_with_its_sign() {
        let captured = UtcInstant { secs: 1_787_604_456 };
        assert_eq!(captured.rfc3339(), "2026-08-24T20:47:36Z");
        assert_eq!(captured.rfc3339_with(UtcOffset { secs: -21_600 }), "2026-08-24T14:47:36-06:00");
        assert_eq!(captured.rfc3339_with(UtcOffset { secs: 19_800 }), "2026-08-25T02:17:36+05:30");
    }

    #[test]
    fn a_leap_day_is_a_real_date() {
        let civil = UtcInstant { secs: 1_709_164_800 }.civil(UtcOffset { secs: 0 });
        assert_eq!((civil.year, civil.month, civil.day), (2024, 2, 29));
    }

    #[test]
    fn a_civil_time_names_the_instant_it_came_from() {
        let captured = UtcInstant { secs: 1_787_604_456 };
        for offset in [UtcOffset { secs: -21_600 }, UtcOffset { secs: 19_800 }, UtcOffset { secs: 0 }] {
            assert_eq!(captured.civil(offset).instant(offset), Some(captured), "{}", offset.label());
        }
    }

    #[test]
    fn the_extremes_of_an_i64_instant_convert_without_overflow() {
        let late = UtcInstant { secs: i64::MAX }.civil(UtcOffset { secs: 50_400 });
        let early = UtcInstant { secs: i64::MIN }.civil(UtcOffset { secs: -50_400 });
        assert!(late.year > early.year);
        assert_eq!(late.instant(UtcOffset { secs: 50_400 }), Some(UtcInstant { secs: i64::MAX }));
        assert_eq!(late.instant(UtcOffset { secs: -50_400 }), None);
    }

    #[test]
    fn the_calendar_decides_which_civil_times_exist() {
        let base = Civil { year: 2024, month: 2, day: 29, hour: 23, minute: 59, second: 59 };
        assert!(base.is_valid());
        assert!(!Civil { year: 2023, ..base }.is_valid());
        assert!(Civil { year: 2000, ..base }.is_valid());
        assert!(!Civil { year: 1900, ..base }.is_valid());
        assert!(!Civil { month: 4, day: 31, ..base }.is_valid());
        assert!(!Civil { month: 0, ..base }.is_valid());
        assert!(!Civil { month: 13, ..base }.is_valid());
        assert!(!Civil { day: 0, ..base }.is_valid());
        assert!(!Civil { hour: 24, ..base }.is_valid());
        assert!(!Civil { minute: 60, ..base }.is_valid());
        assert!(!Civil { second: 60, ..base }.is_valid());
    }

    #[test]
    fn a_file_time_ages_by_whole_seconds_counting_its_nanoseconds() {
        let mtime = FileTime { secs: 100, nanos: 999_999_999 };
        assert_eq!(mtime.age_secs(UtcInstant { secs: 130 }), 29);
        assert_eq!(FileTime { secs: 100, nanos: 0 }.age_secs(UtcInstant { secs: 130 }), 30);
        assert_eq!(FileTime { secs: i64::MIN, nanos: 1 }.age_secs(UtcInstant { secs: i64::MAX }), i64::MAX);
    }
}
```

`crates/vpt-domain/src/digest.rs`:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hex_round_trips_and_the_prefixes_are_its_leading_characters() {
        let mut bytes = [0u8; 32];
        bytes[..6].copy_from_slice(&[0x4f, 0x3a, 0xb1, 0x9c, 0x02, 0xde]);
        let digest = Sha256Digest(bytes);
        assert!(digest.hex().starts_with("4f3ab19c02de"));
        assert_eq!(digest.hex().len(), 64);
        assert_eq!(digest.hash12(), "4f3ab19c02de");
        assert_eq!(digest.hash8(), "4f3ab19c");
        assert_eq!(Sha256Digest::from_hex(&digest.hex()), Some(digest));
    }

    #[test]
    fn malformed_hex_is_refused() {
        assert_eq!(Sha256Digest::from_hex("zz"), None);
        assert_eq!(Sha256Digest::from_hex(&"ab".repeat(31)), None);
    }
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-domain`

Expected: the build of the crate's tests fails with `cannot find` for `UtcInstant`, `UtcOffset`,
`FileTime`, `Civil` and `Sha256Digest`. A run that succeeds does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-domain/src/time.rs`, above its test module:

```rust
//! Instants, offsets and file times, with the civil-date arithmetic the
//! identity and the notes need. No clock lives here.

const NANOS_PER_SECOND: i128 = 1_000_000_000;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct UtcInstant {
    pub secs: i64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct UtcOffset {
    pub secs: i32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct FileTime {
    pub secs: i64,
    pub nanos: u32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Civil {
    pub year: i64,
    pub month: u32,
    pub day: u32,
    pub hour: u32,
    pub minute: u32,
    pub second: u32,
}

impl UtcInstant {
    pub fn civil(self, offset: UtcOffset) -> Civil {
        let local = i128::from(self.secs) + i128::from(offset.secs);
        let days = local.div_euclid(86_400);
        let seconds = local.rem_euclid(86_400);
        let (year, month, day) = civil_from_days(days);
        Civil {
            year,
            month,
            day,
            hour: (seconds / 3_600) as u32,
            minute: ((seconds % 3_600) / 60) as u32,
            second: (seconds % 60) as u32,
        }
    }

    pub fn rfc3339(self) -> String {
        let c = self.civil(UtcOffset { secs: 0 });
        format!("{:04}-{:02}-{:02}T{:02}:{:02}:{:02}Z", c.year, c.month, c.day, c.hour, c.minute, c.second)
    }

    pub fn rfc3339_with(self, offset: UtcOffset) -> String {
        let c = self.civil(offset);
        format!(
            "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}{}",
            c.year, c.month, c.day, c.hour, c.minute, c.second, offset.label()
        )
    }
}

impl UtcOffset {
    pub fn label(self) -> String {
        let sign = if self.secs < 0 { '-' } else { '+' };
        let magnitude = self.secs.unsigned_abs();
        format!("{sign}{:02}:{:02}", magnitude / 3_600, (magnitude % 3_600) / 60)
    }
}

impl Civil {
    /// The instant this civil time names when read at `offset`.
    pub fn instant(self, offset: UtcOffset) -> Option<UtcInstant> {
        let seconds = i128::from(self.hour) * 3_600 + i128::from(self.minute) * 60 + i128::from(self.second);
        let local = days_from_civil(self.year, self.month, self.day) * 86_400 + seconds;
        i64::try_from(local - i128::from(offset.secs)).ok().map(|secs| UtcInstant { secs })
    }

    pub fn is_valid(self) -> bool {
        (1..=12).contains(&self.month)
            && (1..=days_in_month(self.year, self.month)).contains(&self.day)
            && self.hour < 24
            && self.minute < 60
            && self.second < 60
    }
}

impl FileTime {
    /// Whole seconds from this file time to `now`, the nanoseconds counted.
    pub fn age_secs(self, now: UtcInstant) -> i64 {
        let elapsed = (i128::from(now.secs) - i128::from(self.secs)) * NANOS_PER_SECOND - i128::from(self.nanos);
        elapsed.div_euclid(NANOS_PER_SECOND).clamp(i128::from(i64::MIN), i128::from(i64::MAX)) as i64
    }
}

fn days_in_month(year: i64, month: u32) -> u32 {
    match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 if year % 4 == 0 && (year % 100 != 0 || year % 400 == 0) => 29,
        _ => 28,
    }
}

/// Days since 1970-01-01 to a proleptic Gregorian date (Howard Hinnant's algorithm).
fn civil_from_days(days: i128) -> (i64, u32, u32) {
    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = z.rem_euclid(146_097);
    let yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    let year = if m <= 2 { y + 1 } else { y };
    (i64::try_from(year).expect("an i64 instant spans fewer than i64 years"), m, d)
}

/// A proleptic Gregorian date to days since 1970-01-01 (the inverse of `civil_from_days`).
fn days_from_civil(year: i64, month: u32, day: u32) -> i128 {
    let y = i128::from(year) - i128::from(month <= 2);
    let era = y.div_euclid(400);
    let yoe = y.rem_euclid(400);
    let m = i128::from(month);
    let doy = (153 * (if m > 2 { m - 3 } else { m + 9 }) + 2) / 5 + i128::from(day) - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146_097 + doe - 719_468
}
```

`crates/vpt-domain/src/digest.rs`, above its test module:

```rust
//! A SHA-256 digest and the prefixes the identity and note names use.

#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct Sha256Digest(pub [u8; 32]);

impl Sha256Digest {
    pub fn hex(&self) -> String {
        self.0.iter().map(|byte| format!("{byte:02x}")).collect()
    }

    pub fn hash12(&self) -> String {
        self.hex()[..12].to_owned()
    }

    pub fn hash8(&self) -> String {
        self.hex()[..8].to_owned()
    }

    pub fn from_hex(text: &str) -> Option<Sha256Digest> {
        if text.len() != 64 || !text.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            return None;
        }
        let mut bytes = [0u8; 32];
        for (index, chunk) in text.as_bytes().chunks(2).enumerate() {
            bytes[index] = u8::from_str_radix(std::str::from_utf8(chunk).ok()?, 16).ok()?;
        }
        Some(Sha256Digest(bytes))
    }
}

impl std::fmt::Debug for Sha256Digest {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Sha256Digest({})", self.hex())
    }
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-domain`

Expected: the nine tests of `time` and `digest` PASS alongside the earlier domain tests. Run
`cargo clippy -p vpt-domain --all-targets -- -D warnings` and expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates/vpt-domain
SKIP_AI_COMMIT=1 git commit -m "feat(domain): instants, offsets, file times and digests"
```

______________________________________________________________________
