### Task 5: Settings and root resolution

## Controller execution constraints

- Read the ledger's Tasks 5 and 6 source read-only ruling. Reject Home and Config equal to or below the Voice Memos container in either input order, but permit harmless ancestors. Preserve symmetric store/state overlap rejection.
- Test-first means compiling behavioral failures, not unresolved-name compiler errors. Preserve existing parser, output, configuration and duration regressions.
- Retain the existing schema/default-rendering and structural/value validation rather than replacing prior modules wholesale with plan samples. Inspect the actual Task 3 and 4 APIs before editing.
- Complete Task 5 only. Task 5a's descriptor access is separate and immediately follows. Database-amendment D1 starts after Task 10; do not implement it here.
- Add explicit equality, descendant, ancestor and unrelated-root cases for Home and Config. Keep every filesystem fixture inside uniquely owned temporary roots.
- Use clean-code-rust and OWASP boundary review. Apply exact mutation/control pairs, full workspace gates, timings, staged-file size audit and committed-HEAD secrets scan. Record evidence in task-5-report.md.
- You own only this task's layout, retention value, application settings, adapter settings/roots/paths, focused tests and required exports, plus your report/evidence. Main owns progress.md and Todoist. You are not alone: preserve all unrelated work.
- No unsolicited docstrings, broad lint suppression, subagents, new worktree, unrelated edits, push, pull request, installation, live destinations or destructive cleanup. Use apply_patch for authored edits and verify buffer safety.
- Preserve curated exports and natural file boundaries. The command crate remains vpt. Do not modify third-party sources or bypass any denied safeguard.

The validated table becomes typed `Settings` the application reads; roots are expanded, made absolute,
resolved through the home's permitted symlink, and refused when they overlap in a way spec section 4.1
forbids. Resolution writes nothing: every root is computed and checked first, and only a separate, later
call creates the approved leaves. The home may contain its stores. The protected root is the Voice Memos
container, the parent of `recordings_dir`, so the live database beside `Recordings/` is covered by the
overlap rule too; the configuration directory is a root of its own.

**Files:**

- Create: `crates/vpt-domain/src/layout.rs`, `crates/vpt-domain/src/retention.rs`
- Modify: `crates/vpt-domain/src/lib.rs`
- Create: `crates/vpt-application/src/settings.rs`
- Modify: `crates/vpt-application/src/lib.rs`
- Create: `crates/vpt-adapters/src/config/settings.rs`, `crates/vpt-adapters/src/config/roots.rs`,
  `crates/vpt-adapters/src/config/roots/tests.rs`, `crates/vpt-adapters/src/config/paths.rs`
- Modify: `crates/vpt-adapters/src/config/mod.rs`

**Interfaces:**

- Consumes: `config::{get, ConfigError, STORE_KEYS, load_text}`, `parse_duration`.

- Produces:

  - `vpt_domain::layout::StoreKey::{Audio, Transcripts, Analysis, Briefs, EngineOutputs,`
    `Drafts, Released}` with `all() -> [StoreKey; 7]`, `key_name(self) -> &'static str`,
    `default_leaf(self) -> &'static str`, `from_key_name(name: &str) -> Option<StoreKey>`,
    `is_private(self) -> bool` (everything but `Released`);
    `RootName::{Home, Store(StoreKey), State, Config, VoiceMemos}` with `key_name(self) -> String`;
    `RootConflict { pub first: RootName, pub second: RootName }`;
    `check_overlaps(roots: &[(RootName, &Path)]) -> Result<(), RootConflict>`.
  - `vpt_domain::retention::Hold` with `never() -> Hold`, `of_seconds(seconds: u64) -> Hold`,
    `seconds(self) -> u64` (the expiry decision arrives in Task 31).
  - `vpt_application::Settings { pub config_version: u32, pub home: PathBuf, pub state_dir: PathBuf,`
    `pub symlink_target: Option<PathBuf>, pub helper_path: PathBuf, pub stores: StorePaths,`
    `pub source: SourceSettings, pub notify: NotifySettings, pub retention: RetentionSettings }`;
    `StorePaths { pub audio, pub transcripts, pub analysis, pub briefs, pub engine_outputs, pub drafts,`
    `pub released: PathBuf }` with `get(&self, key: StoreKey) -> &Path` and
    `set(&mut self, key: StoreKey, path: PathBuf)`;
    `SourceSettings { pub recordings_dir: PathBuf, pub read_titles: bool, pub quiet_period_secs: u64,`
    `pub deferral_page_threshold: u32, pub max_audio_bytes: u64 }`;
    `NotifyMode::{Desktop, Command(Vec<String>), Off}`;
    `NotifySettings { pub mode: NotifyMode, pub aggregate_after: u32 }`;
    `RetentionSettings { pub enabled: bool, pub include_audio: bool, pub holds: Vec<(StoreKey, Hold)> }`
    with `hold(&self, key: StoreKey) -> Hold`.
  - `vpt_adapters::config::{DEFAULT_HOME: &str, from_table(table: &toml::Table, home_dir: &Path) ->`
    `Result<Settings, ConfigError>}`.
  - `vpt_adapters::config::RootError::{NotAbsolute { key: String }, ParentMissing { key: String },`
    `NotADirectory { key: String }, PathEscape { key: String }, Overlap { first: String, second: String },`
    `Io { key: String, detail: String }}`;
    `Roots { pub home: PathBuf, pub state_dir: PathBuf, pub stores: StorePaths,`
    `pub recordings_dir: PathBuf,` `pub container: PathBuf, pub config_dir: PathBuf }` (every path
    absolute, canonical where it exists);
    `planned_directory(path: &Path, key: &str) -> Result<PathBuf, RootError>` (resolve existing ancestors
    without creation); `resolve_stores(settings: &Settings) -> Result<StorePaths, RootError>` (home and
    stores only); `resolve(settings: &Settings, config_dir: &Path) -> Result<Roots, RootError>` (writes
    nothing); `Roots::create_state_dir(&self) -> Result<(), RootError>` and
    `Roots::create_leaves(&self) -> Result<(), RootError>` (the home and every missing store leaf, mode
    0700, only after a resolution succeeded).
  - `vpt_adapters::config::{config_path(env: impl Fn(&str) -> Option<String>) -> PathBuf,`
    `default_state_dir(env: impl Fn(&str) -> Option<String>) -> String}`.

- [ ] **Step 1: Write the failing tests**

Declare the modules first: `crates/vpt-domain/src/lib.rs` gains `pub mod layout;` and
`pub mod retention;`; `crates/vpt-application/src/lib.rs` becomes

```rust
//! Use cases and the ports they own.

mod settings;

pub use settings::{NotifyMode, NotifySettings, RetentionSettings, Settings, SourceSettings, StorePaths};
```

and `crates/vpt-adapters/src/config/mod.rs` gains `mod paths; mod roots; mod settings;` with

```rust
pub use paths::{config_path, default_state_dir};
pub use roots::{RootError, Roots, planned_directory, resolve, resolve_stores};
pub use settings::{DEFAULT_HOME, from_table};
```

`crates/vpt-adapters/src/lib.rs` also gains `pub use config::{RootError, Roots};`.

Each new file starts as its test module alone. `crates/vpt-domain/src/layout.rs`:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;

    #[test]
    fn the_home_may_contain_its_stores() {
        let roots = [
            (RootName::Home, Path::new("/h")),
            (RootName::Store(StoreKey::Audio), Path::new("/h/audio")),
            (RootName::Store(StoreKey::Released), Path::new("/h/released")),
            (RootName::State, Path::new("/s")),
            (RootName::Config, Path::new("/c")),
            (RootName::VoiceMemos, Path::new("/vm")),
        ];
        assert_eq!(check_overlaps(&roots), Ok(()));
    }

    #[test]
    fn two_stores_may_not_nest_or_coincide() {
        let roots = [
            (RootName::Store(StoreKey::Audio), Path::new("/h/audio")),
            (RootName::Store(StoreKey::Drafts), Path::new("/h/audio/drafts")),
        ];
        assert_eq!(
            check_overlaps(&roots),
            Err(RootConflict { first: RootName::Store(StoreKey::Audio), second: RootName::Store(StoreKey::Drafts) })
        );
    }

    #[test]
    fn a_writable_root_may_not_overlap_the_voice_memos_container() {
        let roots = [(RootName::State, Path::new("/vm/state")), (RootName::VoiceMemos, Path::new("/vm"))];
        assert!(check_overlaps(&roots).is_err());
        let roots = [(RootName::Store(StoreKey::Audio), Path::new("/x")), (RootName::VoiceMemos, Path::new("/x/Recordings"))];
        assert!(check_overlaps(&roots).is_err());
    }

    #[test]
    fn the_release_destination_may_not_overlap_a_private_root() {
        let roots = [(RootName::Store(StoreKey::Released), Path::new("/c/out")), (RootName::Config, Path::new("/c"))];
        assert!(check_overlaps(&roots).is_err());
        let roots = [(RootName::State, Path::new("/s")), (RootName::Store(StoreKey::Released), Path::new("/s/out"))];
        assert!(check_overlaps(&roots).is_err());
    }
}
```

`crates/vpt-adapters/src/config/roots.rs` starts with `#[cfg(test)] mod tests;`.
`crates/vpt-adapters/src/config/roots/tests.rs`:

```rust
use super::*;
use crate::config::{from_table, load_text};
use std::os::unix::fs::PermissionsExt;
use vpt_application::Settings;

/// A fixture whose Voice Memos container is `<temp>/voice-memos` and whose
/// writable roots all sit outside it.
fn fixture() -> tempfile::TempDir {
    let temp = tempfile::tempdir().expect("temp");
    std::fs::create_dir_all(temp.path().join("h")).expect("home");
    std::fs::create_dir_all(temp.path().join("voice-memos/Recordings")).expect("voice memos");
    std::fs::write(temp.path().join("voice-memos/CloudRecordings.db"), b"live").expect("live db");
    std::fs::create_dir_all(temp.path().join("cfg")).expect("config dir");
    temp
}

fn settings_in(root: &Path, extra: &str) -> Settings {
    let text = format!(
        "config_version = 1\n[home]\npath = \"{}\"\nstate_dir = \"{}\"\n[source]\nrecordings_dir = \"{}\"\n{extra}",
        root.join("h").display(),
        root.join("s").display(),
        root.join("voice-memos/Recordings").display()
    );
    from_table(&load_text(&text).expect("loads"), root).expect("settings")
}

fn entries(dir: &Path) -> Vec<String> {
    let mut names: Vec<String> = std::fs::read_dir(dir)
        .expect("readable")
        .map(|entry| {
            entry
                .expect("entry")
                .file_name()
                .to_string_lossy()
                .into_owned()
        })
        .collect();
    names.sort();
    names
}

#[test]
fn resolution_writes_nothing_and_create_leaves_makes_the_store_leaves_0700() {
    let temp = fixture();
    let roots = resolve(&settings_in(temp.path(), ""), &temp.path().join("cfg")).expect("resolves");
    assert!(
        !temp.path().join("h/audio").exists(),
        "resolve created a leaf"
    );
    assert!(
        !temp.path().join("s").exists(),
        "resolve created the state directory"
    );
    roots.create_leaves().expect("leaves");
    assert!(roots.stores.audio.is_dir());
    assert_eq!(
        roots.stores.audio,
        temp.path()
            .join("h/audio")
            .canonicalize()
            .expect("canonical")
    );
    assert_eq!(
        std::fs::metadata(&roots.stores.audio)
            .expect("meta")
            .permissions()
            .mode()
            & 0o777,
        0o700
    );
    roots.create_state_dir().expect("state");
    assert_eq!(
        std::fs::metadata(&roots.state_dir)
            .expect("meta")
            .permissions()
            .mode()
            & 0o777,
        0o700
    );
}

#[test]
fn a_missing_default_home_is_a_prospective_leaf_with_its_stores_below_it() {
    let temp = fixture();
    std::fs::remove_dir(temp.path().join("h")).expect("no home yet");
    let roots = resolve(&settings_in(temp.path(), ""), &temp.path().join("cfg")).expect("resolves");
    assert_eq!(
        roots.stores.drafts,
        temp.path()
            .canonicalize()
            .expect("canonical")
            .join("h/drafts")
    );
    roots.create_leaves().expect("leaves");
    assert!(temp.path().join("h/drafts").is_dir());
}

#[test]
fn a_store_pointed_elsewhere_needs_an_existing_parent() {
    let temp = fixture();
    let extra = format!(
        "[stores]\naudio = \"{}\"\n",
        temp.path().join("missing/audio").display()
    );
    let error = resolve(&settings_in(temp.path(), &extra), &temp.path().join("cfg")).unwrap_err();
    assert_eq!(
        error,
        RootError::ParentMissing {
            key: "stores.audio".into()
        }
    );
}

#[test]
fn a_store_inside_the_voice_memos_container_is_refused_and_the_container_is_untouched() {
    let temp = fixture();
    let container = temp.path().join("voice-memos");
    let before = entries(&container);
    let live = std::fs::metadata(container.join("CloudRecordings.db")).expect("live");
    let extra = format!(
        "[stores]\ndrafts = \"{}\"\n",
        container.join("drafts").display()
    );

    let error = resolve(&settings_in(temp.path(), &extra), &temp.path().join("cfg")).unwrap_err();

    assert_eq!(
        error,
        RootError::Overlap {
            first: "source.recordings_dir".into(),
            second: "stores.drafts".into()
        }
    );
    assert_eq!(entries(&container), before);
    assert!(!container.join("drafts").exists());
    let after = std::fs::metadata(container.join("CloudRecordings.db")).expect("live");
    assert_eq!(
        (after.len(), after.modified().expect("mtime")),
        (live.len(), live.modified().expect("mtime"))
    );
    assert!(
        !temp.path().join("h/audio").exists(),
        "a refusal created a leaf elsewhere"
    );
}

#[test]
fn the_configuration_directory_is_a_root_the_released_store_may_not_overlap() {
    let temp = fixture();
    let extra = format!(
        "[stores]\nreleased = \"{}\"\n",
        temp.path().join("cfg/out").display()
    );
    let error = resolve(&settings_in(temp.path(), &extra), &temp.path().join("cfg")).unwrap_err();
    assert_eq!(
        error,
        RootError::Overlap {
            first: "config".into(),
            second: "stores.released".into()
        }
    );
}

#[test]
fn a_relative_root_after_expansion_is_refused() {
    let temp = fixture();
    let error = resolve(
        &settings_in(temp.path(), "[stores]\nbriefs = \"briefs\"\n"),
        &temp.path().join("cfg"),
    )
    .unwrap_err();
    assert_eq!(
        error,
        RootError::NotAbsolute {
            key: "stores.briefs".into()
        }
    );
}

#[test]
fn a_file_where_a_root_belongs_is_refused() {
    let temp = fixture();
    std::fs::write(temp.path().join("h/audio"), b"not a directory").expect("file");
    let error = resolve(&settings_in(temp.path(), ""), &temp.path().join("cfg")).unwrap_err();
    assert_eq!(
        error,
        RootError::NotADirectory {
            key: "stores.audio".into()
        }
    );
}

#[test]
fn a_symlinked_home_is_followed_when_no_target_is_configured() {
    let temp = fixture();
    std::fs::remove_dir(temp.path().join("h")).expect("replace the home");
    std::fs::create_dir_all(temp.path().join("real")).expect("real home");
    std::os::unix::fs::symlink(temp.path().join("real"), temp.path().join("h")).expect("link");
    let roots = resolve(&settings_in(temp.path(), ""), &temp.path().join("cfg")).expect("resolves");
    assert_eq!(
        roots.home,
        temp.path().join("real").canonicalize().expect("canonical")
    );
    assert_eq!(
        roots.container,
        temp.path()
            .join("voice-memos")
            .canonicalize()
            .expect("canonical")
    );
}

#[test]
fn a_missing_home_does_not_authorize_parent_traversal_into_the_source() {
    let temp = fixture();
    std::fs::remove_dir(temp.path().join("h")).expect("missing home");
    let before = entries(&temp.path().join("voice-memos"));
    let settings = settings_in(
        temp.path(),
        "[stores]\naudio = \"<home>/../voice-memos/evil\"\n",
    );

    assert_eq!(
        resolve(&settings, &temp.path().join("cfg")).unwrap_err(),
        RootError::ParentMissing {
            key: "stores.audio".into(),
        }
    );
    assert_eq!(entries(&temp.path().join("voice-memos")), before);
    assert!(!temp.path().join("h").exists());
}
#[test]
fn a_dangling_configuration_directory_link_is_refused() {
    let temp = fixture();
    let selected = temp.path().join("config-link");
    std::os::unix::fs::symlink(temp.path().join("absent"), &selected).expect("link");
    assert_eq!(
        resolve(&settings_in(temp.path(), ""), &selected).unwrap_err(),
        RootError::PathEscape {
            key: "config".into()
        }
    );
}

#[test]
fn resolution_can_describe_absent_source_and_deep_default_directories_without_writes() {
    let temp = fixture();
    let mut settings = settings_in(temp.path(), "");
    settings.state_dir = temp.path().join("new/local/state/vpt");
    settings.source.recordings_dir = temp.path().join("absent-source/Recordings");
    let selected = temp.path().join("new/config/vpt");
    let roots = resolve(&settings, &selected).expect("prospective roots");
    let base = temp.path().canonicalize().expect("canonical");
    assert_eq!(roots.config_dir, base.join("new/config/vpt"));
    assert_eq!(roots.state_dir, base.join("new/local/state/vpt"));
    assert_eq!(roots.container, base.join("absent-source"));
    assert!(!temp.path().join("new").exists());
    assert!(!temp.path().join("absent-source").exists());
}
```

`crates/vpt-adapters/src/config/settings.rs`:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::load_text;
    use std::path::Path;
    use vpt_application::NotifyMode;
    use vpt_domain::layout::StoreKey;

    #[test]
    fn tilde_and_home_placeholders_expand() {
        let settings = from_table(&load_text("config_version = 1\n").expect("loads"), Path::new("/h/someone")).expect("settings");
        assert_eq!(settings.home, Path::new("/h/someone/.vpt"));
        assert_eq!(settings.stores.get(StoreKey::EngineOutputs), Path::new("/h/someone/.vpt/engine-outputs"));
        assert_eq!(settings.state_dir, Path::new("/h/someone/.local/state/vpt"));
    }

    #[test]
    fn notify_command_mode_carries_its_argv_and_off_carries_nothing() {
        let table = load_text("config_version = 1\n[notify]\nmode = \"command\"\ncommand = [\"notify-command\", \"{event}\"]\n").expect("loads");
        let settings = from_table(&table, Path::new("/u")).expect("settings");
        assert_eq!(settings.notify.mode, NotifyMode::Command(vec!["notify-command".into(), "{event}".into()]));
        let table = load_text("config_version = 1\n[notify]\nmode = \"off\"\n").expect("loads");
        assert_eq!(from_table(&table, Path::new("/u")).expect("settings").notify.mode, NotifyMode::Off);
    }

    #[test]
    fn command_mode_with_an_empty_command_is_refused() {
        let table = load_text("config_version = 1\n[notify]\nmode = \"command\"\n").expect("loads");
        let error = from_table(&table, Path::new("/u")).unwrap_err();
        assert_eq!(error.key(), Some("notify.command"));
    }

    #[test]
    fn a_symlink_target_with_a_non_default_home_is_refused() {
        let table = load_text("config_version = 1\n[home]\npath = \"/elsewhere\"\nsymlink_target = \"/vol/vpt\"\n").expect("loads");
        assert_eq!(from_table(&table, Path::new("/u")).unwrap_err().key(), Some("home.symlink_target"));
    }

    #[test]
    fn retention_holds_are_parsed_per_store() {
        let table = load_text("config_version = 1\n[retention]\nenabled = true\n[retention.hold]\naudio = \"2d\"\n").expect("loads");
        let settings = from_table(&table, Path::new("/u")).expect("settings");
        assert!(settings.retention.enabled);
        assert_eq!(settings.retention.hold(StoreKey::Audio).seconds(), 172_800);
        assert_eq!(settings.retention.hold(StoreKey::Drafts).seconds(), 0);
    }
}
```

`crates/vpt-adapters/src/config/paths.rs`:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    fn env_of(pairs: &[(&str, &str)]) -> impl Fn(&str) -> Option<String> + '_ {
        move |name| pairs.iter().find(|(key, _)| *key == name).map(|(_, value)| (*value).to_owned())
    }

    #[test]
    fn vpt_config_wins_over_xdg_which_wins_over_home() {
        assert_eq!(config_path(env_of(&[("VPT_CONFIG", "/c.toml"), ("XDG_CONFIG_HOME", "/x"), ("HOME", "/h")])), PathBuf::from("/c.toml"));
        assert_eq!(config_path(env_of(&[("XDG_CONFIG_HOME", "/x"), ("HOME", "/h")])), PathBuf::from("/x/vpt/config.toml"));
        assert_eq!(config_path(env_of(&[("HOME", "/h")])), PathBuf::from("/h/.config/vpt/config.toml"));
    }

    #[test]
    fn the_state_dir_default_follows_xdg_state_home_when_set() {
        assert_eq!(default_state_dir(env_of(&[("XDG_STATE_HOME", "/s")])), "/s/vpt");
        assert_eq!(default_state_dir(env_of(&[])), "~/.local/state/vpt");
    }
}
```

`crates/vpt-application/src/settings.rs` and `crates/vpt-domain/src/retention.rs` start as their doc
lines; the re-exports in `lib.rs` name items that do not exist yet, which is part of the red build.

- [ ] **Step 2: Run the tests to verify they fail**

Run independently, including the second command after the first expected failure:

Run: `cargo test -p vpt-domain layout`

Run: `cargo test -p vpt-adapters config`

Expected: the builds fail with `cannot find` for `check_overlaps`, `RootName`, `from_table`, `resolve`,
`config_path` and the `Settings` re-export. Every new test module is compiled and selected; a run that
selects zero tests, or that succeeds, does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-domain/src/layout.rs`, above its test module:

```rust
//! The store keys and the root overlap rule of spec section 4.1.

use std::path::Path;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StoreKey {
    Audio,
    Transcripts,
    Analysis,
    Briefs,
    EngineOutputs,
    Drafts,
    Released,
}

impl StoreKey {
    pub fn all() -> [StoreKey; 7] {
        [
            StoreKey::Audio,
            StoreKey::Transcripts,
            StoreKey::Analysis,
            StoreKey::Briefs,
            StoreKey::EngineOutputs,
            StoreKey::Drafts,
            StoreKey::Released,
        ]
    }

    pub fn key_name(self) -> &'static str {
        match self {
            StoreKey::Audio => "audio",
            StoreKey::Transcripts => "transcripts",
            StoreKey::Analysis => "analysis",
            StoreKey::Briefs => "briefs",
            StoreKey::EngineOutputs => "engine_outputs",
            StoreKey::Drafts => "drafts",
            StoreKey::Released => "released",
        }
    }

    pub fn default_leaf(self) -> &'static str {
        match self {
            StoreKey::EngineOutputs => "engine-outputs",
            other => other.key_name(),
        }
    }

    pub fn from_key_name(name: &str) -> Option<StoreKey> {
        StoreKey::all().into_iter().find(|key| key.key_name() == name)
    }

    pub fn is_private(self) -> bool {
        self != StoreKey::Released
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RootName {
    Home,
    Store(StoreKey),
    State,
    Config,
    VoiceMemos,
}

impl RootName {
    pub fn key_name(self) -> String {
        match self {
            RootName::Home => "home.path".into(),
            RootName::Store(store) => format!("stores.{}", store.key_name()),
            RootName::State => "home.state_dir".into(),
            RootName::Config => "config".into(),
            RootName::VoiceMemos => "source.recordings_dir".into(),
        }
    }

    fn writable(self) -> bool {
        matches!(self, RootName::Store(_) | RootName::State)
    }
}

#[derive(Debug, PartialEq, Eq)]
pub struct RootConflict {
    pub first: RootName,
    pub second: RootName,
}

fn overlap(a: &Path, b: &Path) -> bool {
    a.starts_with(b) || b.starts_with(a)
}

fn forbidden(a: RootName, b: RootName) -> bool {
    match (a, b) {
        (RootName::Store(_), RootName::Store(_)) => true,
        (RootName::VoiceMemos, other) | (other, RootName::VoiceMemos) => other.writable(),
        (RootName::Store(StoreKey::Released), other) | (other, RootName::Store(StoreKey::Released)) => {
            matches!(other, RootName::State | RootName::Config)
        }
        _ => false,
    }
}

pub fn check_overlaps(roots: &[(RootName, &Path)]) -> Result<(), RootConflict> {
    for (index, (first, first_path)) in roots.iter().enumerate() {
        for (second, second_path) in &roots[index + 1..] {
            if forbidden(*first, *second) && overlap(first_path, second_path) {
                return Err(RootConflict { first: *first, second: *second });
            }
        }
    }
    Ok(())
}
```

A released store overlapping a private store is covered by the store-versus-store arm.

`crates/vpt-domain/src/retention.rs` (the type only; Task 31 adds the decision):

```rust
//! Retention: a hold per store and the expiry decision.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Hold {
    seconds: u64,
}

impl Hold {
    pub fn never() -> Hold {
        Hold { seconds: 0 }
    }

    pub fn of_seconds(seconds: u64) -> Hold {
        Hold { seconds }
    }

    pub fn seconds(self) -> u64 {
        self.seconds
    }
}
```

`crates/vpt-application/src/settings.rs`:

```rust
//! Validated settings. Built by the configuration adapter, read by use cases;
//! nothing here knows TOML.

use std::path::{Path, PathBuf};
use vpt_domain::layout::StoreKey;
use vpt_domain::retention::Hold;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Settings {
    pub config_version: u32,
    pub home: PathBuf,
    pub state_dir: PathBuf,
    pub symlink_target: Option<PathBuf>,
    pub helper_path: PathBuf,
    pub stores: StorePaths,
    pub source: SourceSettings,
    pub notify: NotifySettings,
    pub retention: RetentionSettings,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StorePaths {
    pub audio: PathBuf,
    pub transcripts: PathBuf,
    pub analysis: PathBuf,
    pub briefs: PathBuf,
    pub engine_outputs: PathBuf,
    pub drafts: PathBuf,
    pub released: PathBuf,
}

impl StorePaths {
    pub fn get(&self, key: StoreKey) -> &Path {
        match key {
            StoreKey::Audio => &self.audio,
            StoreKey::Transcripts => &self.transcripts,
            StoreKey::Analysis => &self.analysis,
            StoreKey::Briefs => &self.briefs,
            StoreKey::EngineOutputs => &self.engine_outputs,
            StoreKey::Drafts => &self.drafts,
            StoreKey::Released => &self.released,
        }
    }

    pub fn set(&mut self, key: StoreKey, path: PathBuf) {
        match key {
            StoreKey::Audio => self.audio = path,
            StoreKey::Transcripts => self.transcripts = path,
            StoreKey::Analysis => self.analysis = path,
            StoreKey::Briefs => self.briefs = path,
            StoreKey::EngineOutputs => self.engine_outputs = path,
            StoreKey::Drafts => self.drafts = path,
            StoreKey::Released => self.released = path,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SourceSettings {
    pub recordings_dir: PathBuf,
    pub read_titles: bool,
    pub quiet_period_secs: u64,
    pub deferral_page_threshold: u32,
    pub max_audio_bytes: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NotifyMode {
    Desktop,
    Command(Vec<String>),
    Off,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NotifySettings {
    pub mode: NotifyMode,
    pub aggregate_after: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RetentionSettings {
    pub enabled: bool,
    pub include_audio: bool,
    pub holds: Vec<(StoreKey, Hold)>,
}

impl RetentionSettings {
    pub fn hold(&self, key: StoreKey) -> Hold {
        self.holds.iter().find(|(store, _)| *store == key).map_or(Hold::never(), |(_, hold)| *hold)
    }
}
```

`crates/vpt-adapters/src/config/settings.rs`, above its test module:

```rust
//! From the validated table to typed settings, with `~` and `<home>/` expanded.

use super::load::{ConfigError, get};
use std::path::{Path, PathBuf};
use toml::{Table, Value};
use vpt_application::{NotifyMode, NotifySettings, RetentionSettings, Settings, SourceSettings, StorePaths};
use vpt_domain::duration::parse_duration;
use vpt_domain::layout::StoreKey;
use vpt_domain::retention::Hold;

pub const DEFAULT_HOME: &str = "~/.vpt";

pub fn from_table(table: &Table, home_dir: &Path) -> Result<Settings, ConfigError> {
    let home_text = text(table, "home.path")?;
    let home = expand(&home_text, home_dir, None);
    let symlink_text = text(table, "home.symlink_target")?;
    let symlink_target = if symlink_text.is_empty() {
        None
    } else {
        if home_text != DEFAULT_HOME {
            return Err(ConfigError::OutOfRange {
                key: "home.symlink_target".into(),
                rule: "home.path must stay at its default when a symlink target is set".into(),
            });
        }
        Some(expand(&symlink_text, home_dir, None))
    };
    let mut stores = StorePaths {
        audio: PathBuf::new(),
        transcripts: PathBuf::new(),
        analysis: PathBuf::new(),
        briefs: PathBuf::new(),
        engine_outputs: PathBuf::new(),
        drafts: PathBuf::new(),
        released: PathBuf::new(),
    };
    for key in StoreKey::all() {
        let raw = text(table, &format!("stores.{}", key.key_name()))?;
        stores.set(key, expand(&raw, home_dir, Some(&home)));
    }
    let mode = match text(table, "notify.mode")?.as_str() {
        "desktop" => NotifyMode::Desktop,
        "off" => NotifyMode::Off,
        _ => {
            let argv = strings(table, "notify.command")?;
            if argv.is_empty() {
                return Err(ConfigError::OutOfRange { key: "notify.command".into(), rule: "command mode needs a command".into() });
            }
            NotifyMode::Command(argv)
        }
    };
    let mut holds = Vec::new();
    for key in StoreKey::all() {
        holds.push((key, hold(table, &format!("retention.hold.{}", key.key_name()))?));
    }
    Ok(Settings {
        config_version: small(table, "config_version")?,
        home,
        state_dir: expand(&text(table, "home.state_dir")?, home_dir, None),
        symlink_target,
        helper_path: PathBuf::from(text(table, "helper.path")?),
        stores,
        source: SourceSettings {
            recordings_dir: expand(&text(table, "source.recordings_dir")?, home_dir, None),
            read_titles: boolean(table, "source.read_titles")?,
            quiet_period_secs: u64::from(small(table, "source.quiet_period_secs")?),
            deferral_page_threshold: small(table, "source.deferral_page_threshold")?,
            max_audio_bytes: wide(table, "source.max_audio_bytes")?,
        },
        notify: NotifySettings { mode, aggregate_after: small(table, "notify.aggregate_after")? },
        retention: RetentionSettings {
            enabled: boolean(table, "retention.enabled")?,
            include_audio: boolean(table, "retention.include_audio")?,
            holds,
        },
    })
}

fn expand(raw: &str, home_dir: &Path, home: Option<&Path>) -> PathBuf {
    if let Some(rest) = raw.strip_prefix("~/") {
        return home_dir.join(rest);
    }
    if raw == "~" {
        return home_dir.to_path_buf();
    }
    if let (Some(rest), Some(home)) = (raw.strip_prefix("<home>/"), home) {
        return home.join(rest);
    }
    PathBuf::from(raw)
}

fn leaf<'a>(table: &'a Table, path: &str) -> Result<&'a Value, ConfigError> {
    get(table, path).ok_or_else(|| ConfigError::UnknownKey(path.into()))
}

fn text(table: &Table, path: &str) -> Result<String, ConfigError> {
    leaf(table, path)?.as_str().map(str::to_owned).ok_or_else(|| wrong(path, "string"))
}

fn boolean(table: &Table, path: &str) -> Result<bool, ConfigError> {
    leaf(table, path)?.as_bool().ok_or_else(|| wrong(path, "boolean"))
}

/// A validated 32-bit integer; the validator already refused anything outside `u32`.
fn small(table: &Table, path: &str) -> Result<u32, ConfigError> {
    let value = leaf(table, path)?.as_integer().ok_or_else(|| wrong(path, "integer"))?;
    u32::try_from(value).map_err(|_| wrong(path, "integer"))
}

fn wide(table: &Table, path: &str) -> Result<u64, ConfigError> {
    let value = leaf(table, path)?.as_integer().ok_or_else(|| wrong(path, "integer"))?;
    u64::try_from(value).map_err(|_| wrong(path, "integer"))
}

fn strings(table: &Table, path: &str) -> Result<Vec<String>, ConfigError> {
    let items = leaf(table, path)?.as_array().ok_or_else(|| wrong(path, "list of strings"))?;
    items.iter().map(|item| item.as_str().map(str::to_owned).ok_or_else(|| wrong(path, "list of strings"))).collect()
}

fn hold(table: &Table, path: &str) -> Result<Hold, ConfigError> {
    match leaf(table, path)? {
        Value::Integer(0) => Ok(Hold::never()),
        Value::String(duration) => parse_duration(duration)
            .map(Hold::of_seconds)
            .map_err(|_| ConfigError::OutOfRange { key: path.into(), rule: "0 or <n>s|m|h|d".into() }),
        _ => Err(wrong(path, "duration")),
    }
}

fn wrong(path: &str, expected: &str) -> ConfigError {
    ConfigError::WrongType { key: path.into(), expected: expected.into() }
}
```

`crates/vpt-adapters/src/config/roots.rs`, above its test module:

```rust
//! Resolve every configured root once, at startup, without writing, and
//! refuse the overlaps of spec section 4.1. Creation is a separate, later act.

use std::fs::DirBuilder;
use std::os::unix::fs::DirBuilderExt;
use std::path::{Path, PathBuf};
use vpt_application::{Settings, StorePaths};
use vpt_domain::layout::{RootName, StoreKey, check_overlaps};

#[derive(Debug, PartialEq, Eq)]
pub enum RootError {
    NotAbsolute { key: String },
    ParentMissing { key: String },
    NotADirectory { key: String },
    PathEscape { key: String },
    Overlap { first: String, second: String },
    Io { key: String, detail: String },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Roots {
    pub home: PathBuf,
    pub state_dir: PathBuf,
    pub stores: StorePaths,
    pub recordings_dir: PathBuf,
    pub container: PathBuf,
    pub config_dir: PathBuf,
}

pub fn resolve(settings: &Settings, config_dir: &Path) -> Result<Roots, RootError> {
    let home = planned_directory(&settings.home, "home.path")?;
    let state_dir = planned_directory(&settings.state_dir, "home.state_dir")?;
    let recordings_dir =
        planned_directory(&settings.source.recordings_dir, "source.recordings_dir")?;
    let container = recordings_dir
        .parent()
        .map(Path::to_path_buf)
        .ok_or_else(|| RootError::NotAbsolute {
            key: "source.recordings_dir".into(),
        })?;
    let config_path = if config_dir.is_absolute() {
        config_dir.to_path_buf()
    } else {
        std::env::current_dir()
            .map_err(|error| RootError::Io {
                key: "config".into(),
                detail: error.kind().to_string(),
            })?
            .join(config_dir)
    };
    let config_dir = planned_directory(&config_path, "config")?;
    let mut stores = settings.stores.clone();
    for key in StoreKey::all() {
        let below_home = settings
            .stores
            .get(key)
            .strip_prefix(&settings.home)
            .ok()
            .and_then(|rest| {
                let mut components = rest.components();
                match (components.next(), components.next()) {
                    (Some(std::path::Component::Normal(name)), None) => Some(home.join(name)),
                    _ => None,
                }
            });
        let path = prospective(
            settings.stores.get(key),
            &format!("stores.{}", key.key_name()),
            below_home,
        )?;
        stores.set(key, path);
    }
    let mut roots: Vec<(RootName, &Path)> = vec![
        (RootName::Home, &home),
        (RootName::State, &state_dir),
        (RootName::Config, &config_dir),
        (RootName::VoiceMemos, &container),
    ];
    for key in StoreKey::all() {
        roots.push((RootName::Store(key), stores.get(key)));
    }
    check_overlaps(&roots).map_err(|conflict| RootError::Overlap {
        first: conflict.first.key_name(),
        second: conflict.second.key_name(),
    })?;
    Ok(Roots {
        home,
        state_dir,
        stores,
        recordings_dir,
        container,
        config_dir,
    })
}

impl Roots {
    /// The private state directory, created before the write lock is taken.
    pub fn create_state_dir(&self) -> Result<(), RootError> {
        private_dir(&self.state_dir, "home.state_dir")
    }

    /// The home and every missing store leaf, mode 0700, in that order.
    pub fn create_leaves(&self) -> Result<(), RootError> {
        private_dir(&self.home, "home.path")?;
        for key in StoreKey::all() {
            private_dir(self.stores.get(key), &format!("stores.{}", key.key_name()))?;
        }
        Ok(())
    }
}

pub fn planned_directory(path: &Path, key: &str) -> Result<PathBuf, RootError> {
    if !path.is_absolute() {
        return Err(RootError::NotAbsolute { key: key.into() });
    }
    let mut cursor = path;
    let mut missing = Vec::new();
    loop {
        match cursor.canonicalize() {
            Ok(mut parent) => {
                if !parent.is_dir() {
                    return Err(RootError::NotADirectory { key: key.into() });
                }
                for leaf in missing.iter().rev() {
                    parent.push(leaf);
                }
                return Ok(parent);
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                match cursor.symlink_metadata() {
                    Ok(_) => return Err(RootError::PathEscape { key: key.into() }),
                    Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                    Err(error) => {
                        return Err(RootError::Io {
                            key: key.into(),
                            detail: error.kind().to_string(),
                        });
                    }
                }
                let leaf = cursor
                    .file_name()
                    .ok_or_else(|| RootError::ParentMissing { key: key.into() })?;
                missing.push(leaf.to_os_string());
                cursor = cursor
                    .parent()
                    .ok_or_else(|| RootError::ParentMissing { key: key.into() })?;
            }
            Err(error) => {
                return Err(RootError::Io {
                    key: key.into(),
                    detail: error.kind().to_string(),
                });
            }
        }
    }
}

pub fn resolve_stores(settings: &Settings) -> Result<StorePaths, RootError> {
    let home = planned_directory(&settings.home, "home.path")?;
    let mut stores = settings.stores.clone();
    for key in StoreKey::all() {
        let configured = settings.stores.get(key);
        let below_home = configured
            .strip_prefix(&settings.home)
            .ok()
            .and_then(|rest| {
                let mut components = rest.components();
                match (components.next(), components.next()) {
                    (Some(std::path::Component::Normal(name)), None) => Some(home.join(name)),
                    _ => None,
                }
            });
        stores.set(
            key,
            prospective(
                configured,
                &format!("stores.{}", key.key_name()),
                below_home,
            )?,
        );
    }
    let mut roots = vec![(RootName::Home, home.as_path())];
    for key in StoreKey::all() {
        roots.push((RootName::Store(key), stores.get(key)));
    }
    check_overlaps(&roots).map_err(|conflict| RootError::Overlap {
        first: conflict.first.key_name(),
        second: conflict.second.key_name(),
    })?;
    Ok(stores)
}

/// An absolute path, canonical where it exists. A missing leaf under an
/// existing parent resolves to `<canonical parent>/<leaf>`; a missing parent is
/// a refusal, unless `below_home` names where the leaf will sit once the home
/// itself, a prospective leaf, exists.
fn prospective(path: &Path, key: &str, below_home: Option<PathBuf>) -> Result<PathBuf, RootError> {
    if !path.is_absolute() {
        return Err(RootError::NotAbsolute { key: key.into() });
    }
    match path.canonicalize() {
        Ok(canonical) => {
            if !canonical.is_dir() {
                return Err(RootError::NotADirectory { key: key.into() });
            }
            return Ok(canonical);
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => {
            return Err(RootError::Io {
                key: key.into(),
                detail: error.kind().to_string(),
            });
        }
    }
    match path.symlink_metadata() {
        Ok(_) => return Err(RootError::PathEscape { key: key.into() }),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => {
            return Err(RootError::Io {
                key: key.into(),
                detail: error.kind().to_string(),
            });
        }
    }
    let parent = path
        .parent()
        .ok_or_else(|| RootError::NotAbsolute { key: key.into() })?;
    let leaf = path
        .file_name()
        .ok_or_else(|| RootError::NotAbsolute { key: key.into() })?;
    match parent.canonicalize() {
        Ok(parent) => {
            if !parent.is_dir() {
                return Err(RootError::NotADirectory { key: key.into() });
            }
            Ok(parent.join(leaf))
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            below_home.ok_or_else(|| RootError::ParentMissing { key: key.into() })
        }
        Err(error) => Err(RootError::Io {
            key: key.into(),
            detail: error.kind().to_string(),
        }),
    }
}

fn private_dir(path: &Path, key: &str) -> Result<(), RootError> {
    match DirBuilder::new().mode(0o700).create(path) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => Ok(()),
        Err(error) => Err(RootError::Io {
            key: key.into(),
            detail: error.kind().to_string(),
        }),
    }
}
```

`Roots.container` is what the overlap rule protects, so a store beside `Recordings/` inside Apple's group
container is refused as well as one inside it, and the refusal names `source.recordings_dir` first
because the container precedes every store in the list `check_overlaps` walks. The unresolved
`settings.home` prefix permits exactly one normal store component beneath a missing home. A parent
traversal or deeper missing store parent is refused. `create_leaves` creates the home first.

`crates/vpt-adapters/src/config/paths.rs`, above its test module:

```rust
//! Where the configuration file is, from the environment alone.

use std::path::PathBuf;

pub fn config_path(env: impl Fn(&str) -> Option<String>) -> PathBuf {
    if let Some(explicit) = env("VPT_CONFIG") {
        return PathBuf::from(explicit);
    }
    if let Some(xdg) = env("XDG_CONFIG_HOME") {
        return PathBuf::from(xdg).join("vpt/config.toml");
    }
    PathBuf::from(env("HOME").unwrap_or_default()).join(".config/vpt/config.toml")
}

/// The `home.state_dir` value `vpt setup` writes.
pub fn default_state_dir(env: impl Fn(&str) -> Option<String>) -> String {
    match env("XDG_STATE_HOME") {
        Some(xdg) => format!("{xdg}/vpt"),
        None => "~/.local/state/vpt".into(),
    }
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test --workspace`

Expected: all PASS.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(config): typed settings and root resolution without writes"
```

______________________________________________________________________
