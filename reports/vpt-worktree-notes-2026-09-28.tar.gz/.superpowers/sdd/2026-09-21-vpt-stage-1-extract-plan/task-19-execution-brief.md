# Task 19 execution brief

Read task-19-brief.md completely. It contains the approved task. These corrections and prerequisites
govern its execution; this preparation file does not dispatch the task.

## Independent history slice dispatched on 2026-09-27

The `feat/run-history` lane starts from accepted `1720508`. It owns domain event/history values,
application history and event ports, and shared Memory/SQLite history contracts and persistence.
Root reviews the exact data and error interfaces before implementation. Actual ingest still waits
for accepted Task 18. This slice does not own private log files, export orchestration, hooks or CLI
composition. The separate `feat/private-event-log` lane owns the filesystem boundary and can proceed
without the event port. Root resolves shared adapter/protocol export lists during integration.

Use one existing private transaction for work plus its history, and an additive version-2 migration
that preserves version-1 rows and pending intents. Do not expose a general transaction abstraction.
Preserve known committed facts when post-operation validation or connection close fails after commit;
a containment failure still stops new work. A returned error must not imply rollback of known facts.
Retain explicit version-1 fixtures and test both wrapper-validation and close failures test-first.

History identities combine a persisted random ledger namespace and checked sequence, so a recreated
database cannot reuse identifiers still present in an old log. Export acknowledgements bind the
active file identity, increasing end offset and persisted export generation. An explicit restart
after a safely validated replacement or truncation saves the old/new observed positions, increments
the generation and resets acknowledgements for replay. It preserves original identities and times.
An exact repeated restart request is a no-op; a different stale request is refused. A fresh token can
recover a second real truncation to the same offset. Never infer a repair cause or exact repair time.
Test interrupted resets, stale retries after replay progress and two successive truncations before
implementing this state transition. Recovery facts and summaries are saved records, never hooks.

## Export and hook integration seam

Root approved this source-reviewed correction before the history slice's final freeze. Write the
new behavior census, compiling stubs and intended tests before implementation. Existing coverage
chronology is unchanged by this addition.

- `HookFailed` is a saved history fact referencing an event in the same run and namespace. Its closed
  failure classes are spawn, input/output, encoding, nonzero exit, signal, deadline and interruption. Store no
  command arguments, child streams or raw error text. Task 26 owns the one actual original hook
  attempt and its ordering; saving its required failure history uses the existing transaction.
- Saved export failures expose their existing positive SQLite sequence through a namespaced typed
  identity. Memory uses a checked sequence. Repeated failures for the same event and timestamp still
  have distinct identities; these identify recovery boundaries.
- A recovery summary carries evidence and an optional failure window, from the prior summarized
  identity through an existing later failure. Validate that boundary and save the summary atomically
  in `commit_step`. The saved summary owns the watermark, not its later log acknowledgement.
  `RecoveryView` derives the watermark from validated summaries; recovery progress never advances it.
  A summary without a failure window can describe interrupted work without consuming log failures.
- Export failure evidence separately retains optional observed file identity and complete/physical
  ends. An observation is not a confirmed cursor or append acknowledgement. The unaccepted version-2
  schema may add this narrow optional field directly; no new version or compatibility path is needed.
- `last_confirmed` comes only from an acknowledged record in the active export generation. A restart
  observation leaves it absent until a replay append is acknowledged. Encoding failure has its own
  closed class. A work-only recovery summary may have no first observed logging failure time.

Test the duplicate event/time case, stale windows, summary transaction rollback, progress versus
summary boundaries, content-free hook classes and bad references, and observed-file round trips.
Actual recovery, hook delivery and their no-replay composition tests remain Task 26 work.

The writer runs focused checks and compiled mutation controls. Root runs the final combined ship,
release and normal-parallel timing gates. Writers coordinate one native batch at a time directly;
source work and review continue in parallel. No test-runner/build parallelism overrides are approved.

## Full ingest prerequisites

The transactional-history prerequisite is accepted at `4e7413b` with combined ship, release and
normal-parallel timing proof. Task 26 supplies the separately reviewed receipt-based sink port
before this implementation starts; its concrete exporter can proceed in parallel. Read the frozen
sink contract in `task-26-execution-brief.md`. The existing `Trash` port is already accepted and
must be reused. The application-owned clock and actual ingest use case remain this task's work.

Before writing behavior, propose the exact ingest data types and named behavioral census against
the current ports. Use one ledger implementing `RecordingLedger + RunHistory`, and a mutable
receipt-based sink. Preserve the planned report/error information while carrying closed sink
warnings and known completed identities. No second notification type, transaction interface,
process runner, log-file adapter or stringly typed history failure is needed.

For each mutating sweep, save and export `RunStarted` before title refresh or candidate work.
Save the archive target intent and attempt export before publication. Commit the recording, seen
state and its confirmed outcome together through `commit_step`, then export the returned receipt
before more work. A liveness-only seen update also uses one state/history transaction. Finish a
successful run with saved and exported completion, without inventing a success notification.

Keep required-history and sink-stop handling explicit. An unconfirmed state commit cannot report
a newly durable recording; a committed-with-failure receipt must retain its completed work. A
placed or placed-unsynced archive remains available for recovery. Stop before another candidate
or cleanup side effect when required history or safe-state validation fails. An export-only
warning preserves the existing work result. Ordinary ingest failures save only the closed safe
event detail and original occurrence time; never forward raw recorder, ledger or helper text to
event metadata. Failure while saving that required history stops without a recursive save attempt.

Source or archive containment refusal still saves the closed failure event and failed-run history
when the history repository remains trusted. It then stops candidate and cleanup work, retaining
any owned stage. Ledger, required-history and sink failures remain terminal. Task 27 owns human
messages and command error documents derived from typed `IngestFailure`; the historical public
`message()` method is withdrawn from this unshipped application interface.

Test these producer boundaries before implementation: start/export ordering; archive intent before
publication; atomic record/seen/outcome persistence; no new work after each required failure class;
post-commit receipt preservation; log-warning result preservation; bounded warning accumulation;
one safe failure event; and no success event. Retain the original happy-path, title, once-selection,
liveness and staging-ownership assertions. Explicitly resolve safe handling of the not-yet-built
dry-run mode before dispatch rather than exposing a path that ignores it and writes. Task 23 still
owns its complete hashing and no-write implementation and command composition remains Task 27.

## Actual ingest dispatch and behavioral census

Actual ingest is dispatched from accepted `a66dbacf98165958ebdd7a6fd010c4881876f0c7` in
`feat/ingest-happy-path`. The history and receipt-based sink prerequisites are accepted. One ledger
implements both `RecordingLedger` and `RunHistory`; `Ingest` borrows that ledger and its mutable
sink. The application clock exposes `now()` and `offset_at()`. Keep the planned report fields and
bounded warning set, and return `Result<IngestReport, Box<IngestError>>`.

Until Task 23 supplies dry-run behavior, return `DryRunUnavailable` before any clock, title,
candidate, ledger, sink or filesystem call. Until Task 20 supplies durable deferral, refuse a
dataless candidate before opening or cloning it. Those later tasks replace these temporary typed
refusals, with explicit leaf-name mappings; neither mode may silently perform mutating happy-path
work. Do not implement the later tasks in this slice.

An error retains prior and known-completed identities, safe diagnostics, bounded warnings and only
the receipt associated with its known failing commit or sink stop. Do not accumulate every successful
history receipt. Preserve both completed work and a sink stop's committed receipt. Before staged
cleanup for an ordinary failure, save its one safe `IngestFailed` event and `RunFinished::Failed` at
the original occurrence time. Required history failure stops without another save or cleanup.

The approved named census is:

1. `dry_run_refuses_before_any_port_or_history_effect`
2. `run_start_is_committed_and_exported_before_title_refresh`
3. `run_start_failure_stops_without_candidate_or_cleanup`
4. `empty_and_invalid_once_sweeps_still_refresh_titles`
5. `whole_recording_archives_bytes_mode_and_identity`
6. `whole_recording_commits_seen_record_and_outcome_together`
7. `archive_intent_is_exported_before_publication`
8. `success_finishes_run_without_success_event`
9. `second_sweep_updates_liveness_in_history_transaction`
10. `once_selects_only_named_recording`
11. `title_refresh_reads_fresh_copy_before_candidates`
12. `ordinary_title_copy_failure_ingests_untitled_after_copy_attempt`
13. `unsafe_title_copy_refuses_without_candidate_work`
14. `owned_staging_is_only_trash_target_after_prepublication_failure`
15. `invalid_staged_container_cleanup_waits_for_failure_history`
16. `placed_unsynced_target_is_retained_for_recovery`
17. `published_target_survives_unconfirmed_state_commit`
18. `postcommit_receipt_preserves_completed_identity_on_failure`
19. `required_intent_history_failure_stops_before_publish_and_cleanup`
20. `sink_stop_after_start_intent_or_record_stops_new_work`
21. `export_only_warnings_preserve_work_and_finish`
22. `warnings_are_deduplicated_bounded_and_content_free`
23. `ordinary_failure_saves_one_safe_event_with_original_time`
24. `required_failure_event_save_never_recurses_or_cleans_up`
25. `cleanup_helper_error_keeps_owned_staging_and_safe_diagnostic`
26. `non_owned_or_placed_target_never_reaches_trash`
27. `dataless_candidate_is_not_opened_before_gate_task`

## Historical sample reconciliation

The approved report/alert amendment supersedes the sample's `Notification` and `Notifier` names.
Prepare domain events and the application-owned `EventSink` port, with a recording test fake. The
sink logs emitted events and optionally invokes the configured channel command; it has no desktop
delivery mode or helper dependency. Reconcile its exact outcome and diagnostic interface with Task
26's private `events.jsonl` policy before dispatch. The operator approved keeping the work result and
exit status when logging fails and adding a bounded, content-free warning inside the command's
existing JSON document. The event port must return enough diagnostic information for that composition
without converting completed work into failure. Preserve producer privacy, batching and the
observation/dry-run no-write boundaries. The old sample names below describe historical intent only.

The approved recovery summary in spec section 8.7.1 also requires saved run/event history in the
existing SQLite ledger. Before dispatch, reconcile a narrow application-owned history repository
with the mutation ports so a state change and its corresponding history commit together. Keep
external intents distinct from confirmed outcomes. Record meaningful progress before exporting it;
an export warning cannot erase the underlying result. Required history commit failures stop new
work and report completed work through the existing failure path. After each successful commit,
attempt export before continuing work or invoking the original event hook. Neither export nor a
hook runs inside the state/history transaction. Task 26 owns log export and recovery records, and
Task 27 owns startup repair and command-output composition. This is added work, not implemented
behavior or a retroactive claim that the current schema already supports recovery summaries.

- Wait for D5/D6 and Tasks 12-18 to be accepted. Use their actual ports, typed errors and explicit
  database ownership. Reconcile the sample calls at dispatch; do not restore superseded path-based
  SQLite access or widen private adapter modules.
- Own the task's notification values, three ports, ingest happy path and focused integration fixtures.
  Keep the later gate, duplicate, recovery and dry-run tasks separate. You are not alone; preserve
  others' work. One product writer, no subagents. Main owns the ledger and task tracker.
- Compile the new interfaces as unsupported stubs, then retain intended behavioral RED before each
  behavior group. Missing imports are not RED. This includes notification spellings and constructors,
  title refresh ordering, error delivery, and every cleanup branch introduced by this slice.
- Keep source fixtures entirely owned and quiescent during unchanged-tree comparisons. Use real
  archive, recorder and ledger adapters with the planned clock, Trash and notifier fakes. If native and
  contained SQLite operate on the same database concurrently, use separate supervised processes.
- Reuse the actual D6 title fixture and ordinary-error classification. Prove the untitled fallback's
  copy failure occurred; an absent state path alone is not proof. Containment and helper-version
  failures retain their typed refusal. Never print raw SQLite diagnostics or row contents.
- Verify the full happy-path record, archived bytes and mode, persisted seen state, exact once
  selection, liveness refresh, title result and absence of a success notification. Check notification
  metadata without transcript/title content. A title refresh happens before candidate work on every
  mutating sweep, including an empty or invalid candidate set.
- Test ownership on every cleanup path implemented now: only an owned staged path reaches Trash;
  published or placed-unsynced targets remain for recovery. A ledger commit failure must not erase the
  published archive or report its identity as durably recorded. Notification failure cannot undo work.
- Use cohesive private helpers and the existing test layout. The sample's broad dead-code allowance,
  unsolicited docstrings and unused imports are not instructions to bypass the Rust quality gates.
  Report concrete staging diagnostics before adding any exception.
- Preserve all accepted leaves. Record compiled RED, GREEN, exact compiled mutation/control evidence,
  restored hashes, per-leaf timing, staged size census, normal-hook commits and a self-review in
  task-19-report.md. Main dispatches independent review and runs committed-HEAD ship. No installation,
  live stores, real Trash, notifications, publishing or destructive cleanup.
