# Task 2 report

Task 2 is implemented and locally verified. Controller review is pending.

- Base: `b5f818d3f1a3fa97d6bc40fc68861266216fb6c9`
- Branch: `feat/stage-1-extract`
- Commit: `9de4402468dcc9f35704dbfdce5f963a86b6c67e`
- Final suite: 31 passing leaves, zero failures. All 17 baseline leaves survive; 14 are added.
- Work kind: new protocol/output behavior, plus version-envelope delegation under existing coverage.

## Implementation

`vpt-protocol::result::document` supplies the ordered `vpt.result/1` envelope. The version command uses it, removing its duplicate envelope construction. `ErrorDocument` constructs `vpt.error/1` directly from concrete values, retains ordered identities and completed work, and includes optional checks and diagnostics. No serialization failure is converted to null.

`cli::output::emit` is the sole stdout/stderr writer. Success writes stdout; failure writes stderr. A stdout failure becomes Store and exits 1. A stderr failure exits 1, including JSON output and simultaneous broken streams. All diagnostics use fallible writes.

The controller's refusal ruling is implemented in the shared human formatter: `.rule("same_family")` with message `engines share a family` prints `vpt: same_family: engines share a family`. JSON retains the bare message and separate rule field. The parser-help ruling is explicit in the internal `Outcome::ParseFailure` variant. Ordinary `Failure(Usage)` contains only its message; parser failures append usage help in human mode. JSON still contains one document.

The crate graph remains `vpt-domain <- vpt-application <- vpt-adapters <- vpt`, with independent `vpt-protocol` consumed by adapters and the command crate. Implementation modules remain private; the protocol's intended `error` and `result` APIs are public. No new ports, registry, persistence, configuration, generated artifacts, or external consumers were introduced. The three prescribed serde_json dependencies enable preserve_order; the lockfile adds only serde_json's dependency on the already locked indexmap.

## Test-first evidence

1. Baseline: `cargo test --offline --locked --workspace --no-fail-fast --features dev-tools`, exit 0, all 17 existing leaves pass.
2. Compiling protocol stubs and new command tests: `cargo test --offline --locked -p vpt-protocol -p vpt --no-fail-fast`, exit 101. All seven protocol leaves fail expected assertions. Unknown-verb JSON and closed-stdout JSON fail because stderr is human text. Existing leaves pass. A temporary unimplemented-command JSON test also failed as expected.
3. Compiling output-format stub: `cargo test --offline --locked -p vpt --lib cli::output::tests`, exit 101. All three selected formatter tests fail on empty output or invalid JSON.
4. Initial implementation: `cargo fmt --all && cargo test --offline --workspace --no-fail-fast --features dev-tools`, exit 0, 32 leaves pass. This unlocked offline run updates Cargo.lock for preserve_order; subsequent gates use --locked.
5. Refusal-rule correction: `cargo test --offline --locked -p vpt --lib cli::output::tests::human_failure_includes_each_diagnostic -- --exact`, exit 101 with bare message missing `same_family:`, then exit 0 after the formatter change.
6. Parser-help correction: `cargo test --offline --locked -p vpt --lib cli::output::tests::human_usage_error_contains_only_its_message -- --exact`, exit 101 because ordinary Usage had appended parser help, then exit 0 after carrying parser intent explicitly. `cargo test --offline --locked -p vpt --test usage` passes all five acceptance leaves.
7. The provisional `an_unimplemented_verb_under_json_is_one_usage_document` test was removed at the controller's direction because it asserted temporary placeholder output. The provisional formatter test `human_usage_includes_usage_after_the_message` became the ordinary-Usage regression; the existing unknown-verb acceptance retains parser-help coverage. No baseline test was removed or renamed.

## Leaf inventory

Each baseline leaf maps to the same name below and passes before and after Task 2. The stdout-failure diagnostic assertion now expects the planned Store message.

- `cli::args::tests::a_trailing_unknown_argument_is_refused`: baseline PASS, final PASS, same-name successor.
- `cli::args::tests::a_value_flag_without_a_value_is_refused`: baseline PASS, final PASS, same-name successor.
- `cli::args::tests::an_unknown_verb_is_a_usage_error_naming_it`: baseline PASS, final PASS, same-name successor.
- `cli::args::tests::every_stage_one_verb_decodes_its_arguments`: baseline PASS, final PASS, same-name successor.
- `cli::args::tests::global_flags_cannot_fill_missing_value_slots`: baseline PASS, final PASS, same-name successor.
- `cli::args::tests::json_and_config_are_global_flags_in_any_position`: baseline PASS, final PASS, same-name successor.
- `cli::args::tests::missing_positionals_subcommands_and_flag_values_are_refused`: baseline PASS, final PASS, same-name successor.
- `cli::args::tests::non_utf8_paths_are_refused_without_substitution`: baseline PASS, final PASS, same-name successor.
- `runner_captures_output_and_exit_status`: baseline PASS, final PASS, same-name successor.
- `watchdog_terminates_the_hanging_group_and_reaps_its_child`: baseline PASS, final PASS, same-name successor.
- `an_unknown_verb_prints_usage_to_stderr_and_exits_2`: baseline PASS, final PASS, same-name successor.
- `unknown_input_with_broken_stderr_exits_one`: baseline PASS, final PASS, same-name successor.
- `unimplemented_verb_with_broken_stderr_exits_one`: baseline PASS, final PASS, same-name successor.
- `a_stdout_write_failure_exits_one`: baseline PASS, final PASS, same-name successor.
- `version_reports_the_crate_version_and_no_helper_when_the_path_is_empty`: baseline PASS, final PASS, same-name successor.
- `version_without_json_prints_one_human_line`: baseline PASS, final PASS, same-name successor.
- `version_with_both_output_streams_broken_exits_one`: baseline PASS, final PASS, same-name successor.

Added leaves, all PASS:

- `cli::output::tests::human_failure_includes_each_diagnostic`
- `cli::output::tests::human_usage_error_contains_only_its_message`
- `cli::output::tests::json_failure_contains_diagnostics_in_one_document`
- `an_unknown_verb_under_json_is_an_error_document_on_stderr`
- `json_usage_with_broken_stderr_exits_one`
- `a_json_stdout_write_failure_is_one_store_document_on_stderr`
- `json_version_with_both_output_streams_broken_exits_one`
- `error::tests::a_refusal_carries_its_rule_and_exits_3`
- `error::tests::every_kind_maps_to_the_spec_exit_code`
- `error::tests::a_non_refusal_has_a_null_rule`
- `error::tests::checks_appear_only_when_given`
- `error::tests::diagnostics_are_retained_inside_the_one_error_document_when_present`
- `error::tests::ids_and_completed_preserve_order_and_escaped_text`
- `result::tests::a_result_document_leads_with_schema_and_command`

## Mutation verification

Each probe used apply_patch, then `rg -n -F` to verify the exact mutated source bytes before cargo ran. Each mutation compiled and failed a named behavioral assertion with exit 101. The reverse patch restored the source, and the identical cargo command then passed with exit 0. A warning in the parser-intent mutant reports the deliberately unused ParseFailure variant; it is absent after restoration.

### 1. refusal exit mapping

File: `crates/vpt-protocol/src/error.rs`

Before:
```rust
            Self::Refused => 3,
```

Mutation:
```rust
            Self::Refused => 1,
```

Command: `cargo test --offline --locked -p vpt-protocol --lib error::tests::every_kind_maps_to_the_spec_exit_code -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test error::tests::every_kind_maps_to_the_spec_exit_code ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 6 filtered out; finished in 0.00s
```

### 2. refusal rule omitted

File: `crates/vpt-protocol/src/error.rs`

Before:
```rust
            self.rule.clone().map_or(Value::Null, Value::String),
```

Mutation:
```rust
            Value::Null,
```

Command: `cargo test --offline --locked -p vpt-protocol --lib error::tests::a_refusal_carries_its_rule_and_exits_3 -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test error::tests::a_refusal_carries_its_rule_and_exits_3 ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 6 filtered out; finished in 0.00s
```

### 3. diagnostics replaced with null

File: `crates/vpt-protocol/src/error.rs`

Before:
```rust
            error.insert("diagnostics".into(), self.diagnostics.clone().into());
```

Mutation:
```rust
            error.insert("diagnostics".into(), Value::Null);
```

Command: `cargo test --offline --locked -p vpt-protocol --lib error::tests::diagnostics_are_retained_inside_the_one_error_document_when_present -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test error::tests::diagnostics_are_retained_inside_the_one_error_document_when_present ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 6 filtered out; finished in 0.00s
```

### 4. result schema corrupted

File: `crates/vpt-protocol/src/result.rs`

Before:
```rust
    ordered.insert("schema".into(), "vpt.result/1".into());
```

Mutation:
```rust
    ordered.insert("schema".into(), "vpt.result/2".into());
```

Command: `cargo test --offline --locked -p vpt-protocol --lib result::tests::a_result_document_leads_with_schema_and_command -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test result::tests::a_result_document_leads_with_schema_and_command ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 6 filtered out; finished in 0.00s
```

### 5. ignored stderr failure

File: `crates/vpt/src/cli/output.rs`

Before:
```rust
                return 1;
```

Mutation:
```rust
                return error.exit_code();
```

Command: `cargo test --offline --locked -p vpt --test usage broken_stderr`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test json_usage_with_broken_stderr_exits_one ... FAILED
test unknown_input_with_broken_stderr_exits_one ... FAILED
test unimplemented_verb_with_broken_stderr_exits_one ... FAILED
test result: FAILED. 0 passed; 3 failed; 0 ignored; 0 measured; 3 filtered out; finished in 0.01s
```

### 6. ignored stdout failure

File: `crates/vpt/src/cli/output.rs`

Before:
```rust
            if std::io::stdout().write_all(text.as_bytes()).is_err() {
```

Mutation:
```rust
            if std::io::stdout().write_all(text.as_bytes()).is_err() && false {
```

Command: `cargo test --offline --locked -p vpt --test version`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test a_json_stdout_write_failure_is_one_store_document_on_stderr ... FAILED
test version_without_json_prints_one_human_line ... ok
test a_stdout_write_failure_exits_one ... FAILED
test version_with_both_output_streams_broken_exits_one ... FAILED
test json_version_with_both_output_streams_broken_exits_one ... FAILED
test version_reports_the_crate_version_and_no_helper_when_the_path_is_empty ... ok
test result: FAILED. 2 passed; 4 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
```

### 7. dispatch drops JSON selection

File: `crates/vpt/src/lib.rs`

Before:
```rust
    emit(outcome, invocation.json)
```

Mutation:
```rust
    emit(outcome, false)
```

Command: `cargo test --offline --locked -p vpt --test version version_reports_the_crate_version_and_no_helper_when_the_path_is_empty -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test version_reports_the_crate_version_and_no_helper_when_the_path_is_empty ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.01s
```

### 8. emission hangs

File: `crates/vpt/src/cli/output.rs`

Before:
```rust
pub(crate) fn emit(outcome: Outcome, json: bool) -> i32 {
```

Mutation:
```rust
pub(crate) fn emit(outcome: Outcome, json: bool) -> i32 {
    std::thread::sleep(std::time::Duration::from_secs(30));
```

Command: `cargo test --offline --locked -p vpt --test version version_without_json_prints_one_human_line -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test version_without_json_prints_one_human_line ... FAILED
slow command: 502.316667ms
command exceeded 500 ms deadline
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.51s
```

### 9. dispatch returns constant success

File: `crates/vpt/src/lib.rs`

Before:
```rust
    emit(outcome, invocation.json)
```

Mutation:
```rust
    let _ = outcome;
    0
```

Command: `cargo test --offline --locked -p vpt --test version version_without_json_prints_one_human_line -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test version_without_json_prints_one_human_line ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.01s
```

### 10. human refusal rule omitted

File: `crates/vpt/src/cli/output.rs`

Before:
```rust
        (ErrorKind::Refused, Some(rule)) => format!("vpt: {rule}: {}\n", error.message),
```

Mutation:
```rust
        (ErrorKind::Refused, Some(_rule)) => format!("vpt: {}\n", error.message),
```

Command: `cargo test --offline --locked -p vpt --lib cli::output::tests::human_failure_includes_each_diagnostic -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test cli::output::tests::human_failure_includes_each_diagnostic ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 10 filtered out; finished in 0.00s
```

### 11. ordinary Usage gains parser help

File: `crates/vpt/src/cli/output.rs`

Before:
```rust
    if parser_help {
```

Mutation:
```rust
    if parser_help || error.kind == ErrorKind::Usage {
```

Command: `cargo test --offline --locked -p vpt --lib cli::output::tests::human_usage_error_contains_only_its_message -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test cli::output::tests::human_usage_error_contains_only_its_message ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 10 filtered out; finished in 0.00s
```

### 12. parse path loses parser-help intent

File: `crates/vpt/src/lib.rs`

Before:
```rust
            Outcome::ParseFailure(ErrorDocument::new(ErrorKind::Usage, error.0)),
```

Mutation:
```rust
            Outcome::Failure(ErrorDocument::new(ErrorKind::Usage, error.0)),
```

Command: `cargo test --offline --locked -p vpt --test usage an_unknown_verb_prints_usage_to_stderr_and_exits_2 -- --exact`

Mutant exit: 101. Restored control exit: 0.

Selected mutant leaf results:
```text
test an_unknown_verb_prints_usage_to_stderr_and_exits_2 ... FAILED
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 4 filtered out; finished in 0.01s
```


The hang mutation inserted a 30-second sleep in the actual emitter. The acceptance runner failed at 502.316667 ms and its restored control passed. The unchanged watchdog test also checks termination and reaping of its owned child group.

## Final gates

All commands ran after both controller corrections, with exit 0:

- `cargo fmt --all`
- `CARGO_NET_OFFLINE=true just test-rust`
- `CARGO_NET_OFFLINE=true just lint-check`
- `CARGO_NET_OFFLINE=true just ship`
- `cargo check --offline --locked --workspace --all-targets --features dev-tools`
- `cargo build --offline --locked --release -p vpt`
- `git -c core.fsmonitor=false diff --cached --check`
- `git -c core.fsmonitor=false diff --exit-code`

The recipes ran rustfmt check, Clippy with warnings denied, the complete workspace tests including dev-tools, rustdoc with warnings denied, gitleaks, and the tracked-file size gate. Gitleaks scanned 83 commits and reported no leaks. The final release build completed in 0.93 seconds.

Under the full workspace run, the 11 command-unit tests and seven protocol tests each had a suite time of 0.00 seconds. Usage and version suites completed in at most 0.02 seconds each. The two harness tests completed in 0.51 seconds. Every leaf is below the one-second ceiling; acceptance commands retain their enforced 500 ms deadline and one-second outer assertion.

## Staged file-size audit

All new Rust sources were staged before running the clean-code-rust command. The only command adjustment is disabling the broken fsmonitor integration through git's read-only `-c core.fsmonitor=false` option.

```bash
git -c core.fsmonitor=false ls-files 'crates/*.rs' | while IFS= read -r f; do
  awk -v F="$f" '
    /^[[:space:]]*#\[cfg\(test\)\]/ && !seen { seen = 1 }
    !seen { impl++ }
    { total++ }
    END {
      if (F ~ /(^|\/)tests(\.rs|\/)/) impl = 0
      printf "%5d impl %5d total  %s\n", impl, total, F
    }' "$f"
done | sort -k3,3rn
```

```text
  135 impl   280 total  crates/vpt/src/cli/args.rs
  128 impl   225 total  crates/vpt-protocol/src/error.rs
    0 impl   125 total  crates/vpt/tests/support/mod.rs
   55 impl    92 total  crates/vpt/src/cli/output.rs
    0 impl    89 total  crates/vpt/tests/version.rs
    0 impl    64 total  crates/vpt/tests/usage.rs
    0 impl    58 total  crates/vpt/tests/harness.rs
   33 impl    33 total  crates/vpt/src/lib.rs
   12 impl    27 total  crates/vpt-protocol/src/result.rs
   17 impl    17 total  crates/vpt/src/commands/version.rs
    4 impl     4 total  crates/vpt/src/bin/vpt-fake-engine.rs
    3 impl     3 total  crates/vpt/src/main.rs
    2 impl     2 total  crates/vpt-protocol/src/lib.rs
    2 impl     2 total  crates/vpt/src/cli/mod.rs
    1 impl     1 total  crates/vpt-adapters/src/lib.rs
    1 impl     1 total  crates/vpt-application/src/lib.rs
    1 impl     1 total  crates/vpt-domain/src/lib.rs
    1 impl     1 total  crates/vpt/src/commands/mod.rs
```

Every file is below the 200 implementation/300 total targets. The largest is the unchanged parser at 135/280. Main remains three lines. No waiver or lint suppression was added.

## Boundaries and concerns

Task 1's original-token adjacency checks, invalid-UTF8 refusal, unique TempDir, controlled environment, null stdin, caller-owned redirects, and bounded process-group runner are unchanged. No live destination, installed binary, store, vault, or user configuration was accessed by tests. No apply, push, pull request, merge, installation, or third-party source change occurred. Neovim tools were unavailable; the diagnostic could not identify a caller pane, consistent with the controller's existing worktree preflight.

The normal-hook commit command `SKIP_AI_COMMIT=1 git -c core.fsmonitor=false commit -m "feat: add shared result and error output contracts"` exited 0. Post-commit status is clean, HEAD has the stated base as its single parent, and `git diff HEAD --exit-code` exits 0. The diff against the base for `cli/args.rs`, `tests/support/mod.rs`, and `tests/harness.rs` is empty.

The new JSON contract is an intentional change to prior JSON failures. Human stdout and the parser surface remain covered by the existing acceptance and parser leaves. No previous-main binary differential was run for this task; the named baseline leaves and byte-preserved parser are the compatibility evidence supplied here.

No known Task 2 behavior defect remains. Later command implementations remain outside this task. Controller review is still required before proceeding to Task 3.

## Durable committed-HEAD verification

Both runs below used HEAD `9de4402468dcc9f35704dbfdce5f963a86b6c67e`. Output was captured with `2>&1 | tee <log>` under `set -o pipefail`, preserving the command exit status. Product files, index, and commit history were unchanged.

| Command | Exit | Result | Worktree-relative log path |
| --- | --- | --- | --- |
| `cargo test --offline --locked --workspace --no-fail-fast --features dev-tools` | 0 | All 31 leaves pass, zero failed or ignored. Harness suite 0.51 s; usage 0.03 s; version 0.02 s; command and protocol unit suites 0.00 s. | `.superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/task-2-post-commit-tests.log` |
| `gitleaks git --no-banner --no-color --redact --log-opts='HEAD'` | 0 | 84 commits scanned, including Task 2; 1,533,578 bytes scanned; no leaks found. | `.superpowers/sdd/2026-09-21-vpt-stage-1-extract-plan/task-2-post-commit-secrets.log` |

The test log preserves each selected leaf name, result, suite timing, and documentation-test result. Both logs are ignored evidence files beside this report.
