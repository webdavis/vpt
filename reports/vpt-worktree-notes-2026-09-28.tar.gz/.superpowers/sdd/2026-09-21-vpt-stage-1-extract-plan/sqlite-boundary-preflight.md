# SQLite pathname-boundary preflight

Source-only review by /root/vpt_sqlite_boundary_preflight. No product files changed and no experiment ran. A requested disposable diagnostic experiment was blocked by a security safeguard; it will not be retried or moved to another tool. Defensive, read-only API feasibility research continues.

Versions inspected: rusqlite 0.39.0, libsqlite3-sys 0.37.0, bundled SQLite 3.51.3.

The source directory is /Users/stephen/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/. Rusqlite passes the pathname and flags to sqlite3_open_v2 at rusqlite-0.39.0/src/inner_connection.rs:90. The following anchors are in libsqlite3-sys-0.37.0/sqlite3/sqlite3.c:

- 46124-46178 and 63711-63718: full-path resolution rejects a pre-existing ancestor symlink when NOFOLLOW is requested.
- 45866-45882: database and journal opens add O_NOFOLLOW and call robust_open.
- 68475-68477: WAL opens request READWRITE, CREATE and WAL.
- 44204-44239: shared-memory names derive from the stored database pathname; the writable branch uses O_RDWR, O_CREAT and O_NOFOLLOW. readonly_shm selects the read-only branch.
- 40035-40042 and 39612-39613: robust_open calls plain open, without the retained directory descriptor.
- 40824-40831: the moved-file check compares the main database pathname inode with its held inode; it does not bind sidecar creation atomically to that directory.

The installed macOS open manual distinguishes target-only O_NOFOLLOW from O_NOFOLLOW_ANY at /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/share/man/man2/open.2:222. SQLite's official open documentation, https://www.sqlite.org/c3ref/open.html, does not promise a retained-directory binding.

The concern is a concurrently changed ancestor during a later sidecar open. Before/after root checks do not establish that the intermediate pathname write used the retained root. This needs an actor able to change the parent directory; no privilege escalation, real-container modification or executed race has been demonstrated.

Spec section 4.1, lines 277-283, resolves roots once, prohibits writable overlap with Voice Memos, and requires refusal when an opened or published path traverses a link or escapes its root. Section 5.1, lines 421-425, prohibits creating or modifying anything inside the Voice Memos container. The spec states strong preservation outcomes but does not explicitly define the concurrent-ancestor-mutation threat model.

reports/vpt-plan1-fix-log.md:176-177 records R07 root rechecks and R08 observational preservation. Lines 105-107 record F66's preserved sidecars and readonly_shm fix. Those address stable replacement and read-only effects, not an atomic pathname binding. No configuration-only solution meeting retained-root identity has been established. Task 11 remains undispatched pending a design decision.

Read-only feasibility review completed: SQLite's opening API accepts a filename and optional filesystem implementation name; rusqlite from_handle accepts an existing SQLite connection, not an operating-system descriptor. SQLite file-control pointers expose existing objects rather than adopting RootDir. No supported flag-only or descriptor-adoption path was established. A stronger adapter design or an explicit restriction of the containment contract is needed before claiming protection during concurrent ancestor replacement.

The controller asked the operator whether to extend the design for that stronger protection, recommending yes. While that answer is pending, Task 3 may finish its already-running implementation and review, but Task 11 must not start. No third-party source modification or retry of the blocked experiment is proposed.
