# Task 6 cleanup ownership

Read-only follow-up by /root/vpt_setup_terminal_preflight at Task 5a HEAD. No changes, builds or runtime probes.

The existing ProcessGroup::drop at crates/vpt/tests/support/mod.rs:115 already sends TERM, waits up to 50 ms, then sends KILL. Its shell fixture's caught TERM trap waits for its child. Preserve that bounded grace and make ownership evidence explicit.

1. A fixture parent installs a caught no-op SIGTERM handler and unblocks SIGTERM.
2. It spawns a same-group helper child that retains output descriptors and blocks on a private pipe. The parent owns the writer and uses a readiness message, not a sleep.
3. The parent takes and retains ChildStdin before child.wait(), because wait otherwise closes stored stdin and releases the child prematurely.
4. Group TERM terminates the execed child. The parent survives, reaps it, records PID and status, and exits. The runner reaps its direct child.
5. Require both the reaping record and disappearance of the recorded process group. A missing record fails ownership verification.

Use a caught handler, not SIG_IGN: exec resets caught handlers but preserves ignored signals and blocked masks. Verify KILL escalation separately with a direct child that ignores TERM and has no children. Keep the retained-output-peer regression separate; it proves collection bounds, not descendant reaping.

Keep the 500 ms command deadline and 50 ms TERM grace. All output collection and post-KILL try_wait polling share an absolute final cleanup deadline below one second, for example 900 ms from runner entry. Remove blocking joins and unconditional final wait. A command timeout stays a timeout even if the cooperative fixture exits successfully during cleanup.

Whole-group KILL cannot guarantee reaping by a parent it also kills. The controller cannot waitpid an arbitrary grandchild, and macOS reparents such children. Do not create an intentionally orphaned or detached-escape fixture. Never report missing reaping evidence as successful cleanup. A finite deadline cannot guarantee scheduling under every machine condition; verify actual leaf timings on this host.

Verified sources:

- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man2/execve.2:123, signal disposition and mask inheritance.
- /Users/stephen/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/src/rust/library/std/src/process.rs:2396, Child::wait drops stored stdin.
- /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/man/man2/wait.2:220, child ownership and reparenting.

These source contracts are not runtime evidence. Task 6 still owns compilation, bounded regression, mutation/control and final gate verification.
