# Task 25 execution brief

## Independent protocol slice, 2026-09-27

The bounded reader and helper reply types depend only on the existing protocol crate's serde
dependencies. They may be implemented in an isolated lane while the process-runner fixture is
diagnosed. This slice owns `limits.rs`, its private visitor and tests, `helper.rs` and its tests,
and the protocol root exports. It includes helper version parsing, but no helper invocation,
Trash port, command routing, configuration loading, notification type or adapter dependency.
Task 25 remains incomplete until its client and command composition pass their own review and
the integrated checks. The process-runner acceptance prerequisite still governs that later slice.

## Client and command slice

Dispatched on 2026-09-27 in `feat/helper-client`, from accepted `1720508`. The protocol and bounded
process runner are accepted. The writer consumes them unchanged, implements the client and version
composition, and introduces only the approved application Trash port needed by that client. The
history lane does not own `ports/trash.rs`; root combines shared export lists. No ingest or logging
adapter is required. Root owns combined gates; this writer runs focused tests, mutation controls and
static checks. Preparation-only wording below is superseded for this slice, not for withdrawn helper
notification behavior.

Read task-25-brief.md completely after Task 24 is accepted. Inspect the actual spawn, Sandbox,
configuration, error and Trash interfaces before adapting the samples. Preparation only, not dispatch.

The report/alert amendment limits this helper client to version and Trash. Omit notification
requests, posted documents, notification adapters and fake-notify routes from the old samples.
Task 26's command hooks do not use the helper or depend on its availability.

- Own the bounded JSON reader, helper protocol/client, version composition and their focused tests.
  You are not alone; preserve others' work. One product writer, no subagents. Main owns the ledger and
  task tracker. Input-budget and helper side-effect boundaries require independent Astra review.
- Replace missing-symbol compile failures with compiling behavioral RED at each intended operation.
  Cover actual helper-version syntax and rejection as well as client compatibility, rather than
  introducing the sample's whole version parser behind only a happy-path integration check.
- Check bytes including trailing whitespace, depth before descent, decoded key/text character limits,
  and array entry limit before decoding the extra value. Require end-of-document. Keep errors fixed
  and safe; do not quote JSON, rejected values or child streams. Preserve exact boundary controls,
  escaped Unicode and malformed-over-limit inputs that prove rejection order.
- Retain one extra stdout byte so a valid JSON prefix followed by excess data cannot pass. Respect
  actual Task 24 typed failures and limits; never infer successful complete delivery from truncated
  transport output. Do not add another process runner or parser framework.
- Successful helper compatibility alone is cached for the command's fixed helper/environment.
  Rejected or failed checks remain uncached. Trash performs no action before compatibility;
  an inexact returned Trash path fails with its intended type. Cover all safe
  status mappings, including interruption, signal and nonzero exit, without raw stream diagnostics.
- Preserve additive field-name diagnostics, escaped for control characters, drainable exactly once,
  with no additive values. Use synthetic canaries for invalid schema/version/reply types and output.
- Every real fake-helper invocation needs explicit temporary HOME, all XDG roots, VPT_CONFIG and
  controlled PATH, including direct public-client tests. The sample's zero-environment version() calls
  do not supply that isolation. Reuse the actual Sandbox environment helper; never change global test
  environment or invoke the operator's deployed helper. Missing helpers stay sandbox paths.
- Version selects --config before environment/default config. Only an absent selected config permits
  PATH fallback; unreadable/invalid existing config yields helper_version null with exit 0. Cover the
  unreadable case as well as malformed bytes. Preserve the JSON/exit contract and earlier version tests.
- Install the accepted interrupt handlers only in command startup, never in the parallel test process.
  Keep earlier sandbox process routes and all accepted leaves. Add exact compiled mutations for limits,
  sentinel, compatibility and Trash reply ownership with byte-identical restored controls.
- Report chronology, raw logs, mutation hashes, timing/size audit and normal-hook commits in
  task-25-report.md. Main owns review and final ship. No live data, real helper/Trash/notification,
  installation, publication or destructive evidence cleanup.
