### Task 11: The SQLite ledger: open, permissions, WAL and the versioned schema

## Controller execution constraints

- STOP before implementation until the controller resolves the ledger pathname-boundary preflight recorded in progress.md. The sample's pathname opens do not become descriptor-relative merely because before/after checks pass. Read any resulting ruling and use actual RootDir APIs.
- Use clean-code-rust, shared persistence/testing guidance, OWASP path-boundary guidance and sql-toolkit. Do not patch a third-party dependency or invent a custom production virtual filesystem without a controller decision.
- Preserve the approved 5-second production busy timeout. The busy-contention test has an independent deadline and owned-process cleanup, not only its injected 50 ms timeout. Prove an actual hang mutation fails safely.
- Use compiling behavioral RED. Test migration atomicity, foreign-key enforcement, private database/sidecar permissions, future versions, read-only snapshots during and after use, absent schema, a live WAL and changed roots/links.
- Read-only paths must not repair permissions, create sidecars, checkpoint or migrate. Tests use only owned temporary directories.
- Preserve existing modules/tests and curate public exports. Split files naturally after rustfmt as needed, without broad lint suppression or unsolicited docstrings.
- Capture raw RED/GREEN, exact mutation/control pairs, full current gates, timings, staged-file size audit and committed-HEAD gitleaks in task-11-report.md.
- No subagents, new worktree, unrelated edits, push, pull request, install, live paths or destructive cleanup.


The schema created here is the whole ledger of spec section 4.4, not stage 1's slice of it: `seen`,
`recordings`, `transcripts`, `proposals`, `flags`, `occasions`, `tags`, `relations`, `releases`,
`dirty_publications` and `retention_intents`. Stages 2 to 4 add rows and repositories over these tables;
they add columns through a migration, never by editing version 1. Stage 1 implements repositories over
`seen`, `recordings`, `dirty_publications` and `retention_intents` only.

Two ways in. A mutating command has created the private state directory and holds its lock (Task 27), so
it opens the ledger writable through the state root's descriptor: the database file is created
exclusively at mode 0600 when absent, repaired to 0600 when present, refused when a link or a non-file
stands at its name, switched to WAL and migrated. An observational command or a dry run opens read-only:
no directory, file, mode, journal setting or schema is created or changed, and an absent state directory
or database, or a database file with no schema yet, is reported as `None` so the composition root
substitutes the empty memory ledger of Task 12.

**Files:**

- Create: `crates/vpt-application/src/ports/ledger.rs` (the error type only in this task)
- Modify: `crates/vpt-application/src/ports/mod.rs`
- Create: `crates/vpt-adapters/src/ledger/mod.rs`, `crates/vpt-adapters/src/ledger/sqlite/mod.rs`,
  `crates/vpt-adapters/src/ledger/sqlite/migrations.rs`,
  `crates/vpt-adapters/src/ledger/sqlite/connection.rs`,
  `crates/vpt-adapters/src/ledger/sqlite/boundary_tests.rs`
- Modify: `crates/vpt-adapters/src/lib.rs`

**Interfaces:**

- Consumes: `vpt_adapters::{Access, ContainedError, Kind, RootDir}`.

- Produces: `vpt_application::ports::LedgerError::{Busy, UnsupportedSchema(u32), Conflict(String),`
  `Corrupt(String), Io(String), PathEscape(PathBuf)}`;
  `vpt_adapters::{SqliteLedger, OpenError, SCHEMA_VERSION}` (`ledger/mod.rs` keeps `sqlite` private and
  re-exports these) with `OpenError::{Contained(ContainedError), Ledger(LedgerError)}` (`From` both ways
  in), `SqliteLedger::BUSY_TIMEOUT: Duration = Duration::from_secs(5)`,
  `SqliteLedger::open(state: &RootDir) -> Result<SqliteLedger, OpenError>`,
  `SqliteLedger::open_with_timeout(state: &RootDir, busy: Duration) -> Result<SqliteLedger, OpenError>`,
  `SqliteLedger::open_read_only(state_dir: &Path) -> Result<Option<SqliteLedger>, OpenError>`,
  `fn database_path(&self) -> &Path`, `fn schema_version(&self) -> Result<u32, LedgerError>`,
  `pub(crate) fn transaction<T>(&self, op: impl FnOnce(&rusqlite::Transaction<'_>) ->`
  `Result<T, LedgerError>) -> Result<T, LedgerError>` (an `Io` error on a read-only ledger),
  `pub(crate) fn read<T>(&self, op: impl FnOnce(&rusqlite::Connection) -> Result<T,`
  `LedgerError>) -> Result<T, LedgerError>`; `SCHEMA_VERSION: u32 = 1`;
  `pub(crate) fn map(error: rusqlite::Error) -> LedgerError` in `ledger::sqlite`.

- [ ] **Step 1: Write the failing tests**

Declare the modules first. `crates/vpt-application/src/ports/mod.rs` gains `mod ledger;` and
`pub use ledger::LedgerError;`. `crates/vpt-adapters/src/lib.rs` gains `mod ledger;` and
`pub use ledger::{OpenError, SCHEMA_VERSION, SqliteLedger};`; `crates/vpt-adapters/src/ledger/mod.rs` is:

```rust
//! The ledger: one SQLite type implementing every repository, and an
//! in-memory twin that runs the same contract.

mod sqlite;

pub use sqlite::{OpenError, SCHEMA_VERSION, SqliteLedger};
```

`crates/vpt-adapters/src/ledger/sqlite/mod.rs` starts as `mod migrations;` plus its test module, and
`migrations.rs` starts empty:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::{DirBuilderExt, PermissionsExt};

    fn state() -> (tempfile::TempDir, RootDir) {
        let temp = tempfile::tempdir().expect("temp");
        let dir = temp.path().canonicalize().expect("canonical").join("state");
        std::fs::DirBuilder::new().mode(0o700).create(&dir).expect("state dir");
        let root = RootDir::open(&dir).expect("root");
        (temp, root)
    }

    fn journal_mode(ledger: &SqliteLedger) -> String {
        ledger.read(|c| c.query_row("PRAGMA journal_mode", [], |row| row.get(0)).map_err(map)).expect("mode")
    }

    #[test]
    fn open_creates_a_0600_database_at_schema_version_1_in_wal_mode() {
        let (_temp, state) = state();
        let ledger = SqliteLedger::open(&state).expect("opens");
        assert_eq!(ledger.database_path(), state.path().join("vpt.db"));
        assert_eq!(std::fs::metadata(ledger.database_path()).expect("db").permissions().mode() & 0o777, 0o600);
        assert_eq!(ledger.schema_version().expect("version"), 1);
        assert_eq!(journal_mode(&ledger), "wal");
    }

    #[test]
    fn opening_twice_is_idempotent_repairs_the_mode_and_every_table_exists() {
        let (_temp, state) = state();
        SqliteLedger::open(&state).expect("first");
        std::fs::set_permissions(state.path().join("vpt.db"), std::fs::Permissions::from_mode(0o644)).expect("loosen");
        let ledger = SqliteLedger::open(&state).expect("second");
        assert_eq!(std::fs::metadata(ledger.database_path()).expect("db").permissions().mode() & 0o777, 0o600);
        let names: Vec<String> = ledger
            .read(|c| {
                let mut statement = c.prepare("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name").map_err(map)?;
                let rows = statement.query_map([], |row| row.get(0)).map_err(map)?;
                rows.collect::<Result<_, _>>().map_err(map)
            })
            .expect("names");
        for table in [
            "seen", "recordings", "transcripts", "proposals", "flags", "occasions", "tags", "relations", "releases",
            "dirty_publications", "retention_intents",
        ] {
            assert!(names.iter().any(|name| name == table), "{table} missing from {names:?}");
        }
    }

    #[test]
    fn a_future_schema_version_is_refused_with_its_number() {
        let (_temp, state) = state();
        let ledger = SqliteLedger::open(&state).expect("opens");
        ledger.read(|c| c.pragma_update(None, "user_version", 99).map_err(map)).expect("bump");
        assert_eq!(SqliteLedger::open(&state).unwrap_err(), OpenError::Ledger(LedgerError::UnsupportedSchema(99)));
        assert_eq!(
            SqliteLedger::open_read_only(state.path()).unwrap_err(),
            OpenError::Ledger(LedgerError::UnsupportedSchema(99))
        );
    }

    #[test]
    fn a_link_in_place_of_the_database_is_refused_before_anything_is_opened() {
        let (temp, state) = state();
        let elsewhere = temp.path().join("elsewhere.db");
        std::fs::write(&elsewhere, b"").expect("elsewhere");
        std::os::unix::fs::symlink(&elsewhere, state.path().join("vpt.db")).expect("link");
        let refused = ContainedError::NotRegular(state.path().join("vpt.db"));
        assert_eq!(SqliteLedger::open(&state).unwrap_err(), OpenError::Contained(refused.clone()));
        assert_eq!(SqliteLedger::open_read_only(state.path()).unwrap_err(), OpenError::Contained(refused));
        assert_eq!(std::fs::metadata(&elsewhere).expect("target").len(), 0);
    }

    #[test]
    fn a_held_write_lock_surfaces_as_busy_after_the_bounded_wait() {
        let (_temp, state) = state();
        let ledger = SqliteLedger::open_with_timeout(&state, Duration::from_millis(50)).expect("opens");
        let mut holder = rusqlite::Connection::open(ledger.database_path()).expect("second connection");
        let held = holder.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate).expect("held");

        let outcome = ledger.transaction(|t| t.execute("DELETE FROM seen", []).map(|_| ()).map_err(map));

        assert_eq!(outcome.unwrap_err(), LedgerError::Busy);
        drop(held);
    }

    #[test]
    fn read_only_open_reports_none_and_creates_nothing_when_state_or_database_is_absent() {
        let temp = tempfile::tempdir().expect("temp");
        let absent = temp.path().canonicalize().expect("canonical").join("state");
        assert!(SqliteLedger::open_read_only(&absent).expect("absent dir").is_none());
        assert!(!absent.exists());
        let (_temp, state) = state();
        assert!(SqliteLedger::open_read_only(state.path()).expect("absent db").is_none());
        assert_eq!(state.names().expect("names"), Vec::<String>::new());
        std::fs::write(state.path().join("vpt.db"), b"").expect("empty file");
        assert!(SqliteLedger::open_read_only(state.path()).expect("no schema").is_none());
        assert_eq!(std::fs::metadata(state.path().join("vpt.db")).expect("db").len(), 0);
    }

    #[test]
    fn read_only_open_reads_an_existing_ledger_and_refuses_to_write() {
        let (_temp, state) = state();
        SqliteLedger::open(&state).expect("create");
        std::fs::set_permissions(state.path().join("vpt.db"), std::fs::Permissions::from_mode(0o644)).expect("loosen");
        let ledger = SqliteLedger::open_read_only(state.path()).expect("opens").expect("present");
        assert_eq!(ledger.schema_version().expect("version"), 1);
        assert_eq!(std::fs::metadata(ledger.database_path()).expect("db").permissions().mode() & 0o777, 0o644);
        let outcome = ledger.transaction(|t| t.execute("DELETE FROM seen", []).map(|_| ()).map_err(map));
        assert!(matches!(outcome, Err(LedgerError::Io(_))), "{outcome:?}");
    }
}
```

Add `#[cfg(test)] mod boundary_tests;` at the end of `ledger/sqlite/mod.rs` before the red run.
`crates/vpt-adapters/src/ledger/sqlite/boundary_tests.rs`:

```rust
use super::*;
use std::os::unix::fs::{MetadataExt, PermissionsExt};

fn fixture() -> (tempfile::TempDir, RootDir) {
    let temp = tempfile::tempdir().expect("temp");
    let path = temp.path().canonicalize().expect("canonical").join("state");
    std::fs::create_dir(&path).expect("state");
    let root = RootDir::open(&path).expect("root");
    (temp, root)
}

#[derive(Debug, PartialEq, Eq)]
struct SnapshotRow {
    path: PathBuf,
    mode: u32,
    mtime_secs: i64,
    mtime_nanos: i64,
    bytes: Vec<u8>,
}

fn snapshot(root: &RootDir) -> Vec<SnapshotRow> {
    let mut paths = vec![root.path().to_path_buf()];
    paths.extend(
        root.names()
            .expect("names")
            .into_iter()
            .map(|name| root.path().join(name)),
    );
    paths.sort();
    paths
        .into_iter()
        .map(|path| {
            let metadata = path.symlink_metadata().expect("metadata");
            assert!(!metadata.file_type().is_symlink());
            let bytes = if metadata.is_file() {
                std::fs::read(&path).expect("bytes")
            } else {
                Vec::new()
            };
            SnapshotRow {
                path,
                mode: metadata.permissions().mode() & 0o777,
                mtime_secs: metadata.mtime(),
                mtime_nanos: metadata.mtime_nsec(),
                bytes,
            }
        })
        .collect()
}

#[test]
fn reconnect_refuses_a_replaced_state_root() {
    let (temp, root) = fixture();
    let ledger = SqliteLedger::open(&root).expect("ledger");
    std::fs::rename(root.path(), temp.path().join("held")).expect("move");
    std::fs::create_dir(root.path()).expect("replacement");
    let replacement = root.path().join(DATABASE);
    std::fs::write(&replacement, b"replacement").expect("replacement db");

    assert_eq!(
        ledger.schema_version(),
        Err(LedgerError::PathEscape(root.path().to_path_buf()))
    );
    assert_eq!(
        std::fs::read(replacement).expect("unchanged"),
        b"replacement"
    );
}

#[test]
fn reconnect_refuses_a_database_link_added_after_open() {
    let (temp, root) = fixture();
    let ledger = SqliteLedger::open(&root).expect("ledger");
    let path = root.path().join(DATABASE);
    std::fs::rename(&path, temp.path().join("held.db")).expect("move database");
    let target = temp.path().join("target");
    std::fs::write(&target, b"keep").expect("target");
    std::os::unix::fs::symlink(&target, &path).expect("link");

    assert_eq!(ledger.schema_version(), Err(LedgerError::PathEscape(path)));
    assert_eq!(std::fs::read(target).expect("unchanged"), b"keep");
}

#[test]
fn read_only_queries_preserve_files_while_open_and_after_close() {
    let (_temp, root) = fixture();
    drop(SqliteLedger::open(&root).expect("ledger"));
    let before = snapshot(&root);
    let ledger = SqliteLedger::open_read_only(root.path())
        .expect("read-only")
        .expect("present");
    ledger
        .read(|connection| {
            let version: u32 = connection
                .pragma_query_value(None, "user_version", |row| row.get(0))
                .map_err(map)?;
            assert_eq!(version, 1);
            assert!(snapshot(&root) == before, "the state changed while open");
            Ok(())
        })
        .expect("query");
    drop(ledger);
    assert!(snapshot(&root) == before, "the state changed after close");
}

#[test]
fn read_only_open_refuses_a_missing_wal_without_creating_it() {
    let (temp, root) = fixture();
    drop(SqliteLedger::open(&root).expect("ledger"));
    let wal = root.path().join("vpt.db-wal");
    std::fs::rename(&wal, temp.path().join("held.wal")).expect("move WAL");
    let before = snapshot(&root);

    assert!(matches!(
        SqliteLedger::open_read_only(root.path()),
        Err(OpenError::Ledger(LedgerError::Io(_)))
    ));
    assert_eq!(snapshot(&root), before);
    assert!(!wal.exists());
}

#[test]
fn read_only_queries_see_committed_rows_still_in_a_live_wal() {
    let (_temp, root) = fixture();
    let writer = SqliteLedger::open(&root).expect("ledger");
    let connection = writer.connect().expect("writer connection");
    connection
        .pragma_update(None, "wal_autocheckpoint", 0)
        .expect("disable checkpoint");
    connection
        .execute_batch(
            "CREATE TABLE read_probe(value INTEGER NOT NULL);
             INSERT INTO read_probe(value) VALUES (42);",
        )
        .expect("committed WAL row");
    let reader = SqliteLedger::open_read_only(root.path())
        .expect("read-only")
        .expect("present");
    let value: i64 = reader
        .read(|connection| {
            connection
                .query_row("SELECT value FROM read_probe", [], |row| row.get(0))
                .map_err(map)
        })
        .expect("WAL row");
    assert_eq!(value, 42);
}
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `cargo test -p vpt-adapters ledger`

Expected: the build fails with `cannot find` for `SqliteLedger`, `OpenError`, `LedgerError` and `map` in
`ledger::sqlite::tests`, and `unresolved import` for the re-exports in `ledger/mod.rs`. A run that
selects zero tests does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

`crates/vpt-application/src/ports/ledger.rs` (this task's part; Task 12 adds the rows and traits):

```rust
//! The ledger repositories a use case reads and writes.

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LedgerError {
    Busy,
    PathEscape(std::path::PathBuf),
    UnsupportedSchema(u32),
    Conflict(String),
    Corrupt(String),
    Io(String),
}
```

`crates/vpt-adapters/src/ledger/sqlite/migrations.rs`:

```rust
//! The versioned schema. Version 1 is the whole ledger of spec section 4.4;
//! a later stage adds columns with a new version, never by editing this one.

use rusqlite::{Connection, TransactionBehavior};
use vpt_application::ports::LedgerError;

pub const VERSION: u32 = 1;

const SCHEMA_V1: &str = "
CREATE TABLE seen (
  path TEXT PRIMARY KEY,
  file_name TEXT NOT NULL,
  size INTEGER NOT NULL,
  mtime_secs INTEGER NOT NULL,
  mtime_nanos INTEGER NOT NULL,
  flags INTEGER NOT NULL,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  deferral_count INTEGER NOT NULL DEFAULT 0,
  deferral_reason TEXT,
  deferred_size INTEGER,
  source_gone_at INTEGER,
  recording TEXT
);
CREATE TABLE recordings (
  id TEXT PRIMARY KEY,
  source_path TEXT,
  digest TEXT NOT NULL UNIQUE,
  captured_at INTEGER NOT NULL,
  captured_offset INTEGER NOT NULL,
  duration_secs INTEGER NOT NULL,
  title TEXT,
  title_source TEXT NOT NULL,
  ingested_at INTEGER NOT NULL,
  audio_path TEXT NOT NULL,
  stage_transcribe TEXT NOT NULL,
  stage_note TEXT NOT NULL,
  stage_synthesis TEXT NOT NULL,
  transcript_note_path TEXT,
  analysis_note_path TEXT,
  engines TEXT,
  language TEXT,
  open_flags INTEGER NOT NULL DEFAULT 0,
  diagnostics INTEGER NOT NULL DEFAULT 0,
  audio_trashed_at INTEGER
);
CREATE TABLE transcripts (
  recording TEXT PRIMARY KEY REFERENCES recordings(id),
  engine TEXT NOT NULL,
  body TEXT NOT NULL,
  accepted_at INTEGER NOT NULL
);
CREATE TABLE proposals (
  recording TEXT PRIMARY KEY REFERENCES recordings(id),
  input_digest TEXT NOT NULL,
  body TEXT NOT NULL,
  accepted_at INTEGER NOT NULL
);
CREATE TABLE flags (
  identifier TEXT PRIMARY KEY,
  recording TEXT NOT NULL REFERENCES recordings(id),
  shape TEXT NOT NULL,
  class TEXT NOT NULL,
  ranges TEXT,
  artifact TEXT,
  claim_index INTEGER,
  claim_digest TEXT,
  record_text TEXT,
  alternative_text TEXT,
  confidence REAL,
  state TEXT NOT NULL,
  resolution_text TEXT,
  resolved_at INTEGER
);
CREATE TABLE occasions (
  id TEXT PRIMARY KEY,
  provider_key TEXT NOT NULL UNIQUE,
  source TEXT NOT NULL,
  at INTEGER NOT NULL,
  duration_secs INTEGER,
  title TEXT NOT NULL,
  participants TEXT NOT NULL,
  tags TEXT NOT NULL,
  pack TEXT,
  brief_path TEXT,
  briefed_at INTEGER
);
CREATE TABLE tags (
  recording TEXT NOT NULL REFERENCES recordings(id),
  tag TEXT NOT NULL,
  state TEXT NOT NULL,
  provenance TEXT NOT NULL,
  PRIMARY KEY (recording, tag)
);
CREATE TABLE relations (
  recording TEXT NOT NULL REFERENCES recordings(id),
  kind TEXT NOT NULL,
  target TEXT NOT NULL,
  state TEXT NOT NULL,
  provenance TEXT NOT NULL,
  rule TEXT,
  ranges TEXT,
  PRIMARY KEY (recording, kind, target)
);
CREATE TABLE releases (
  sequence INTEGER PRIMARY KEY AUTOINCREMENT,
  recording TEXT NOT NULL REFERENCES recordings(id),
  stage TEXT NOT NULL,
  destination TEXT NOT NULL,
  content_digest TEXT NOT NULL,
  source_digest TEXT NOT NULL,
  report_path TEXT NOT NULL,
  snapshot TEXT NOT NULL,
  released_at INTEGER NOT NULL
);
CREATE TABLE dirty_publications (
  target TEXT PRIMARY KEY,
  expected_previous TEXT,
  intended TEXT NOT NULL,
  recorded_at INTEGER NOT NULL
);
CREATE TABLE retention_intents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artifact_kind TEXT NOT NULL,
  recording TEXT,
  path TEXT NOT NULL,
  expected TEXT NOT NULL,
  recorded_at INTEGER NOT NULL,
  completed_at INTEGER
);
";

pub fn migrate(connection: &mut Connection) -> Result<(), LedgerError> {
    let version = current(connection)?;
    if version == VERSION {
        return Ok(());
    }
    let transaction = connection.transaction_with_behavior(TransactionBehavior::Immediate).map_err(super::map)?;
    let version = current(&transaction)?;
    if version == 0 {
        transaction.execute_batch(SCHEMA_V1).map_err(super::map)?;
    }
    transaction.pragma_update(None, "user_version", VERSION).map_err(super::map)?;
    transaction.commit().map_err(super::map)
}

/// The stored version, refused when it is newer than this build understands.
pub fn current(connection: &Connection) -> Result<u32, LedgerError> {
    let version: u32 = connection.pragma_query_value(None, "user_version", |row| row.get(0)).map_err(super::map)?;
    if version > VERSION {
        return Err(LedgerError::UnsupportedSchema(version));
    }
    Ok(version)
}
```

`crates/vpt-adapters/src/ledger/sqlite/mod.rs`, above its test module:

```rust
//! One SQLite database: WAL, a bounded busy timeout, restrictive modes, and
//! versioned migrations at open. The retained state root is checked at each connection.

mod connection;
mod migrations;

use crate::contained::{Access, ContainedError, Kind, RootDir};
use rusqlite::{Connection, ErrorCode, Transaction, TransactionBehavior};
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::time::Duration;
use vpt_application::ports::LedgerError;

pub use migrations::VERSION as SCHEMA_VERSION;

const DATABASE: &str = "vpt.db";
const SIDE_FILES: [&str; 2] = ["vpt.db-wal", "vpt.db-shm"];

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OpenError {
    Contained(ContainedError),
    Ledger(LedgerError),
}

impl From<ContainedError> for OpenError {
    fn from(error: ContainedError) -> OpenError {
        OpenError::Contained(error)
    }
}

impl From<LedgerError> for OpenError {
    fn from(error: LedgerError) -> OpenError {
        OpenError::Ledger(error)
    }
}

#[derive(Debug)]
pub struct SqliteLedger {
    state: RootDir,
    path: PathBuf,
    busy_timeout: Duration,
    read_only: bool,
}

impl SqliteLedger {
    pub const BUSY_TIMEOUT: Duration = Duration::from_secs(5);

    pub fn open(state: &RootDir) -> Result<SqliteLedger, OpenError> {
        Self::open_with_timeout(state, Self::BUSY_TIMEOUT)
    }

    /// Writable: the file is created at 0600 when absent, repaired to 0600 when
    /// present, refused when a link or a non-file stands at its name, then
    /// switched to WAL and migrated.
    pub fn open_with_timeout(
        state: &RootDir,
        busy_timeout: Duration,
    ) -> Result<SqliteLedger, OpenError> {
        state.revalidate()?;
        let database = match state.open_file(Path::new(DATABASE), Access::ReadWrite) {
            Ok(file) => file,
            Err(ContainedError::Io {
                kind: std::io::ErrorKind::NotFound,
                ..
            }) => state.create_file(Path::new(DATABASE), 0o600)?,
            Err(error) => return Err(error.into()),
        };
        database
            .set_permissions(std::fs::Permissions::from_mode(0o600))
            .map_err(|error| LedgerError::Io(error.to_string()))?;
        drop(database);
        no_link_beside(state)?;
        let ledger = SqliteLedger {
            state: state.try_clone()?,
            path: state.path().join(DATABASE),
            busy_timeout,
            read_only: false,
        };
        let mut connection = ledger.connect()?;
        migrations::migrate(&mut connection)?;
        ledger.state.revalidate()?;
        Ok(ledger)
    }

    /// Read-only: nothing is created, changed or migrated. `None` when the state
    /// directory or the database is absent, or the file holds no schema yet.
    pub fn open_read_only(state_dir: &Path) -> Result<Option<SqliteLedger>, OpenError> {
        let state = match RootDir::open(state_dir) {
            Ok(state) => state,
            Err(ContainedError::Io {
                kind: std::io::ErrorKind::NotFound,
                ..
            }) => return Ok(None),
            Err(error) => return Err(error.into()),
        };
        let path = match state.regular(Path::new(DATABASE)) {
            Ok(path) => path,
            Err(ContainedError::Io {
                kind: std::io::ErrorKind::NotFound,
                ..
            }) => return Ok(None),
            Err(error) => return Err(error.into()),
        };
        no_link_beside(&state)?;
        if state.stat(Path::new(DATABASE))?.size == 0 {
            return Ok(None);
        }
        let ledger = SqliteLedger {
            state,
            path,
            busy_timeout: Self::BUSY_TIMEOUT,
            read_only: true,
        };
        match ledger.read(migrations::current)? {
            0 => Ok(None),
            _ => Ok(Some(ledger)),
        }
    }

    pub fn database_path(&self) -> &Path {
        &self.path
    }

    pub fn schema_version(&self) -> Result<u32, LedgerError> {
        self.read(|c| {
            c.pragma_query_value(None, "user_version", |row| row.get(0))
                .map_err(map)
        })
    }

    fn connect(&self) -> Result<Connection, LedgerError> {
        connection::open(&self.state, self.busy_timeout, self.read_only)
    }

    pub(crate) fn transaction<T>(
        &self,
        operation: impl FnOnce(&Transaction<'_>) -> Result<T, LedgerError>,
    ) -> Result<T, LedgerError> {
        if self.read_only {
            return Err(LedgerError::Io("the ledger is read-only".into()));
        }
        let mut connection = self.connect()?;
        let transaction = connection
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(map)?;
        let value = operation(&transaction)?;
        connection::check(&self.state, false)?;
        transaction.commit().map_err(map)?;
        Ok(value)
    }

    pub(crate) fn read<T>(
        &self,
        operation: impl FnOnce(&Connection) -> Result<T, LedgerError>,
    ) -> Result<T, LedgerError> {
        let connection = self.connect()?;
        let value = operation(&connection)?;
        connection::check(&self.state, self.read_only)?;
        Ok(value)
    }
}

/// SQLite opens the journal and shared-memory files by name beside the
/// database; a link standing at either name is refused first.
fn no_link_beside(state: &RootDir) -> Result<(), ContainedError> {
    for name in SIDE_FILES {
        match state.stat(Path::new(name)) {
            Ok(stat) if stat.kind != Kind::File => {
                return Err(ContainedError::NotRegular(state.path().join(name)));
            }
            Ok(_)
            | Err(ContainedError::Io {
                kind: std::io::ErrorKind::NotFound,
                ..
            }) => {}
            Err(error) => return Err(error),
        }
    }
    Ok(())
}

pub(crate) fn map(error: rusqlite::Error) -> LedgerError {
    match &error {
        rusqlite::Error::SqliteFailure(failure, _) if failure.code == ErrorCode::DatabaseBusy => {
            LedgerError::Busy
        }
        rusqlite::Error::SqliteFailure(failure, _)
            if failure.code == ErrorCode::ConstraintViolation =>
        {
            LedgerError::Conflict(error.to_string())
        }
        rusqlite::Error::SqliteFailure(failure, _)
            if failure.code == ErrorCode::DatabaseCorrupt
                || failure.code == ErrorCode::NotADatabase =>
        {
            LedgerError::Corrupt(error.to_string())
        }
        _ => LedgerError::Io(error.to_string()),
    }
}
```

`crates/vpt-adapters/src/ledger/sqlite/connection.rs`:

```rust
use super::{DATABASE, SIDE_FILES, map, no_link_beside};
use crate::contained::{ContainedError, RootDir};
use rusqlite::{Connection, OpenFlags};
use std::os::unix::ffi::OsStrExt;
use std::path::Path;
use std::time::Duration;
use vpt_application::ports::LedgerError;

pub(super) fn open(
    state: &RootDir,
    busy_timeout: Duration,
    read_only: bool,
) -> Result<Connection, LedgerError> {
    check(state, read_only)?;
    let path = state.path().join(DATABASE);
    let common = OpenFlags::SQLITE_OPEN_NO_MUTEX | OpenFlags::SQLITE_OPEN_NOFOLLOW;
    let opened = if read_only {
        Connection::open_with_flags(
            read_only_uri(&path),
            common | OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_URI,
        )
    } else {
        Connection::open_with_flags(&path, common | OpenFlags::SQLITE_OPEN_READ_WRITE)
    };
    let connection = match opened {
        Ok(connection) => connection,
        Err(error) => {
            check(state, read_only)?;
            return Err(open_error(error, &path));
        }
    };
    check(state, read_only)?;
    persist_wal(&connection)?;
    connection.busy_timeout(busy_timeout).map_err(map)?;
    if !read_only {
        connection
            .pragma_update(None, "journal_mode", "WAL")
            .map_err(map)?;
    }
    connection
        .pragma_update(None, "foreign_keys", "ON")
        .map_err(map)?;
    check(state, read_only)?;
    Ok(connection)
}

pub(super) fn check(state: &RootDir, require_sidecars: bool) -> Result<(), LedgerError> {
    state.revalidate().map_err(contained)?;
    state.regular(Path::new(DATABASE)).map_err(contained)?;
    no_link_beside(state).map_err(contained)?;
    if require_sidecars {
        for name in SIDE_FILES {
            match state.regular(Path::new(name)) {
                Ok(_) => {}
                Err(ContainedError::Io {
                    kind: std::io::ErrorKind::NotFound,
                    ..
                }) => {
                    return Err(LedgerError::Io(format!(
                        "read-only ledger requires existing {name}"
                    )));
                }
                Err(error) => return Err(contained(error)),
            }
        }
    }
    Ok(())
}

fn persist_wal(connection: &Connection) -> Result<(), LedgerError> {
    let mut enabled: std::ffi::c_int = 1;
    // SAFETY: the connection and integer outlive this synchronous call.
    let result = unsafe {
        rusqlite::ffi::sqlite3_file_control(
            connection.handle(),
            c"main".as_ptr(),
            rusqlite::ffi::SQLITE_FCNTL_PERSIST_WAL,
            (&mut enabled as *mut std::ffi::c_int).cast(),
        )
    };
    if result == rusqlite::ffi::SQLITE_OK {
        Ok(())
    } else {
        Err(LedgerError::Io(format!(
            "could not preserve SQLite sidecars: code {result}"
        )))
    }
}

fn read_only_uri(path: &Path) -> String {
    const HEX: &[u8; 16] = b"0123456789ABCDEF";
    let mut uri = String::from("file:");
    for &byte in path.as_os_str().as_bytes() {
        if byte.is_ascii_alphanumeric() || matches!(byte, b'/' | b'-' | b'.' | b'_' | b'~') {
            uri.push(char::from(byte));
        } else {
            uri.push('%');
            uri.push(char::from(HEX[usize::from(byte >> 4)]));
            uri.push(char::from(HEX[usize::from(byte & 15)]));
        }
    }
    uri.push_str("?mode=ro&readonly_shm=1");
    uri
}

fn contained(error: ContainedError) -> LedgerError {
    match error {
        ContainedError::Escape { path, .. }
        | ContainedError::NotRegular(path)
        | ContainedError::NotADirectory(path) => LedgerError::PathEscape(path),
        ContainedError::Io { path, kind } => {
            LedgerError::Io(format!("{kind} at {}", path.display()))
        }
    }
}

fn open_error(error: rusqlite::Error, path: &Path) -> LedgerError {
    match &error {
        rusqlite::Error::SqliteFailure(failure, _)
            if failure.extended_code == rusqlite::ffi::SQLITE_CANTOPEN_SYMLINK =>
        {
            LedgerError::PathEscape(path.to_path_buf())
        }
        _ => map(error),
    }
}
```

Every connection revalidates the retained root and all database leaves. Writable connections preserve the
write-ahead log and shared-memory sidecars; read-only connections require those regular files and use
`readonly_shm=1`, so observation creates or changes no durable file. Missing sidecars fail without
repair. A zero-length database returns `None` before SQLite opens it.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test -p vpt-adapters ledger`

Expected: 12 tests PASS. The busy test finishes in well under a second: the wait is 50 ms. Run
`cargo clippy -p vpt-adapters --all-targets -- -D warnings` and expect no warnings.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(ledger): SQLite open through the state root, WAL, the version 1 schema"
```

______________________________________________________________________


