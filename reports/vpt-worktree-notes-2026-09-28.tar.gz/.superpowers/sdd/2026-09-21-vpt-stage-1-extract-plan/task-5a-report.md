Task 5a is committed as `1661c1227b5a19498efe4d94d3a4523730a67cba` on
`feat/stage-1-extract`, based on `19d0f58e3d8e994a47b7bf918e7bc1efabe59487`.
The tracked worktree and index are clean. [Commit output](task5a-commit.log).

`RootDir` retains the directory handle for leaf validation, metadata, open/create, directory
creation, rename and sync. Enumeration revalidates the saved path, then opens an independent stream
relative to the retained descriptor. The stream owns its descriptor, distinguishes end of input from
errors, skips invalid Unicode names and dot entries, sorts names, and closes on every return path.
The public interface matches the brief. The controller approved the private file/directory/rename
split. Configuration loading and `roots/directory.rs::private_dir` now use the checked access layer.

| Verification | Result | Raw evidence |
| --- | --- | --- |
| Baseline `cargo test --locked --workspace --no-fail-fast --features dev-tools` | 105 pass | [Baseline](task5a-baseline.log) |
| RED `cargo test --locked -p vpt-adapters contained` | Compiles; 17 expected behavioral failures | [RED](task5a-contained-red.log) |
| RED `cargo test --locked -p vpt-adapters creating_` | Both creation regressions fail: `Ok(())` instead of `PathEscape` | [Roots RED](task5a-roots-red.log) |
| GREEN `cargo test --locked -p vpt-adapters` | 77 pass, 0.11 s | [Adapter GREEN](task5a-adapters-green-3.log) |
| Final `cargo test --locked -p vpt-adapters contained` | 18 pass, 0.02 s | [Contained GREEN](task5a-contained-green.log) |
| `just ship` | Exit 0, 125 leaves, 8.59 s | [Ship](task5a-ship.log) |
| `just lint-check` | Exit 0, 0.80 s | [Lint](task5a-lint-check.log) |
| `just test-rust` | Exit 0, 1.90 s | [Tests](task5a-test-rust.log) |
| `cargo check --locked --workspace --all-targets` | Exit 0, 1.05 s | [Check](task5a-check.log) |
| `cargo build --locked --release --workspace` | Exit 0, 1.46 s | [Release](task5a-release.log) |
| Committed-HEAD `gitleaks git --no-banner` | Exit 0, 91 commits, no leaks, 1.93 s | [Secrets scan](task5a-committed-head-secrets.log) |

The compiling RED scaffold used explicit unimplemented methods. The configuration regressions
failed against the original real loader, and the root regressions failed against the original real
creator. The first implementation compile exposed two sibling-module visibility errors, corrected
to `pub(super)`. The next run passed 75 leaves but could not construct an invalid Unicode filename:
the fixture filesystem returned `EILSEQ`. This fixture error is not counted as behavioral RED.
The existing inline name decoder was extracted into private `entry_name`, tested with literal bytes,
and mutation-verified. Both intermediate logs remain: [compile](task5a-adapters-green.log),
[fixture](task5a-adapters-green-2.log).

All 27 unique mutations compiled and failed their exact named leaf with exit 101. Each restored
control passed with exit 0, after checking byte-identical restoration. The
[mutation ledger](task5a-mutations-all.json) records each exact substitution, source hashes, build
command/output, executable command/output and elapsed time. The
[runner](task5a-mutations.py) applies edits through `apply_patch` and asserts the full on-disk bytes
before compilation. One formatted-token mismatch stopped before editing; the corrected runner
continued only the remaining cases.

The required deterministic enumeration leaf retains and revalidates A, replaces its path with a
link to B, and requires all three A entries on both complete reads. The
[path-enumeration mutant](task5a-path-enumeration-mutant.log) returned B's `impostor`, and the
[shared-offset mutant](task5a-shared-directory-offset-mutant.log) returned an empty second listing.
Their [path control](task5a-path-enumeration-control.log) and
[offset control](task5a-shared-directory-offset-control.log) passed. The
[invalid-byte mutant](task5a-invalid-name-mutant.log) failed and its
[control](task5a-invalid-name-control.log) passed.

Removing `O_NONBLOCK` failed the owned-process FIFO (first-in, first-out) regression in 0.518 s,
including killing and reaping its child at the independent 500 ms deadline. Its
[mutant](task5a-fifo-blocking-mutant.log) and [control](task5a-fifo-blocking-control.log) show the exact
leaf; the control took 0.025 s. The test uses no reader threads, thread joins, synchronization sleeps,
global hooks or syscall overrides. All mutation leaves finished below one second. In the parallel
workspace suite the slowest entire suite took 0.51 s, bounding every leaf below one second; adapters
took 0.12 s. The [name map](task5a-test-map.log) preserves every one of the 105 baseline names and
adds 20. [Removed leaves](task5a-removed-leaves.log) is empty.

The [prescribed staged-file size audit](task5a-size-audit.log) includes all handwritten Rust files
after formatting and staging. Changed files peak at 162 implementation lines and 208 total lines,
within the 200/300 targets. The approved schema table (471/471) and loader tests (0/304) are unchanged.
Native flags and signatures were checked against the installed Software Development Kit headers;
directory-stream ownership, entry lifetime, errors and close semantics were checked in the installed
`fdopendir(3)` manual. [Native evidence](task5a-native-api-evidence.log).

Owned files, all under `crates/vpt-adapters/src/`:

- `contained.rs`, `contained/file.rs`, `contained/directory.rs`, `contained/rename.rs`.
- `contained/tests.rs`, `contained/tests/files.rs`, `contained/tests/directory.rs`, `contained/tests/fifo.rs`.
- `config/load.rs`, `config/load/tests/contained.rs`.
- `config/roots/directory.rs`, `config/roots/tests.rs`, `lib.rs`.

Self-review found no unresolved Task 5a issue. The filesystem trust boundary runs from configured
paths or leaf names through validation to descriptor-relative native calls; directory replacement
cannot redirect the retained file operations or enumeration. Unsafe code is confined to concrete
adapter calls with ownership and pointer-lifetime invariants. Metadata and directory-type checks
classify links and special files without following them. Creation refuses links introduced after
resolution, and the loader preserves existing parse/error regressions. No dependency, schema,
command crate, protocol format or external consumer changed. The ignored report/evidence is the
only work outside the 13 committed files. Main retains progress/Todoist ownership and independent
review. No live data, database work, installation, apply, push, pull request or merge occurred.
