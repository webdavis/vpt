# Task 23 execution brief

Read task-23-brief.md completely after Task 22 is accepted. Reconcile with the actual D5/D6 and ingest
interfaces. This is preparation, not dispatch.

- Own dry-run hashing, mode handling and abort behavior with focused tests. You are not alone;
  preserve others' work. One product writer, no subagents. Main owns the ledger and task tracker.
- Record compiling, reachable behavioral RED before adding each behavior. Existing dry-run failure
  event suppression is a regression guard, not a new failing test.
- Run the normal source gates before dry-run hashing. Hash from the validated descriptor's start,
  recheck its metadata after hashing, and defer changed input. Exercise a deliberately pre-positioned
  handle and a controlled metadata change at the actual read boundary.
- Find dry-run titles by current whole digest, not source path, filename or title-copy contents. A
  lookup failure fails the run with its typed safe error. Never refresh or acquire title-copy writes.
- Verify no durable effects using the accepted complete snapshot helper, not the sample's narrower
  copy_snapshot tuple. Cover state, title copy and archive with quiescent fixture writers, as well as
  zero staging, helper/Trash calls, ledger mutations and events. Read-only database owners and their
  companion policy follow D5; do not use a writable fixture connection for the observed invocation.
- --once applies candidate gates to exactly its path and never marks other sources gone. Preserve
  approved startup recovery separately from candidate selection. Dry-run --once is observational.
- A previously nonempty full store becoming empty aborts; a fresh empty store succeeds. Only the
  mutating run marks disappearance and emits one failure event. Cover failures after accepted ingest
  and recovery, retaining exactly the identities already durable in the partial report.
- Reuse crate-local probes, preserve all accepted leaves, and retain compiled mutations with exact
  restored controls. No broad lint allowances, sample docstrings or new test framework.
- Report chronology, logs, hashes, timing/size audit and normal-hook commits in task-23-report.md.
  Main owns independent review and final ship. No live data, real Trash, notifications, installation,
  publishing or destructive evidence cleanup.
