# Task 9: MPEG-4 wholeness gate

## Controller acceptance

Accepted at 17ea73a571bb152a4a38b3d105e659b89efd6bf8 after independent Astra review and scoped re-review (task-9-review-1.md and task-9-review-2.md). The fresh committed-HEAD just ship exited 0 in task-9-fix1-controller-ship.log, with 202 named passing leaves and a clean 96-commit secrets scan. The controller's independent comparison retained all 178 original baseline leaves and counted 24 added. Both final hashes match the report, and the worktree/index are clean with unchanged HEAD. No deadline recurrence; the earlier issue remains tracked separately. Eight compiled mutation categories have passing restored controls. No live media, installation or publication was performed.

Base: `2b50fa373f9d6483663ffd7a21bb246e844b96cf`.

The domain parser uses the supplied length and bounded read callback to walk top-level boxes, then `moov` children for `mvhd`. It derives presentation creation time and whole-second duration from version 0 or 1 fields. A size-zero child extends to file end and is refused if that crosses its parent. Unknown-duration sentinels in either version are refused. The fixtures feature was already declared; no manifest changed.

## Test-first and mutation evidence

The first focused command could not write the worktree target or evidence log under the sandbox (`Operation not permitted`); it did not execute tests. The escalated [compiling RED](task-9-red-02.log) ran 21 filtered leaves, including two existing layout leaves: 18 new behavior tests failed against the stub, one rejection test passed. The first [GREEN](task-9-green-01.log) passed those 21. The [expanded focused run](task-9-expanded-control-01.log) passed 24 filtered leaves after the remaining edge tests were added. The final [named-leaf list](task-9-final-leaves-02.log) has 200 leaves, with [22 added](task-9-added-leaves-02.log) and [zero missing](task-9-missing-leaves-02.log) against the 178-leaf Task 8 baseline. The baseline was normalized to C sort order before comparison.

Every mutation below was verified on disk, compiled, failed its named behavior test with exit 101, then restored to the same `container.rs` SHA-256 hash `a947b5a0faf14198afe63dbc49873834e9fbaf9e0dc541036f45783724831e83` and passed its control with exit 0. Each raw mutant log contains the exact source line and its unique hash.

| Exact edit | Failing behavior | Raw mutant and control |
| --- | --- | --- |
| `0 => (file_end - offset, 8)` to `0 => (parent_end - offset, 8)` | size-zero child crossing its parent became `MissingMvhd` | [mutant](task-9-mut-size-zero-01.log), [control](task-9-control-size-zero-01.log) |
| `timescale == 0 || unknown` to `timescale == 0 && unknown` | both version-specific unknown-duration tests accepted sentinels | [mutant](task-9-mut-duration-01.log), [control](task-9-control-duration-01.log) |
| `moov = Some((offset + header.header_len, offset + header.length))` to `moov = Some((0, 0))` | positive whole-file test lost the movie header | [mutant](task-9-mut-root-01.log), [control](task-9-control-root-01.log) |
| base header bound `checked_add(8)` to `checked_add(4)` | seven-byte file triggered an unsafe read request and `Unreadable` | [mutant](task-9-mut-short-header-01.log), [control](task-9-control-short-header-01.log) |
| added a one-byte read from the `mdat` body after its header | bounded-read test caught the payload read at offset 36 | [mutant](task-9-mut-payload-01.log), [control](task-9-control-payload-01.log) |

No mutation survived. The callback tests cover header and `mvhd` failures. The payload test asserts that no read exceeds 28 bytes or intersects the 100,000-byte payload; its [pre-mutation control](task-9-payload-control-before-01.log) passed.

## Final-source checks

| Command | Result | Raw evidence |
| --- | --- | --- |
| `just ship` | exit 0, 200 leaves, documentation and 95-commit secrets scan clean, 25.41 s | [ship](task-9-ship-final-01.log) |
| `cargo check --locked --workspace --all-targets --features dev-tools` | exit 0, 6.15 s | [check](task-9-check-final-01.log) |
| `just test-rust` | exit 0, 200 leaves, 4.94 s | [test](task-9-test-rust-final-01.log) |
| `just lint-check` | exit 0, 2.54 s | [lint](task-9-lint-check-final-01.log) |
| `cargo build --locked --release` | exit 0, 12.34 s | [release](task-9-release-final-01.log) |
| domain Clippy with `--all-targets --features fixtures -- -D warnings` | exit 0, 0.90 s | [Clippy](task-9-domain-clippy-final-01.log) |
| staged `git diff --check` and exact line audit | exit 0; parser 177 implementation / 179 total, tests 237 total, fixtures 52 total | [size](task-9-size-audit-final-01.log) |

The ship size gate retains two inherited warnings: `config/schema.rs` at 471 implementation lines and `config/load/tests.rs` at 304 total lines. The tracked 500 ms CLI deadline failure (`6hc7MMRc2QhRm75g`) did not recur in these runs.

Commit `6eaf984` contains only the four owned Rust files. The [committed-HEAD redacted secrets scan](task-9-committed-head-secrets-01.log) exited 0: 96 commits scanned, no leaks found, 7.15 s. The controller owns the fresh committed-HEAD ship and independent boundary review.

## Review round 1: positive metadata coverage

Astra approved the implementation and identified a test gap: the original positive durations were integral, and version 1 creation and duration fit in 32 bits. The decoder was already correct. The only source change in this round adds two tests to `container/tests.rs`. One sets a 7.999-second raw duration and expects 7 seconds. The other verifies that the assembled version 1 creation and duration fields are both above `u32::MAX`, then checks the decoded values. [The initial focused control](task-9-fix1-focused-control-01.log) passed all 24 container tests.

Three compiled mutations verified the new assertions. Each log records the exact edit and a unique mutant hash. Each mutant failed with exit 101; its focused restored control passed with exit 0 and parser SHA-256 `a947b5a0faf14198afe63dbc49873834e9fbaf9e0dc541036f45783724831e83`. No mutation survived.

| Exact edit | Observed failure | Raw mutant and restored control |
| --- | --- | --- |
| `duration / timescale` to `duration.div_ceil(timescale)` | fractional duration became 8 instead of 7 | [mutant](task-9-fix1-mut-floor-01.log), [control](task-9-fix1-control-floor-01.log) |
| version 1 creation read narrowed from 64 to low 32 bits | creation became `-2082844800` instead of `2212122496` | [mutant](task-9-fix1-mut-v1-creation-01.log), [control](task-9-fix1-control-v1-creation-01.log) |
| version 1 duration read narrowed from 64 to low 32 bits | duration became 0 instead of `4294968` | [mutant](task-9-fix1-mut-v1-duration-01.log), [control](task-9-fix1-control-v1-duration-01.log) |

The final [named-leaf list](task-9-fix1-final-leaves-01.log) contains 202 tests: [two added](task-9-fix1-added-leaves-01.log), [none missing](task-9-fix1-missing-leaves-01.log) from the 200-leaf Task 9 control, and all 178 original baseline leaves retained. The test file has SHA-256 `f0e66b604d6e1615526dceced5759f6956f74dab15e3af2d8821081f39dc7fcb`.

| Final-source gate | Result | Raw evidence |
| --- | --- | --- |
| `just ship` | exit 0, 202 tests, docs and 96-commit scan clean, 18.67 s | [ship](task-9-fix1-ship-01.log) |
| all-targets `cargo check` | exit 0, 5.05 s | [check](task-9-fix1-check-01.log) |
| `just test-rust` | exit 0, 202 tests, 3.52 s | [test](task-9-fix1-test-rust-01.log) |
| `just lint-check` | exit 0, 1.67 s | [lint](task-9-fix1-lint-check-01.log) |
| focused domain Clippy | exit 0, 0.31 s | [Clippy](task-9-fix1-domain-clippy-01.log) |
| release build | exit 0, 4.01 s | [release](task-9-fix1-release-01.log) |
| staged `git diff --check` and size audit | exit 0; only `container/tests.rs`, 261 total lines | [size](task-9-fix1-size-audit-01.log) |

The tracked 500 ms CLI deadline failure did not recur. The two inherited size warnings remain unchanged. Amended HEAD `17ea73a` contains the original four owned Rust files, with only `container/tests.rs` changed in review round 1. The [committed-HEAD redacted secrets scan](task-9-fix1-committed-head-secrets-01.log) exited 0: 96 commits scanned, no leaks found, 9.06 s. The controller owns the fresh committed-HEAD ship and scoped rereview.
