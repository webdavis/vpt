Spec compliance: Compliant for D1 at `1a00d858db6a744970599096318340af1ce7ccee`, including both controller rulings.

Reviewer: `/root/vpt_review_d1_astra`, independent `gpt-6-astra` at `xhigh`.

### Strengths

- Retained-directory operations preserve containment during creation and cleanup. Type and link-count checks precede permission changes; exclusive creation and requested synchronization errors propagate. Evidence: `crates/vpt-adapters/src/contained/file.rs:10`, `:38`; `crates/vpt-adapters/src/database/files.rs:55`, `:96`.
- Bare-leaf validation and the closed role enum produce only the authorized database and three companion names. No pathname fallback or dependency change appears in the diff. Evidence: `crates/vpt-adapters/src/database/files.rs:28`, `:44`; `crates/vpt-adapters/src/database/mod.rs:36`.
- All four policies enforce actual descriptor access. Observation preserves existing `0640` files; refreshed copies permit writes only to shared memory. Tests inspect descriptor flags, failed writes, contents, and metadata. Evidence: `crates/vpt-adapters/src/database/mod.rs:22`; `crates/vpt-adapters/src/database/tests/files/policies.rs:27`, `:94`.
- Replacement-root and replacement-ancestor tests exercise retained opens, creation, and removal while checking unchanged replacement snapshots. Unsafe-entry tests cover every role and policy. Evidence: `crates/vpt-adapters/src/database/tests/files.rs:15`, `:46`; `crates/vpt-adapters/src/database/tests/files/refusal.rs:10`.

### Focused checks

- Risk: inherited opening helpers could weaken D1 flags or type checks. Checked `contained.rs:57`, `:77`, `:108`, `:153` and `contained/file.rs:119`: close-on-exec, no-follow, nonblocking opening, bare syscall names, and regular-file validation remain present. Completed the diff's truncated `stat` and `c_name` context; their retained-descriptor behavior is preserved.
- Risk: shared revalidation classification could change setup failure handling incorrectly. Checked `contained/directory.rs:35`, `config/write.rs:37`, `:58`, and `config/write/directory.rs:74`, `:83`. Callers propagate the strengthened containment refusal; ordinary input/output failures retain their existing mapping.
- Audited all nine temporary expectations: two checked-root methods at `contained/file.rs:6`, `:34`; `DatabaseFiles` and its implementation at `database/files.rs:10`, `:20`; five policy, role, and error items at `database/mod.rs:6`, `:18`, `:32`, `:44`, `:70`. Each names an approved consumer and uses `cfg_attr(not(test), expect(...))`. No module-wide allowance, hidden production module, synthetic caller, or public visibility expansion appears.
- Removal synchronization matches the ruling: checked unlink occurs first, and `root.sync()` runs exactly when requested, with failure propagated. Creation also synchronizes. Evidence: `database/files.rs:96`; `contained/file.rs:29`. Injected synchronization-failure verification remains D3 work.
- Evidence audit confirms 209 baseline names retained, 16 added, and zero missing. All 14 mutant logs show successful compilation followed by behavioral failure; controls pass with matching original/restored hashes. Independently calculated current source hashes match those controls.
- Worker and controller ship logs pass. The only reported size warnings concern the inherited schema and configuration-test files. D1 files remain within the stated targets. Evidence: `task-D1-size-audit-final-01.log:17`, `:22`; `task-D1-controller-ship.log:334`.
- Worker runs bound every test target below one second. The controller's adapter and setup totals, 13.48 seconds and 1.66 seconds, do not establish individual test durations. They establish neither individual compliance nor an individual violation. Evidence: `task-D1-ship-final-01.log:50`, `:204`; `task-D1-controller-ship.log:67`, `:200`.
- No suite or focused test was rerun during this review. The two corrected fixture mistakes and later error-payload characterization are disclosed accurately. The existing 500 ms command-deadline follow-up remains unresolved.

### Issues

- Critical: None.
- Important: None.
- Minor: None attributable to D1.

### Assessment

Task quality: Approved.

The implementation meets the checked-file boundary and policy requirements with behavioral and mutation evidence. This approval covers D1; FIFO watchdogs, locks, callbacks, connection lifetime, shared memory, schema, and title integration remain assigned to D2 through D6.
