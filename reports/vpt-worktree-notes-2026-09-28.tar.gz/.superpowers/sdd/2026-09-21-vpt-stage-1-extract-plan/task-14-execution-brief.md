# Task 14 execution brief

Ready for dispatch from accepted `5ec7b49`: Task 13 and Task 12's journal are accepted. Read the entire approved Task 14 in `docs/superpowers/plans/2026-09-21-vpt-stage-1-extract-plan.md`, from `### Task 14:` through the next task heading (currently lines 8491-9050). The controller reread it fully on 2026-09-27. Inspect the actual accepted journal and current retained-root publication APIs before implementation.

## Ownership and boundaries

- Own the stores application port, publication repair use case, filesystem stores adapter, their focused tests and curated exports, plus ignored Task 14 report/evidence. Main owns progress/Todoist. Preserve other work; one product writer, no new worktree or subagents.
- Preserve the exact repair contract: clear a journal row only after a successful directory sync; refuse changed targets and mismatching render digests without overwriting; retain rows on failures. No rendered Stage 1 product, generic renderer framework or extra repair modes.
- Reuse held-root operations for opening, exclusive temporary creation, rename and sync. Temporary collisions retry only AlreadyExists and preserve old entries. Final artifacts remain the approved 0644; do not conflate them with private database files. Read-only construction must leave absent roots absent. Keep typed containment errors distinct from ordinary input/output failures.
- Use compiling behavioral RED, exact compiled mutations and byte-identical passing restored controls. Preserve every baseline leaf. Keep new tests under one second, all fixtures owned/synthetic, no live files, install, push, pull request, merge, apply, third-party edits or destructive cleanup. Use clean-code-rust and normal local commit hooks, verify editor safety and apply_patch. Stage new files for the size audit and run final-source gates/release. Controller owns the fresh committed-HEAD ship.

## Digest contract check

Tracked with Task 13's duration boundary in Todoist `6hc85XHXH5QRq5mg`; close only after both owning tasks pass independent review.

The approved sample describes `digest_open` as hashing an open file from its start, but its read loop begins at the caller's existing cursor. Its current sample test exercises only a freshly opened file. This is a source-level sample mismatch, not a reproduced runtime defect. Add one owned-file regression with a nonzero initial cursor and assert the whole-file known digest. Meet the stated from-start behavior with the existing standard library, preserving bounded reads and ordinary error propagation. Mutation-test omission of the actual start-position operation. No new digest API or dependency is needed.

The controller also read Task 17's consumers: archive finishing and digest currently pass newly opened descriptors. That does not change the public helper's stated from-start behavior, and no archive implementation is authorized in this task.

## Readiness audit

- The sample chooses a held root by its stored pathname without revalidating its identity for digest,
  publication and directory sync. Current `RootDir::revalidate` already detects replacement. Pin those
  three refusal paths with an owned fixture that renames `temp/store` aside and installs a replacement;
  both directories must remain unchanged. Put the common check at the owner boundary.
- Keep every negative test and mutant inside one owned temporary parent. The sample's outside-root
  pathname points at the temporary directory's parent; use sibling `temp/outside.md` instead.
- Pin a directory-sync failure on both already-intended and republish repair paths, and a journal-clear
  failure after successful sync. Assert the exact completed side effects and pending row in each case.
- Pin an abandoned temporary file after publication failure, then retry with the same store and prove
  that the abandoned entry is preserved and a new sequence is used. An owned directory at the target
  can force the initial rename failure without a new fault framework.
- Preserve both approved sync boundaries: `publish` syncs its completed rename, and repair confirms
  directory sync before clearing the journal row. Spec section 4.1 requires link components to be
  refused when published. Direct `publish` therefore rejects a symlink target before creating a
  temporary file; pin the link and referent remaining unchanged. An owned directory target still
  exercises ordinary rename failure and abandoned-temporary preservation. Keep these checks narrow.

Root grants the whole test-first implementation package, focused checks, mutations and static gates.
Coordinate native verification with the other lanes; source work and reviews proceed independently.
Root owns independent review and final integrated-tree gates, avoiding duplicate full-suite runs.
