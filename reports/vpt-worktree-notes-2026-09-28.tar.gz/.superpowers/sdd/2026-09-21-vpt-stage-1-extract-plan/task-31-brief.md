### Task 31: The retention decision and the intents journal

Retention needs two things before it can run: the pure expiry rule and a journal of intents that survives
a crash between the intent and the helper's answer. The journal is a port with the SQLite and in-memory
ledgers behind it, under one contract, like the two before it.

**Files:**

- Modify: `crates/vpt-domain/src/retention.rs`
- Create: `crates/vpt-application/src/ports/retention.rs`
- Modify: `crates/vpt-application/src/ports/mod.rs`
- Create: `crates/vpt-adapters/src/ledger/sqlite/retention.rs`
- Create: `crates/vpt-adapters/src/ledger/contract/retention.rs`
- Modify: `crates/vpt-adapters/src/ledger/sqlite/mod.rs`, `crates/vpt-adapters/src/ledger/memory.rs`,
  `crates/vpt-adapters/src/ledger/contract.rs`
- Modify: `crates/vpt/src/compose/ledger.rs`
- Test: the contract invocations in both ledgers' test modules gain the new suite

**Interfaces:**

- Consumes: `Hold`, `FileTime`, `UtcInstant`, `LedgerError`, the `retention_intents` table of Task 11.
- Produces:
  - `vpt_domain::retention::expired(mtime: FileTime, hold: Hold, now: UtcInstant) -> bool`.
  - `vpt_application::ports::{ArtifactKind::Audio,`
    `NewIntent { pub kind: ArtifactKind, pub recording: RecordingId, pub path: PathBuf,`
    `pub expected: Sha256Digest, pub recorded_at: UtcInstant },`
    `RetentionIntent { pub id: i64, pub kind: ArtifactKind, pub recording: RecordingId,`
    `pub path: PathBuf, pub expected: Sha256Digest, pub recorded_at: UtcInstant }, RetentionJournal}`
    with `fn record_intent(&self, intent: &NewIntent) -> Result<i64, LedgerError>`,
    `fn pending_intents(&self) -> Result<Vec<RetentionIntent>, LedgerError>`,
    `fn complete_intent(&self, id: i64, at: UtcInstant) -> Result<(), LedgerError>`.
  - `retention_journal_contract!` and the two implementations.

The `expected` column is text so a later stage can record a note's identity and stage there; stage 1
records the digest hex, the only ownership proof an audio clone has.

- [ ] **Step 1: Write the failing tests**

The existing `retention` domain module already compiles. Register `mod retention;` in the application
ports module and `pub use retention::{ArtifactKind, NewIntent, RetentionIntent, RetentionJournal};` in
Step 1, with the new file containing only the tests until Step 3. Register `mod retention;` in the SQLite
module before the red run. Keep `contract` and both ledgers' test modules private.

`crates/vpt-domain/src/retention.rs`, test section:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    const NOW: UtcInstant = UtcInstant { secs: 1_000_000 };

    #[test]
    fn a_hold_of_never_expires_nothing() {
        assert!(!expired(FileTime { secs: 0, nanos: 0 }, Hold::never(), NOW));
    }

    #[test]
    fn a_file_expires_at_the_hold_boundary_and_not_one_second_before() {
        let hold = Hold::of_seconds(86_400);
        assert!(!expired(FileTime { secs: NOW.secs - 86_399, nanos: 0 }, hold, NOW));
        assert!(expired(FileTime { secs: NOW.secs - 86_400, nanos: 0 }, hold, NOW));
        assert!(expired(FileTime { secs: 0, nanos: 0 }, hold, NOW));
    }

    #[test]
    fn a_file_from_the_future_never_expires() {
        assert!(!expired(FileTime { secs: NOW.secs + 10, nanos: 0 }, Hold::of_seconds(1), NOW));
    }

    #[test]
    fn a_large_hold_does_not_wrap_and_nanoseconds_delay_the_boundary() {
        assert!(!expired(FileTime { secs: 0, nanos: 0 }, Hold::of_seconds(u64::MAX), NOW));
        let hold = Hold::of_seconds(1);
        assert!(!expired(FileTime { secs: NOW.secs - 1, nanos: 1 }, hold, NOW));
        assert!(expired(FileTime { secs: NOW.secs - 1, nanos: 0 }, hold, NOW));
        assert!(!expired(FileTime { secs: i64::MIN, nanos: 0 }, Hold::of_seconds(u64::MAX), UtcInstant { secs: i64::MAX - 1 }));
    }
}
```

`crates/vpt-adapters/src/ledger/contract.rs` registers its private child in Step 1:

```rust
mod retention;
pub(crate) use retention::{retention_journal_contract, retention_scenarios};
```

`crates/vpt-adapters/src/ledger/contract/retention.rs`:

```rust
pub(crate) mod retention_scenarios {
    use super::super::digest;
    use std::path::PathBuf;
    use vpt_application::ports::{ArtifactKind, NewIntent, RetentionJournal};
    use vpt_domain::identity::RecordingId;
    use vpt_domain::time::UtcInstant;

    fn intent(seed: u8) -> NewIntent {
        NewIntent {
            kind: ArtifactKind::Audio,
            recording: RecordingId::parse("2026-08-24T144736-4f3ab19c02de").expect("id"),
            path: PathBuf::from(format!("/store/{seed}.m4a")),
            expected: digest(seed),
            recorded_at: UtcInstant { secs: 100 },
        }
    }

    pub fn a_recorded_intent_is_pending_with_its_fields<J: RetentionJournal>(journal: &J) {
        let id = journal.record_intent(&intent(1)).expect("recorded");
        let pending = journal.pending_intents().expect("pending");
        assert_eq!(pending.len(), 1);
        assert_eq!(pending[0].id, id);
        assert_eq!(pending[0].path, PathBuf::from("/store/1.m4a"));
        assert_eq!(pending[0].expected, digest(1));
        assert_eq!(pending[0].kind, ArtifactKind::Audio);
    }

    pub fn completing_an_intent_removes_it_and_keeps_the_others_in_order<J: RetentionJournal>(journal: &J) {
        let first = journal.record_intent(&intent(1)).expect("first");
        let second = journal.record_intent(&intent(2)).expect("second");
        journal.complete_intent(first, UtcInstant { secs: 200 }).expect("completed");
        let pending = journal.pending_intents().expect("pending");
        assert_eq!(pending.iter().map(|i| i.id).collect::<Vec<_>>(), vec![second]);
    }
}

macro_rules! retention_journal_contract {
    ($make:expr) => {
        mod retention_journal_contract {
            use super::*;
            use crate::ledger::contract::retention_scenarios::*;

            #[test]
            fn a_recorded_intent_is_pending_with_its_fields_() {
                let (_guard, journal) = $make();
                a_recorded_intent_is_pending_with_its_fields(&journal);
            }
            #[test]
            fn completing_an_intent_removes_it_and_keeps_the_others_in_order_() {
                let (_guard, journal) = $make();
                completing_an_intent_removes_it_and_keeps_the_others_in_order(&journal);
            }
        }
    };
}
pub(crate) use retention_journal_contract;
```

and, in the `tests` modules of `sqlite/mod.rs` and `memory.rs`, beside the two earlier invocations:

```rust
    crate::ledger::contract::retention_journal_contract!(open_ledger);
```

```rust
    crate::ledger::contract::retention_journal_contract!(fresh);
```

- [ ] **Step 2: Run the tests to verify they fail**

Run independently, including the second command after the first expected failure:

Run: `cargo test -p vpt-domain retention`

Run: `cargo test -p vpt-adapters ledger`

Expected: compile errors naming `expired`, `NewIntent`, `RetentionJournal`. The new test modules must be
compiled and selected. Zero selected tests or a successful command does not satisfy this step.

- [ ] **Step 3: Write the minimal implementation**

Insert the imports and `expired` function before the existing test module in
`crates/vpt-domain/src/retention.rs`. Keep the test module last:

```rust
use crate::time::{FileTime, UtcInstant};

/// Expired when the hold is set and the file's age has reached it.
pub fn expired(mtime: FileTime, hold: Hold, now: UtcInstant) -> bool {
    let age = (i128::from(now.secs) - i128::from(mtime.secs)) * 1_000_000_000 - i128::from(mtime.nanos);
    let limit = i128::from(hold.seconds()) * 1_000_000_000;
    hold.seconds() != 0 && age >= limit
}
```

`crates/vpt-application/src/ports/retention.rs`:

```rust
//! The journal of retention intents: recorded before the helper is asked,
//! completed after it answers, reconciled after anything else.

use super::ledger::LedgerError;
use std::path::PathBuf;
use vpt_domain::digest::Sha256Digest;
use vpt_domain::identity::RecordingId;
use vpt_domain::time::UtcInstant;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ArtifactKind {
    Audio,
}

impl ArtifactKind {
    pub fn as_str(self) -> &'static str {
        match self {
            ArtifactKind::Audio => "audio",
        }
    }

    pub fn parse(text: &str) -> Option<ArtifactKind> {
        (text == "audio").then_some(ArtifactKind::Audio)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NewIntent {
    pub kind: ArtifactKind,
    pub recording: RecordingId,
    pub path: PathBuf,
    pub expected: Sha256Digest,
    pub recorded_at: UtcInstant,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RetentionIntent {
    pub id: i64,
    pub kind: ArtifactKind,
    pub recording: RecordingId,
    pub path: PathBuf,
    pub expected: Sha256Digest,
    pub recorded_at: UtcInstant,
}

pub trait RetentionJournal {
    fn record_intent(&self, intent: &NewIntent) -> Result<i64, LedgerError>;
    fn pending_intents(&self) -> Result<Vec<RetentionIntent>, LedgerError>;
    fn complete_intent(&self, id: i64, at: UtcInstant) -> Result<(), LedgerError>;
}
```

Keep the private module and curated exports registered in Step 1.
`crates/vpt-adapters/src/ledger/sqlite/retention.rs`:

```rust
//! `retention_intents` behind the journal port.

use super::{SqliteLedger, map};
use rusqlite::params;
use std::path::PathBuf;
use vpt_application::ports::{ArtifactKind, LedgerError, NewIntent, RetentionIntent, RetentionJournal};
use vpt_domain::digest::Sha256Digest;
use vpt_domain::identity::RecordingId;
use vpt_domain::time::UtcInstant;

impl RetentionJournal for SqliteLedger {
    fn record_intent(&self, intent: &NewIntent) -> Result<i64, LedgerError> {
        self.transaction(|tx| {
            tx.execute(
                "INSERT INTO retention_intents (artifact_kind, recording, path, expected, recorded_at) VALUES (?1, ?2, ?3, ?4, ?5)",
                params![intent.kind.as_str(), intent.recording.as_str(), intent.path.to_string_lossy(), intent.expected.hex(), intent.recorded_at.secs],
            )
            .map_err(map)?;
            Ok(tx.last_insert_rowid())
        })
    }

    fn pending_intents(&self) -> Result<Vec<RetentionIntent>, LedgerError> {
        self.read(|connection| {
            let mut statement = connection
                .prepare("SELECT id, artifact_kind, recording, path, expected, recorded_at FROM retention_intents WHERE completed_at IS NULL ORDER BY id")
                .map_err(map)?;
            let rows = statement
                .query_map([], |row| {
                    Ok((row.get::<_, i64>(0)?, row.get::<_, String>(1)?, row.get::<_, String>(2)?, row.get::<_, String>(3)?, row.get::<_, String>(4)?, row.get::<_, i64>(5)?))
                })
                .map_err(map)?;
            let mut intents = Vec::new();
            for row in rows {
                let (id, kind, recording, path, expected, recorded_at) = row.map_err(map)?;
                intents.push(RetentionIntent {
                    id,
                    kind: ArtifactKind::parse(&kind).ok_or_else(|| LedgerError::Corrupt(format!("artifact kind {kind}")))?,
                    recording: RecordingId::parse(&recording).map_err(|_| LedgerError::Corrupt(format!("recording {recording}")))?,
                    path: PathBuf::from(path),
                    expected: Sha256Digest::from_hex(&expected).ok_or_else(|| LedgerError::Corrupt(format!("digest {expected}")))?,
                    recorded_at: UtcInstant { secs: recorded_at },
                });
            }
            Ok(intents)
        })
    }

    fn complete_intent(&self, id: i64, at: UtcInstant) -> Result<(), LedgerError> {
        self.transaction(|tx| {
            tx.execute("UPDATE retention_intents SET completed_at = ?2 WHERE id = ?1", params![id, at.secs]).map_err(map)?;
            Ok(())
        })
    }
}
```

`sqlite/mod.rs` adds `mod retention;`. Append to `crates/vpt-adapters/src/ledger/memory.rs`, with
`NewIntent`, `RetentionIntent` and `RetentionJournal` added to its imports:

```rust
impl RetentionJournal for MemoryLedger {
    fn record_intent(&self, intent: &NewIntent) -> Result<i64, LedgerError> {
        self.with(|state| {
            let id = state.intents.len() as i64 + 1;
            state.intents.push((
                RetentionIntent {
                    id,
                    kind: intent.kind,
                    recording: intent.recording.clone(),
                    path: intent.path.clone(),
                    expected: intent.expected,
                    recorded_at: intent.recorded_at,
                },
                None,
            ));
            Ok(id)
        })
    }

    fn pending_intents(&self) -> Result<Vec<RetentionIntent>, LedgerError> {
        self.with(|state| Ok(state.intents.iter().filter(|(_, done)| done.is_none()).map(|(intent, _)| intent.clone()).collect()))
    }

    fn complete_intent(&self, id: i64, at: UtcInstant) -> Result<(), LedgerError> {
        self.with(|state| {
            if let Some((_, done)) = state.intents.iter_mut().find(|(intent, _)| intent.id == id) {
                *done = Some(at);
            }
            Ok(())
        })
    }
}
```

`State` gains `intents: Vec<(RetentionIntent, Option<UtcInstant>)>`. Measure the final file with
`just file-size`; the three implementation blocks do not establish its formatted line count.

Append to `crates/vpt/src/compose/ledger.rs`:

```rust
use vpt_application::ports::{NewIntent, RetentionIntent, RetentionJournal};

impl RetentionJournal for RuntimeLedger {
    fn record_intent(&self, intent: &NewIntent) -> Result<i64, LedgerError> {
        match self {
            Self::Sqlite(ledger) => ledger.record_intent(intent),
            Self::Empty(ledger) => ledger.record_intent(intent),
        }
    }

    fn pending_intents(&self) -> Result<Vec<RetentionIntent>, LedgerError> {
        match self {
            Self::Sqlite(ledger) => ledger.pending_intents(),
            Self::Empty(ledger) => ledger.pending_intents(),
        }
    }

    fn complete_intent(&self, id: i64, at: UtcInstant) -> Result<(), LedgerError> {
        match self {
            Self::Sqlite(ledger) => ledger.complete_intent(id, at),
            Self::Empty(ledger) => ledger.complete_intent(id, at),
        }
    }
}
```

The existing imports in that file supply `LedgerError` and `UtcInstant`.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `cargo fmt --all`

Run: `cargo test --workspace --features dev-tools`

Expected: all PASS, four new contract tests among them.

- [ ] **Step 5: Commit**

Run: `cargo fmt --all`

```bash
git add crates
SKIP_AI_COMMIT=1 git commit -m "feat(retention): the expiry rule and the intents journal under one contract"
```

______________________________________________________________________

